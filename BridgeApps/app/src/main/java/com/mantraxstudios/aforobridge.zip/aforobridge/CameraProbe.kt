package com.mantraxstudios.aforobridge

import android.content.Context
import android.graphics.SurfaceTexture
import android.view.Surface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IVLCVout

object CameraProbe {

    private val COMMON_CHANNELS = listOf(
        "stream1", "stream2", "h264Preview_01_main", "Streaming/Channels/101",
        "cam/realmonitor?channel=1&subtype=0", "live", "live/ch0", "11", "video1", "1"
    )

    data class Result(val ok: Boolean, val channel: String?, val message: String)

    suspend fun autoDetect(context: Context, s: Settings, preferred: String?): Result {
        if (s.camIp.isBlank()) return Result(false, null, "Primero elige la IP de la cámara.")
        val list = LinkedHashSet<String>()
        if (!preferred.isNullOrBlank()) list.add(preferred)
        list.addAll(COMMON_CHANNELS)
        for (ch in list) {
            val (ok, authError) = testUrl(context, s.rtspUrl(ch))
            if (ok) return Result(true, ch, "✓ ¡Cámara conectada correctamente!")
            if (authError) return Result(false, null, "Usuario o contraseña de la cámara incorrectos.")
        }
        return Result(false, null, "No pude conectar. Revisa la IP, el usuario y la contraseña.")
    }

    private suspend fun testUrl(context: Context, url: String): Pair<Boolean, Boolean> =
        withContext(Dispatchers.Main) {
            var vlc: LibVLC? = null
            var player: MediaPlayer? = null
            var st: SurfaceTexture? = null
            var sf: Surface? = null
            try {
                vlc = LibVLC(context, arrayListOf("--rtsp-tcp", "--no-audio", "--network-caching=300"))
                player = MediaPlayer(vlc)

                st = SurfaceTexture(false).also { it.setDefaultBufferSize(64, 48) }
                sf = Surface(st)
                val vout = player.vlcVout
                vout.setVideoSurface(sf, null)
                // IVLCVout.Callback solo tiene onSurfacesCreated y onSurfacesDestroyed
                vout.addCallback(object : IVLCVout.Callback {
                    override fun onSurfacesCreated(v: IVLCVout) {}
                    override fun onSurfacesDestroyed(v: IVLCVout) {}
                })
                vout.attachViews()

                var result: Pair<Boolean, Boolean>? = null
                player.setEventListener { event ->
                    when (event.type) {
                        MediaPlayer.Event.Playing          -> result = true to false
                        MediaPlayer.Event.EncounteredError -> result = false to false
                        MediaPlayer.Event.EndReached       -> result = false to false
                    }
                }

                val media = Media(vlc, android.net.Uri.parse(url))
                media.addOption(":rtsp-tcp")
                media.addOption(":no-audio")
                player.media = media
                media.release()
                player.play()

                withTimeout(12_000) {
                    while (result == null) delay(100)
                    result!!
                }
            } catch (_: TimeoutCancellationException) {
                false to false
            } catch (_: Exception) {
                false to false
            } finally {
                runCatching { player?.setEventListener(null) }
                runCatching { player?.vlcVout?.detachViews() }
                runCatching { player?.stop(); player?.release() }
                runCatching { vlc?.release() }
                runCatching { sf?.release() }
                runCatching { st?.release() }
            }
        }
}
