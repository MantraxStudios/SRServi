package com.mantraxstudios.aforobridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.view.Surface
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IVLCVout
import java.time.LocalDate

/**
 * Servicio usando LibVLC para RTSP.
 */
class CountingService : Service() {

    companion object {
        const val CHANNEL_ID = "aforo_counter"
        const val NOTIF_ID = 1001

        val isRunning  = MutableStateFlow(false)
        val status     = MutableStateFlow("Detenido")
        val countIn    = MutableStateFlow(0)
        val countOut   = MutableStateFlow(0)

        fun start(ctx: Context) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, CountingService::class.java))
        fun stop(ctx: Context) =
            ctx.stopService(Intent(ctx, CountingService::class.java))
    }

    private lateinit var settings: Settings
    private lateinit var api: Api
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var libvlc: LibVLC? = null
    private var mediaPlayer: MediaPlayer? = null
    private var surfaceTexture: SurfaceTexture? = null
    private var surface: Surface? = null

    private var detector: MotionDetector? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var retryRunnable: Runnable? = null
    private var destroyed = false
    private var started = false

    private var lastFrameMs = 0L
    private val FRAME_INTERVAL_MS = 100L   // procesar ~10 fps para el detector

    private val snapChannel = Channel<ByteArray>(Channel.CONFLATED)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            settings = Settings(this)
            api = Api(settings.serverUrl)
            createChannel()
        } catch (e: Throwable) {
            status.value = "Error al crear servicio: ${e.message}"
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startForegroundSafely(buildNotif("Iniciando…"))
            if (!started) { started = true; setup() }
        } catch (e: Throwable) {
            status.value = "Error al iniciar: ${e.message}"
            runCatching { stopSelf() }
        }
        return START_STICKY
    }

    private fun setup() {
        runCatching { acquireWakeLock() }
        isRunning.value = true
        status.value = "Conectando…"

        scope.launch {
            try {
                api.setBaseUrl(settings.serverUrl)
                api.login(settings.email, settings.password)
            } catch (e: Exception) {
                status.value = "Error de sesión: ${e.message}"
            }

            val today = LocalDate.now().toString()
            val savedIn: Int; val savedOut: Int
            if (settings.countDate == today) {
                savedIn = settings.countIn; savedOut = settings.countOut
            } else {
                savedIn = 0; savedOut = 0
                settings.countDate = today
                settings.countIn = 0; settings.countOut = 0
            }
            countIn.value = savedIn; countOut.value = savedOut

            val line = runCatching { api.getLineConfig(settings.storeId) }.getOrNull()
            detector = MotionDetector(
                sensitivity = settings.sensitivity,
                x1 = line?.x1 ?: 0.15, y1 = line?.y1 ?: 0.5,
                x2 = line?.x2 ?: 0.85, y2 = line?.y2 ?: 0.5,
                flip = line?.flip ?: false,
                initialIn = savedIn, initialOut = savedOut,
                onCountChanged = { cIn, cOut ->
                    settings.countIn = cIn; settings.countOut = cOut
                }
            ) { dir ->
                countIn.value = detector?.countIn ?: 0
                countOut.value = detector?.countOut ?: 0
                scope.launch { api.postEvent(settings.storeId, dir) }
                mainHandler.post { updateNotif() }
            }

            scope.launch {
                api.saveRtspInfo(settings.storeId, settings.rtspUrl(), settings.sensitivity)
            }

            try { startCapture() } catch (e: Exception) {
                status.value = "Error de cámara: ${e.message}"
                updateNotif(); scheduleRetry()
            }

            scope.launch(Dispatchers.IO) {
                for (jpeg in snapChannel) {
                    runCatching { api.uploadSnapshot(settings.storeId, jpeg) }
                }
            }

            scope.launch {
                while (isActive) {
                    delay(60_000)
                    runCatching { api.getLineConfig(settings.storeId) }.getOrNull()
                        ?.let { detector?.updateLine(it) }
                }
            }
        }
    }

    private fun startCapture() {
        releaseCapture()

        // SurfaceTexture offscreen — VLC necesita un Surface para decodificar
        // aunque no lo mostremos en pantalla. Usamos tamaño pequeño para ahorrar memoria.
        val st = SurfaceTexture(false).also { it.setDefaultBufferSize(320, 240) }
        surfaceTexture = st
        val sf = Surface(st)
        surface = sf

        val vlcOptions = arrayListOf(
            "--rtsp-tcp",
            "--network-caching=300",
            "--no-audio",
            "--no-sub-autodetect-file",
            "--drop-late-frames",
            "--skip-frames",
            "--no-snapshot-preview"
        )
        val vlc = LibVLC(this, vlcOptions)
        libvlc = vlc

        val player = MediaPlayer(vlc)
        mediaPlayer = player

        // Conectar el Surface al output de VLC
        val vout = player.vlcVout
        vout.setVideoSurface(sf, null)
        vout.addCallback(object : IVLCVout.Callback {
            override fun onSurfacesCreated(vlcVout: IVLCVout) {}
            override fun onSurfacesDestroyed(vlcVout: IVLCVout) {}
        })
        vout.attachViews()

        player.setEventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Playing -> {
                    status.value = "Contando"
                    mainHandler.post { updateNotif() }
                    // Iniciar el bucle de captura de frames
                    mainHandler.post { scheduleFrameCapture() }
                }
                MediaPlayer.Event.EncounteredError -> {
                    if (!destroyed) {
                        status.value = "Reconectando…"
                        mainHandler.post { updateNotif(); scheduleRetry() }
                    }
                }
                MediaPlayer.Event.EndReached -> {
                    if (!destroyed) mainHandler.post { scheduleRetry() }
                }
            }
        }

        val media = Media(vlc, android.net.Uri.parse(settings.rtspUrl()))
        media.addOption(":rtsp-tcp")
        media.addOption(":no-audio")
        media.addOption(":network-caching=300")
        player.media = media
        media.release()
        player.play()
    }

    /**
     * Captura un frame via MediaPlayer.getThumbnail() y lo procesa.
     * getThumbnail() devuelve un Bitmap del frame actual — es la API pública
     * correcta de libvlc-android para capturar frames sin Surface visible.
     */
    private fun scheduleFrameCapture() {
        if (destroyed) return
        val player = mediaPlayer ?: return

        val now = System.currentTimeMillis()
        if (now - lastFrameMs >= FRAME_INTERVAL_MS) {
            lastFrameMs = now
            scope.launch(Dispatchers.IO) {
                try {
                    // getThumbnail() captura el frame actual del decoder
                    val bmp: Bitmap? = player.getThumbnail()
                    if (bmp != null && !bmp.isRecycled) {
                        val luma = YuvUtils.luminanceFromBitmap(bmp, 320, 240)
                        detector?.process(luma)

                        val jpeg = YuvUtils.jpegFromBitmap(bmp)
                        bmp.recycle()
                        if (jpeg.isNotEmpty()) snapChannel.trySend(jpeg)
                    }
                } catch (_: Throwable) {}
            }
        }

        // Reprogramar para el siguiente frame
        if (!destroyed && mediaPlayer?.isPlaying == true) {
            mainHandler.postDelayed({ scheduleFrameCapture() }, FRAME_INTERVAL_MS)
        }
    }

    private fun scheduleRetry(delayMs: Long = 5_000) {
        if (destroyed) return
        val r = Runnable {
            if (!destroyed) {
                try { startCapture() } catch (_: Exception) {
                    status.value = "Error al reconectar"
                    updateNotif(); scheduleRetry()
                }
            }
        }
        retryRunnable = r
        mainHandler.postDelayed(r, delayMs)
    }

    private fun releaseCapture() {
        retryRunnable?.let { mainHandler.removeCallbacks(it) }
        retryRunnable = null
        runCatching {
            mediaPlayer?.let { p ->
                p.setEventListener(null)
                p.vlcVout.detachViews()
                p.stop()
                p.release()
            }
        }
        mediaPlayer = null
        runCatching { libvlc?.release() }
        libvlc = null
        runCatching { surface?.release() }
        surface = null
        runCatching { surfaceTexture?.release() }
        surfaceTexture = null
    }

    // ── Notificación ─────────────────────────────────────────────────────────
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Contador de aforo",
                NotificationManager.IMPORTANCE_LOW)
            ch.description = "Mantiene el conteo activo en segundo plano"
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotif(text: String): Notification {
        val open = android.app.PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AforoBridge")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    private fun updateNotif() {
        val text = "${status.value} · Entradas ${countIn.value} · Salidas ${countOut.value}"
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotif(text))
    }

    private fun startForegroundSafely(notif: Notification) {
        try {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> {
                    val serviceType =
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                        else
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    ServiceCompat.startForeground(this, NOTIF_ID, notif, serviceType)
                }
                else -> startForeground(NOTIF_ID, notif)
            }
        } catch (_: Throwable) {
            try { startForeground(NOTIF_ID, notif) } catch (_: Throwable) { stopSelf() }
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AforoBridge::counting")
            .apply { setReferenceCounted(false); acquire(12 * 60 * 60 * 1000L) }
    }

    override fun onDestroy() {
        super.onDestroy()
        destroyed = true
        detector?.let {
            settings.countIn = it.countIn; settings.countOut = it.countOut
            settings.countDate = LocalDate.now().toString()
        }
        isRunning.value = false; status.value = "Detenido"
        releaseCapture()
        runCatching { wakeLock?.release() }
        scope.cancel()
    }
}
