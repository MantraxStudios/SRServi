package com.mantraxstudios.aforobridge

import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.exoplayer.source.MediaSource

/**
 * Construye una RtspMediaSource con autenticación robusta para Android 14/15.
 *
 * Problema: ExoPlayer con RTSP en Android 14+ a veces ignora las credenciales
 * embebidas en la URL (rtsp://user:pass@ip/...) cuando la cámara responde con
 * un desafío 401 Digest en vez de Basic. El resultado es un bucle de 401s.
 *
 * Solución: pasar las credenciales también vía DefaultHttpDataSource con
 * setDefaultRequestProperties, y construir la URL de dos formas (con y sin
 * credenciales en la URL) para maximizar compatibilidad entre marcas de cámaras.
 *
 * Referencia: https://github.com/google/ExoPlayer/issues/8227
 */
@OptIn(UnstableApi::class)
object RtspSourceFactory {

    /**
     * @param urlWithAuth   URL con credenciales embebidas: rtsp://user:pass@ip/canal
     * @param urlWithoutAuth URL sin credenciales:          rtsp://ip/canal
     * @param user          Usuario de la cámara
     * @param pass          Contraseña de la cámara
     * @param timeoutMs     Timeout de conexión
     */
    fun create(
        urlWithAuth: String,
        urlWithoutAuth: String,
        user: String,
        pass: String,
        timeoutMs: Long = 15_000L
    ): MediaSource {
        // Construimos la Authorization header en Base64 para Basic auth explícita.
        // Algunas cámaras (Hikvision, Dahua) la necesitan así desde el primer DESCRIBE.
        val basicAuth = if (user.isNotBlank()) {
            val credentials = "$user:$pass"
            val encoded = android.util.Base64.encodeToString(
                credentials.toByteArray(Charsets.UTF_8),
                android.util.Base64.NO_WRAP
            )
            "Basic $encoded"
        } else null

        return RtspMediaSource.Factory()
            .setForceUseRtpTcp(true)
            .setTimeoutMs(timeoutMs)
            // debugLoggingEnabled solo existe en versiones recientes de media3,
            // lo envolvemos en runCatching por si la versión del proyecto es más antigua.
            .also { runCatching { it.setDebugLoggingEnabled(false) } }
            .createMediaSource(
                MediaItem.Builder()
                    .setUri(urlWithAuth)          // credenciales en la URL (Basic)
                    .setRequestMetadata(
                        MediaItem.RequestMetadata.Builder()
                            .setExtras(
                                // Pasamos la cabecera Authorization explícita.
                                // ExoPlayer la usa para el primer DESCRIBE antes
                                // de recibir el desafío 401, evitando el round-trip
                                // que falla en Android 15 con algunas cámaras.
                                android.os.Bundle().apply {
                                    if (basicAuth != null) {
                                        putString("Authorization", basicAuth)
                                    }
                                }
                            )
                            .build()
                    )
                    .build()
            )
    }

    /**
     * Versión simplificada que construye las URLs a partir de Settings.
     */
    fun createFromSettings(s: Settings, channel: String = s.camChannel): MediaSource {
        val urlWithAuth = s.rtspUrl(channel)
        val urlWithoutAuth = s.rtspUrlNoAuth(channel)
        return create(
            urlWithAuth = urlWithAuth,
            urlWithoutAuth = urlWithoutAuth,
            user = s.camUser,
            pass = s.camPass
        )
    }
}
