import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Register from './pages/Register';
import WorkerLogin from './pages/WorkerLogin';
import WorkerPanel from './pages/WorkerPanel';
import Dashboard from './pages/admin/Dashboard';
import Stores from './pages/admin/Stores';
import Categories from './pages/admin/Categories';
import Products from './pages/admin/Products';
import Ingredients from './pages/admin/Ingredients';
import Extras from './pages/admin/Extras';
import Orders from './pages/admin/Orders';
import Workers from './pages/admin/Workers';
import Settings from './pages/admin/Settings';
import MercadoPagoPoints from './pages/admin/MercadoPagoPoints';
import Coupons from './pages/admin/Coupons';
import Index from './pages/Index';
import Store from './pages/Store';

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="loading">Cargando...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return children;
}

function PublicRoute({ children }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="loading">Cargando...</div>;
  }

  if (user) {
    return <Navigate to="/admin" replace />;
  }

  return children;
}

function App() {
  return (
    <AuthProvider>
      <Router future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/store/:code" element={<Store />} />
          <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
          <Route path="/register" element={<PublicRoute><Register /></PublicRoute>} />
          <Route path="/admin" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
            <Route index element={<Dashboard />} />
            <Route path="stores" element={<Stores />} />
            <Route path="categories" element={<Categories />} />
            <Route path="products" element={<Products />} />
            <Route path="ingredients" element={<Ingredients />} />
            <Route path="extras" element={<Extras />} />
            <Route path="orders" element={<Orders />} />
            <Route path="workers" element={<Workers />} />
            <Route path="mercado-pago-points" element={<MercadoPagoPoints />} />
            <Route path="coupons" element={<Coupons />} />
            <Route path="settings" element={<Settings />} />
          </Route>
          <Route path="/worker-login" element={<WorkerLogin />} />
          <Route path="/worker-panel" element={<WorkerPanel />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
