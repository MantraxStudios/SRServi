import { useState, useEffect, createContext, useContext } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const API = 'https://srservi2.srautomatic.com';

import {
  faList,
  faBox,
  faFlask,
  faPlus,
  faShoppingBag,
  faSignOutAlt,
  faPalette,
  faStore,
  faChevronDown,
  faUsers,
  faCreditCard,
  faPercent,
  faCog,
  faBars,
  faTimes,
  faBarcode,
  faCrown,
  faChartLine,
  faLock,
  faPuzzlePiece,
  faGlobe,
  faTabletAlt,
  faTicketAlt,
  faBookOpen,
  faCashRegister
} from '@fortawesome/free-solid-svg-icons';

export const StoreContext = createContext();

export const useStore = () => useContext(StoreContext);

function Layout() {
  const { user, token, logout } = useAuth();
  const [isPremiumUser, setIsPremiumUser] = useState(false);
  const navigate = useNavigate();
  const [stores, setStores] = useState([]);
  const [selectedStore, setSelectedStore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [storeDropdownOpen, setStoreDropdownOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const [openDropdowns, setOpenDropdowns] = useState({});

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (token) {
      fetchStores();
      fetch(API + '/api/my-plan', { headers: { 'Authorization': 'Bearer ' + token } })
        .then(r => r.json())
        .then(data => {
          const planName = data?.plan?.plan_name || data?.plan?.name || '';
          setIsPremiumUser(!!planName && planName !== 'Gratis');
        })
        .catch(() => {});
    }
  }, [token]);

  const fetchStores = async () => {
    try {
      const response = await fetch(API + '/api/stores', {
        headers: { 'Authorization': 'Bearer ' + token }
      });
      const data = await response.json();

      if (Array.isArray(data) && data.length === 0) {
        const response2 = await fetch(API + '/api/stores', {
          method: 'POST',
          headers: {
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            name: user?.business_name || user?.username || 'Mi Tienda',
            primary_color: '#000000',
            secondary_color: '#FFFFFF',
            accent_color: '#D4AF37',
            header_color: '#000000',
            currency_code: 'USD',
            currency_symbol: '$',
            currency_name: 'Dólar Estadounidense'
          })
        });

        if (response2.ok) {
          const newStore = await response2.json();
          setStores([newStore]);
          setSelectedStore(newStore);
          localStorage.setItem('selectedStoreId', newStore.id.toString());
        }
      } else {
        setStores(data);

        if (data.length > 0 && !selectedStore) {
          const savedStoreId = localStorage.getItem('selectedStoreId');
          const savedStore = data.find(s => s.id === parseInt(savedStoreId));
          setSelectedStore(savedStore || data[0]);
          if (savedStore || data[0]) {
            localStorage.setItem('selectedStoreId', (savedStore || data[0]).id.toString());
          }
        }
      }
    } catch (error) {
      console.error('Error fetching stores:', error);
    } finally {
      setLoading(false);
    }
  };

  const selectStore = (store) => {
    setSelectedStore(store);
    localStorage.setItem('selectedStoreId', store.id.toString());
    setStoreDropdownOpen(false);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const toggleDropdown = (key) => {
    setOpenDropdowns(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const colors = selectedStore ? {
    primary: selectedStore.primary_color || '#000000',
    secondary: selectedStore.secondary_color || '#FFFFFF',
    accent: selectedStore.accent_color || '#D4AF37'
  } : {
    primary: '#000000',
    secondary: '#FFFFFF',
    accent: '#D4AF37'
  };

  if (loading) {
    return (
      <div className="loading-center" style={{
        '--store-primary': colors.primary,
        '--store-secondary': colors.secondary,
        '--store-accent': colors.accent
      }}>
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <StoreContext.Provider value={{ selectedStore, stores, selectStore, fetchStores, colors }}>
      <div className="layout-wrapper" style={{
        '--store-primary': colors.primary,
        '--store-secondary': colors.secondary,
        '--store-accent': colors.accent
      }}>
        {isMobile && menuOpen && (
          <div className="mobile-overlay" onClick={() => setMenuOpen(false)} />
        )}

        <nav className={`admin-sidebar ${isMobile ? (menuOpen ? 'mobile-open' : 'mobile-closed') : ''}`}>
          <div className="sidebar-header">
            <div className="sidebar-brand">
              <div className="sidebar-brand-logo">
                <FontAwesomeIcon icon={faStore} />
              </div>
              <div className="sidebar-brand-text">
                <h1>SRServi</h1>
                <small>Panel de Administración</small>
              </div>
            </div>
            {isMobile && (
              <button className="sidebar-close-btn" onClick={() => setMenuOpen(false)}>
                <FontAwesomeIcon icon={faTimes} />
              </button>
            )}
          </div>

          {user?.support_pin && (
            <div className="sidebar-pin-badge">
              <FontAwesomeIcon icon={faLock} />
              <span>PIN Soporte</span>
              <strong>{user.support_pin}</strong>
            </div>
          )}

          <div className="store-selector">
            <div className="relative">
              <button
                className="store-selector-btn"
                onClick={() => setStoreDropdownOpen(!storeDropdownOpen)}
              >
                <span className="store-selector-label">
                  <FontAwesomeIcon icon={faStore} />
                  <span className="store-selector-name">
                    {selectedStore?.name || 'Seleccionar Tienda'}
                  </span>
                </span>
                <FontAwesomeIcon icon={faChevronDown} rotation={storeDropdownOpen ? 180 : 0} />
              </button>

              {storeDropdownOpen && (
                <div className="store-dropdown">
                  {stores.map(store => (
                    <div
                      key={store.id}
                      className={`store-dropdown-item ${selectedStore?.id === store.id ? 'active' : ''}`}
                      onClick={() => selectStore(store)}
                    >
                      <div className="store-dropdown-dot" />
                      <div className="store-dropdown-info">
                        <div className="store-dropdown-name">{store.name}</div>
                        <div className="store-dropdown-code">Código: {store.code}</div>
                      </div>
                    </div>
                  ))}
                  <div
                    className="store-dropdown-manage"
                    onClick={() => { setStoreDropdownOpen(false); navigate('/admin/stores'); }}
                  >
                    <FontAwesomeIcon icon={faPlus} />
                    Gestionar Tiendas
                  </div>
                </div>
              )}
            </div>
          </div>

          <ul className="sidebar-nav" onClick={(e) => { if (!e.target.closest('.dropdown-item') && !e.target.closest('.dropdown-header') && !e.target.closest('.dropdown-container')) setMenuOpen(false); }}>
            <li className="sidebar-section-label">Principal</li>
            <li>
              <NavLink to="/admin/tutoriales" onClick={() => setMenuOpen(false)}>
                <FontAwesomeIcon icon={faBookOpen} />
                <span>Tutoriales</span>
              </NavLink>
            </li>
            {selectedStore && (
              <li>
                <a
                  href={`/store/${selectedStore.code}?admin_edit=${token}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setMenuOpen(false)}
                  style={{ textDecoration: 'none' }}
                >
                  <FontAwesomeIcon icon={faBox} />
                  <span>Editor Totem</span>
                </a>
              </li>
            )}
            <li>
              <NavLink to="/admin/mercado-pago-points" onClick={() => setMenuOpen(false)}>
                <FontAwesomeIcon icon={faCashRegister} />
                <span>Vincular POS</span>
              </NavLink>
            </li>

            <li className="sidebar-section-label">Más</li>
            <li className="dropdown-container">
              <button className={`dropdown-header${openDropdowns['todo'] ? ' open' : ''}`} onClick={() => toggleDropdown('todo')}>
                <FontAwesomeIcon icon={faCog} />
                <span>Administración</span>
                <FontAwesomeIcon icon={faChevronDown} className="dropdown-chevron" rotation={openDropdowns['todo'] ? 180 : 0} />
              </button>
              {openDropdowns['todo'] && (
                <div className="dropdown-content">
                  {/* Gestión */}
                  <NavLink to="/admin/orders" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faShoppingBag} />
                    <span>Pedidos</span>
                  </NavLink>
                  <NavLink to="/admin/analytics" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faChartLine} />
                    <span>Análisis</span>
                  </NavLink>
                  <NavLink to="/admin/workers" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faUsers} />
                    <span>Trabajadores</span>
                  </NavLink>
                  <NavLink to="/admin/coupons" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faPercent} />
                    <span>Cupones</span>
                  </NavLink>
                  <NavLink to="/admin/market" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faBarcode} />
                    <span>Market</span>
                  </NavLink>

                  {/* Sistema */}
                  <NavLink to="/admin/plans" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faCrown} />
                    <span>Planes</span>
                  </NavLink>
                  <NavLink to="/admin/settings" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faPalette} />
                    <span>Colores y QR</span>
                  </NavLink>
                  <NavLink to="/admin/worker-config" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faUsers} />
                    <span>Pago manual</span>
                  </NavLink>
                  <NavLink to="/admin/store-pin" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faLock} />
                    <span>PIN Tienda</span>
                  </NavLink>
                  <NavLink to="/admin/configurations" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faCreditCard} />
                    <span>Configuraciones de Pago</span>
                  </NavLink>
                  <NavLink to="/admin/devices" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faTabletAlt} />
                    <span>Dispositivos</span>
                  </NavLink>

                  {/* Componentes */}
                  <NavLink to="/admin/plugins" end className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faPuzzlePiece} />
                    <span>Plugins</span>
                  </NavLink>
                  <NavLink to="/admin/workshop" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faGlobe} />
                    <span>Workshop</span>
                  </NavLink>
                  {/* Soporte */}
                  <NavLink to="/admin/tickets" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    <FontAwesomeIcon icon={faTicketAlt} />
                    <span>Soporte</span>
                  </NavLink>
                </div>
              )}
            </li>
          </ul>

          <div className="sidebar-footer">
            <button onClick={handleLogout} className="sidebar-logout-btn">
              <FontAwesomeIcon icon={faSignOutAlt} />
              <span>Cerrar Sesión</span>
            </button>
          </div>
        </nav>
        <main className="admin-content">
          <div className="mobile-header">
            <button className="mobile-header-btn" onClick={() => setMenuOpen(true)}>
              <FontAwesomeIcon icon={faBars} />
            </button>
            <h1>SRServi</h1>
            {user?.support_pin && (
              <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '6px', background: '#f0f0f0', padding: '4px 10px', borderRadius: '8px', fontSize: '11px', color: '#666' }}>
                <FontAwesomeIcon icon={faLock} style={{ color: '#9b59b6' }} />
                <span>PIN: <strong style={{ letterSpacing: '2px', color: '#333' }}>{user.support_pin}</strong></span>
              </div>
            )}
          </div>
          <Outlet />
        </main>
      </div>
    </StoreContext.Provider>
  );
}

export default Layout;
