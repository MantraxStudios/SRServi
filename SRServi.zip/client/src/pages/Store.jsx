import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { detectLanguage, t, LANGUAGES } from '../i18n';
import {
  faShoppingCart,
  faPlus,
  faMinus,
  faTimes,
  faTimesCircle,
  faBox,
  faArrowLeft,
  faCopy,
  faCreditCard,
  faMoneyBillWave,
  faCheck,
  faTags,
  faInfinity,
  faUtensils,
  faChevronRight,
  faCheckCircle,
  faGripVertical,
  faLock,
  faEdit,
  faTrash,
  faFolder,
  faFolderPlus,
  faPalette,
  faCode,
  faFire,
  faGlobe,
  faClock,
  faQrcode,
  faDownload
} from '@fortawesome/free-solid-svg-icons';
import { io } from 'socket.io-client';
import { SOCKET_URL, getImageUrl } from '../config.js';
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  useSortable,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import PluginSlot from '../components/PluginSlot';
import { PluginProvider } from '../context/PluginContext';

const API = 'https://srservi2.srautomatic.com';

function SortableProductCard({ product, onEdit, onDelete, currencySymbol }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: product.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 1000 : 1,
    position: 'relative',
  };

  const isUnlimited = product.unlimited_stock === true || product.unlimited_stock === 1 || product.unlimited_stock === '1';
  const isOutOfStock = !isUnlimited && product.stock === 0;

  return (
    <div ref={setNodeRef} style={style}>
      <div className={`store-product-wrapper${isOutOfStock ? ' out-of-stock' : ''}`}>
        <div className="store-edit-drag-handle" {...attributes} {...listeners}>
          <FontAwesomeIcon icon={faGripVertical} />
        </div>
        <div className={`store-product-card${isOutOfStock ? ' out-of-stock' : ''}`}>
          {isOutOfStock && (
            <div className="out-of-stock-badge">Agotado</div>
          )}
          <div className="store-prod-edit-overlay">
            <button onClick={() => onEdit(product)} className="store-prod-edit-btn">
              <FontAwesomeIcon icon={faEdit} />
            </button>
            <button onClick={() => onDelete(product)} className="store-prod-edit-btn danger">
              <FontAwesomeIcon icon={faTrash} />
            </button>
          </div>
          <div className="store-product-image">
            {product.image ? (
              <img
                src={getImageUrl(product.image)}
                alt={product.name}
                className={isOutOfStock ? 'grayscale' : ''}
              />
            ) : (
              <FontAwesomeIcon icon={faBox} className="placeholder-icon" />
            )}
          </div>
        </div>
        <div className="store-product-info">
          <div className={`store-product-details${isOutOfStock ? ' out-of-stock' : ''}`}>
            <span className="store-product-name">{product.name}:</span>
            <span className="store-product-price">{currencySymbol}{Number(product.price).toFixed(2)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function Store() {
  const { code } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const terminalFromUrl = searchParams.get('terminal');
  const configFromUrl = searchParams.get('config');
  const adminEditToken = searchParams.get('admin_edit');
  const deliveryMode = searchParams.get('delivery') === 'true';
  const qrReturnResult = searchParams.get('x_result');
  const qrReturnRef = searchParams.get('x_reference');
  const [qrPaymentResult, setQrPaymentResult] = useState(null);
  const [store, setStore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [orderType, setOrderType] = useState('serve');
  const [productConfig, setProductConfig] = useState({
    selectedIngredients: [],
    selectedExtras: [],
    quantity: 1
  });
  const [ingredientsModalOpen, setIngredientsModalOpen] = useState(false);
  const [extrasModalOpen, setExtrasModalOpen] = useState(false);
  const [productModalStep, setProductModalStep] = useState('main');
  const [addingToCart, setAddingToCart] = useState(false);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [lastOrderNumber, setLastOrderNumber] = useState(null);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [paymentError, setPaymentError] = useState(null);
  const [availableTerminals, setAvailableTerminals] = useState([]);
  const [selectedTerminalId, setSelectedTerminalId] = useState(
    localStorage.getItem('srservi_last_terminal_id') || ''
  );
  const [couponCodeInput, setCouponCodeInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const [couponLoading, setCouponLoading] = useState(false);
  const [pendingOrderData, setPendingOrderData] = useState(null);
  const [activeCategory, setActiveCategory] = useState('all');
  const [configurations, setConfigurations] = useState([]);
  const [selectedConfiguration, setSelectedConfiguration] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [editDragActiveId, setEditDragActiveId] = useState(null);
  const [sessionPin, setSessionPin] = useState(null);
  const [catModalOpen, setCatModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState(null);
  const [catName, setCatName] = useState('');
  const [pluginPaymentProvider, setPluginPaymentProvider] = useState(null);
  const [qrProvider, setQrProvider] = useState(null);
  const [qrPaymentUrl, setQrPaymentUrl] = useState(null);
  const [pluginPaymentKey, setPluginPaymentKey] = useState(null);
  const [deviceUid] = useState(() => {
    let uid = localStorage.getItem('srservi_device_uid');
    if (!uid) {
      uid = 'dev_' + crypto.randomUUID();
      localStorage.setItem('srservi_device_uid', uid);
    }
    return uid;
  });
  const [adminToken, setAdminToken] = useState(null);
  const [editorTab, setEditorTab] = useState('products');
  const [extras, setExtras] = useState([]);
  const [ingredients, setIngredients] = useState([]);
  const [complementModal, setComplementModal] = useState(null);
  const [showRestartConfirm, setShowRestartConfirm] = useState(false);
  const [restartingSending, setRestartingSending] = useState(false);
  const [complementForm, setComplementForm] = useState({ name: '', price: '', type: 'extra', category_id: '', stock: '', unlimited_stock: true, imageFile: null });
  const [prodModalOpen, setProdModalOpen] = useState(false);
  const [editingProd, setEditingProd] = useState(null);
  const [prodForm, setProdForm] = useState({ name: '', price: '', category_id: '', description: '', barcode: '', stock: '0', unlimited_stock: true, has_extras: false, has_ingredients: false, max_extras: '', max_ingredients: '' });
  const [prodImageFile, setProdImageFile] = useState(null);
  const [prodSaving, setProdSaving] = useState(false);
  const [prodNewExtras, setProdNewExtras] = useState([]);
  const [prodNewComplements, setProdNewComplements] = useState([]);
  const [showComplementsModal, setShowComplementsModal] = useState(false);
  const [selectedIngredientIds, setSelectedIngredientIds] = useState([]);
  const [selectedExtraIds, setSelectedExtraIds] = useState([]);
  const [complementsTab, setComplementsTab] = useState('complements');
  const [editingComplement, setEditingComplement] = useState(null);
  const [styleEditorOpen, setStyleEditorOpen] = useState(false);
  const [styleTab, setStyleTab] = useState('visual');
  const [visualSettings, setVisualSettings] = useState({
    fontFamily: '', fontSize: '', titleSize: '', priceSize: '',
    fontWeight: '', textShadow: '', cardShadow: '', cardRadius: '',
    productNameColor: '', productPriceColor: '', cardBg: '', cardBorder: '',
    headerBg: '', headerTextColor: '', categoryBg: '', categoryActiveColor: '',
    cartBg: '', cartTextColor: ''
  });
  const [customCss, setCustomCss] = useState('');
  const [styleSaving, setStyleSaving] = useState(false);
  const [topSellingIds, setTopSellingIds] = useState([]);
  const [lang, setLang] = useState(detectLanguage);
  const [showLangPicker, setShowLangPicker] = useState(false);
  const [welcomeModalOpen, setWelcomeModalOpen] = useState(false);
  const [welcomeClosing, setWelcomeClosing] = useState(false);
  const [welcomeSelectedLang, setWelcomeSelectedLang] = useState(null);
  const [inactivityModalOpen, setInactivityModalOpen] = useState(false);
  const [inactivityCountdown, setInactivityCountdown] = useState(10);
  const inactivityTimerRef = useRef(null);
  const inactivityCountdownRef = useRef(null);
  const longPressTimerRef = useRef(null);
  const categoryRef = useRef(null);
  const storeIdRef = useRef(null);
  const socketRef = useRef(null);
  const pendingOrderDataRef = useRef(null);

  useEffect(() => {
    setActiveCategory('all');
    storeIdRef.current = store?.store?.id || null;
  }, [store?.store?.id]);

  useEffect(() => {
    pendingOrderDataRef.current = pendingOrderData;
  }, [pendingOrderData]);

  useEffect(() => {
    if (!qrReturnRef) return;
    const allParams = {};
    searchParams.forEach((v, k) => { allParams[k] = v; });
    fetch('/api/plugins/qr/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(allParams)
    }).then(r => r.json()).then(data => {
      setQrPaymentResult(data);
    }).catch(() => {
      setQrPaymentResult({ success: false, message: 'Error verificando pago' });
    });
  }, [qrReturnRef]);

  // Inactivity timer: only starts AFTER user interacts, then if idle → modal → reload
  useEffect(() => {
    if (editMode || deliveryMode) return;
    let userHasInteracted = false;
    const startInactivityTimer = () => {
      if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
      if (inactivityCountdownRef.current) clearInterval(inactivityCountdownRef.current);
      setInactivityModalOpen(false);
      setInactivityCountdown(10);
      const timeout = (store?.store?.inactivity_timeout || 120) * 1000;
      inactivityTimerRef.current = setTimeout(() => {
        setInactivityModalOpen(true);
        setInactivityCountdown(10);
        let count = 10;
        inactivityCountdownRef.current = setInterval(() => {
          count--;
          setInactivityCountdown(count);
          if (count <= 0) {
            clearInterval(inactivityCountdownRef.current);
            window.location.reload();
          }
        }, 1000);
      }, timeout);
    };
    const onUserActivity = () => {
      if (!userHasInteracted) {
        userHasInteracted = true;
      }
      if (userHasInteracted) {
        startInactivityTimer();
      }
    };
    const events = ['touchstart', 'mousedown', 'keydown', 'scroll'];
    events.forEach(e => document.addEventListener(e, onUserActivity, { passive: true }));
    // Don't start timer until user interacts
    return () => {
      events.forEach(e => document.removeEventListener(e, onUserActivity));
      if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
      if (inactivityCountdownRef.current) clearInterval(inactivityCountdownRef.current);
    };
  }, [editMode]);

  // Welcome/language modal disabled — just reset state after order completion
  const showWelcomeAfterOrder = () => {
    setCart([]);
    setCartOpen(false);
    setPaymentModalOpen(false);
    setCashPaymentSuccess(false);
  };

  useEffect(() => {
    if (selectedConfiguration?.is_minimarket && store?.store?.code) {
      navigate(`/market/${store.store.code}${configFromUrl ? `?config=${configFromUrl}` : ''}`);
    }
  }, [selectedConfiguration, store]);

  // If only one order type is allowed, auto-select it (don't ask the user)
  useEffect(() => {
    if (!selectedConfiguration) return;
    const serveOnly = selectedConfiguration.allow_serve && !selectedConfiguration.allow_takeout;
    const takeoutOnly = !selectedConfiguration.allow_serve && selectedConfiguration.allow_takeout;
    if (serveOnly && orderType !== 'serve') setOrderType('serve');
    else if (takeoutOnly && orderType !== 'takeout') setOrderType('takeout');
  }, [selectedConfiguration]);

  useEffect(() => {
    const container = categoryRef.current;
    if (!container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const cat = entry.target.dataset.category;
            if (cat) setActiveCategory(cat);
          }
        });
      },
      { root: container, threshold: 0.5 }
    );

    const reobserve = () => {
      const tabs = container.querySelectorAll('.category-tab');
      tabs.forEach((tab) => observer.observe(tab));
    };

    reobserve();
    const mutationObserver = new MutationObserver(reobserve);
    mutationObserver.observe(container, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      mutationObserver.disconnect();
    };
  }, []);

  const [paymentWaiting, setPaymentWaiting] = useState(false);
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);
  const [paymentCancelled, setPaymentCancelled] = useState(false);
  const [cashPaymentSuccess, setCashPaymentSuccess] = useState(false);
  const [paymentTimeLeft, setPaymentTimeLeft] = useState(90);
  const [notification, setNotification] = useState(null);
  const [barcode, setBarcode] = useState('');
  const barcodeInputRef = useRef(null);
  const isTouchDevice = typeof window !== 'undefined' && (
    'ontouchstart' in window ||
    (navigator.maxTouchPoints && navigator.maxTouchPoints > 0)
  );

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchStore();
    loadStoreStyles();

    const socket = io(SOCKET_URL);
    socketRef.current = socket;

    socket.on('connect', () => {
      console.log('Conectado al servidor WebSocket:', socket.id);
      if (storeIdRef.current) {
        socket.emit('register_store', storeIdRef.current);
      }
    });

    socket.on('reconnect', () => {
      console.log('Reconectado al servidor WebSocket:', socket.id);
      if (storeIdRef.current) {
        socket.emit('register_store', storeIdRef.current);
      }
    });

    socket.on('product_created', (product) => {
      console.log('Producto creado en tiempo real:', product);
      setStore(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          products: [...prev.products, product]
        };
      });
    });

    socket.on('product_updated', (product) => {
      console.log('Producto actualizado en tiempo real:', product);
      setStore(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          products: prev.products.map(p => p.id === product.id ? product : p)
        };
      });
    });

    socket.on('product_deleted', (data) => {
      console.log('Producto eliminado en tiempo real:', data);
      setStore(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          products: prev.products.filter(p => p.id !== data.id)
        };
      });
    });

    socket.on('category_created', () => fetchStore());
    socket.on('category_updated', () => fetchStore());
    socket.on('category_deleted', () => fetchStore());
    socket.on('ingredient_created', () => fetchStore());
    socket.on('ingredient_updated', () => fetchStore());
    socket.on('ingredient_deleted', () => fetchStore());
    socket.on('extra_created', () => fetchStore());
    socket.on('extra_updated', () => fetchStore());
    socket.on('extra_deleted', () => fetchStore());
    socket.on('inventory_updated', (data) => {
      console.log('Inventario actualizado en tiempo real:', data);
      setStore(prev => {
        if (!prev) return prev;
        const updatedProducts = prev.products.map(product => {
          if (product.id === data.product_id) {
            return {
              ...product,
              stock: data.stock !== undefined ? data.stock : product.stock,
              unlimited_stock: data.unlimited_stock !== undefined ? data.unlimited_stock : product.unlimited_stock
            };
          }
          if (product.ingredients) {
            product.ingredients = product.ingredients.map(ing => {
              if (ing.id === data.product_id) {
                return {
                  ...ing,
                  stock: data.stock !== undefined ? data.stock : ing.stock,
                  unlimited_stock: data.unlimited_stock !== undefined ? data.unlimited_stock : ing.unlimited_stock
                };
              }
              return ing;
            });
          }
          if (product.extras) {
            product.extras = product.extras.map(ext => {
              if (ext.id === data.product_id) {
                return {
                  ...ext,
                  stock: data.stock !== undefined ? data.stock : ext.stock,
                  unlimited_stock: data.unlimited_stock !== undefined ? data.unlimited_stock : ext.unlimited_stock
                };
              }
              return ext;
            });
          }
          return product;
        });
        return { ...prev, products: updatedProducts };
      });
    });

    socket.on('qr_payment_completed', (data) => {
      if (data.order_id && pendingOrderDataRef?.current?.order?.id === data.order_id) {
        setPaymentWaiting(false); setQrPaymentUrl(null);
        setPaymentConfirmed(true);
        setLastOrderNumber(pendingOrderDataRef.current.order.order_number);
        setCart([]);
        setCartOpen(false);
      }
    });

    socket.on('totem_restart', (data) => {
      console.log('totem_restart received:', data, 'myStore:', storeIdRef.current, 'isAdmin:', !!adminEditToken);
      // Only restart if this is not the admin editor and matches our store
      if (!adminEditToken && storeIdRef.current && String(data.store_id) === String(storeIdRef.current)) {
        showRestartNotification(5);
      }
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, [code, terminalFromUrl]);

  useEffect(() => {
    if (store?.store?.id && socketRef.current?.connected) {
      socketRef.current.emit('register_store', store.store.id);
    }
  }, [store?.store?.id]);

  const fetchStore = async () => {
    try {
      const response = await fetch(`/api/public/${code}`, { cache: 'no-store' });

      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Código no encontrado');
        }
        if (response.status === 403) {
          const data = await response.json();
          throw new Error(data.error || 'Tienda suspendida');
        }
        throw new Error('Error al cargar la tienda');
      }

      const data = await response.json();
      const uniqueProducts = (data.products || []).filter((product, index, self) =>
        index === self.findIndex((p) => p.id === product.id)
      );
      const uniqueCategories = (data.categories || []).filter((cat, index, self) =>
        index === self.findIndex((c) => c.id === cat.id)
      );
      const uniqueIngredients = (data.ingredients || []).filter((ing, index, self) =>
        index === self.findIndex((i) => i.id === ing.id)
      );
      const uniqueExtras = (data.extras || []).filter((ext, index, self) =>
        index === self.findIndex((e) => e.id === ext.id)
      );
      const deduplicatedData = {
        ...data,
        products: uniqueProducts,
        categories: uniqueCategories,
        ingredients: uniqueIngredients,
        extras: uniqueExtras
      };
      console.log('Store data received:', deduplicatedData);
      console.log('Number of products:', deduplicatedData.products?.length || 0);
      setStore(deduplicatedData);
      if (data.top_selling) setTopSellingIds(data.top_selling);

      // Welcome/language modal disabled — no longer shown on page load

      const terminalsResponse = await fetch(`/api/public/${code}/mercado-pago-terminals`);
      if (terminalsResponse.ok) {
        const terminalsData = await terminalsResponse.json();
        const safeTerminals = Array.isArray(terminalsData) ? terminalsData : [];
        setAvailableTerminals(safeTerminals);
        const hasTerminalFromUrl = terminalFromUrl && safeTerminals.some(terminal => String(terminal.id) === String(terminalFromUrl));
        setSelectedTerminalId(prev =>
          hasTerminalFromUrl
            ? String(terminalFromUrl)
            : (prev && safeTerminals.some(terminal => String(terminal.id) === String(prev)))
            ? prev
            : (safeTerminals[0]?.id ? String(safeTerminals[0].id) : '')
        );
      } else {
        setAvailableTerminals([]);
        setSelectedTerminalId('');
      }

      let configsData = [];
      const configsResponse = await fetch(`/api/public/store-configurations/${data.store.id}`);
      if (configsResponse.ok) {
        configsData = await configsResponse.json();
        setConfigurations(configsData);

        if (configFromUrl) {
          const urlConfig = configsData.find(c => String(c.id) === String(configFromUrl));
          setSelectedConfiguration(urlConfig || null);
        } else {
          const defaultConfig = configsData.find(c => c.is_default) || configsData[0];
          setSelectedConfiguration(defaultConfig || null);
        }
      } else {
        setConfigurations([]);
        setSelectedConfiguration(null);
      }

      // Auto-enter edit mode if admin token
      if (adminEditToken) {
        try {
          const vRes = await fetch(`/api/public/${code}/validate-admin`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token: adminEditToken })
          });
          const vData = await vRes.json();
          if (vData.valid) {
            setAdminToken(adminEditToken);
            setEditMode(true);
            setSessionPin('admin');
          }
        } catch { /* ignore */ }
      }

      // Register this device
      fetch(`/api/public/${code}/register-device`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ device_uid: deviceUid })
      }).catch(() => {});

      // Load device-specific config
      try {
        const dcRes = await fetch(`/api/public/device-config/${deviceUid}/${data.store.id}`);
        if (dcRes.ok) {
          const dc = await dcRes.json();
          // Apply assigned configuration
          if (dc.config_id && configsData) {
            const assigned = configsData.find(c => c.id === dc.config_id);
            if (assigned) setSelectedConfiguration(assigned);
          }
          // Pending restart (admin changed config)
          if (dc.pending_restart) {
            const delay = parseInt(dc.restart_time) || 10;
            showRestartNotification(delay);
          }
        }
      } catch { /* ignore */ }

      // Check if a plugin payment provider is available
      try {
        const lastTerminalId = localStorage.getItem('srservi_last_terminal_id') || '';
        const lastTerminalName = localStorage.getItem('srservi_last_terminal_name') || '';
        const lastTerminalProvider = localStorage.getItem('srservi_last_terminal_provider') || '';
        console.log('[Store] Checking payment provider - store_id:', data.store.id, 'terminal_id:', lastTerminalId, 'terminal_name:', lastTerminalName, 'provider:', lastTerminalProvider, 'device_uid:', deviceUid);
        const ppRes = await fetch(`/api/plugins/payments/provider?store_id=${data.store.id}&device_uid=${deviceUid}&terminal_id=${lastTerminalId}&terminal_provider=${lastTerminalProvider}`);
        const ppData = await ppRes.json();
        console.log('[Store] Payment provider response:', ppData);
        if (ppData.available) {
          setPluginPaymentProvider(ppData);
          console.log('[Store] pluginPaymentProvider SET:', ppData);
        } else {
          console.log('[Store] pluginPaymentProvider NOT set - reason:', ppData.reason);
        }
      } catch (e) { console.error('[Store] Payment provider error:', e); /* no payment plugin, ignore */ }

      // Check QR provider availability
      try {
        const qrRes = await fetch(`/api/plugins/qr/provider?store_id=${data.store.id}`);
        if (qrRes.ok) {
          const qrData = await qrRes.json();
          if (qrData.available) setQrProvider(qrData);
        }
      } catch { /* no qr provider, ignore */ }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const colors = store?.store ? {
    primary: store.store.primary_color || '#000000',
    secondary: store.store.secondary_color || '#FFFFFF',
    accent: store.store.accent_color || '#D4AF37',
    header: store.store.header_color || '#000000',
    currency: {
      symbol: store.store.currency_symbol || '$',
      code: store.store.currency_code || 'USD',
      name: store.store.currency_name || 'Dólar Estadounidense'
    }
  } : {
    primary: '#000000',
    secondary: '#FFFFFF',
    accent: '#D4AF37',
    header: '#000000',
    currency: {
      symbol: '$',
      code: 'USD',
      name: 'Dólar Estadounidense'
    }
  };

  const openProductModal = (product) => {
    if (!product.unlimited_stock && product.stock === 0) {
      setNotification({ name: product.name, agotado: true });
      setTimeout(() => setNotification(null), 2000);
      return;
    }
    setSelectedProduct(product);
    setProductConfig({
      selectedIngredients: [],
      selectedExtras: [],
      quantity: 1,
      notes: ''
    });

    const hasIngredients = product.has_ingredients && product.ingredients && product.ingredients.length > 0;
    const hasExtras = product.has_extras && product.extras && product.extras.length > 0;

    if (hasIngredients) {
      setProductModalStep('complements');
      setTimeout(() => setIngredientsModalOpen(true), 100);
    } else if (hasExtras) {
      setProductModalStep('extras');
      setTimeout(() => setExtrasModalOpen(true), 100);
    } else {
      setProductModalStep('main');
      setTimeout(() => addToCart(), 100);
    }
  };

  const closeProductModal = () => {
    setSelectedProduct(null);
    setProductModalStep('main');
    setAddingToCart(false);
    setIngredientsModalOpen(false);
    setExtrasModalOpen(false);
  };

  const anyModalOpen = pinModalOpen || prodModalOpen || catModalOpen || complementModal || showRestartConfirm || editMode || ingredientsModalOpen || extrasModalOpen || paymentModalOpen || cartOpen;

  useEffect(() => {
    if (isTouchDevice) return;
    if (anyModalOpen) return;
    if (barcodeInputRef.current) {
      barcodeInputRef.current.focus({ preventScroll: true });
    }
    const interval = setInterval(() => {
      if (anyModalOpen) return;
      if (barcodeInputRef.current && document.activeElement !== barcodeInputRef.current) {
        barcodeInputRef.current.focus({ preventScroll: true });
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [anyModalOpen, isTouchDevice]);

  // Global Bluetooth / USB-HID barcode scanner listener.
  // Works on tablets too (where the old auto-focus input path is skipped).
  // Heuristic: rapid keyboard input (<50 ms between keys) followed by Enter
  // is treated as a scanner read, not as the user typing. Input is ignored
  // when the focus is already on a text field (so admin editing isn't hijacked).
  useEffect(() => {
    if (anyModalOpen) return;
    let buffer = '';
    let lastTime = 0;
    const handleKey = (e) => {
      const active = document.activeElement;
      const tag = active?.tagName;
      const isEditable = tag === 'INPUT' || tag === 'TEXTAREA' || active?.isContentEditable;
      // Allow the dedicated hidden barcodeInput (it has a className we can detect)
      const isDedicated = active?.classList?.contains('barcode-input');
      if (isEditable && !isDedicated) return;

      const now = Date.now();
      const gap = now - lastTime;
      lastTime = now;

      if (e.key === 'Enter') {
        if (buffer.length >= 3) {
          handleBarcodeScan(buffer);
        }
        buffer = '';
        return;
      }
      // Reset buffer if gap too long (user typing manually)
      if (gap > 120) buffer = '';
      if (e.key.length === 1) buffer += e.key;
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [anyModalOpen, store]);

  const handleBarcodeScan = (barcodeValue) => {
    if (!store?.products) return;
    const found = store.products.find(p => p.barcode === barcodeValue);
    if (found) {
      if (!found.unlimited_stock && found.stock === 0) {
        setNotification({ name: found.name, agotado: true });
        setTimeout(() => setNotification(null), 2000);
        return;
      }
      setNotification({ name: found.name, image: found.image });
      setTimeout(() => setNotification(null), 2000);
      const unitPrice = found.price;
      const cartItem = {
        id: Date.now(),
        product_id: found.id,
        product_name: found.name,
        product_image: found.image,
        unit_price: unitPrice,
        quantity: 1,
        total: unitPrice
      };
      setCart([...cart, cartItem]);
    } else if (barcodeValue.length > 0) {
      setNotification({ name: 'Producto no encontrado', image: null });
      setTimeout(() => setNotification(null), 2000);
    }
  };

  const toggleIngredient = (ingredient) => {
    const isOutOfStock = !ingredient.unlimited_stock && ingredient.stock === 0;
    if (isOutOfStock) {
      return;
    }
    setProductConfig(prev => {
      const exists = prev.selectedIngredients.find(i => i.id === ingredient.id);
      if (exists) {
        return {
          ...prev,
          selectedIngredients: prev.selectedIngredients.filter(i => i.id !== ingredient.id)
        };
      } else {
        const maxIngredients = parseInt(selectedProduct.max_ingredients) || 0;
        if (maxIngredients > 0 && prev.selectedIngredients.length >= maxIngredients) {
          alert(`${t('maxComplements', lang)} ${maxIngredients} ${t('complementWord', lang)}`);
          return prev;
        }
        return {
          ...prev,
          selectedIngredients: [...prev.selectedIngredients, ingredient]
        };
      }
    });
  };

  const toggleExtra = (extra) => {
    const isOutOfStock = !extra.unlimited_stock && extra.stock === 0;
    if (isOutOfStock) {
      return;
    }
    setProductConfig(prev => {
      const exists = prev.selectedExtras.find(e => e.id === extra.id);
      if (exists) {
        return {
          ...prev,
          selectedExtras: prev.selectedExtras.filter(e => e.id !== extra.id)
        };
      } else {
        const maxExtras = parseInt(selectedProduct.max_extras) || 0;
        if (maxExtras > 0 && prev.selectedExtras.length >= maxExtras) {
          alert(`${t('maxComplements', lang)} ${maxExtras} ${t('extraWord', lang)}`);
          return prev;
        }
        return {
          ...prev,
          selectedExtras: [...prev.selectedExtras, extra]
        };
      }
    });
  };

  const calculateProductPrice = () => {
    if (!selectedProduct) return 0;

    let price = selectedProduct.price;

    productConfig.selectedIngredients.forEach(ing => {
      price += ing.price || 0;
    });

    productConfig.selectedExtras.forEach(extra => {
      price += extra.price || 0;
    });

    return price;
  };

  const addToCart = () => {
    if (!selectedProduct) return;

    setIngredientsModalOpen(false);
    setExtrasModalOpen(false);

    const unitPrice = calculateProductPrice();
    const cartItem = {
      id: Date.now(),
      product_id: selectedProduct.id,
      product_name: selectedProduct.name,
      product_image: selectedProduct.image,
      unit_price: unitPrice,
      quantity: productConfig.quantity,
      total: unitPrice * productConfig.quantity,
      selected_ingredients: productConfig.selectedIngredients.map(i => i.name),
      selected_extras: productConfig.selectedExtras.map(e => e.name)
    };

    setCart([...cart, cartItem]);
    setNotification({ name: selectedProduct.name, image: selectedProduct.image });
    setProductModalStep('main');
    closeProductModal();
    setTimeout(() => setNotification(null), 1500);
  };

  const handleNextToExtras = () => {
    const requiredIngredients = selectedProduct.ingredients.filter(ing => ing.is_required);
    const missingRequired = requiredIngredients.filter(req =>
      !productConfig.selectedIngredients.some(sel => sel.id === req.id)
    );

    if (missingRequired.length > 0) {
      alert(`${t('selectRequired', lang)}\n${missingRequired.map(i => '- ' + i.name).join('\n')}`);
      return;
    }
    setIngredientsModalOpen(false);

    if (selectedProduct.has_extras && selectedProduct.extras && selectedProduct.extras.length > 0) {
      setProductModalStep('extras');
      setTimeout(() => setExtrasModalOpen(true), 100);
    } else {
      setTimeout(() => addToCart(), 100);
    }
  };

  const handleBackToMain = () => {
    setIngredientsModalOpen(false);
    setExtrasModalOpen(false);
    setProductModalStep('main');
  };

  const handleBackToComplements = () => {
    setExtrasModalOpen(false);
    setProductModalStep('complements');
    setTimeout(() => setIngredientsModalOpen(true), 100);
  };

  const updateQuantity = (itemId, delta) => {
    setCart(prev => prev.map(item => {
      if (item.id === itemId) {
        const newQuantity = item.quantity + delta;
        if (newQuantity > 0) {
          return {
            ...item,
            quantity: newQuantity,
            total: Number(item.unit_price) * newQuantity
          };
        }
      }
      return item;
    }));
  };

  const removeFromCart = (itemId) => {
    setCart(prev => prev.filter(item => item.id !== itemId));
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + (item.unit_price * item.quantity), 0);
  };

  const getFinalTotal = () => {
    const subtotal = getCartTotal();
    const discount = Number(appliedCoupon?.discount_total || 0);
    return Math.max(subtotal - discount, 0);
  };

  const getCartCount = () => {
    return cart.reduce((count, item) => count + item.quantity, 0);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    alert(t('qrCodeCopied', lang) + ' ' + code);
  };

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setCartOpen(false);
    if (deliveryMode) {
      if (qrProvider) {
        processPayment('qr');
      } else {
        alert(t('noQRConfigured', lang));
      }
    } else {
      setPaymentModalOpen(true);
    }
  };

  const applyCoupon = async () => {
    if (!couponCodeInput.trim() || cart.length === 0) return;
    try {
      setCouponLoading(true);
      const response = await fetch(`/api/public/${code}/coupons/validate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          coupon_code: couponCodeInput.trim(),
          subtotal: getCartTotal()
        })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'No se pudo aplicar el cupón');
      }
      setAppliedCoupon(data);
      setCouponCodeInput(data.coupon_code || couponCodeInput.trim().toUpperCase());
    } catch (err) {
      alert(err.message);
      setAppliedCoupon(null);
    } finally {
      setCouponLoading(false);
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponCodeInput('');
  };

  const processPayment = async (selectedMethod = paymentMethod) => {
    if (cart.length === 0) return;
    const hasPluginProvider = selectedMethod === 'card' && pluginPaymentProvider;
    const lastTerminalProvider = localStorage.getItem('srservi_last_terminal_provider') || '';
    const forceTuu = selectedMethod === 'card' && lastTerminalProvider === 'tuu';
    if (selectedMethod === 'card' && !hasPluginProvider && !forceTuu && !selectedTerminalId) {
      alert(t('noTerminalAssigned', lang));
      return;
    }

    setPaymentMethod(selectedMethod);
    setProcessingPayment(true);
    setPaymentError(null);
    setPaymentConfirmed(false);
    setPaymentCancelled(false);

    const finalTotal = getFinalTotal();
    const storeId = store.store.id;
    const cartItems = cart.map(item => ({
      product_id: item.product_id,
      quantity: item.quantity,
      unit_price: item.unit_price,
      selected_ingredients: item.selected_ingredients,
      selected_extras: item.selected_extras
    }));

    try {
      // --- Plugin payment provider (Tuu, etc.) ---
      if (hasPluginProvider || forceTuu) {
        const orderRes = await fetch(API + '/api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            store_id: storeId, order_type: orderType, payment_method: 'card',
            items: cartItems, coupon_code: appliedCoupon?.coupon_code || null,
            total: Number(finalTotal).toFixed(2), delivery: deliveryMode
          })
        });
        if (!orderRes.ok) throw new Error((await orderRes.json()).error || 'Error al crear pedido');
        const order = await orderRes.json();
        setPendingOrderData({ order, storeId });

        const chargeRes = await fetch('/api/plugins/payments/charge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            store_id: storeId, order_id: order.id,
            amount: Math.round(Number(finalTotal)),
            description: `Pedido #${order.order_number || order.id}`,
            device_uid: deviceUid,
            terminal_id: localStorage.getItem('srservi_last_terminal_id') || null,
            terminal_provider: lastTerminalProvider
          })
        });
        const chargeData = await chargeRes.json();
        if (!chargeData.success) throw new Error(chargeData.error || 'Error al enviar cobro');

        setPluginPaymentKey(chargeData.paymentKey);
        setPaymentWaiting(true);
        setPaymentTimeLeft(300);

      // --- MercadoPago card ---
      } else if (selectedMethod === 'card') {
        const response = await fetch(API + '/api/orders/process-payment', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            store_id: storeId, order_type: orderType, payment_method: selectedMethod,
            items: cartItems, selected_terminal_id: selectedTerminalId ? parseInt(selectedTerminalId) : null,
            coupon_code: appliedCoupon?.coupon_code || null, total: Number(finalTotal).toFixed(2), delivery: deliveryMode
          })
        });
        if (!response.ok) throw new Error((await response.json()).error || 'Error al procesar');
        const result = await response.json();
        setPendingOrderData({ order: result.order || result, storeId });
        setPaymentWaiting(true);
        setPaymentTimeLeft(90);

      // --- QR Provider ---
      } else if (selectedMethod === 'qr') {
        const orderRes = await fetch(API + '/api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            store_id: storeId, order_type: orderType, payment_method: 'card',
            items: cartItems, coupon_code: appliedCoupon?.coupon_code || null,
            total: Number(finalTotal).toFixed(2), delivery: deliveryMode
          })
        });
        if (!orderRes.ok) throw new Error((await orderRes.json()).error || 'Error al crear pedido');
        const order = await orderRes.json();
        setPendingOrderData({ order, storeId });

        const qrRes = await fetch('/api/plugins/qr/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            store_id: storeId, order_id: order.id,
            amount: Math.round(Number(finalTotal)),
            description: `Pedido #${order.order_number || order.id}`
          })
        });
        const qrData = await qrRes.json();
        if (!qrData.success) throw new Error(qrData.error || 'Error generando QR');

        setQrPaymentUrl(qrData.paymentUrl);
        setPaymentWaiting(true);
        setPaymentTimeLeft(300);
        window.open(qrData.paymentUrl, '_blank');

      // --- Cash ---
      } else {
        const response = await fetch(API + '/api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            store_id: storeId, order_type: orderType, payment_method: selectedMethod,
            items: cartItems, coupon_code: appliedCoupon?.coupon_code || null,
            total: Number(finalTotal).toFixed(2), delivery: deliveryMode
          })
        });
        if (!response.ok) throw new Error((await response.json()).error || 'Error al procesar');
        const order = await response.json();
        setPendingOrderData({ order, storeId });
        setLastOrderNumber(order.order_number);
        setCashPaymentSuccess(true);
        setPaymentModalOpen(false);
        setCart([]);
        setCartOpen(false);
      }
    } catch (err) {
      setPaymentError(err.message);
      alert(err.message);
    } finally {
      setProcessingPayment(false);
    }
  };

  useEffect(() => {
    if (!paymentWaiting || !pendingOrderData) return;

    const orderId = pendingOrderData.order.id;
    const storeId = pendingOrderData.storeId;
    const isPluginPayment = !!pluginPaymentKey;

    const onPaymentSuccess = () => {
      setPaymentConfirmed(true);
      setLastOrderNumber(pendingOrderData.order.order_number);
      setCart([]);
      setCartOpen(false);
      setPaymentModalOpen(false);
      setPaymentWaiting(false); setQrPaymentUrl(null);
      setPluginPaymentKey(null);
    };

    const onPaymentFail = () => {
      setPaymentWaiting(false); setQrPaymentUrl(null);
      setPaymentCancelled(true);
      setPluginPaymentKey(null);
    };

    const pollInterval = setInterval(async () => {
      try {
        if (isPluginPayment) {
          // --- Generic plugin payment polling ---
          const res = await fetch(`/api/plugins/payments/status/${pluginPaymentKey}`);
          if (!res.ok) return;
          const data = await res.json();

          if (data.status === 'Completed') {
            clearInterval(pollInterval);
            clearInterval(timerInterval);
            onPaymentSuccess();
          } else if (['Canceled', 'Failed', 'Timeout'].includes(data.status)) {
            clearInterval(pollInterval);
            clearInterval(timerInterval);
            onPaymentFail();
          }
        } else {
          // --- MercadoPago polling ---
          const res = await fetch(`/api/orders/${orderId}/payment-status?store_id=${storeId}`);
          if (!res.ok) return;
          const data = await res.json();

          const mpStatus = data.mp_status || data.status;
          const payStatus = data.payment_status || data.status;
          const paidAmount = data.paid_amount || '0';

          const isApproved =
            (payStatus === 'approved' || payStatus === 'paid' || payStatus === 'processed' ||
             mpStatus === 'processed') &&
            (parseFloat(paidAmount) > 0 || payStatus === 'processed' || mpStatus === 'processed');
          const isCancelled = mpStatus === 'canceled' || mpStatus === 'refunded' ||
            mpStatus === 'expired' || mpStatus === 'failed' ||
            payStatus === 'canceled' || payStatus === 'refunded' ||
            data.order_status === 'canceled' || data.order_status === 'refunded';

          if (isApproved) {
            clearInterval(pollInterval);
            clearInterval(timerInterval);
            await fetch(`/api/orders/${orderId}/confirm-payment`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ store_id: storeId })
            });
            onPaymentSuccess();
          } else if (isCancelled) {
            clearInterval(pollInterval);
            clearInterval(timerInterval);
            onPaymentFail();
          }
        }
      } catch (err) {
        console.error('Error polling payment status:', err);
      }
    }, 5000);

    const timerInterval = setInterval(() => {
      setPaymentTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timerInterval);
          clearInterval(pollInterval);
          if (isPluginPayment && pluginPaymentKey) {
            fetch(`/api/plugins/payments/cancel/${pluginPaymentKey}`, { method: 'POST' });
          }
          onPaymentFail();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      clearInterval(pollInterval);
      clearInterval(timerInterval);
    };
  }, [paymentWaiting, pendingOrderData, pluginPaymentKey]);

  useEffect(() => {
    setAppliedCoupon(null);
  }, [cart]);

  const fetchComplements = async () => {
    try {
      const [exRes, inRes] = await Promise.all([
        fetch(`/api/public/${code}/extras`, { cache: 'no-store' }),
        fetch(`/api/public/${code}/ingredients`, { cache: 'no-store' })
      ]);
      if (exRes.ok) setExtras(await exRes.json());
      if (inRes.ok) setIngredients(await inRes.json());
    } catch { /* ignore */ }
  };

  useEffect(() => {
    if (editMode && adminToken) fetchComplements();
  }, [editMode, adminToken]);

  const saveComplement = async () => {
    if (!complementForm.name.trim()) return;
    const type = complementForm.type;
    const formData = new FormData();
    formData.append('token', adminToken);
    formData.append('name', complementForm.name.trim());
    formData.append('price', parseFloat(complementForm.price) || 0);
    formData.append('category_id', complementForm.category_id || '');
    formData.append('stock', parseInt(complementForm.stock) || 0);
    formData.append('unlimited_stock', complementForm.unlimited_stock);
    if (complementForm.imageFile) formData.append('image', complementForm.imageFile);

    await fetch(`/api/public/${code}/${type === 'extra' ? 'extras' : 'ingredients'}`, {
      method: 'POST',
      body: formData
    });
    setComplementModal(null);
    setComplementForm({ name: '', price: '', type: 'extra', category_id: '', stock: '', unlimited_stock: true, imageFile: null });
    fetchComplements();
    fetchStore();
  };

  const deleteComplement = async (type, id) => {
    if (!confirm('¿Eliminar?')) return;
    await fetch(`/api/public/${code}/${type === 'extra' ? 'extras' : 'ingredients'}/${id}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: adminToken })
    });
    fetchComplements();
    fetchStore();
  };

  const loadStoreStyles = async () => {
    try {
      const res = await fetch(`/api/public/${code}/styles`, { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        const vs = typeof data.visual_settings === 'string' ? JSON.parse(data.visual_settings) : (data.visual_settings || {});
        setVisualSettings(prev => ({ ...prev, ...vs }));
        setCustomCss(data.custom_css || '');
        applyStyles(vs, data.custom_css || '');
      }
    } catch { /* ignore */ }
  };

  const applyStyles = (vs, css) => {
    let old = document.getElementById('store-custom-styles');
    if (old) old.remove();
    const parts = [];
    if (vs.fontFamily) parts.push('.store-container { font-family: ' + vs.fontFamily + ' !important; }');
    if (vs.fontSize) parts.push('.store-container { font-size: ' + vs.fontSize + ' !important; }');
    if (vs.titleSize) parts.push('.store-product-name { font-size: ' + vs.titleSize + ' !important; }');
    if (vs.priceSize) parts.push('.store-product-price { font-size: ' + vs.priceSize + ' !important; }');
    if (vs.fontWeight) parts.push('.store-container { font-weight: ' + vs.fontWeight + ' !important; }');
    if (vs.textShadow) parts.push('.store-product-name, .store-product-price { text-shadow: ' + vs.textShadow + ' !important; }');
    if (vs.cardShadow) parts.push('.store-product-card { box-shadow: ' + vs.cardShadow + ' !important; }');
    if (vs.cardRadius) parts.push('.store-product-card { border-radius: ' + vs.cardRadius + ' !important; }');
    if (vs.productNameColor) parts.push('.store-product-name { color: ' + vs.productNameColor + ' !important; }');
    if (vs.productPriceColor) parts.push('.store-product-price { color: ' + vs.productPriceColor + ' !important; }');
    if (vs.cardBg) parts.push('.store-product-card { background: ' + vs.cardBg + ' !important; }');
    if (vs.cardBorder) parts.push('.store-product-card { border: ' + vs.cardBorder + ' !important; }');
    if (vs.headerBg) parts.push('.store-header { background: ' + vs.headerBg + ' !important; }');
    if (vs.headerTextColor) parts.push('.store-header, .store-header * { color: ' + vs.headerTextColor + ' !important; }');
    if (vs.categoryBg) parts.push('.category-tab { background: ' + vs.categoryBg + ' !important; }');
    if (vs.categoryActiveColor) parts.push('.category-tab.active { background: ' + vs.categoryActiveColor + ' !important; }');
    if (vs.cartBg) parts.push('.cart-bar { background: ' + vs.cartBg + ' !important; }');
    if (vs.cartTextColor) parts.push('.cart-bar, .cart-bar *, .cart-bar-text, .cart-bar-total, .cart-bar-pay-btn { color: ' + vs.cartTextColor + ' !important; }');
    if (css) parts.push(css);
    if (parts.length > 0) {
      const el = document.createElement('style');
      el.id = 'store-custom-styles';
      el.textContent = parts.join('\n');
      document.head.appendChild(el);
    }
  };

  const saveStoreStyles = async () => {
    setStyleSaving(true);
    try {
      await fetch(`/api/public/${code}/styles`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...getAuthBody(), visual_settings: visualSettings, custom_css: customCss })
      });
      applyStyles(visualSettings, customCss);
    } catch (err) { console.error('Error saving styles:', err); }
    finally { setStyleSaving(false); }
  };

  const deleteComplementFromModal = async (type, id) => {
    if (!confirm('¿Eliminar?')) return;
    await fetch(`/api/public/${code}/${type === 'extra' ? 'extras' : 'ingredients'}/${id}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: adminToken })
    });
    if (type === 'extra') setSelectedExtraIds(prev => prev.filter(eid => eid !== id));
    else setSelectedIngredientIds(prev => prev.filter(iid => iid !== id));
    fetchComplements();
  };

  const saveEditComplement = async () => {
    if (!editingComplement || !editingComplement.name.trim()) return;
    const { id, type, name, price, imageFile } = editingComplement;
    const formData = new FormData();
    formData.append('token', adminToken);
    formData.append('name', name.trim());
    formData.append('price', parseFloat(price) || 0);
    formData.append('category_id', '');
    if (imageFile) formData.append('image', imageFile);
    await fetch(`/api/public/${code}/${type === 'extra' ? 'extras' : 'ingredients'}/${id}`, {
      method: 'PUT',
      body: formData
    });
    setEditingComplement(null);
    fetchComplements();
  };

  const updateProductStock = async (productId, stock, unlimitedStock) => {
    await fetch(`/api/public/${code}/products/${productId}/stock`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: adminToken, stock, unlimited_stock: unlimitedStock })
    });
    fetchStore();
  };

  const getAuthBody = () => adminToken ? { token: adminToken } : { pin: sessionPin };

  const showRestartNotification = (delaySec) => {
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:999999;display:flex;flex-direction:column;align-items:center;justify-content:center;background:rgba(0,0,0,0.85);color:#fff;font-family:sans-serif;';
    const countdownEl = document.createElement('div');
    overlay.innerHTML = `
      <div style="font-size:48px;margin-bottom:16px;">&#x1F504;</div>
      <h2 style="margin:0 0 8px;font-size:22px;text-align:center;">El administrador realizó cambios</h2>
      <p style="margin:0 0 20px;font-size:16px;color:#ccc;text-align:center;">Este totem será reiniciado</p>
    `;
    countdownEl.style.cssText = 'font-size:36px;font-weight:bold;color:#D4AF37;';
    countdownEl.textContent = delaySec;
    overlay.appendChild(countdownEl);
    document.body.appendChild(overlay);

    let remaining = delaySec;
    const interval = setInterval(() => {
      remaining--;
      countdownEl.textContent = remaining;
      if (remaining <= 0) {
        clearInterval(interval);
        window.location.reload();
      }
    }, 1000);
  };

  const groupProductsByCategory = () => {
    if (!store?.products) return {};

    const grouped = {};
    store.products.forEach(product => {
      if (!product.category_name) return; // sin categoría solo aparece en "Todo"
      if (!grouped[product.category_name]) {
        grouped[product.category_name] = [];
      }
      grouped[product.category_name].push(product);
    });

    return grouped;
  };

  const handleLongPressStart = () => {
    if (editMode) return;
    longPressTimerRef.current = setTimeout(() => {
      setPinInput('');
      setPinError('');
      setPinModalOpen(true);
    }, 10000);
  };

  const handleLongPressEnd = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handlePinSubmit = async (pinValue) => {
    const pin = pinValue || pinInput;
    if (!pin || pin.length < 4) return;
    try {
      const response = await fetch(`/api/public/${code}/verify-edit-pin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      const data = await response.json();
      if (data.valid) {
        setSessionPin(pin);
        setEditMode(true);
        setPinModalOpen(false);
        setPinInput('');
        setPinError('');
      } else {
        setPinError('PIN incorrecto');
        setPinInput('');
      }
    } catch {
      setPinError('Error al verificar PIN');
      setPinInput('');
    }
  };

  const editSensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } })
  );

  const handleEditDragStart = (event) => {
    setEditDragActiveId(event.active.id);
  };

  const handleEditDragEnd = async (event) => {
    const { active, over } = event;
    setEditDragActiveId(null);

    if (!over || active.id === over.id || !store?.products) return;

    const allProducts = [...store.products];
    const oldIndex = allProducts.findIndex(p => p.id === active.id);
    const newIndex = allProducts.findIndex(p => p.id === over.id);

    if (oldIndex === -1 || newIndex === -1) return;

    const newProducts = arrayMove(allProducts, oldIndex, newIndex);
    setStore(prev => ({ ...prev, products: newProducts }));

    try {
      await fetch(`/api/public/${code}/products/order`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...getAuthBody(),
          products: newProducts.map(p => ({ id: p.id }))
        })
      });
    } catch (error) {
      console.error('Error saving order:', error);
    }
  };

  const openCatModal = (cat = null) => {
    setEditingCat(cat);
    setCatName(cat ? cat.name : '');
    setCatModalOpen(true);
  };

  const saveCat = async () => {
    if (!catName.trim()) return;
    try {
      const url = editingCat
        ? `/api/public/${code}/categories/${editingCat.id}`
        : `/api/public/${code}/categories`;
      await fetch(url, {
        method: editingCat ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...getAuthBody(), name: catName.trim() })
      });
      setCatModalOpen(false);
      setCatName('');
      setEditingCat(null);
      fetchStore();
    } catch (err) {
      console.error('Error saving category:', err);
    }
  };

  const deleteCat = async (cat) => {
    if (!confirm(`¿Eliminar "${cat.name}"? Los productos quedarán sin categoría.`)) return;
    try {
      await fetch(`/api/public/${code}/categories/${cat.id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(getAuthBody())
      });
      fetchStore();
    } catch (err) {
      console.error('Error deleting category:', err);
    }
  };

  const openProdModal = (product = null) => {
    setEditingProd(product);
    setProdForm({
      name: product?.name || '',
      price: product?.price?.toString() || '',
      category_id: product?.category_id?.toString() || '',
      description: product?.description || '',
      barcode: product?.barcode || '',
      stock: product?.stock?.toString() || '0',
      unlimited_stock: product?.unlimited_stock ?? true,
      has_extras: product?.has_extras || false,
      has_ingredients: product?.has_ingredients || false,
      max_extras: product?.max_extras?.toString() || '',
      max_ingredients: product?.max_ingredients?.toString() || ''
    });
    setProdImageFile(null);
    setProdNewExtras([]);
    setProdNewComplements([]);
    if (adminToken) {
      fetchComplements();
      if (product) {
        fetch(`/api/public/${code}/products/${product.id}/complements`, { cache: 'no-store' })
          .then(r => r.json())
          .then(data => {
            setSelectedIngredientIds(data.ingredient_ids || []);
            setSelectedExtraIds(data.extra_ids || []);
          })
          .catch(() => {
            setSelectedIngredientIds(ingredients.map(i => i.id));
            setSelectedExtraIds(extras.map(e => e.id));
          });
      } else {
        // New product: all enabled by default
        setSelectedIngredientIds(ingredients.map(i => i.id));
        setSelectedExtraIds(extras.map(e => e.id));
      }
    }
    setProdModalOpen(true);
  };

  const saveProd = async () => {
    if (!prodForm.name.trim() || !prodForm.price) return;
    setProdSaving(true);
    try {
      const formData = new FormData();
      if (adminToken) formData.append('token', adminToken);
      else formData.append('pin', sessionPin);
      formData.append('name', prodForm.name.trim());
      formData.append('price', parseFloat(prodForm.price));
      formData.append('category_id', prodForm.category_id || '');
      formData.append('description', prodForm.description || '');
      formData.append('barcode', prodForm.barcode || '');
      formData.append('has_extras', prodForm.has_extras);
      formData.append('has_ingredients', prodForm.has_ingredients);
      formData.append('max_extras', prodForm.has_extras ? (parseInt(prodForm.max_extras) || 0) : 0);
      formData.append('max_ingredients', prodForm.has_ingredients ? (parseInt(prodForm.max_ingredients) || 0) : 0);
      if (prodImageFile) {
        formData.append('image', prodImageFile);
      } else if (editingProd) {
        formData.append('keep_image', 'true');
      }

      const url = editingProd
        ? `/api/public/${code}/products/${editingProd.id}`
        : `/api/public/${code}/products`;

      await fetch(url, {
        method: editingProd ? 'PUT' : 'POST',
        body: formData
      });

      // Update stock if admin editor
      if (adminToken) {
        const prodData = await (await fetch(`/api/public/${code}`, { cache: 'no-store' })).json();
        const lastProd = editingProd ? editingProd : prodData.products?.[prodData.products.length - 1];
        if (lastProd?.id) {
          await updateProductStock(lastProd.id, parseInt(prodForm.stock) || 0, prodForm.unlimited_stock);
        }
      }

      // Create new complements & extras, then sync associations
      if (adminToken) {
        const categoryId = prodForm.category_id || '';
        const newIngIds = [];
        const newExtIds = [];

        for (const comp of prodNewComplements) {
          if (!comp.name.trim()) continue;
          const compData = new FormData();
          compData.append('token', adminToken);
          compData.append('name', comp.name.trim());
          compData.append('price', parseFloat(comp.price) || 0);
          compData.append('category_id', categoryId);
          compData.append('stock', 0);
          compData.append('unlimited_stock', 'true');
          if (comp.imageFile) compData.append('image', comp.imageFile);
          const res = await fetch(`/api/public/${code}/ingredients`, { method: 'POST', body: compData });
          if (res.ok) { const d = await res.json(); newIngIds.push(d.id); }
        }
        for (const ext of prodNewExtras) {
          if (!ext.name.trim()) continue;
          const extData = new FormData();
          extData.append('token', adminToken);
          extData.append('name', ext.name.trim());
          extData.append('price', parseFloat(ext.price) || 0);
          extData.append('category_id', categoryId);
          extData.append('stock', 0);
          extData.append('unlimited_stock', 'true');
          if (ext.imageFile) extData.append('image', ext.imageFile);
          const res = await fetch(`/api/public/${code}/extras`, { method: 'POST', body: extData });
          if (res.ok) { const d = await res.json(); newExtIds.push(d.id); }
        }

        if (prodNewComplements.length > 0 || prodNewExtras.length > 0) {
          fetchComplements();
        }

        // Sync complement associations for this product
        const prodData2 = await (await fetch(`/api/public/${code}`, { cache: 'no-store' })).json();
        const targetProd = editingProd ? editingProd : prodData2.products?.[prodData2.products.length - 1];
        if (targetProd?.id) {
          const allIngIds = [...selectedIngredientIds, ...newIngIds];
          const allExtIds = [...selectedExtraIds, ...newExtIds];
          await fetch(`/api/public/${code}/products/${targetProd.id}/complements`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...getAuthBody(), ingredient_ids: allIngIds, extra_ids: allExtIds })
          });
        }
      }

      setProdModalOpen(false);
      setEditingProd(null);
      setProdImageFile(null);
      setProdNewExtras([]);
      setProdNewComplements([]);
      fetchStore();
    } catch (err) {
      console.error('Error saving product:', err);
    } finally {
      setProdSaving(false);
    }
  };

  const deleteProd = async (product) => {
    if (!confirm(`¿Eliminar "${product.name}"?`)) return;
    try {
      await fetch(`/api/public/${code}/products/${product.id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(getAuthBody())
      });
      fetchStore();
    } catch (err) {
      console.error('Error deleting product:', err);
    }
  };

  if (loading) {
    return (
      <div className="loading">
        {t('loading', lang)}
      </div>
    );
  }

  if (error) {
    return (
      <div className="index-container">
        <div className="index-card">
          <h1 className="index-title" style={{ color: '#DC3545' }}>{t('error', lang)}</h1>
          <p className="index-subtitle">{error}</p>
          <button
            className="btn btn-secondary w-full"
            onClick={() => navigate('/')}
          >
            <FontAwesomeIcon icon={faArrowLeft} />
            {t('backToHome', lang)}
          </button>
        </div>
      </div>
    );
  }

  const groupedProducts = groupProductsByCategory();
  const hasProducts = (store?.products || []).length > 0;

  // Smart mode: reorder products putting top sellers first
  const getSmartProducts = () => {
    const prods = store?.products || [];
    if (topSellingIds.length === 0) return prods;
    const top = [];
    const rest = [];
    for (const p of prods) {
      if (topSellingIds.includes(p.id)) top.push(p);
      else rest.push(p);
    }
    // Sort top by their position in topSellingIds (most sold first)
    top.sort((a, b) => topSellingIds.indexOf(a.id) - topSellingIds.indexOf(b.id));
    return [...top, ...rest];
  };

  const renderProductCard = (product) => {
    const isUnlimited = product.unlimited_stock === true || product.unlimited_stock === 1 || product.unlimited_stock === '1';
    const isOutOfStock = !isUnlimited && product.stock === 0;
    const isTopSelling = topSellingIds.includes(product.id);
    return (
      <div
        key={product.id}
        className={`store-product-wrapper${isOutOfStock ? ' out-of-stock' : ''}${isTopSelling ? ' top-selling' : ''}`}
      >
        <div
          className={`store-product-card${isOutOfStock ? ' out-of-stock' : ''}${isTopSelling ? ' top-selling-card' : ''}`}
          onClick={() => !editMode && openProductModal(product)}
        >
          {isTopSelling && !isOutOfStock && (
            <div className="top-selling-badge">
              <FontAwesomeIcon icon={faFire} /> {t('topSelling', lang)}
            </div>
          )}
          {isOutOfStock && (
            <div className="out-of-stock-badge">
              {t('soldOut', lang)}
            </div>
          )}
          {editMode && (
            <div className="store-prod-edit-overlay">
              <button onClick={(e) => { e.stopPropagation(); openProdModal(product); }} className="store-prod-edit-btn">
                <FontAwesomeIcon icon={faEdit} />
              </button>
              <button onClick={(e) => { e.stopPropagation(); deleteProd(product); }} className="store-prod-edit-btn danger">
                <FontAwesomeIcon icon={faTrash} />
              </button>
            </div>
          )}
          <div className="store-product-image">
            {product.image ? (
              <img
                src={getImageUrl(product.image)}
                alt={product.name}
                className={isOutOfStock ? 'grayscale' : ''}
              />
            ) : (
              <FontAwesomeIcon icon={faBox} className="placeholder-icon" />
            )}
          </div>
        </div>
        <div className="store-product-info">
          <div className={`store-product-details${isOutOfStock ? ' out-of-stock' : ''}`}>
            <span className="store-product-name">{product.name}:</span>
            <span className="store-product-price">{colors.currency.symbol}{Number(product.price).toFixed(2)}</span>
          </div>
        </div>
      </div>
    );
  };

  const renderAddProductCard = () => (
    <div className="store-product-wrapper" key="add-product">
      <div className="store-product-card store-add-card" onClick={() => openProdModal()}>
        <FontAwesomeIcon icon={faPlus} className="store-add-icon" />
      </div>
      <div className="store-product-info">
        <div className="store-product-details">
          <span className="store-product-name">Nuevo producto</span>
        </div>
      </div>
    </div>
  );

  return (
    <PluginProvider mode="store">
    <div
      className="store-container"
      style={{ '--store-primary': colors.primary, '--store-secondary': colors.secondary, '--store-accent': colors.accent, '--store-header': colors.header || colors.primary }}
      onTouchStart={handleLongPressStart}
      onTouchEnd={handleLongPressEnd}
      onTouchMove={handleLongPressEnd}
      onMouseDown={handleLongPressStart}
      onMouseUp={handleLongPressEnd}
      onMouseLeave={handleLongPressEnd}
    >
      <header className="store-header">
        <div className="store-header-content">
          <div className="store-header-brand">
            {store?.store?.logo_url && (
              <img
                src={store.store.logo_url}
                alt={store?.store?.name}
                className="store-header-logo"
              />
            )}
            <h1 className="store-header-name">
              {store?.store?.name}
            </h1>
          </div>
          <p className="store-header-powered">
            {t('poweredBy', lang)}
          </p>
          <div className="store-header-spacer" />
        </div>
      </header>

      <PluginSlot name="store-header" context={{ storeId: store?.store?.id, code }} />

      {/* Language selector */}
      <div style={{ position: 'fixed', top: '8px', right: '8px', zIndex: 200 }}>
        <button onClick={() => setShowLangPicker(!showLangPicker)} style={{ background: 'rgba(0,0,0,0.5)', border: 'none', borderRadius: '50%', width: '32px', height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#fff', fontSize: '14px' }}>
          <FontAwesomeIcon icon={faGlobe} />
        </button>
        {showLangPicker && (
          <div style={{ position: 'absolute', top: '36px', right: 0, background: '#fff', borderRadius: '8px', boxShadow: '0 4px 16px rgba(0,0,0,0.15)', overflow: 'hidden', minWidth: '130px' }}>
            {LANGUAGES.map(l => (
              <button key={l.code} onClick={() => { setLang(l.code); localStorage.setItem('srservi_lang', l.code); setShowLangPicker(false); }}
                style={{ display: 'flex', alignItems: 'center', gap: '8px', width: '100%', padding: '8px 12px', border: 'none', background: lang === l.code ? '#f0f0f0' : '#fff', cursor: 'pointer', fontSize: '13px', fontWeight: lang === l.code ? '700' : '400' }}>
                <span>{l.flag}</span> {l.label}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="category-tabs">
        <div
          ref={categoryRef}
          className="category-tabs-list"
        >
        <button
          className={`category-tab${activeCategory === 'all' ? ' active' : ''}`}
          data-category="all"
          onClick={() => setActiveCategory('all')}
        >
          {t('all', lang)}
        </button>
        {(store?.categories || []).map(c => c.name).map(cat => {
          const catObj = (store?.categories || []).find(c => c.name === cat);
          return (
            <button
              key={cat}
              className={`category-tab${activeCategory === cat ? ' active' : ''}`}
              data-category={cat}
              onClick={() => !editMode && setActiveCategory(cat)}
            >
              {cat}
              {editMode && catObj && (
                <span className="cat-tab-edit-icons">
                  <span onClick={(e) => { e.stopPropagation(); openCatModal(catObj); }}><FontAwesomeIcon icon={faEdit} /></span>
                  <span onClick={(e) => { e.stopPropagation(); deleteCat(catObj); }} className="cat-tab-del"><FontAwesomeIcon icon={faTrash} /></span>
                </span>
              )}
            </button>
          );
        })}
        {editMode && (
          <button className="category-tab cat-tab-add" onClick={() => openCatModal()}>
            <FontAwesomeIcon icon={faFolderPlus} />
          </button>
        )}
        </div>
      </div>

      {!hasProducts && (
        <div className="store-empty">
          <div className="store-empty-icon" style={{ background: `linear-gradient(135deg, ${colors.accent}20, ${colors.accent}40)` }}>
            <FontAwesomeIcon icon={faBox} style={{ color: colors.accent }} />
          </div>
          <h2>
            {t('noProducts', lang)}
          </h2>
          <p>
            {t('noProductsDesc', lang)}
          </p>
        </div>
      )}

      {editMode && (
        <div className="store-editor-bar">
          <div className="store-editor-tabs">
            <button className={`store-editor-tab${editorTab === 'products' ? ' active' : ''}`} onClick={() => setEditorTab('products')}>
              <FontAwesomeIcon icon={faBox} /> Productos
            </button>
            {adminToken && (
              <button className={`store-editor-tab${editorTab === 'payment' ? ' active' : ''}`} onClick={() => setEditorTab('payment')}>
                <FontAwesomeIcon icon={faCreditCard} /> Config. Pago
              </button>
            )}
            {adminToken && (
              <button className={`store-editor-tab${editorTab === 'complements' ? ' active' : ''}`} onClick={() => setEditorTab('complements')}>
                <FontAwesomeIcon icon={faPlus} /> Complementos
              </button>
            )}
            {adminToken && (
              <button className="store-editor-tab" onClick={() => { loadStoreStyles(); setStyleEditorOpen(true); }}>
                <FontAwesomeIcon icon={faPalette} /> Estilos
              </button>
            )}
          </div>
          <button className="store-editor-done" onClick={() => { if (adminToken) { setShowRestartConfirm(true); } else { setEditMode(false); } }}>
            Guardar
          </button>
        </div>
      )}

      {editMode && editorTab === 'payment' && adminToken && (
        <div className="store-editor-complements">
          <div className="store-editor-comp-header">
            <span>Config. Pago — configuraciones de la tienda</span>
          </div>
          {configurations.length === 0 ? (
            <span style={{ color: '#999', fontSize: '13px', padding: '8px' }}>Sin configuraciones</span>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {configurations.map(cfg => (
                <div key={cfg.id} style={{ border: '1px solid #333', borderRadius: '10px', padding: '12px', background: '#111' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <strong style={{ color: '#D4AF37' }}>{cfg.name}{cfg.is_default ? ' · por defecto' : ''}</strong>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px', fontSize: '13px', color: '#eee' }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={!!cfg.accept_cash}
                        onChange={async (e) => {
                          const v = e.target.checked;
                          setConfigurations(prev => prev.map(c => c.id === cfg.id ? { ...c, accept_cash: v } : c));
                          try {
                            await fetch(`/api/store-configurations/${cfg.id}`, {
                              method: 'PUT',
                              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${adminToken}` },
                              body: JSON.stringify({ ...cfg, accept_cash: v })
                            });
                          } catch { /* ignore */ }
                        }}
                      /> Efectivo
                    </label>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={!!cfg.accept_card}
                        onChange={async (e) => {
                          const v = e.target.checked;
                          setConfigurations(prev => prev.map(c => c.id === cfg.id ? { ...c, accept_card: v } : c));
                          try {
                            await fetch(`/api/store-configurations/${cfg.id}`, {
                              method: 'PUT',
                              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${adminToken}` },
                              body: JSON.stringify({ ...cfg, accept_card: v })
                            });
                          } catch { /* ignore */ }
                        }}
                      /> Tarjeta
                    </label>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={!!cfg.allow_serve}
                        onChange={async (e) => {
                          const v = e.target.checked;
                          setConfigurations(prev => prev.map(c => c.id === cfg.id ? { ...c, allow_serve: v } : c));
                          try {
                            await fetch(`/api/store-configurations/${cfg.id}`, {
                              method: 'PUT',
                              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${adminToken}` },
                              body: JSON.stringify({ ...cfg, allow_serve: v })
                            });
                          } catch { /* ignore */ }
                        }}
                      /> Comer aquí
                    </label>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={!!cfg.allow_takeout}
                        onChange={async (e) => {
                          const v = e.target.checked;
                          setConfigurations(prev => prev.map(c => c.id === cfg.id ? { ...c, allow_takeout: v } : c));
                          try {
                            await fetch(`/api/store-configurations/${cfg.id}`, {
                              method: 'PUT',
                              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${adminToken}` },
                              body: JSON.stringify({ ...cfg, allow_takeout: v })
                            });
                          } catch { /* ignore */ }
                        }}
                      /> Para llevar
                    </label>
                  </div>
                </div>
              ))}
              <div style={{ color: '#888', fontSize: '12px', fontStyle: 'italic', padding: '6px 2px' }}>
                Los cambios se guardan al instante. Reinicia el tótem para aplicarlos en la pantalla del cliente.
              </div>
            </div>
          )}
        </div>
      )}

      {editMode && editorTab === 'complements' && adminToken && (
        <div className="store-editor-complements">
          <div className="store-editor-comp-header">
            <span>Extras ({extras.length})</span>
            <button className="store-edit-cat-add-btn" onClick={() => { setComplementForm({ ...complementForm, type: 'extra' }); setComplementModal('extra'); }}>
              <FontAwesomeIcon icon={faPlus} /> Nuevo
            </button>
          </div>
          <div className="store-editor-comp-list">
            {extras.map(e => (
              <div key={e.id} className="store-editor-comp-item">
                {e.image && <img src={getImageUrl(e.image)} alt="" className="store-editor-comp-img" />}
                <div className="store-editor-comp-info">
                  <strong>{e.name}</strong>
                  {Number(e.price) > 0 && <span className="store-editor-comp-price">+${Number(e.price).toFixed(0)}</span>}
                </div>
                <button onClick={() => deleteComplement('extra', e.id)} className="store-prod-edit-btn danger" style={{ width: '24px', height: '24px', fontSize: '11px' }}>
                  <FontAwesomeIcon icon={faTrash} />
                </button>
              </div>
            ))}
            {extras.length === 0 && <span style={{ color: '#999', fontSize: '13px', padding: '8px' }}>Sin extras</span>}
          </div>

          <div className="store-editor-comp-header" style={{ marginTop: '12px' }}>
            <span>Ingredientes ({ingredients.length})</span>
            <button className="store-edit-cat-add-btn" onClick={() => { setComplementForm({ ...complementForm, type: 'ingredient' }); setComplementModal('ingredient'); }}>
              <FontAwesomeIcon icon={faPlus} /> Nuevo
            </button>
          </div>
          <div className="store-editor-comp-list">
            {ingredients.map(i => (
              <div key={i.id} className="store-editor-comp-item">
                {i.image && <img src={getImageUrl(i.image)} alt="" className="store-editor-comp-img" />}
                <div className="store-editor-comp-info">
                  <strong>{i.name}</strong>
                  {Number(i.price) > 0 && <span className="store-editor-comp-price">+${Number(i.price).toFixed(0)}</span>}
                </div>
                <button onClick={() => deleteComplement('ingredient', i.id)} className="store-prod-edit-btn danger" style={{ width: '24px', height: '24px', fontSize: '11px' }}>
                  <FontAwesomeIcon icon={faTrash} />
                </button>
              </div>
            ))}
            {ingredients.length === 0 && <span style={{ color: '#999', fontSize: '13px', padding: '8px' }}>Sin ingredientes</span>}
          </div>
        </div>
      )}


      {!editMode && activeCategory === 'all' && hasProducts && (
        <div className="category-sections">
          {(() => {
            const uncategorized = getSmartProducts().filter(p => !p.category_name);
            return uncategorized.length > 0 ? (
              <div className="products-grid">
                {uncategorized.map(product => renderProductCard(product))}
              </div>
            ) : null;
          })()}
          {Object.entries(groupedProducts).map(([category, products]) => (
            <div key={category} className="category-section">
              <div className="category-section-header">
                <div className="flex items-center gap-3">
                  <FontAwesomeIcon
                    icon={faTags}
                    className="category-section-icon"
                  />
                  <h3 className="category-section-title">
                    {category}
                  </h3>
                </div>
                <div className="category-section-line" />
              </div>
              <div className="products-grid">
                {products.map(product => renderProductCard(product))}
              </div>
            </div>
          ))}
        </div>
      )}

      {!editMode && activeCategory !== 'all' && hasProducts && (
        <div className="products-grid">
          {(store?.products || [])
            .filter(product => product.category_name === activeCategory)
            .map(product => renderProductCard(product))}
        </div>
      )}

      {editMode && editorTab === 'products' && (
        <DndContext
          sensors={editSensors}
          collisionDetection={closestCenter}
          onDragStart={handleEditDragStart}
          onDragEnd={handleEditDragEnd}
        >
          <SortableContext
            items={(store?.products || []).map(p => p.id)}
            strategy={rectSortingStrategy}
          >
            <div className="products-grid" style={{ padding: '0 16px' }}>
              {(store?.products || []).map(product => (
                <SortableProductCard key={product.id} product={product} onEdit={openProdModal} onDelete={deleteProd} currencySymbol={colors.currency.symbol} />
              ))}
              {renderAddProductCard()}
            </div>
          </SortableContext>
          <DragOverlay>
            {editDragActiveId ? (() => {
              const product = store?.products?.find(p => p.id === editDragActiveId);
              if (!product) return null;
              return (
                <div className="store-product-wrapper" style={{ opacity: 0.8 }}>
                  <div className="store-product-card">
                    <div className="store-product-image">
                      {product.image ? (
                        <img src={getImageUrl(product.image)} alt={product.name} />
                      ) : (
                        <FontAwesomeIcon icon={faBox} className="placeholder-icon" />
                      )}
                    </div>
                  </div>
                </div>
              );
            })() : null}
          </DragOverlay>
        </DndContext>
      )}

      <PluginSlot name="store-footer" context={{ storeId: store?.store?.id, code }} />

      {hasProducts && (
      <div className="cart-bar">
        <div className="cart-bar-left" onClick={() => setCartOpen(true)}>
          <div className="cart-bar-icon">
            <FontAwesomeIcon icon={faShoppingCart} />
            <span className="cart-bar-count">{getCartCount()}</span>
          </div>
          <span className="cart-bar-text">{t('viewCart', lang)}</span>
        </div>
        <div className="cart-bar-right">
          <span className="cart-bar-total">
            {colors.currency.symbol}{Number(getCartTotal()).toFixed(2)}
          </span>
          <button
            onClick={() => setCartOpen(true)}
            className="cart-bar-pay-btn store-glow-pulse"
          >
            {t('pay', lang)}
          </button>
        </div>
      </div>
      )}

      {notification && (
        <div className="toast">
          {notification.image ? (
            <img
              src={getImageUrl(notification.image)}
              alt={notification.name}
              className="toast-image"
            />
          ) : (
            <div className="toast-placeholder">
              <FontAwesomeIcon icon={faBox} />
            </div>
          )}
          <div>
            <div className="toast-name">{notification.name}</div>
            {notification.agotado ? (
              <div className="toast-status-soldout">{t('soldOut', lang)}</div>
            ) : (
              <div className="toast-status-added">{t('added', lang)} <FontAwesomeIcon icon={faCheck} /></div>
            )}
          </div>
        </div>
      )}

      {!isTouchDevice && (
        <input
          ref={barcodeInputRef}
          type="text"
          inputMode="none"
          value={barcode}
          onChange={(e) => setBarcode(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && barcode) {
              e.preventDefault();
              handleBarcodeScan(barcode);
              setBarcode('');
            }
          }}
          className="barcode-input"
        />
      )}

      {ingredientsModalOpen && selectedProduct && (
        <div
          className="store-modal-overlay"
          onClick={() => setIngredientsModalOpen(false)}
        >
          <div
            className="store-modal"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="store-modal-header">
              <button
                onClick={() => {
                  setIngredientsModalOpen(false);
                  setProductModalStep('main');
                }}
                className="store-modal-close"
              >
                <FontAwesomeIcon icon={faTimes} />
              </button>
              <h2 style={{ margin: 0, padding: '10px 40px 0 40px' }}>
                {productModalStep === 'main' ? t('complements', lang) : '1. ' + t('complements', lang)}
              </h2>
            </div>

            <div className="flex justify-center items-center gap-3" style={{
              padding: '12px 20px',
              borderBottom: '2px solid var(--store-primary)'
            }}>
              <span className="font-bold" style={{ fontSize: '16px', color: 'var(--store-primary)' }}>
                {t('selected', lang)}:
              </span>
              <span className="font-bold" style={{
                fontSize: '20px',
                color: productConfig.selectedIngredients.length > 0 ? 'var(--store-accent)' : 'var(--store-primary)'
              }}>
                {productConfig.selectedIngredients.length}
              </span>
              {selectedProduct.max_ingredients > 0 && (
                <>
                  <span style={{ color: 'var(--store-primary)' }}>/</span>
                  <span className="font-bold" style={{ fontSize: '20px', color: 'var(--store-primary)' }}>
                    {selectedProduct.max_ingredients}
                  </span>
                </>
              )}
            </div>

            <div className="store-modal-body">
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(4, 1fr)',
                gap: '10px'
              }}>
                {selectedProduct.ingredients.map(ingredient => {
                  const ingredientIsOutOfStock = !ingredient.unlimited_stock && ingredient.stock === 0;
                  const isSelected = productConfig.selectedIngredients.find(i => i.id === ingredient.id);
                  return (
                  <div
                    key={ingredient.id}
                    className={`option-item${isSelected ? ' selected' : ''}`}
                    style={{
                      flexDirection: 'column',
                      padding: 0,
                      backgroundColor: ingredientIsOutOfStock ? '#f8f9fa' : (isSelected ? 'var(--store-accent)' : '#fff'),
                      borderColor: isSelected ? 'var(--store-accent)' : ingredientIsOutOfStock ? '#dc3545' : '#e0e0e0',
                      borderWidth: '2px',
                      cursor: ingredientIsOutOfStock ? 'not-allowed' : 'pointer',
                      overflow: 'hidden',
                      position: 'relative',
                      opacity: ingredientIsOutOfStock ? 0.6 : 1
                    }}
                    onClick={() => toggleIngredient(ingredient)}
                  >
                    {ingredientIsOutOfStock && (
                      <div style={{
                        position: 'absolute',
                        top: '8px',
                        left: '50%',
                        transform: 'translateX(-50%)',
                        backgroundColor: '#dc3545',
                        color: 'white',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        fontSize: '11px',
                        fontWeight: '600',
                        zIndex: 2,
                      }}>
                        {t('soldOut', lang)}
                      </div>
                    )}
                    {ingredient.unlimited_stock && (
                      <div style={{
                        position: 'absolute',
                        top: '8px',
                        left: '50%',
                        transform: 'translateX(-50%)',
                        backgroundColor: '#28a745',
                        color: 'white',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        fontSize: '11px',
                        fontWeight: '600',
                        zIndex: 2,
                      }}>
                        <FontAwesomeIcon icon={faInfinity} /> {t('stock', lang)}
                      </div>
                    )}
                    {ingredient.image ? (
                      <img
                        src={ingredient.image}
                        alt={ingredient.name}
                        style={{
                          width: '100%',
                          height: '140px',
                          objectFit: 'cover',
                          borderBottom: `1px solid ${isSelected ? 'var(--store-accent)' : '#e0e0e0'}`
                        }}
                      />
                    ) : (
                      <div style={{
                        width: '100%',
                        height: '140px',
                        backgroundColor: 'var(--store-primary)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderBottom: `1px solid ${isSelected ? 'var(--store-accent)' : '#e0e0e0'}`
                      }}>
                        <FontAwesomeIcon icon={faUtensils} style={{ fontSize: '48px', color: 'var(--store-accent)' }} />
                      </div>
                    )}
                    <div className="text-center" style={{ padding: '8px' }}>
                      <div style={{
                        fontWeight: '600',
                        fontSize: '13px',
                        color: isSelected ? '#fff' : 'var(--store-primary)',
                        marginBottom: '2px',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap'
                      }}>
                        {ingredient.name}
                      </div>
                      {Number(ingredient.price) > 0 && (
                        <div style={{
                          fontSize: '12px',
                          fontWeight: '600',
                          color: isSelected ? '#fff' : 'var(--store-accent)'
                        }}>
                          +{colors.currency.symbol}{Number(ingredient.price).toFixed(2)}
                        </div>
                      )}
                    </div>
                    {isSelected && (
                      <div style={{
                        position: 'absolute',
                        top: '4px',
                        right: '4px',
                        width: '22px',
                        height: '22px',
                        borderRadius: '50%',
                        backgroundColor: 'var(--store-primary)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        <FontAwesomeIcon icon={faCheck} style={{ fontSize: '12px', color: 'var(--store-accent)' }} />
                      </div>
                    )}
                  </div>
                );
                })}
              </div>
            </div>

            <div className="store-modal-footer">
              {productModalStep === 'main' ? (
                <button
                  onClick={() => setIngredientsModalOpen(false)}
                  className="btn btn-lg btn-full store-glow-pulse"
                  style={{
                    backgroundColor: 'var(--store-accent)',
                    color: 'var(--store-primary)',
                    fontWeight: '700'
                  }}
                >
                  {t('done', lang)}
                </button>
              ) : (
                <button
                  onClick={selectedProduct.extras?.length > 0 ? handleNextToExtras : addToCart}
                  disabled={addingToCart}
                  className="btn btn-lg btn-full store-glow-pulse"
                  style={{
                    backgroundColor: addingToCart ? '#28a745' : 'var(--store-accent)',
                    color: 'var(--store-primary)',
                    fontWeight: '700'
                  }}
                >
                  {selectedProduct.extras?.length > 0 ? <>{t('next', lang)} <FontAwesomeIcon icon={faChevronRight} /></> : (addingToCart ? t('addedExclaim', lang) : `${t('addBtn', lang)} - ${colors.currency.symbol}${(calculateProductPrice() * productConfig.quantity).toFixed(2)}`)}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {extrasModalOpen && selectedProduct && (
        <div
          className="store-modal-overlay"
          onClick={() => setExtrasModalOpen(false)}
        >
          <div
            className="store-modal"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="store-modal-header">
              <button
                onClick={() => {
                  setExtrasModalOpen(false);
                  setProductModalStep('main');
                }}
                className="store-modal-close"
              >
                <FontAwesomeIcon icon={faTimes} />
              </button>
              <h2 style={{ margin: 0, padding: '10px 40px 0 40px' }}>
                {productModalStep === 'main' ? t('extras', lang) : '2. ' + t('extras', lang)}
              </h2>
            </div>

            <div className="flex justify-center items-center gap-3" style={{
              padding: '12px 20px',
              borderBottom: '2px solid var(--store-primary)'
            }}>
              <span className="font-bold" style={{ fontSize: '16px', color: 'var(--store-primary)' }}>
                {t('selected', lang)}:
              </span>
              <span className="font-bold" style={{
                fontSize: '20px',
                color: productConfig.selectedExtras.length > 0 ? 'var(--store-accent)' : 'var(--store-primary)'
              }}>
                {productConfig.selectedExtras.length}
              </span>
              {selectedProduct.max_extras > 0 && (
                <>
                  <span style={{ color: 'var(--store-primary)' }}>/</span>
                  <span className="font-bold" style={{ fontSize: '20px', color: 'var(--store-primary)' }}>
                    {selectedProduct.max_extras}
                  </span>
                </>
              )}
            </div>

            <div className="store-modal-body">
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(4, 1fr)',
                gap: '10px'
              }}>
                {selectedProduct.extras.map(extra => {
                  const extraIsOutOfStock = !extra.unlimited_stock && extra.stock === 0;
                  const isSelected = productConfig.selectedExtras.find(e => e.id === extra.id);
                  return (
                  <div
                    key={extra.id}
                    className={`option-item${isSelected ? ' selected' : ''}`}
                    style={{
                      flexDirection: 'column',
                      padding: 0,
                      backgroundColor: extraIsOutOfStock ? '#f8f9fa' : (isSelected ? 'var(--store-accent)' : '#fff'),
                      borderColor: isSelected ? 'var(--store-accent)' : extraIsOutOfStock ? '#dc3545' : '#e0e0e0',
                      borderWidth: '2px',
                      cursor: extraIsOutOfStock ? 'not-allowed' : 'pointer',
                      overflow: 'hidden',
                      position: 'relative',
                      opacity: extraIsOutOfStock ? 0.6 : 1
                    }}
                    onClick={() => toggleExtra(extra)}
                  >
                    {extraIsOutOfStock && (
                      <div style={{
                        position: 'absolute',
                        top: '8px',
                        left: '50%',
                        transform: 'translateX(-50%)',
                        backgroundColor: '#dc3545',
                        color: 'white',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        fontSize: '11px',
                        fontWeight: '600',
                        zIndex: 2,
                      }}>
                        {t('soldOut', lang)}
                      </div>
                    )}
                    {extra.unlimited_stock && (
                      <div style={{
                        position: 'absolute',
                        top: '8px',
                        left: '50%',
                        transform: 'translateX(-50%)',
                        backgroundColor: '#28a745',
                        color: 'white',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        fontSize: '11px',
                        fontWeight: '600',
                        zIndex: 2,
                      }}>
                        <FontAwesomeIcon icon={faInfinity} /> {t('stock', lang)}
                      </div>
                    )}
                    {extra.image ? (
                      <img
                        src={extra.image}
                        alt={extra.name}
                        style={{
                          width: '100%',
                          height: '140px',
                          objectFit: 'cover',
                          borderBottom: `1px solid ${isSelected ? 'var(--store-accent)' : '#e0e0e0'}`
                        }}
                      />
                    ) : (
                      <div style={{
                        width: '100%',
                        height: '140px',
                        backgroundColor: 'var(--store-primary)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderBottom: `1px solid ${isSelected ? 'var(--store-accent)' : '#e0e0e0'}`
                      }}>
                        <FontAwesomeIcon icon={faUtensils} style={{ fontSize: '48px', color: 'var(--store-accent)' }} />
                      </div>
                    )}
                    <div className="text-center" style={{ padding: '8px' }}>
                      <div style={{
                        fontWeight: '600',
                        fontSize: '13px',
                        color: isSelected ? '#fff' : 'var(--store-primary)',
                        marginBottom: '2px',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap'
                      }}>
                        {extra.name}
                      </div>
                      {Number(extra.price) > 0 && (
                        <div style={{
                          fontSize: '12px',
                          fontWeight: '600',
                          color: isSelected ? '#fff' : 'var(--store-accent)'
                        }}>
                          +{colors.currency.symbol}{Number(extra.price).toFixed(2)}
                        </div>
                      )}
                    </div>
                    {isSelected && (
                      <div style={{
                        position: 'absolute',
                        top: '4px',
                        right: '4px',
                        width: '22px',
                        height: '22px',
                        borderRadius: '50%',
                        backgroundColor: 'var(--store-primary)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        <FontAwesomeIcon icon={faCheck} style={{ fontSize: '12px', color: 'var(--store-accent)' }} />
                      </div>
                    )}
                  </div>
                );
                })}
              </div>
            </div>

            <div className="store-modal-footer">
              {productModalStep === 'main' ? (
                <button
                  onClick={() => setExtrasModalOpen(false)}
                  className="btn btn-lg btn-full store-glow-pulse"
                  style={{
                    backgroundColor: 'var(--store-accent)',
                    color: 'var(--store-primary)',
                    fontWeight: '700'
                  }}
                >
                  {t('done', lang)}
                </button>
              ) : (
                <button
                  onClick={addToCart}
                  disabled={addingToCart}
                  className="btn btn-lg btn-full store-glow-pulse"
                  style={{
                    backgroundColor: addingToCart ? '#28a745' : 'var(--store-accent)',
                    color: 'var(--store-primary)',
                    fontWeight: '700'
                  }}
                >
                  {addingToCart ? t('addedExclaim', lang) : `${t('addBtn', lang)} - ${colors.currency.symbol}${(calculateProductPrice() * productConfig.quantity).toFixed(2)}`}
                </button>
              )}
            </div>
          </div>
        </div>
      )}


      {cartOpen && (
        <div className="cart-overlay" onClick={() => setCartOpen(false)} />
      )}

      <div className={`store-cart-sheet${cartOpen ? ' open' : ''}`}>
        <div className="store-cart-handle" onClick={() => setCartOpen(false)}>
          <div className="store-cart-handle-bar" />
        </div>

        <div className="store-cart-header">
          <div className="store-cart-header-left">
            <FontAwesomeIcon icon={faShoppingCart} />
            <h2>{t('myOrder', lang)}</h2>
          </div>
          <button className="store-cart-close" onClick={() => setCartOpen(false)}>
            <FontAwesomeIcon icon={faTimes} />
          </button>
        </div>

        <div className="store-cart-body">
          {cart.length === 0 ? (
            <div className="store-cart-empty">
              <FontAwesomeIcon icon={faShoppingCart} className="store-cart-empty-icon" />
              <p className="store-cart-empty-title">{t('cartEmpty', lang)}</p>
              <p className="store-cart-empty-text">{t('cartEmptyDesc', lang)}</p>
            </div>
          ) : (
            <>
              {cart.map(item => (
                <div className="store-cart-item" key={item.id}>
                  <div className="store-cart-item-thumb">
                    {item.product_image ? (
                      <img src={getImageUrl(item.product_image)} alt={item.product_name} />
                    ) : (
                      <FontAwesomeIcon icon={faBox} className="store-cart-item-thumb-icon" />
                    )}
                  </div>
                  <div className="store-cart-item-content">
                    <div className="store-cart-item-top">
                      <h4 className="store-cart-item-name">{item.product_name}</h4>
                      <button className="store-cart-item-remove" onClick={() => removeFromCart(item.id)}>
                        <FontAwesomeIcon icon={faTimes} />
                      </button>
                    </div>

                    {item.selected_ingredients && item.selected_ingredients.length > 0 && (
                      <div className="store-cart-item-extras">{item.selected_ingredients.join(', ')}</div>
                    )}
                    {item.selected_extras && item.selected_extras.length > 0 && (
                      <div className="store-cart-item-extras">+ {item.selected_extras.join(', ')}</div>
                    )}

                    <div className="store-cart-item-bottom">
                      <div className="store-cart-qty">
                        <button className="store-cart-qty-btn" onClick={() => updateQuantity(item.id, -1)}>
                          <FontAwesomeIcon icon={faMinus} />
                        </button>
                        <span className="store-cart-qty-value">{item.quantity}</span>
                        <button className="store-cart-qty-btn" onClick={() => updateQuantity(item.id, 1)}>
                          <FontAwesomeIcon icon={faPlus} />
                        </button>
                      </div>
                      <div className="store-cart-item-total">
                        {colors.currency.symbol}{Number(item.total).toFixed(2)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              <div className="store-cart-summary">
                {appliedCoupon && (
                  <div className="store-cart-summary-row store-cart-discount">
                    <span>{t('discount', lang)} ({appliedCoupon.coupon_code})</span>
                    <span>-{colors.currency.symbol}{Number(appliedCoupon.discount_total || 0).toFixed(2)}</span>
                  </div>
                )}
                <div className="store-cart-summary-total">
                  <span>{t('total', lang)}</span>
                  <span>{colors.currency.symbol}{Number(getFinalTotal()).toFixed(2)}</span>
                </div>
                <div className="store-cart-coupon">
                  <input
                    type="text"
                    value={couponCodeInput}
                    onChange={(e) => setCouponCodeInput(e.target.value.toUpperCase())}
                    placeholder={t('couponCode', lang)}
                    className="store-cart-coupon-input"
                  />
                  {appliedCoupon ? (
                    <button onClick={removeCoupon} className="btn btn-danger btn-sm">{t('quit', lang)}</button>
                  ) : (
                    <button onClick={applyCoupon} disabled={couponLoading || !couponCodeInput.trim()} className="btn btn-secondary btn-sm">
                      {couponLoading ? '...' : t('apply', lang)}
                    </button>
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {cart.length > 0 && (
          <div className="store-cart-footer">
            {selectedConfiguration?.allow_serve && selectedConfiguration?.allow_takeout && (
              <div className="store-cart-order-type">
                <label className="store-cart-order-label">{t('orderType', lang)}</label>
                <div className="store-cart-type-grid">
                  <button
                    onClick={() => setOrderType('serve')}
                    className={`store-cart-type-btn${orderType === 'serve' ? ' active store-glow-pulse' : ''}`}
                  >
                    <FontAwesomeIcon icon={faBox} />
                    <span>{t('serveHere', lang)}</span>
                  </button>
                  <button
                    onClick={() => setOrderType('takeout')}
                    className={`store-cart-type-btn${orderType === 'takeout' ? ' active store-glow-pulse' : ''}`}
                  >
                    <FontAwesomeIcon icon={faShoppingCart} />
                    <span>{t('takeoutShort', lang)}</span>
                  </button>
                </div>
              </div>
            )}

            <button onClick={handleCheckout} className="store-cart-checkout-btn store-glow-pulse">
              <FontAwesomeIcon icon={faCheck} />
              {t('confirmOrder', lang)} - {colors.currency.symbol}{Number(getFinalTotal()).toFixed(2)}
            </button>

            <button
              onClick={(e) => { e.stopPropagation(); handleLongPressEnd(); setCart([]); setAppliedCoupon(null); setCouponCodeInput(''); }}
              onMouseDown={(e) => { e.stopPropagation(); handleLongPressEnd(); }}
              onTouchStart={(e) => { e.stopPropagation(); handleLongPressEnd(); }}
              className="store-cart-clear-btn"
            >
              <FontAwesomeIcon icon={faTimesCircle} />
              {t('clearCart', lang)}
            </button>
          </div>
        )}
      </div>

      {paymentModalOpen && (
        <div className="modal-overlay">
          <div className="modal text-center" style={{ maxWidth: '400px' }}>
            <h2 style={{
              color: 'var(--store-primary)',
              marginBottom: '10px',
              fontSize: '24px'
            }}>
              {processingPayment ? t('processingPayment', lang) : t('paymentMethod', lang)}
            </h2>
            <p className="text-muted" style={{ marginBottom: '25px', fontSize: '14px' }}>
              {processingPayment
                ? (paymentMethod === 'card'
                    ? t('tapCardTerminal', lang)
                    : t('processing', lang))
                : t('selectPaymentMethod', lang)
              }
            </p>

            {processingPayment ? (
              <div className="flex flex-col items-center" style={{ padding: '40px', gap: '20px' }}>
                <div style={{
                  width: '60px',
                  height: '60px',
                  border: '5px solid var(--store-accent)',
                  borderTop: '5px solid var(--store-primary)',
                  borderRadius: '50%',
                  animation: 'spin 1s linear infinite'
                }} />
                <p className="text-muted" style={{ fontSize: '14px' }}>
                  {t('waitingTerminal', lang)}
                </p>
              </div>
            ) : (
              <>
                <div className="flex flex-col" style={{ gap: '15px' }}>
                  {selectedConfiguration?.accept_card && (
                    <button
                      onClick={() => processPayment('card')}
                      className="btn btn-lg btn-full store-glow-pulse"
                      style={{
                        backgroundColor: 'var(--store-secondary)',
                        color: 'var(--store-primary)',
                        border: '3px solid #ddd',
                        borderRadius: '15px'
                      }}
                    >
                      <FontAwesomeIcon icon={faCreditCard} style={{ fontSize: '28px' }} />
                      <span className="font-bold" style={{ fontSize: '18px' }}>{t('card', lang)}</span>
                    </button>
                  )}


                  {selectedConfiguration?.accept_cash && (
                    <button
                      onClick={() => processPayment('cash')}
                      className="btn btn-lg btn-full store-glow-pulse"
                      style={{
                        backgroundColor: 'var(--store-secondary)',
                        color: 'var(--store-primary)',
                        border: '3px solid #ddd',
                        borderRadius: '15px'
                      }}
                    >
                      <FontAwesomeIcon icon={faMoneyBillWave} style={{ fontSize: '28px' }} />
                      <span className="font-bold" style={{ fontSize: '18px' }}>{t('cash', lang)}</span>
                    </button>
                  )}

                  {qrProvider && deliveryMode && (
                    <button
                      onClick={() => processPayment('qr')}
                      className="btn btn-lg btn-full store-glow-pulse"
                      style={{
                        backgroundColor: 'var(--store-secondary)',
                        color: 'var(--store-primary)',
                        border: '3px solid #D4AF37',
                        borderRadius: '15px'
                      }}
                    >
                      <FontAwesomeIcon icon={faQrcode} style={{ fontSize: '28px' }} />
                      <span className="font-bold" style={{ fontSize: '18px' }}>{t('payWithQR', lang)}</span>
                    </button>
                  )}

                  {!selectedConfiguration?.accept_cash && !selectedConfiguration?.accept_card && !qrProvider && (
                    <p className="text-muted">{t('noPaymentMethods', lang)}</p>
                  )}
                </div>

                {selectedConfiguration?.accept_card && (
                  <div className="text-muted text-sm" style={{ marginTop: '14px' }}>
                    {pluginPaymentProvider ? (
                      <><FontAwesomeIcon icon={faCreditCard} /> Procesará con <strong>Tuu</strong> — {pluginPaymentProvider.deviceName}</>
                    ) : (
                      <>{t('terminalAssigned', lang)}{' '}
                      <strong>
                        {localStorage.getItem('srservi_last_terminalName') || localStorage.getItem('srservi_last_terminal_id') || 'MercadoPago'}
                      </strong></>
                    )}
                  </div>
                )}

                <p style={{
                  color: '#999',
                  marginTop: '20px',
                  fontSize: '13px',
                  fontStyle: 'italic'
                }}>
                  {t('tapPaymentInfo', lang)}
                </p>

                <button
                  onClick={() => {
                    setPaymentModalOpen(false);
                  }}
                  className="btn"
                  style={{
                    marginTop: '10px',
                    backgroundColor: 'transparent',
                    color: '#666',
                    border: 'none'
                  }}
                >
                  {t('cancel', lang)}
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {paymentWaiting && (
        <div className="modal-overlay">
          <div className="modal text-center" style={{ maxWidth: '400px', padding: '40px' }}>
            <h2 style={{ color: 'var(--store-primary)', marginBottom: '10px', fontSize: '24px' }}>
              {qrPaymentUrl ? t('scanQRToPay', lang) : t('waitingPayment', lang)}
            </h2>

            {qrPaymentUrl ? (
              <>
                <p className="text-muted" style={{ marginBottom: '15px', fontSize: '14px' }}>
                  {t('scanQRDesc', lang)}
                </p>
                <div style={{ margin: '0 auto 15px', display: 'flex', justifyContent: 'center' }}>
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrPaymentUrl)}`}
                    alt="QR"
                    style={{ width: '200px', height: '200px', borderRadius: '12px', border: '2px solid #e0e0e0' }}
                  />
                </div>
                <a
                  href={qrPaymentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-primary"
                  style={{ display: 'inline-block', marginBottom: '15px', padding: '12px 24px', borderRadius: '10px', textDecoration: 'none', background: 'var(--store-accent)', color: 'var(--store-primary)', fontWeight: '700' }}
                >
                  {t('openPaymentLink', lang)}
                </a>
              </>
            ) : (
              <>
                <p className="text-muted" style={{ marginBottom: '20px', fontSize: '14px' }}>
                  {t('tapCardTerminal', lang)}
                </p>
                <div style={{
                  width: '80px',
                  height: '80px',
                  border: '6px solid var(--store-accent)',
                  borderTop: '6px solid var(--store-primary)',
                  borderRadius: '50%',
                  animation: 'spin 1s linear infinite',
                  margin: '0 auto 20px'
                }} />
              </>
            )}
            <p className="text-muted" style={{ fontSize: '14px', marginBottom: '10px' }}>
              {t('waitingPaymentConfirm', lang)}
            </p>
            <p className="font-bold" style={{
              color: paymentTimeLeft <= 30 ? '#DC3545' : 'var(--store-primary)',
              fontSize: '24px',
              marginBottom: '20px'
            }}>
              {Math.floor(paymentTimeLeft / 60)}:{String(paymentTimeLeft % 60).padStart(2, '0')}
            </p>
            <button
              onClick={async () => {
                if (!pendingOrderData) return;
                try {
                  await fetch(`/api/orders/${pendingOrderData.order.id}/cancel-payment`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ store_id: pendingOrderData.storeId })
                  });
                  if (pluginPaymentKey) {
                    await fetch(`/api/plugins/payments/cancel/${pluginPaymentKey}`, { method: 'POST' });
                  }
                } catch (e) { console.error(e); }
                setPaymentWaiting(false); setQrPaymentUrl(null);
                setPaymentCancelled(true);
              }}
              className="btn btn-danger"
              style={{ padding: '12px 24px', borderRadius: '10px' }}
            >
              {t('cancelPayment', lang)}
            </button>
          </div>
        </div>
      )}

      {qrPaymentResult && (
        <div className="modal-overlay">
          <div className="modal text-center" style={{ maxWidth: '400px', padding: '30px 24px' }}>
            {qrPaymentResult.success ? (
              <>
                <FontAwesomeIcon icon={faCheckCircle} style={{ fontSize: '50px', marginBottom: '12px', color: 'var(--success)' }} />
                <h2 style={{ color: 'var(--store-primary)', marginBottom: '4px', fontSize: '22px' }}>
                  {t('paymentSuccess', lang)}
                </h2>
                <p className="text-muted" style={{ marginBottom: '16px', fontSize: '13px' }}>
                  {qrPaymentResult.message}
                </p>

                {qrPaymentResult.order?.order_number && (
                  <div id="qr-order-card" style={{
                    background: 'var(--store-primary)',
                    color: 'var(--store-secondary)',
                    borderRadius: '20px',
                    padding: '24px 20px',
                    marginBottom: '16px',
                    border: '4px solid var(--store-accent)'
                  }}>
                    <p style={{ fontSize: '13px', margin: '0 0 8px', opacity: 0.8, textTransform: 'uppercase', letterSpacing: '2px' }}>{t('yourOrder', lang)}</p>
                    <p style={{ fontSize: '90px', fontWeight: '900', margin: '0', lineHeight: '1', color: 'var(--store-accent)' }}>
                      #{qrPaymentResult.order.order_number}
                    </p>
                    <p style={{ fontSize: '12px', marginTop: '12px', marginBottom: 0, opacity: 0.7 }}>
                      {store?.store?.name}
                    </p>
                  </div>
                )}

                <div style={{ background: '#f8f8f8', borderRadius: '10px', padding: '12px', marginBottom: '14px', fontSize: '12px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0' }}>
                    <span style={{ color: '#888' }}>{t('amount', lang)}</span>
                    <span style={{ fontWeight: '700' }}>${qrPaymentResult.amount}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', borderTop: '1px solid #eee' }}>
                    <span style={{ color: '#888' }}>{t('reference', lang)}</span>
                    <span style={{ fontFamily: 'monospace', fontSize: '10px', color: '#555' }}>{qrPaymentResult.reference}</span>
                  </div>
                </div>

                {qrPaymentResult.order?.order_number && (
                  <button
                    onClick={() => {
                      const orderNum = qrPaymentResult.order.order_number;
                      const storeName = store?.store?.name || 'Tienda';
                      const canvas = document.createElement('canvas');
                      canvas.width = 600;
                      canvas.height = 800;
                      const ctx = canvas.getContext('2d');

                      // Background
                      ctx.fillStyle = '#000000';
                      ctx.fillRect(0, 0, 600, 800);

                      // Border
                      ctx.strokeStyle = '#D4AF37';
                      ctx.lineWidth = 12;
                      ctx.strokeRect(20, 20, 560, 760);

                      // Title
                      ctx.fillStyle = '#FFFFFF';
                      ctx.font = 'bold 28px Arial';
                      ctx.textAlign = 'center';
                      ctx.fillText('TU PEDIDO', 300, 130);

                      // Big order number (auto-fit)
                      ctx.fillStyle = '#D4AF37';
                      const orderText = '#' + orderNum;
                      let fontSize = 220;
                      ctx.font = `bold ${fontSize}px Arial`;
                      while (ctx.measureText(orderText).width > 480 && fontSize > 60) {
                        fontSize -= 10;
                        ctx.font = `bold ${fontSize}px Arial`;
                      }
                      ctx.fillText(orderText, 300, 420);

                      // Store name
                      ctx.fillStyle = '#FFFFFF';
                      ctx.font = '24px Arial';
                      ctx.fillText(storeName, 300, 580);

                      // Amount
                      ctx.font = 'bold 32px Arial';
                      ctx.fillText('$' + qrPaymentResult.amount, 300, 640);

                      // Pago confirmado
                      ctx.fillStyle = '#22c55e';
                      ctx.font = 'bold 22px Arial';
                      ctx.fillText('PAGO CONFIRMADO', 300, 700);

                      // Reference small
                      ctx.fillStyle = '#888';
                      ctx.font = '12px monospace';
                      ctx.fillText(qrPaymentResult.reference, 300, 740);

                      const link = document.createElement('a');
                      link.download = `pedido-${orderNum}.png`;
                      link.href = canvas.toDataURL('image/png');
                      link.click();
                    }}
                    className="btn"
                    style={{ background: 'var(--store-accent)', color: 'var(--store-primary)', border: 'none', borderRadius: '10px', padding: '12px 20px', fontWeight: '700', marginBottom: '10px', width: '100%' }}
                  >
                    <FontAwesomeIcon icon={faDownload} /> {t('downloadReceipt', lang)}
                  </button>
                )}
              </>
            ) : (
              <>
                <FontAwesomeIcon icon={faTimesCircle} style={{ fontSize: '60px', marginBottom: '20px', color: '#dc3545' }} />
                <h2 style={{ color: '#dc3545', marginBottom: '10px', fontSize: '24px' }}>
                  {t('paymentNotCompleted', lang)}
                </h2>
                <p className="text-muted" style={{ marginBottom: '15px', fontSize: '14px' }}>
                  {qrPaymentResult.message || t('paymentNotProcessed', lang)}
                </p>
              </>
            )}
            <button
              onClick={() => {
                setQrPaymentResult(null);
                window.history.replaceState({}, '', `/store/${code}${deliveryMode ? '?delivery=true' : ''}`);
              }}
              className="btn btn-primary btn-lg"
              style={{ borderRadius: '10px', padding: '12px 30px' }}
            >
              {t('continueText', lang)}
            </button>
          </div>
        </div>
      )}

      {paymentConfirmed && (
        <div className="modal-overlay">
          <div className="modal text-center" style={{ maxWidth: '400px', padding: '40px' }}>
            <FontAwesomeIcon icon={faCheckCircle} style={{ fontSize: '60px', marginBottom: '20px', color: 'var(--success)' }} />
            <h2 style={{ color: 'var(--store-primary)', marginBottom: '10px', fontSize: '24px' }}>
              {t('thankYouPurchase', lang)}
            </h2>
            <p className="text-muted" style={{ marginBottom: '20px', fontSize: '16px' }}>
              {t('pleaseWait', lang)}
            </p>
            {lastOrderNumber && (
              <div style={{
                backgroundColor: 'var(--store-primary)',
                color: 'var(--store-secondary)',
                padding: '20px',
                borderRadius: '15px',
                marginBottom: '20px'
              }}>
                <p style={{ fontSize: '14px', marginBottom: '5px', opacity: 0.8 }}>{t('orderNumberLabel', lang)}</p>
                <p className="font-bold" style={{ fontSize: '48px', margin: 0 }}>{lastOrderNumber}</p>
              </div>
            )}
            <button
              onClick={() => {
                setPaymentConfirmed(false);
                setPendingOrderData(null);
                setLastOrderNumber(null);
                showWelcomeAfterOrder();
              }}
              className="btn btn-lg btn-full"
              style={{
                marginTop: '25px',
                backgroundColor: 'var(--store-accent)',
                color: 'var(--store-primary)'
              }}
            >
              {t('confirm', lang)}
            </button>
          </div>
        </div>
      )}

      {paymentCancelled && (
        <div className="modal-overlay">
          <div className="modal text-center" style={{ maxWidth: '400px', padding: '40px' }}>
            <FontAwesomeIcon icon={faTimesCircle} style={{ fontSize: '60px', marginBottom: '20px', color: 'var(--danger)' }} />
            <h2 style={{ color: '#DC3545', marginBottom: '10px', fontSize: '24px' }}>
              {t('paymentNotCompleted', lang)}
            </h2>
            {pendingOrderData?.order?.order_number && (
              <p className="font-bold" style={{ color: '#DC3545', marginBottom: '10px', fontSize: '18px' }}>
                {t('orderNumberLabel', lang)} #{pendingOrderData.order.order_number}
              </p>
            )}
            <p className="text-muted" style={{ marginBottom: '25px', fontSize: '14px' }}>
              {t('paymentNotCompletedDesc', lang)}
            </p>
            <div className="flex flex-col" style={{ gap: '15px' }}>
              {selectedConfiguration?.accept_card && (
                <button
                  onClick={() => {
                    setPaymentCancelled(false);
                    setPendingOrderData(null);
                    setProcessingPayment(true);
                    processPayment('card');
                  }}
                  className="btn btn-lg btn-full"
                  style={{
                    backgroundColor: 'var(--store-primary)',
                    color: 'var(--store-secondary)',
                    borderRadius: '15px'
                  }}
                >
                  <FontAwesomeIcon icon={faCreditCard} style={{ fontSize: '22px' }} />
                  <span className="font-bold" style={{ fontSize: '18px' }}>{t('retryCard', lang)}</span>
                </button>
              )}
              {selectedConfiguration?.accept_cash && (
                <button
                  onClick={() => {
                    setPaymentCancelled(false);
                    setPaymentModalOpen(true);
                  }}
                  className="btn btn-lg btn-full"
                  style={{
                    backgroundColor: 'var(--store-accent)',
                    color: 'var(--store-primary)',
                    borderRadius: '15px'
                  }}
                >
                  <FontAwesomeIcon icon={faMoneyBillWave} style={{ fontSize: '22px' }} />
                  <span className="font-bold" style={{ fontSize: '18px' }}>{t('payCash', lang)}</span>
                </button>
              )}
              <button
                onClick={async () => {
                  try {
                    await fetch(`/api/orders/${pendingOrderData.order.id}/cancel-payment`, {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ store_id: pendingOrderData.storeId })
                    });
                    if (pluginPaymentKey) {
                      await fetch(`/api/plugins/payments/cancel/${pluginPaymentKey}`, { method: 'POST' });
                    }
                  } catch (e) { console.error(e); }
                  setPaymentCancelled(false);
                  setPendingOrderData(null);
                  setPaymentWaiting(false); setQrPaymentUrl(null);
                  setCart([]);
                  setCartOpen(false);
                  setPaymentModalOpen(false);
                }}
                className="btn btn-danger btn-lg btn-full"
                style={{ borderRadius: '15px' }}
              >
                <FontAwesomeIcon icon={faTimesCircle} style={{ fontSize: '22px' }} />
                <span className="font-bold" style={{ fontSize: '18px' }}>{t('cancelOrder', lang)}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {cashPaymentSuccess && (
        <div className="modal-overlay">
          <div className="modal text-center" style={{ maxWidth: '400px', padding: '40px' }}>
            <FontAwesomeIcon icon={faCheckCircle} style={{ fontSize: '60px', marginBottom: '20px', color: 'var(--success)' }} />
            <h2 style={{ color: 'var(--store-primary)', marginBottom: '10px', fontSize: '24px' }}>
              {t('thankYouPurchase', lang)}
            </h2>
            <p className="text-muted" style={{ marginBottom: '20px', fontSize: '16px' }}>
              {t('pleaseWait', lang)}
            </p>
            {lastOrderNumber && (
              <div style={{
                backgroundColor: 'var(--store-primary)',
                color: 'var(--store-secondary)',
                padding: '20px',
                borderRadius: '15px',
                marginBottom: '20px'
              }}>
                <p style={{ fontSize: '14px', marginBottom: '5px', opacity: 0.8 }}>{t('orderNumberLabel', lang)}</p>
                <p className="font-bold" style={{ fontSize: '48px', margin: 0 }}>{lastOrderNumber}</p>
              </div>
            )}
            <p style={{
              color: '#999',
              fontSize: '13px',
              fontStyle: 'italic'
            }}>
              {t('cashAtCounter', lang)}
            </p>
            <button
              onClick={() => {
                setLastOrderNumber(null);
                showWelcomeAfterOrder();
              }}
              className="btn btn-lg btn-full"
              style={{
                marginTop: '25px',
                backgroundColor: 'var(--store-accent)',
                color: 'var(--store-primary)'
              }}
            >
              {t('confirm', lang)}
            </button>
          </div>
        </div>
      )}
      {prodModalOpen && (
        <div className="store-modal-overlay" onClick={() => setProdModalOpen(false)} onMouseDown={(e) => e.stopPropagation()} onTouchStart={(e) => e.stopPropagation()}>
          <div className="store-prod-modal" onClick={(e) => e.stopPropagation()}>
            <h3 style={{ margin: '0 0 14px', color: 'var(--store-primary)', textAlign: 'center' }}>
              {editingProd ? 'Editar Producto' : 'Nuevo Producto'}
            </h3>

            <div className="store-prod-modal-image-area">
              {prodImageFile ? (
                <img src={URL.createObjectURL(prodImageFile)} alt="Preview" className="store-prod-modal-preview" />
              ) : editingProd?.image ? (
                <img src={getImageUrl(editingProd.image)} alt="Actual" className="store-prod-modal-preview" />
              ) : (
                <div className="store-prod-modal-no-image">
                  <FontAwesomeIcon icon={faBox} />
                </div>
              )}
              <label className="store-prod-modal-image-btn">
                <FontAwesomeIcon icon={faEdit} /> {prodImageFile || editingProd?.image ? 'Cambiar' : 'Agregar imagen'}
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => { if (e.target.files[0]) setProdImageFile(e.target.files[0]); }}
                  style={{ display: 'none' }}
                />
              </label>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <input
                type="text"
                value={prodForm.name}
                onChange={(e) => setProdForm({ ...prodForm, name: e.target.value })}
                placeholder="Nombre del producto"
                autoFocus={false}
                className="store-prod-modal-input main"
              />
              <div style={{ display: 'flex', gap: '8px' }}>
                <input
                  type="number"
                  step="0.01"
                  value={prodForm.price}
                  onChange={(e) => setProdForm({ ...prodForm, price: e.target.value })}
                  placeholder="Precio"
                  className="store-prod-modal-input"
                  style={{ flex: 1 }}
                />
                <select
                  value={prodForm.category_id}
                  onChange={(e) => setProdForm({ ...prodForm, category_id: e.target.value })}
                  className="store-prod-modal-input"
                  style={{ flex: 1 }}
                >
                  <option value="">Sin categoría</option>
                  {(store?.categories || []).map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>
              <input
                type="text"
                value={prodForm.description}
                onChange={(e) => setProdForm({ ...prodForm, description: e.target.value })}
                placeholder="Descripción (opcional)"
                className="store-prod-modal-input"
              />
              <input
                type="text"
                value={prodForm.barcode}
                onChange={(e) => setProdForm({ ...prodForm, barcode: e.target.value })}
                placeholder="Código de barras (escanear o escribir)"
                className="store-prod-modal-input"
                style={{ fontFamily: 'monospace', letterSpacing: '1px' }}
              />
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '14px', cursor: 'pointer', flex: 1 }}>
                  <input type="checkbox" checked={prodForm.unlimited_stock} onChange={(e) => setProdForm({ ...prodForm, unlimited_stock: e.target.checked })} />
                  Stock ilimitado
                </label>
                {!prodForm.unlimited_stock && (
                  <input
                    type="number"
                    min="0"
                    value={prodForm.stock}
                    onChange={(e) => setProdForm({ ...prodForm, stock: e.target.value })}
                    placeholder="Stock"
                    className="store-prod-modal-input"
                    style={{ width: '80px' }}
                  />
                )}
              </div>

              {adminToken && (
                <div style={{ borderTop: '1px solid #e0e0e0', paddingTop: '12px', marginTop: '4px' }}>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '10px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 10px', borderRadius: '8px', border: '2px solid', borderColor: prodForm.has_extras ? '#22c55e' : '#e0e0e0', background: prodForm.has_extras ? '#dcfce7' : '#fafafa' }}>
                      <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '13px', fontWeight: '600', margin: 0 }}>
                        <input type="checkbox" checked={prodForm.has_extras} onChange={(e) => setProdForm({ ...prodForm, has_extras: e.target.checked })} style={{ width: '18px', height: '18px' }} />
                        Lleva Extras
                      </label>
                      {prodForm.has_extras && (
                        <input type="number" min="0" value={prodForm.max_extras} onChange={(e) => setProdForm({ ...prodForm, max_extras: e.target.value })} placeholder="Max (0=ilim)" className="store-prod-modal-input" style={{ width: '100px', padding: '5px 8px', fontSize: '13px' }} />
                      )}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 10px', borderRadius: '8px', border: '2px solid', borderColor: prodForm.has_ingredients ? '#22c55e' : '#e0e0e0', background: prodForm.has_ingredients ? '#dcfce7' : '#fafafa' }}>
                      <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '13px', fontWeight: '600', margin: 0 }}>
                        <input type="checkbox" checked={prodForm.has_ingredients} onChange={(e) => setProdForm({ ...prodForm, has_ingredients: e.target.checked })} style={{ width: '18px', height: '18px' }} />
                        Lleva Complementos
                      </label>
                      {prodForm.has_ingredients && (
                        <input type="number" min="0" value={prodForm.max_ingredients} onChange={(e) => setProdForm({ ...prodForm, max_ingredients: e.target.value })} placeholder="Max (0=ilim)" className="store-prod-modal-input" style={{ width: '100px', padding: '5px 8px', fontSize: '13px' }} />
                      )}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <button
                      onClick={() => { setComplementsTab('complements'); setShowComplementsModal(true); }}
                      style={{ flex: 1, padding: '10px', fontSize: '13px', fontWeight: '600', borderRadius: '8px', border: '2px solid var(--store-primary)', background: 'var(--store-secondary)', color: 'var(--store-primary)', cursor: 'pointer' }}
                    >
                      Complementos {selectedIngredientIds.length > 0 && <span style={{ fontSize: '11px', opacity: 0.7 }}>({selectedIngredientIds.length})</span>}
                    </button>
                    <button
                      onClick={() => { setComplementsTab('extras'); setShowComplementsModal(true); }}
                      style={{ flex: 1, padding: '10px', fontSize: '13px', fontWeight: '600', borderRadius: '8px', border: '2px solid var(--store-primary)', background: 'var(--store-secondary)', color: 'var(--store-primary)', cursor: 'pointer' }}
                    >
                      Extras {selectedExtraIds.length > 0 && <span style={{ fontSize: '11px', opacity: 0.7 }}>({selectedExtraIds.length})</span>}
                    </button>
                  </div>
                </div>
              )}
            </div>
            <div style={{ display: 'flex', gap: '8px', marginTop: '14px' }}>
              <button
                onClick={() => { setProdModalOpen(false); setProdImageFile(null); setProdNewExtras([]); setProdNewComplements([]); }}
                className="store-prod-modal-btn cancel"
              >
                Cancelar
              </button>
              <button
                onClick={saveProd}
                disabled={!prodForm.name.trim() || !prodForm.price || prodSaving}
                className={`store-prod-modal-btn confirm${!prodForm.name.trim() || !prodForm.price || prodSaving ? ' disabled' : ''}`}
              >
                {prodSaving ? 'Guardando...' : editingProd ? 'Guardar' : 'Crear'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showComplementsModal && (
        <div className="store-modal-overlay" onClick={() => setShowComplementsModal(false)} onMouseDown={(e) => e.stopPropagation()} onTouchStart={(e) => e.stopPropagation()}>
          <div className="store-prod-modal" onClick={(e) => e.stopPropagation()} style={{ maxHeight: '85vh', display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', gap: '0', marginBottom: '14px', borderRadius: '8px', overflow: 'hidden', border: '2px solid var(--store-primary)' }}>
              <button
                onClick={() => setComplementsTab('complements')}
                style={{ flex: 1, padding: '10px', fontSize: '13px', fontWeight: '700', border: 'none', cursor: 'pointer', background: complementsTab === 'complements' ? 'var(--store-primary)' : 'var(--store-secondary)', color: complementsTab === 'complements' ? 'var(--store-secondary)' : 'var(--store-primary)' }}
              >
                Complementos
              </button>
              <button
                onClick={() => setComplementsTab('extras')}
                style={{ flex: 1, padding: '10px', fontSize: '13px', fontWeight: '700', border: 'none', cursor: 'pointer', background: complementsTab === 'extras' ? 'var(--store-primary)' : 'var(--store-secondary)', color: complementsTab === 'extras' ? 'var(--store-secondary)' : 'var(--store-primary)' }}
              >
                Extras
              </button>
            </div>

            <div style={{ flex: 1, overflowY: 'auto' }}>
              {complementsTab === 'complements' && (
                <>
                  {ingredients.length === 0 && prodNewComplements.length === 0 && (
                    <p style={{ textAlign: 'center', color: '#999', fontSize: '13px', padding: '16px 0' }}>No hay complementos creados</p>
                  )}
                  {ingredients.map(ing => {
                    const active = selectedIngredientIds.includes(ing.id);
                    return (
                      <div key={ing.id} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px', borderRadius: '8px', marginBottom: '4px', background: active ? 'rgba(0,128,0,0.08)' : '#fafafa', border: active ? '2px solid #2ecc71' : '2px solid transparent' }}>
                        <div onClick={() => setSelectedIngredientIds(active ? selectedIngredientIds.filter(id => id !== ing.id) : [...selectedIngredientIds, ing.id])} style={{ display: 'flex', alignItems: 'center', gap: '10px', flex: 1, cursor: 'pointer' }}>
                          <div style={{ width: '36px', height: '36px', borderRadius: '8px', overflow: 'hidden', flexShrink: 0, background: '#eee', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            {ing.image ? <img src={getImageUrl(ing.image)} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <FontAwesomeIcon icon={faBox} style={{ color: '#ccc' }} />}
                          </div>
                          <div style={{ flex: 1 }}>
                            <div style={{ fontSize: '14px', fontWeight: '600' }}>{ing.name}</div>
                            {Number(ing.price) > 0 && <div style={{ fontSize: '12px', color: '#888' }}>+${Number(ing.price).toFixed(0)}</div>}
                          </div>
                          <FontAwesomeIcon icon={active ? faCheckCircle : faTimesCircle} style={{ fontSize: '20px', color: active ? '#2ecc71' : '#ddd' }} />
                        </div>
                        <div style={{ display: 'flex', gap: '4px', flexShrink: 0 }}>
                          <button onClick={(ev) => { ev.stopPropagation(); setEditingComplement({ id: ing.id, type: 'ingredient', name: ing.name, price: ing.price?.toString() || '', imageFile: null }); }} style={{ background: 'none', border: 'none', color: 'var(--store-primary)', cursor: 'pointer', padding: '4px', fontSize: '13px' }}><FontAwesomeIcon icon={faEdit} /></button>
                          <button onClick={(ev) => { ev.stopPropagation(); deleteComplementFromModal('ingredient', ing.id); }} style={{ background: 'none', border: 'none', color: '#e74c3c', cursor: 'pointer', padding: '4px', fontSize: '13px' }}><FontAwesomeIcon icon={faTrash} /></button>
                        </div>
                      </div>
                    );
                  })}
                  {prodNewComplements.map((comp, i) => (
                    <div key={`new-${i}`} style={{ display: 'flex', gap: '6px', marginTop: '6px', alignItems: 'center', padding: '6px', background: '#fffbe6', borderRadius: '8px', border: '1px dashed #e6c200' }}>
                      <label style={{ width: '32px', height: '32px', borderRadius: '6px', background: comp.imageFile ? 'transparent' : '#f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0, overflow: 'hidden', border: '1px solid #ddd' }}>
                        {comp.imageFile ? <img src={URL.createObjectURL(comp.imageFile)} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <FontAwesomeIcon icon={faBox} style={{ fontSize: '12px', color: '#bbb' }} />}
                        <input type="file" accept="image/*" onChange={(e) => { if (e.target.files[0]) { const arr = [...prodNewComplements]; arr[i] = { ...arr[i], imageFile: e.target.files[0] }; setProdNewComplements(arr); } }} style={{ display: 'none' }} />
                      </label>
                      <input type="text" value={comp.name} onChange={(e) => { const arr = [...prodNewComplements]; arr[i] = { ...arr[i], name: e.target.value }; setProdNewComplements(arr); }} placeholder="Nombre" className="store-prod-modal-input" style={{ flex: 2, padding: '8px', fontSize: '13px' }} />
                      <input type="number" step="0.01" value={comp.price} onChange={(e) => { const arr = [...prodNewComplements]; arr[i] = { ...arr[i], price: e.target.value }; setProdNewComplements(arr); }} placeholder="$" className="store-prod-modal-input" style={{ flex: 1, padding: '8px', fontSize: '13px' }} />
                      <button onClick={() => setProdNewComplements(prodNewComplements.filter((_, j) => j !== i))} style={{ background: 'none', border: 'none', color: '#e74c3c', cursor: 'pointer', padding: '4px' }}><FontAwesomeIcon icon={faTimes} /></button>
                    </div>
                  ))}
                  <button onClick={() => setProdNewComplements([...prodNewComplements, { name: '', price: '', imageFile: null }])} style={{ fontSize: '13px', color: 'var(--store-primary)', background: '#fff', border: '2px dashed #ccc', borderRadius: '8px', padding: '10px', cursor: 'pointer', width: '100%', marginTop: '8px', fontWeight: '600' }}>
                    <FontAwesomeIcon icon={faPlus} /> Crear nuevo complemento
                  </button>
                </>
              )}

              {complementsTab === 'extras' && (
                <>
                  {extras.length === 0 && prodNewExtras.length === 0 && (
                    <p style={{ textAlign: 'center', color: '#999', fontSize: '13px', padding: '16px 0' }}>No hay extras creados</p>
                  )}
                  {extras.map(e => {
                    const active = selectedExtraIds.includes(e.id);
                    return (
                      <div key={e.id} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px', borderRadius: '8px', marginBottom: '4px', background: active ? 'rgba(0,128,0,0.08)' : '#fafafa', border: active ? '2px solid #2ecc71' : '2px solid transparent' }}>
                        <div onClick={() => setSelectedExtraIds(active ? selectedExtraIds.filter(id => id !== e.id) : [...selectedExtraIds, e.id])} style={{ display: 'flex', alignItems: 'center', gap: '10px', flex: 1, cursor: 'pointer' }}>
                          <div style={{ width: '36px', height: '36px', borderRadius: '8px', overflow: 'hidden', flexShrink: 0, background: '#eee', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            {e.image ? <img src={getImageUrl(e.image)} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <FontAwesomeIcon icon={faBox} style={{ color: '#ccc' }} />}
                          </div>
                          <div style={{ flex: 1 }}>
                            <div style={{ fontSize: '14px', fontWeight: '600' }}>{e.name}</div>
                            {Number(e.price) > 0 && <div style={{ fontSize: '12px', color: '#888' }}>+${Number(e.price).toFixed(0)}</div>}
                          </div>
                          <FontAwesomeIcon icon={active ? faCheckCircle : faTimesCircle} style={{ fontSize: '20px', color: active ? '#2ecc71' : '#ddd' }} />
                        </div>
                        <div style={{ display: 'flex', gap: '4px', flexShrink: 0 }}>
                          <button onClick={(ev) => { ev.stopPropagation(); setEditingComplement({ id: e.id, type: 'extra', name: e.name, price: e.price?.toString() || '', imageFile: null }); }} style={{ background: 'none', border: 'none', color: 'var(--store-primary)', cursor: 'pointer', padding: '4px', fontSize: '13px' }}><FontAwesomeIcon icon={faEdit} /></button>
                          <button onClick={(ev) => { ev.stopPropagation(); deleteComplementFromModal('extra', e.id); }} style={{ background: 'none', border: 'none', color: '#e74c3c', cursor: 'pointer', padding: '4px', fontSize: '13px' }}><FontAwesomeIcon icon={faTrash} /></button>
                        </div>
                      </div>
                    );
                  })}
                  {prodNewExtras.map((ext, i) => (
                    <div key={`new-${i}`} style={{ display: 'flex', gap: '6px', marginTop: '6px', alignItems: 'center', padding: '6px', background: '#fffbe6', borderRadius: '8px', border: '1px dashed #e6c200' }}>
                      <label style={{ width: '32px', height: '32px', borderRadius: '6px', background: ext.imageFile ? 'transparent' : '#f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0, overflow: 'hidden', border: '1px solid #ddd' }}>
                        {ext.imageFile ? <img src={URL.createObjectURL(ext.imageFile)} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <FontAwesomeIcon icon={faBox} style={{ fontSize: '12px', color: '#bbb' }} />}
                        <input type="file" accept="image/*" onChange={(e) => { if (e.target.files[0]) { const arr = [...prodNewExtras]; arr[i] = { ...arr[i], imageFile: e.target.files[0] }; setProdNewExtras(arr); } }} style={{ display: 'none' }} />
                      </label>
                      <input type="text" value={ext.name} onChange={(e) => { const arr = [...prodNewExtras]; arr[i] = { ...arr[i], name: e.target.value }; setProdNewExtras(arr); }} placeholder="Nombre" className="store-prod-modal-input" style={{ flex: 2, padding: '8px', fontSize: '13px' }} />
                      <input type="number" step="0.01" value={ext.price} onChange={(e) => { const arr = [...prodNewExtras]; arr[i] = { ...arr[i], price: e.target.value }; setProdNewExtras(arr); }} placeholder="$" className="store-prod-modal-input" style={{ flex: 1, padding: '8px', fontSize: '13px' }} />
                      <button onClick={() => setProdNewExtras(prodNewExtras.filter((_, j) => j !== i))} style={{ background: 'none', border: 'none', color: '#e74c3c', cursor: 'pointer', padding: '4px' }}><FontAwesomeIcon icon={faTimes} /></button>
                    </div>
                  ))}
                  <button onClick={() => setProdNewExtras([...prodNewExtras, { name: '', price: '', imageFile: null }])} style={{ fontSize: '13px', color: 'var(--store-primary)', background: '#fff', border: '2px dashed #ccc', borderRadius: '8px', padding: '10px', cursor: 'pointer', width: '100%', marginTop: '8px', fontWeight: '600' }}>
                    <FontAwesomeIcon icon={faPlus} /> Crear nuevo extra
                  </button>
                </>
              )}
            </div>

            {editingComplement && (
              <div style={{ marginTop: '10px', padding: '12px', background: '#fffbe6', borderRadius: '8px', border: '2px solid #e6c200' }}>
                <div style={{ fontSize: '12px', fontWeight: '700', color: '#333', marginBottom: '8px' }}>Editando: {editingComplement.name}</div>
                <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                  <label style={{ width: '32px', height: '32px', borderRadius: '6px', background: editingComplement.imageFile ? 'transparent' : '#f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0, overflow: 'hidden', border: '1px solid #ddd' }}>
                    {editingComplement.imageFile ? <img src={URL.createObjectURL(editingComplement.imageFile)} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <FontAwesomeIcon icon={faBox} style={{ fontSize: '12px', color: '#bbb' }} />}
                    <input type="file" accept="image/*" onChange={(e) => { if (e.target.files[0]) setEditingComplement({ ...editingComplement, imageFile: e.target.files[0] }); }} style={{ display: 'none' }} />
                  </label>
                  <input type="text" value={editingComplement.name} onChange={(e) => setEditingComplement({ ...editingComplement, name: e.target.value })} placeholder="Nombre" className="store-prod-modal-input" style={{ flex: 2, padding: '8px', fontSize: '13px' }} />
                  <input type="number" step="0.01" value={editingComplement.price} onChange={(e) => setEditingComplement({ ...editingComplement, price: e.target.value })} placeholder="$" className="store-prod-modal-input" style={{ flex: 1, padding: '8px', fontSize: '13px' }} />
                </div>
                <div style={{ display: 'flex', gap: '6px', marginTop: '8px' }}>
                  <button onClick={() => setEditingComplement(null)} style={{ flex: 1, padding: '8px', borderRadius: '6px', border: '1px solid #ccc', background: '#fff', fontSize: '13px', cursor: 'pointer' }}>Cancelar</button>
                  <button onClick={saveEditComplement} disabled={!editingComplement.name.trim()} style={{ flex: 1, padding: '8px', borderRadius: '6px', border: 'none', background: 'var(--store-primary)', color: 'var(--store-secondary)', fontSize: '13px', fontWeight: '700', cursor: 'pointer' }}>Guardar</button>
                </div>
              </div>
            )}

            <button
              onClick={() => { setShowComplementsModal(false); setEditingComplement(null); }}
              style={{ marginTop: '14px', padding: '12px', borderRadius: '8px', border: 'none', background: 'var(--store-primary)', color: 'var(--store-secondary)', fontSize: '14px', fontWeight: '700', cursor: 'pointer', width: '100%' }}
            >
              Listo
            </button>
          </div>
        </div>
      )}

      {styleEditorOpen && (
        <div className="store-modal-overlay" onClick={() => setStyleEditorOpen(false)} onMouseDown={(e) => e.stopPropagation()} onTouchStart={(e) => e.stopPropagation()}>
          <div className="store-prod-modal" onClick={(e) => e.stopPropagation()} style={{ maxHeight: '90vh', display: 'flex', flexDirection: 'column', maxWidth: '420px' }}>
            <h3 style={{ margin: '0 0 12px', color: 'var(--store-primary)', textAlign: 'center' }}>
              <FontAwesomeIcon icon={faPalette} /> Editor de Estilos
              <span style={{ fontSize: '10px', display: 'block', color: '#999', marginTop: '2px' }}>PREMIUM</span>
            </h3>

            <div style={{ display: 'flex', gap: '0', marginBottom: '12px', borderRadius: '8px', overflow: 'hidden', border: '2px solid var(--store-primary)' }}>
              <button onClick={() => setStyleTab('visual')} style={{ flex: 1, padding: '8px', fontSize: '12px', fontWeight: '700', border: 'none', cursor: 'pointer', background: styleTab === 'visual' ? 'var(--store-primary)' : 'var(--store-secondary)', color: styleTab === 'visual' ? 'var(--store-secondary)' : 'var(--store-primary)' }}>
                <FontAwesomeIcon icon={faPalette} /> Visual
              </button>
              <button onClick={() => setStyleTab('css')} style={{ flex: 1, padding: '8px', fontSize: '12px', fontWeight: '700', border: 'none', cursor: 'pointer', background: styleTab === 'css' ? 'var(--store-primary)' : 'var(--store-secondary)', color: styleTab === 'css' ? 'var(--store-secondary)' : 'var(--store-primary)' }}>
                <FontAwesomeIcon icon={faCode} /> CSS Pro
              </button>
            </div>

            <div style={{ flex: 1, overflowY: 'auto' }}>
              {styleTab === 'visual' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  <div style={{ fontSize: '12px', fontWeight: '700', color: '#555', borderBottom: '1px solid #eee', paddingBottom: '4px' }}>Tipografia</div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Fuente</label>
                      <select value={visualSettings.fontFamily} onChange={(e) => { const v = { ...visualSettings, fontFamily: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} className="store-prod-modal-input" style={{ padding: '8px', fontSize: '12px', width: '100%' }}>
                        <option value="">Por defecto</option>
                        <option value="'Inter', sans-serif">Inter</option>
                        <option value="'Roboto', sans-serif">Roboto</option>
                        <option value="'Poppins', sans-serif">Poppins</option>
                        <option value="'Montserrat', sans-serif">Montserrat</option>
                        <option value="'Playfair Display', serif">Playfair Display</option>
                        <option value="'Lato', sans-serif">Lato</option>
                        <option value="'Oswald', sans-serif">Oswald</option>
                        <option value="'Raleway', sans-serif">Raleway</option>
                        <option value="monospace">Monospace</option>
                      </select>
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Peso</label>
                      <select value={visualSettings.fontWeight} onChange={(e) => { const v = { ...visualSettings, fontWeight: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} className="store-prod-modal-input" style={{ padding: '8px', fontSize: '12px', width: '100%' }}>
                        <option value="">Normal</option>
                        <option value="300">Light (300)</option>
                        <option value="400">Regular (400)</option>
                        <option value="500">Medium (500)</option>
                        <option value="600">Semi Bold (600)</option>
                        <option value="700">Bold (700)</option>
                        <option value="800">Extra Bold (800)</option>
                      </select>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Tamaño general</label>
                      <input type="text" value={visualSettings.fontSize} onChange={(e) => { const v = { ...visualSettings, fontSize: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} placeholder="ej: 14px" className="store-prod-modal-input" style={{ padding: '8px', fontSize: '12px', width: '100%', boxSizing: 'border-box' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Tamaño titulo</label>
                      <input type="text" value={visualSettings.titleSize} onChange={(e) => { const v = { ...visualSettings, titleSize: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} placeholder="ej: 16px" className="store-prod-modal-input" style={{ padding: '8px', fontSize: '12px', width: '100%', boxSizing: 'border-box' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Tamaño precio</label>
                      <input type="text" value={visualSettings.priceSize} onChange={(e) => { const v = { ...visualSettings, priceSize: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} placeholder="ej: 18px" className="store-prod-modal-input" style={{ padding: '8px', fontSize: '12px', width: '100%', boxSizing: 'border-box' }} />
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: '11px', color: '#888' }}>Sombra de texto</label>
                    <select value={visualSettings.textShadow} onChange={(e) => { const v = { ...visualSettings, textShadow: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} className="store-prod-modal-input" style={{ padding: '8px', fontSize: '12px', width: '100%' }}>
                      <option value="">Sin sombra</option>
                      <option value="1px 1px 2px rgba(0,0,0,0.3)">Suave</option>
                      <option value="2px 2px 4px rgba(0,0,0,0.5)">Media</option>
                      <option value="3px 3px 6px rgba(0,0,0,0.7)">Fuerte</option>
                      <option value="0 0 10px rgba(255,255,255,0.8)">Glow claro</option>
                      <option value="0 0 10px rgba(0,0,0,0.8)">Glow oscuro</option>
                    </select>
                  </div>

                  <div style={{ fontSize: '12px', fontWeight: '700', color: '#555', borderBottom: '1px solid #eee', paddingBottom: '4px', marginTop: '6px' }}>Colores</div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Nombre producto</label>
                      <input type="color" value={visualSettings.productNameColor || '#000000'} onChange={(e) => { const v = { ...visualSettings, productNameColor: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} style={{ width: '100%', height: '32px', border: 'none', cursor: 'pointer', borderRadius: '6px' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Precio producto</label>
                      <input type="color" value={visualSettings.productPriceColor || '#000000'} onChange={(e) => { const v = { ...visualSettings, productPriceColor: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} style={{ width: '100%', height: '32px', border: 'none', cursor: 'pointer', borderRadius: '6px' }} />
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Header fondo</label>
                      <input type="color" value={visualSettings.headerBg || '#000000'} onChange={(e) => { const v = { ...visualSettings, headerBg: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} style={{ width: '100%', height: '32px', border: 'none', cursor: 'pointer', borderRadius: '6px' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Header texto</label>
                      <input type="color" value={visualSettings.headerTextColor || '#ffffff'} onChange={(e) => { const v = { ...visualSettings, headerTextColor: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} style={{ width: '100%', height: '32px', border: 'none', cursor: 'pointer', borderRadius: '6px' }} />
                    </div>
                  </div>

                  <div style={{ fontSize: '12px', fontWeight: '700', color: '#555', borderBottom: '1px solid #eee', paddingBottom: '4px', marginTop: '6px' }}>Tarjetas de producto</div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Fondo tarjeta</label>
                      <input type="color" value={visualSettings.cardBg || '#ffffff'} onChange={(e) => { const v = { ...visualSettings, cardBg: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} style={{ width: '100%', height: '32px', border: 'none', cursor: 'pointer', borderRadius: '6px' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Borde tarjeta</label>
                      <input type="text" value={visualSettings.cardBorder} onChange={(e) => { const v = { ...visualSettings, cardBorder: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} placeholder="ej: 2px solid gold" className="store-prod-modal-input" style={{ padding: '8px', fontSize: '12px', width: '100%', boxSizing: 'border-box' }} />
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Sombra tarjeta</label>
                      <select value={visualSettings.cardShadow} onChange={(e) => { const v = { ...visualSettings, cardShadow: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} className="store-prod-modal-input" style={{ padding: '8px', fontSize: '12px', width: '100%' }}>
                        <option value="">Sin sombra</option>
                        <option value="0 2px 8px rgba(0,0,0,0.1)">Suave</option>
                        <option value="0 4px 16px rgba(0,0,0,0.15)">Media</option>
                        <option value="0 8px 32px rgba(0,0,0,0.2)">Grande</option>
                        <option value="0 0 20px rgba(212,175,55,0.3)">Glow dorado</option>
                        <option value="0 0 20px rgba(0,0,0,0.4)">Glow oscuro</option>
                      </select>
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Radio bordes</label>
                      <select value={visualSettings.cardRadius} onChange={(e) => { const v = { ...visualSettings, cardRadius: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} className="store-prod-modal-input" style={{ padding: '8px', fontSize: '12px', width: '100%' }}>
                        <option value="">Por defecto</option>
                        <option value="0">Sin bordes (0)</option>
                        <option value="4px">Poco (4px)</option>
                        <option value="8px">Normal (8px)</option>
                        <option value="16px">Redondeado (16px)</option>
                        <option value="24px">Muy redondeado (24px)</option>
                        <option value="50%">Circular</option>
                      </select>
                    </div>
                  </div>

                  <div style={{ fontSize: '12px', fontWeight: '700', color: '#555', borderBottom: '1px solid #eee', paddingBottom: '4px', marginTop: '6px' }}>Categorias</div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Fondo tab</label>
                      <input type="color" value={visualSettings.categoryBg || '#ffffff'} onChange={(e) => { const v = { ...visualSettings, categoryBg: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} style={{ width: '100%', height: '32px', border: 'none', cursor: 'pointer', borderRadius: '6px' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Tab activo</label>
                      <input type="color" value={visualSettings.categoryActiveColor || '#000000'} onChange={(e) => { const v = { ...visualSettings, categoryActiveColor: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} style={{ width: '100%', height: '32px', border: 'none', cursor: 'pointer', borderRadius: '6px' }} />
                    </div>
                  </div>

                  <div style={{ fontSize: '12px', fontWeight: '700', color: '#555', borderBottom: '1px solid #eee', paddingBottom: '4px', marginTop: '6px' }}>Barra del carrito</div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Fondo carrito</label>
                      <input type="color" value={visualSettings.cartBg || '#000000'} onChange={(e) => { const v = { ...visualSettings, cartBg: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} style={{ width: '100%', height: '32px', border: 'none', cursor: 'pointer', borderRadius: '6px' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: '11px', color: '#888' }}>Texto carrito</label>
                      <input type="color" value={visualSettings.cartTextColor || '#ffffff'} onChange={(e) => { const v = { ...visualSettings, cartTextColor: e.target.value }; setVisualSettings(v); applyStyles(v, customCss); }} style={{ width: '100%', height: '32px', border: 'none', cursor: 'pointer', borderRadius: '6px' }} />
                    </div>
                  </div>
                </div>
              )}

              {styleTab === 'css' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <p style={{ fontSize: '11px', color: '#888', margin: 0 }}>CSS personalizado. Usa selectores como <code>.store-container</code>, <code>.store-product-card</code>, <code>.store-header</code>, etc.</p>
                  <textarea
                    value={customCss}
                    onChange={(e) => { setCustomCss(e.target.value); applyStyles(visualSettings, e.target.value); }}
                    placeholder={`.store-product-card {\n  border: 2px solid gold;\n  transform: scale(1.02);\n}\n\n.store-header {\n  background: linear-gradient(135deg, #1a1a2e, #16213e);\n}`}
                    style={{ width: '100%', minHeight: '250px', padding: '12px', fontSize: '12px', fontFamily: 'monospace', border: '2px solid #e0e0e0', borderRadius: '8px', resize: 'vertical', boxSizing: 'border-box', lineHeight: '1.5', background: '#1e1e1e', color: '#d4d4d4' }}
                  />
                </div>
              )}
            </div>

            <div style={{ display: 'flex', gap: '8px', marginTop: '12px' }}>
              <button onClick={() => setStyleEditorOpen(false)} className="store-prod-modal-btn cancel">Cerrar</button>
              <button onClick={() => {
                if (!confirm('Reiniciar todos los estilos a los valores por defecto?')) return;
                const defaults = { fontFamily: '', fontSize: '', titleSize: '', priceSize: '', fontWeight: '', textShadow: '', cardShadow: '', cardRadius: '', productNameColor: '', productPriceColor: '', cardBg: '', cardBorder: '', headerBg: '', headerTextColor: '', categoryBg: '', categoryActiveColor: '', cartBg: '', cartTextColor: '' };
                setVisualSettings(defaults);
                setCustomCss('');
                applyStyles(defaults, '');
              }} className="store-prod-modal-btn cancel" style={{ flex: 'none', padding: '10px', fontSize: '12px' }}>
                Reiniciar
              </button>
              <button onClick={saveStoreStyles} disabled={styleSaving} className="store-prod-modal-btn confirm" style={{ background: 'var(--store-accent)', color: 'var(--store-primary)' }}>
                {styleSaving ? 'Guardando...' : 'Guardar estilos'}
              </button>
            </div>
          </div>
        </div>
      )}

      {complementModal && (
        <div className="store-modal-overlay" onClick={() => setComplementModal(null)} onMouseDown={(e) => e.stopPropagation()} onTouchStart={(e) => e.stopPropagation()}>
          <div className="store-prod-modal" onClick={(e) => e.stopPropagation()}>
            <h3 style={{ margin: '0 0 14px', color: 'var(--store-primary)', textAlign: 'center' }}>
              Nuevo {complementModal === 'extra' ? 'Extra' : 'Ingrediente'}
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <input type="text" value={complementForm.name} onChange={(e) => setComplementForm({ ...complementForm, name: e.target.value })} placeholder="Nombre" autoFocus className="store-prod-modal-input main" />
              <input type="number" step="0.01" value={complementForm.price} onChange={(e) => setComplementForm({ ...complementForm, price: e.target.value })} placeholder="Precio adicional" className="store-prod-modal-input" />
              <select value={complementForm.category_id} onChange={(e) => setComplementForm({ ...complementForm, category_id: e.target.value })} className="store-prod-modal-input">
                <option value="">Sin categoría</option>
                {(store?.categories || []).map(cat => (<option key={cat.id} value={cat.id}>{cat.name}</option>))}
              </select>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '14px', cursor: 'pointer', flex: 1 }}>
                  <input type="checkbox" checked={complementForm.unlimited_stock} onChange={(e) => setComplementForm({ ...complementForm, unlimited_stock: e.target.checked })} />
                  Stock ilimitado
                </label>
                {!complementForm.unlimited_stock && (
                  <input type="number" min="0" value={complementForm.stock} onChange={(e) => setComplementForm({ ...complementForm, stock: e.target.value })} placeholder="Stock" className="store-prod-modal-input" style={{ width: '80px' }} />
                )}
              </div>
              <label className="store-prod-modal-image-btn" style={{ alignSelf: 'flex-start' }}>
                <FontAwesomeIcon icon={faEdit} /> {complementForm.imageFile ? complementForm.imageFile.name : 'Imagen'}
                <input type="file" accept="image/*" onChange={(e) => { if (e.target.files[0]) setComplementForm({ ...complementForm, imageFile: e.target.files[0] }); }} style={{ display: 'none' }} />
              </label>
            </div>
            <div style={{ display: 'flex', gap: '8px', marginTop: '14px' }}>
              <button onClick={() => setComplementModal(null)} className="store-prod-modal-btn cancel">Cancelar</button>
              <button onClick={saveComplement} disabled={!complementForm.name.trim()} className={`store-prod-modal-btn confirm${!complementForm.name.trim() ? ' disabled' : ''}`}>Crear</button>
            </div>
          </div>
        </div>
      )}

      {catModalOpen && (
        <div className="store-modal-overlay" onClick={() => setCatModalOpen(false)} onMouseDown={(e) => e.stopPropagation()} onTouchStart={(e) => e.stopPropagation()}>
          <div className="store-pin-modal" onClick={(e) => e.stopPropagation()}>
            <h3 style={{ margin: '0 0 16px', color: 'var(--store-primary)', textAlign: 'center' }}>
              {editingCat ? 'Editar Categoría' : 'Nueva Categoría'}
            </h3>
            <input
              type="text"
              value={catName}
              onChange={(e) => setCatName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') saveCat(); }}
              placeholder="Nombre de la categoría"
              autoFocus
              style={{
                width: '100%',
                padding: '12px',
                fontSize: '16px',
                border: '2px solid var(--store-primary)',
                borderRadius: '8px',
                outline: 'none',
                boxSizing: 'border-box'
              }}
            />
            <div style={{ display: 'flex', gap: '8px', marginTop: '12px' }}>
              <button
                onClick={() => setCatModalOpen(false)}
                style={{
                  flex: 1, padding: '10px', border: '2px solid #e0e0e0', borderRadius: '8px',
                  background: '#fff', fontSize: '14px', cursor: 'pointer', fontWeight: '600'
                }}
              >
                Cancelar
              </button>
              <button
                onClick={saveCat}
                disabled={!catName.trim()}
                style={{
                  flex: 1, padding: '10px', border: 'none', borderRadius: '8px',
                  background: catName.trim() ? 'var(--store-accent)' : '#ccc',
                  color: catName.trim() ? 'var(--store-primary)' : '#666',
                  fontSize: '14px', cursor: catName.trim() ? 'pointer' : 'default', fontWeight: '700'
                }}
              >
                {editingCat ? 'Guardar' : 'Crear'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showRestartConfirm && (
        <div className="store-modal-overlay" onClick={() => {}}>
          <div className="store-pin-modal" style={{ maxWidth: '340px', textAlign: 'center' }}>
            <div style={{ fontSize: '48px', marginBottom: '12px' }}>&#x1F504;</div>
            <h3 style={{ margin: '0 0 8px', color: 'var(--store-primary)' }}>Edición completada</h3>
            <p style={{ margin: '0 0 20px', fontSize: '14px', color: '#666' }}>
              ¿Deseas reiniciar todos los totems para que apliquen los cambios?
            </p>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                onClick={() => { setShowRestartConfirm(false); setEditMode(false); }}
                style={{ flex: 1, padding: '12px', border: '2px solid #e0e0e0', borderRadius: '8px', background: '#fff', fontSize: '14px', fontWeight: '600', cursor: 'pointer' }}
              >
                No, solo salir
              </button>
              <button
                onClick={async () => {
                  setRestartingSending(true);
                  try {
                    await fetch(`/api/public/${code}/restart-all`, {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ token: adminToken })
                    });
                  } catch {}
                  setRestartingSending(false);
                  setShowRestartConfirm(false);
                  setEditMode(false);
                }}
                disabled={restartingSending}
                style={{ flex: 1, padding: '12px', border: 'none', borderRadius: '8px', background: 'var(--store-accent)', color: 'var(--store-primary)', fontSize: '14px', fontWeight: '700', cursor: 'pointer' }}
              >
                {restartingSending ? 'Enviando...' : 'Reiniciar totems'}
              </button>
            </div>
          </div>
        </div>
      )}

      {pinModalOpen && (
        <div className="store-modal-overlay" onClick={() => setPinModalOpen(false)}>
          <div className="store-pin-modal" onClick={(e) => e.stopPropagation()}>
            <div style={{ marginBottom: '14px', padding: '10px', background: '#f5f5f5', borderRadius: '8px', fontSize: '11px', color: '#666', lineHeight: '1.6' }}>
              <div style={{ fontWeight: '700', fontSize: '12px', color: '#333', marginBottom: '4px' }}>Info del Totem</div>
              <div><strong>Device UID:</strong> <span style={{ fontFamily: 'monospace', fontSize: '10px', wordBreak: 'break-all' }}>{deviceUid}</span></div>
              <div><strong>Tienda:</strong> {store?.store?.name || '-'} ({code})</div>
              <div><strong>Store ID:</strong> {store?.store?.id || '-'}</div>
              <div><strong>Config:</strong> {selectedConfiguration?.name || 'Ninguna'} {selectedConfiguration?.id ? `(#${selectedConfiguration.id})` : ''}</div>
              <div><strong>Terminal:</strong> {selectedTerminalId || 'Ninguna'}</div>
              <div><strong>Socket:</strong> {socketRef.current?.connected ? 'Conectado' : 'Desconectado'} {socketRef.current?.id ? `(${socketRef.current.id})` : ''}</div>
            </div>
            <div style={{ textAlign: 'center', marginBottom: '16px' }}>
              <FontAwesomeIcon icon={faLock} style={{ fontSize: '28px', color: 'var(--store-accent)', marginBottom: '8px' }} />
              <h3 style={{ margin: 0, color: 'var(--store-primary)' }}>Ingresa el PIN</h3>
            </div>

            <div className="pin-dots">
              {[0, 1, 2, 3].map(i => (
                <div
                  key={i}
                  className={`pin-dot${pinInput.length > i ? ' filled' : ''}`}
                  style={{
                    borderColor: pinError ? '#dc3545' : 'var(--store-primary)'
                  }}
                />
              ))}
            </div>

            {pinError && (
              <p style={{ color: '#dc3545', textAlign: 'center', margin: '8px 0 0', fontSize: '14px' }}>
                {pinError}
              </p>
            )}

            <div className="pin-numpad">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, null, 0, 'del'].map((key, idx) => (
                <button
                  key={idx}
                  className={`pin-numpad-btn${key === null ? ' pin-numpad-empty' : ''}${key === 'del' ? ' pin-numpad-del' : ''}`}
                  onClick={() => {
                    if (key === null) return;
                    if (key === 'del') {
                      setPinInput(prev => prev.slice(0, -1));
                      setPinError('');
                      return;
                    }
                    if (pinInput.length >= 4) return;
                    const newPin = pinInput + key;
                    setPinInput(newPin);
                    setPinError('');
                    if (newPin.length === 4) {
                      setTimeout(() => {
                        handlePinSubmit(newPin);
                      }, 200);
                    }
                  }}
                  disabled={key === null}
                >
                  {key === 'del' ? (
                    <FontAwesomeIcon icon={faArrowLeft} />
                  ) : key !== null ? key : ''}
                </button>
              ))}
            </div>

            <button
              onClick={() => setPinModalOpen(false)}
              style={{
                width: '100%',
                padding: '10px',
                marginTop: '12px',
                backgroundColor: 'transparent',
                color: '#999',
                border: 'none',
                fontSize: '14px',
                cursor: 'pointer'
              }}
            >
              Cancelar
            </button>
          </div>
        </div>
      )}
      {/* Welcome modal - language selection with explosion animation */}
      {welcomeModalOpen && (
        <div className="store-modal-overlay" style={{ zIndex: 99999, transition: 'opacity 0.4s', opacity: welcomeClosing ? 0 : 1 }}>
          <style>{`
            @keyframes welcome-float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
            @keyframes welcome-card-in { from{opacity:0;transform:scale(0.8) translateY(30px)} to{opacity:1;transform:scale(1) translateY(0)} }
            @keyframes welcome-btn-in { from{opacity:0;transform:translateX(-20px)} to{opacity:1;transform:translateX(0)} }
            @keyframes welcome-pulse { 0%,100%{box-shadow:0 0 0 0 var(--store-accent)} 50%{box-shadow:0 0 0 12px transparent} }
            @keyframes welcome-selected-zoom { 0%{transform:scale(1)} 40%{transform:scale(1.15)} 100%{transform:scale(30);opacity:0} }
            @keyframes welcome-check-pop { 0%{transform:scale(0) rotate(-45deg);opacity:0} 50%{transform:scale(1.3) rotate(10deg);opacity:1} 100%{transform:scale(1) rotate(0deg);opacity:1} }
            @keyframes welcome-particles { 0%{transform:translate(0,0) scale(1);opacity:1} 100%{opacity:0} }
            @keyframes welcome-shimmer { 0%{background-position:-200% center} 100%{background-position:200% center} }
          `}</style>
          <div style={{ background: 'var(--store-primary)', borderRadius: '24px', padding: '36px 28px', maxWidth: '380px', width: '92%', textAlign: 'center', color: 'var(--store-secondary)', animation: 'welcome-card-in 0.6s cubic-bezier(0.34,1.56,0.64,1) both', position: 'relative', overflow: 'hidden' }}>

            {/* Particles on selection */}
            {welcomeSelectedLang && (
              <>
                {Array.from({ length: 12 }).map((_, i) => {
                  const angle = (i / 12) * 360;
                  const dist = 80 + Math.random() * 60;
                  const dx = Math.cos(angle * Math.PI / 180) * dist;
                  const dy = Math.sin(angle * Math.PI / 180) * dist;
                  return <div key={i} style={{ position: 'absolute', top: '50%', left: '50%', width: '8px', height: '8px', borderRadius: '50%', background: 'var(--store-accent)', animation: `welcome-particles 0.7s ease-out ${i * 0.03}s both`, transform: `translate(${dx}px, ${dy}px)`, zIndex: 10 }} />;
                })}
              </>
            )}

            <div style={{ fontSize: '42px', marginBottom: '12px', animation: 'welcome-float 2s ease-in-out infinite', color: 'var(--store-accent)' }}>
              <FontAwesomeIcon icon={faGlobe} />
            </div>
            <h2 style={{ margin: '0 0 4px', fontSize: '26px', fontWeight: '800', background: `linear-gradient(90deg, var(--store-secondary), var(--store-accent), var(--store-secondary))`, backgroundSize: '200% auto', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', animation: 'welcome-shimmer 3s linear infinite' }}>
              {lang === 'en' ? 'Welcome!' : lang === 'pt' ? 'Bem-vindo!' : 'Bienvenido!'}
            </h2>
            <p style={{ margin: '0 0 24px', fontSize: '14px', opacity: 0.7 }}>
              {lang === 'en' ? 'Select your language' : lang === 'pt' ? 'Selecione seu idioma' : 'Selecciona tu idioma'}
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {LANGUAGES.map((l, idx) => {
                const isSelected = welcomeSelectedLang === l.code;
                return (
                  <button
                    key={l.code}
                    disabled={!!welcomeSelectedLang}
                    onClick={() => {
                      setWelcomeSelectedLang(l.code);
                      setLang(l.code);
                      localStorage.setItem('srservi_lang', l.code);
                      setTimeout(() => setWelcomeClosing(true), 600);
                      setTimeout(() => { setWelcomeModalOpen(false); setWelcomeClosing(false); setWelcomeSelectedLang(null); }, 1000);
                    }}
                    style={{
                      padding: '16px', borderRadius: '14px', border: 'none', fontSize: '17px', fontWeight: '700', cursor: welcomeSelectedLang ? 'default' : 'pointer',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px',
                      background: isSelected ? 'var(--store-accent)' : 'rgba(255,255,255,0.1)',
                      color: isSelected ? 'var(--store-primary)' : 'var(--store-secondary)',
                      animation: isSelected ? 'welcome-selected-zoom 0.8s cubic-bezier(0.22,1,0.36,1) 0.2s both' : `welcome-btn-in 0.4s ease ${0.2 + idx * 0.1}s both`,
                      transition: 'background 0.2s, transform 0.2s, box-shadow 0.2s',
                      position: 'relative', zIndex: isSelected ? 5 : 1,
                      ...(welcomeSelectedLang && !isSelected ? { opacity: 0, transform: 'scale(0.8)', transition: 'all 0.3s ease' } : {})
                    }}
                  >
                    <FontAwesomeIcon icon={faGlobe} style={{ fontSize: '20px' }} />
                    {l.label}
                    {isSelected && (
                      <FontAwesomeIcon icon={faCheck} style={{ fontSize: '20px', animation: 'welcome-check-pop 0.4s cubic-bezier(0.34,1.56,0.64,1) both' }} />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Inactivity modal - auto restart */}
      {inactivityModalOpen && (
        <div className="store-modal-overlay" style={{ zIndex: 99998 }}>
          <div style={{ background: '#fff', borderRadius: '20px', padding: '32px 24px', maxWidth: '360px', width: '90%', textAlign: 'center' }}>
            <h2 style={{ margin: '0 0 8px', fontSize: '22px', color: '#333' }}>
              {lang === 'en' ? 'Are you still there?' : lang === 'pt' ? 'Voce ainda esta ai?' : 'Sigues ahi?'}
            </h2>
            <p style={{ margin: '0 0 4px', fontSize: '14px', color: '#888' }}>
              {lang === 'en' ? 'The screen will restart in' : lang === 'pt' ? 'A tela sera reiniciada em' : 'La pantalla se reiniciara en'}
            </p>
            <div style={{ fontSize: '48px', fontWeight: '800', color: inactivityCountdown <= 3 ? '#e74c3c' : 'var(--store-primary)', margin: '8px 0 16px' }}>
              {inactivityCountdown}
            </div>
            <button
              className="store-glow-pulse-green"
              onClick={() => {
                setInactivityModalOpen(false);
                setInactivityCountdown(10);
                if (inactivityCountdownRef.current) clearInterval(inactivityCountdownRef.current);
              }}
              style={{ width: '100%', padding: '16px', borderRadius: '12px', border: 'none', background: '#2ecc71', color: '#fff', fontSize: '18px', fontWeight: '700', cursor: 'pointer' }}
            >
              {lang === 'en' ? 'Yes, I\'m here!' : lang === 'pt' ? 'Sim, estou aqui!' : 'Si, estoy aqui!'}
            </button>
          </div>
        </div>
      )}
    </div>
    </PluginProvider>
  );
}

export default Store;
