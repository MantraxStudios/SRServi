import mysql from 'mysql2/promise';

const dbConfig = {
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: 'mysql',
  database: 'srservi'
};

async function migrate() {
  let pool;
  try {
    pool = mysql.createPool(dbConfig);
    const connection = await pool.getConnection();
    console.log('✅ Conexión a MySQL establecida');

    const [columns] = await connection.execute('SHOW COLUMNS FROM orders');
    const columnNames = columns.map(c => c.Field);
    console.log('Columnas actuales:', columnNames);

    if (!columnNames.includes('payment_method')) {
      console.log('➕ Agregando columna payment_method...');
      await connection.execute('ALTER TABLE orders ADD COLUMN payment_method VARCHAR(20) DEFAULT \'card\' AFTER status');
      console.log('✅ Columna payment_method agregada');
    } else {
      console.log('ℹ️ Columna payment_method ya existe');
    }

    if (!columnNames.includes('cash_approved')) {
      console.log('➕ Agregando columna cash_approved...');
      await connection.execute('ALTER TABLE orders ADD COLUMN cash_approved BOOLEAN DEFAULT FALSE AFTER payment_method');
      console.log('✅ Columna cash_approved agregada');
    } else {
      console.log('ℹ️ Columna cash_approved ya existe');
    }

    console.log('\n✅ Migración completada');
    connection.release();
    await pool.end();
    process.exit(0);
  } catch (error) {
    console.error('❌ Error en la migración:', error.message);
    if (pool) await pool.end();
    process.exit(1);
  }
}

migrate();
