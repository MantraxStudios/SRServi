import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const API = 'https://srservi2.srautomatic.com';

// ── Auth Modal ────────────────────────────────────────────────────────────────
function DeliveryAuthModal({ onAuth, onClose }) {
  const [tab, setTab] = useState('login');
  const [step, setStep] = useState('form');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const reset = (newTab) => { setTab(newTab); setStep('form'); setError(''); setCode(''); };

  const handleLogin = async () => {
    if (!email.includes('@') || !password) { setError('Completa todos los campos'); return; }
    setLoading(true); setError('');
    try {
      const r = await fetch(`${API}/api/delivery/auth/login`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim().toLowerCase(), password })
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Error');
      localStorage.setItem('deliveryToken', d.token);
      localStorage.setItem('deliveryCustomer', JSON.stringify(d.customer));
      onAuth(d.customer, d.token);
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  const handleRegister = async () => {
    if (!name.trim() || !email.includes('@') || !password || password.length < 6) {
      setError('Completa todos los campos. La contraseña debe tener al menos 6 caracteres.'); return;
    }
    setLoading(true); setError('');
    try {
      const r = await fetch(`${API}/api/delivery/auth/register`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim().toLowerCase(), password, name: name.trim(), phone: phone.trim() })
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Error');
      setStep('verify');
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  const handleVerify = async () => {
    if (code.length !== 6) { setError('El código tiene 6 dígitos'); return; }
    setLoading(true); setError('');
    try {
      const r = await fetch(`${API}/api/delivery/auth/verify`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim().toLowerCase(), code: code.trim(), name: name.trim(), phone: phone.trim() })
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Error');
      localStorage.setItem('deliveryToken', d.token);
      localStorage.setItem('deliveryCustomer', JSON.stringify(d.customer));
      onAuth(d.customer, d.token);
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  const inp = {
    width: '100%', padding: '14px 16px',
    background: '#f9fafb', border: '1.5px solid #e5e7eb',
    borderRadius: 12, color: '#111', fontSize: 14,
    outline: 'none', boxSizing: 'border-box',
  };

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.65)', zIndex: 9999, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
      <div style={{ background: '#fff', borderRadius: '24px 24px 0 0', width: '100%', maxWidth: 500, boxShadow: '0 -8px 40px rgba(0,0,0,0.2)' }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '14px 0 0' }}>
          <div style={{ width: 40, height: 4, background: '#e5e7eb', borderRadius: 2 }} />
        </div>
        <div style={{ padding: '20px 22px 44px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
            <div style={{ flex: 1, display: 'flex', background: '#f3f4f6', borderRadius: 12, padding: 4 }}>
              {[['login', 'Ingresar'], ['register', 'Crear cuenta']].map(([t, lbl]) => (
                <button key={t} onClick={() => reset(t)} style={{
                  flex: 1, padding: '9px', borderRadius: 9, border: 'none',
                  fontWeight: 700, fontSize: 13, cursor: 'pointer',
                  background: tab === t ? '#fff' : 'transparent',
                  color: tab === t ? '#111' : '#9ca3af',
                  boxShadow: tab === t ? '0 1px 6px rgba(0,0,0,0.1)' : 'none',
                  transition: 'all 0.15s'
                }}>{lbl}</button>
              ))}
            </div>
            <button onClick={onClose} style={{ background: '#f3f4f6', border: 'none', borderRadius: '50%', width: 36, height: 36, fontSize: 18, cursor: 'pointer', color: '#6b7280', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>×</button>
          </div>

          {step === 'form' && tab === 'login' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <input type="email" placeholder="tu@email.com" value={email} autoFocus
                onChange={e => { setEmail(e.target.value); setError(''); }}
                onKeyDown={e => e.key === 'Enter' && handleLogin()} style={inp} />
              <div style={{ position: 'relative' }}>
                <input type={showPwd ? 'text' : 'password'} placeholder="Contraseña" value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  onKeyDown={e => e.key === 'Enter' && handleLogin()}
                  style={{ ...inp, paddingRight: 48 }} />
                <button onClick={() => setShowPwd(s => !s)} style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', fontSize: 16, color: '#9ca3af' }}>
                  {showPwd ? '🙈' : '👁'}
                </button>
              </div>
              {error && <div style={{ color: '#ef4444', fontSize: 12, background: '#fef2f2', padding: '8px 12px', borderRadius: 8 }}>{error}</div>}
              <button onClick={handleLogin} disabled={loading} style={{ padding: '15px', background: loading ? '#f3f4f6' : '#D4AF37', color: loading ? '#9ca3af' : '#000', border: 'none', borderRadius: 12, fontWeight: 800, fontSize: 15, cursor: loading ? 'default' : 'pointer', marginTop: 4, boxShadow: loading ? 'none' : '0 4px 16px rgba(212,175,55,0.4)' }}>
                {loading ? 'Ingresando...' : 'Ingresar'}
              </button>
              <p style={{ textAlign: 'center', fontSize: 13, color: '#9ca3af', margin: '4px 0 0' }}>
                ¿Primera vez?{' '}
                <button onClick={() => reset('register')} style={{ background: 'none', border: 'none', color: '#D4AF37', fontWeight: 700, cursor: 'pointer', fontSize: 13 }}>Crear cuenta</button>
              </p>
            </div>
          )}

          {step === 'form' && tab === 'register' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <input type="text" placeholder="Nombre completo *" value={name} autoFocus onChange={e => { setName(e.target.value); setError(''); }} style={inp} />
              <input type="tel" placeholder="Teléfono" value={phone} onChange={e => { setPhone(e.target.value); setError(''); }} style={inp} />
              <input type="email" placeholder="Email *" value={email} onChange={e => { setEmail(e.target.value); setError(''); }} style={inp} />
              <div style={{ position: 'relative' }}>
                <input type={showPwd ? 'text' : 'password'} placeholder="Contraseña * (mín. 6 caracteres)" value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }} style={{ ...inp, paddingRight: 48 }} />
                <button onClick={() => setShowPwd(s => !s)} style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', fontSize: 16, color: '#9ca3af' }}>
                  {showPwd ? '🙈' : '👁'}
                </button>
              </div>
              {error && <div style={{ color: '#ef4444', fontSize: 12, background: '#fef2f2', padding: '8px 12px', borderRadius: 8 }}>{error}</div>}
              <button onClick={handleRegister} disabled={loading} style={{ padding: '15px', background: loading ? '#f3f4f6' : '#D4AF37', color: loading ? '#9ca3af' : '#000', border: 'none', borderRadius: 12, fontWeight: 800, fontSize: 15, cursor: loading ? 'default' : 'pointer', marginTop: 4, boxShadow: loading ? 'none' : '0 4px 16px rgba(212,175,55,0.4)' }}>
                {loading ? 'Creando cuenta...' : 'Crear cuenta'}
              </button>
            </div>
          )}

          {step === 'verify' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14, textAlign: 'center' }}>
              <div>
                <div style={{ fontSize: 40, marginBottom: 12 }}>📧</div>
                <h3 style={{ margin: '0 0 8px', fontSize: 18, fontWeight: 800, color: '#111' }}>Verificá tu email</h3>
                <p style={{ color: '#6b7280', fontSize: 13, margin: 0 }}>Código enviado a <strong style={{ color: '#D4AF37' }}>{email}</strong></p>
              </div>
              <input type="text" inputMode="numeric" maxLength={6} placeholder="000000" autoFocus value={code}
                onChange={e => { setCode(e.target.value.replace(/\D/g, '')); setError(''); }}
                style={{ ...inp, fontSize: 32, fontWeight: 900, letterSpacing: 14, textAlign: 'center', color: '#D4AF37', padding: '18px' }} />
              {error && <div style={{ color: '#ef4444', fontSize: 12, background: '#fef2f2', padding: '8px 12px', borderRadius: 8 }}>{error}</div>}
              <button onClick={handleVerify} disabled={loading} style={{ padding: '15px', background: loading ? '#f3f4f6' : '#D4AF37', color: loading ? '#9ca3af' : '#000', border: 'none', borderRadius: 12, fontWeight: 800, fontSize: 15, cursor: loading ? 'default' : 'pointer', boxShadow: loading ? 'none' : '0 4px 16px rgba(212,175,55,0.4)' }}>
                {loading ? 'Verificando...' : 'Confirmar código'}
              </button>
              <button onClick={() => { setStep('form'); setCode(''); setError(''); }} style={{ padding: '10px', background: 'transparent', color: '#9ca3af', border: 'none', fontSize: 13, cursor: 'pointer' }}>
                ← Volver
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Product Detail Modal ───────────────────────────────────────────────────────
function ProductModal({ product, onAdd, onClose }) {
  const [qty, setQty] = useState(1);
  const [selectedExtras, setSelectedExtras] = useState([]);
  const [selectedIngredients, setSelectedIngredients] = useState([]);

  const extras = Array.isArray(product.extras) ? product.extras : [];
  const ingredients = Array.isArray(product.ingredients) ? product.ingredients : [];
  const extrasTotal = selectedExtras.reduce((sum, extraId) => {
    const extra = extras.find(e => e.id === extraId);
    return sum + (Number(extra?.price) || 0);
  }, 0);
  const itemUnitPrice = Number(product.price) + extrasTotal;
  const itemTotal = itemUnitPrice * qty;
  const outOfStock = !product.unlimited_stock && product.stock === 0;
  const maxExtras = product.max_extras || 0;

  const toggleExtra = (extraId) => {
    setSelectedExtras(prev => {
      if (prev.includes(extraId)) return prev.filter(id => id !== extraId);
      if (maxExtras > 0 && prev.length >= maxExtras) return prev;
      return [...prev, extraId];
    });
  };

  const toggleIngredient = (ingredientId) => {
    setSelectedIngredients(prev =>
      prev.includes(ingredientId) ? prev.filter(id => id !== ingredientId) : [...prev, ingredientId]
    );
  };

  const handleAdd = () => {
    onAdd({
      id: product.id, name: product.name, price: itemUnitPrice, qty,
      selectedIngredients: ingredients.filter(i => selectedIngredients.includes(i.id)).map(i => ({ id: i.id, name: i.name })),
      selectedExtras: extras.filter(e => selectedExtras.includes(e.id)).map(e => ({ id: e.id, name: e.name, price: Number(e.price) })),
    });
    onClose();
  };

  const imgSrc = product.image ? (product.image.startsWith('http') ? product.image : `${API}${product.image}`) : null;

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.65)', zIndex: 9999, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
      <div style={{ background: '#fff', borderRadius: '24px 24px 0 0', width: '100%', maxWidth: 500, maxHeight: '92vh', overflowY: 'auto', position: 'relative' }}>
        <button onClick={onClose} style={{
          position: 'absolute', top: 14, right: 14, zIndex: 10,
          background: imgSrc ? 'rgba(255,255,255,0.95)' : '#f3f4f6',
          border: 'none', borderRadius: '50%', width: 36, height: 36,
          color: '#374151', fontSize: 18, cursor: 'pointer',
          boxShadow: imgSrc ? '0 2px 8px rgba(0,0,0,0.15)' : 'none',
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600
        }}>×</button>

        {imgSrc ? (
          <div style={{ height: 240, overflow: 'hidden', borderRadius: '24px 24px 0 0', position: 'relative', flexShrink: 0 }}>
            <img src={imgSrc} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(0,0,0,0.35) 0%, transparent 50%)' }} />
          </div>
        ) : (
          <div style={{ height: 24 }} />
        )}

        <div style={{ padding: '20px 20px 40px' }}>
          <div style={{ marginBottom: 18 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
              <h2 style={{ margin: 0, fontSize: 21, fontWeight: 900, color: '#111', lineHeight: 1.2, flex: 1 }}>{product.name}</h2>
              <div style={{ fontSize: 20, fontWeight: 900, color: '#D4AF37', flexShrink: 0 }}>${Number(product.price).toFixed(0)}</div>
            </div>
            {product.description && (
              <p style={{ margin: '8px 0 0', fontSize: 14, color: '#6b7280', lineHeight: 1.6 }}>{product.description}</p>
            )}
          </div>

          {product.has_ingredients && ingredients.length > 0 && (
            <div style={{ marginBottom: 22 }}>
              <div style={{ fontWeight: 800, fontSize: 14, color: '#111', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 3, height: 16, background: '#D4AF37', borderRadius: 2 }} />
                Ingredientes
              </div>
              {ingredients.map(ing => {
                const selected = selectedIngredients.includes(ing.id);
                return (
                  <div key={ing.id} onClick={() => toggleIngredient(ing.id)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid #f3f4f6', cursor: 'pointer' }}>
                    <span style={{ fontSize: 14, color: selected ? '#111' : '#6b7280', fontWeight: selected ? 600 : 400 }}>{ing.name}</span>
                    <div style={{ width: 24, height: 24, borderRadius: 7, flexShrink: 0, background: selected ? '#D4AF37' : '#f3f4f6', border: selected ? 'none' : '1.5px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.15s' }}>
                      {selected && <span style={{ color: '#fff', fontSize: 12, fontWeight: 900 }}>✓</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {product.has_extras && extras.length > 0 && (
            <div style={{ marginBottom: 22 }}>
              <div style={{ fontWeight: 800, fontSize: 14, color: '#111', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 3, height: 16, background: '#D4AF37', borderRadius: 2 }} />
                Extras
              </div>
              {maxExtras > 0 && (
                <div style={{ fontSize: 12, color: '#9ca3af', marginBottom: 12 }}>
                  Elegí hasta {maxExtras} · <span style={{ color: selectedExtras.length === maxExtras ? '#D4AF37' : '#9ca3af', fontWeight: 700 }}>{selectedExtras.length}/{maxExtras}</span>
                </div>
              )}
              {extras.map(extra => {
                const isSelected = selectedExtras.includes(extra.id);
                const maxReached = maxExtras > 0 && selectedExtras.length >= maxExtras;
                const disabled = !isSelected && maxReached;
                return (
                  <div key={extra.id} onClick={() => !disabled && toggleExtra(extra.id)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid #f3f4f6', cursor: disabled ? 'default' : 'pointer', opacity: disabled ? 0.4 : 1 }}>
                    <div>
                      <div style={{ fontSize: 14, color: '#111', fontWeight: isSelected ? 700 : 400 }}>{extra.name}</div>
                      {Number(extra.price) > 0 && <div style={{ fontSize: 12, color: '#D4AF37', fontWeight: 700, marginTop: 2 }}>+${Number(extra.price).toFixed(0)}</div>}
                    </div>
                    <div style={{ width: 24, height: 24, borderRadius: '50%', flexShrink: 0, background: isSelected ? '#D4AF37' : '#f3f4f6', border: isSelected ? 'none' : '1.5px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.15s' }}>
                      {isSelected && <span style={{ color: '#fff', fontSize: 12, fontWeight: 900 }}>✓</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div style={{ display: 'flex', gap: 12, alignItems: 'center', paddingTop: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', background: '#f3f4f6', borderRadius: 14, overflow: 'hidden', flexShrink: 0 }}>
              <button onClick={() => setQty(q => Math.max(1, q - 1))} style={{ background: 'none', border: 'none', width: 44, height: 48, cursor: 'pointer', color: '#374151', fontWeight: 800, fontSize: 20, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>−</button>
              <span style={{ fontWeight: 900, fontSize: 16, minWidth: 28, textAlign: 'center', color: '#111' }}>{qty}</span>
              <button onClick={() => setQty(q => q + 1)} style={{ background: 'none', border: 'none', width: 44, height: 48, cursor: 'pointer', color: '#374151', fontWeight: 800, fontSize: 20, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
            </div>
            <button onClick={handleAdd} disabled={outOfStock} style={{
              flex: 1, padding: '14px 16px',
              background: outOfStock ? '#e5e7eb' : '#D4AF37',
              color: outOfStock ? '#9ca3af' : '#000',
              border: 'none', borderRadius: 14, fontWeight: 800, fontSize: 15,
              cursor: outOfStock ? 'not-allowed' : 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              boxShadow: outOfStock ? 'none' : '0 4px 16px rgba(212,175,55,0.4)'
            }}>
              <span>{outOfStock ? 'Sin stock' : 'Agregar'}</span>
              {!outOfStock && <span style={{ fontWeight: 900 }}>${itemTotal.toFixed(0)}</span>}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Product Card ──────────────────────────────────────────────────────────────
function ProductCard({ product, cart, onSelect }) {
  const cartQty = cart.filter(i => i.id === product.id).reduce((s, i) => s + i.qty, 0);
  const outOfStock = !product.unlimited_stock && product.stock === 0;
  const imgSrc = product.image ? (product.image.startsWith('http') ? product.image : `${API}${product.image}`) : null;

  return (
    <div
      onClick={() => !outOfStock && onSelect()}
      style={{
        display: 'flex', alignItems: 'stretch',
        background: '#fff', borderRadius: 16,
        boxShadow: cartQty > 0 ? '0 4px 16px rgba(212,175,55,0.18)' : '0 2px 10px rgba(0,0,0,0.06)',
        border: cartQty > 0 ? '2px solid rgba(212,175,55,0.4)' : '1px solid rgba(0,0,0,0.07)',
        cursor: outOfStock ? 'default' : 'pointer',
        opacity: outOfStock ? 0.55 : 1,
        overflow: 'hidden',
        transition: 'all 0.15s'
      }}
    >
      <div style={{ flex: 1, padding: '14px 14px 14px 16px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minWidth: 0 }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 15, color: '#111', marginBottom: 4, lineHeight: 1.25 }}>{product.name}</div>
          {product.description && (
            <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.45, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', marginBottom: 6 }}>
              {product.description}
            </div>
          )}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 900, color: '#D4AF37' }}>${Number(product.price).toFixed(0)}</span>
            {outOfStock && <span style={{ fontSize: 10, color: '#ef4444', fontWeight: 700, background: '#fef2f2', padding: '2px 8px', borderRadius: 20, border: '1px solid #fecaca' }}>Sin stock</span>}
          </div>
          {cartQty > 0 && (
            <span style={{ fontSize: 12, fontWeight: 700, color: '#C49B1E', background: 'rgba(212,175,55,0.1)', padding: '3px 10px', borderRadius: 20 }}>
              ×{cartQty} en carrito
            </span>
          )}
        </div>
      </div>

      <div style={{ position: 'relative', width: 96, flexShrink: 0 }}>
        {imgSrc ? (
          <img src={imgSrc} alt="" style={{ width: 96, height: '100%', minHeight: 88, objectFit: 'cover', display: 'block' }} />
        ) : (
          <div style={{ width: 96, height: '100%', minHeight: 88, background: 'linear-gradient(135deg, #f3f4f6, #e9eaec)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28 }}>🍽️</div>
        )}
        {!outOfStock && cartQty === 0 && (
          <div style={{ position: 'absolute', bottom: 8, right: 8, background: '#D4AF37', color: '#000', width: 26, height: 26, borderRadius: '50%', fontSize: 18, fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 8px rgba(212,175,55,0.5)', lineHeight: 1 }}>+</div>
        )}
        {cartQty > 0 && (
          <div style={{ position: 'absolute', top: 6, right: 6, background: '#D4AF37', color: '#000', width: 22, height: 22, borderRadius: '50%', fontSize: 11, fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 6px rgba(212,175,55,0.5)' }}>{cartQty}</div>
        )}
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function DeliveryStore() {
  const { code } = useParams();
  const navigate = useNavigate();

  const searchParams = new URLSearchParams(window.location.search);
  const haulmerRef = searchParams.get('ref');
  const haulmerResult = searchParams.get('x_result');

  const [store, setStore] = useState(null);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [deliverySettings, setDeliverySettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [customer, setCustomer] = useState(() => {
    try { return JSON.parse(localStorage.getItem('deliveryCustomer') || 'null'); } catch { return null; }
  });

  const [cart, setCart] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showAuth, setShowAuth] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [pendingCheckout, setPendingCheckout] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [payStep, setPayStep] = useState('address');
  const [placing, setPlacing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [customerCoords, setCustomerCoords] = useState(null);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [calculatedFee, setCalculatedFee] = useState(null);
  const [activeCategory, setActiveCategory] = useState(null);

  useEffect(() => {
    if (!haulmerRef || !haulmerRef.startsWith('SRSN-')) return;
    if (haulmerResult === 'completed') {
      const xParams = {};
      for (const [k, v] of searchParams.entries()) { if (k.startsWith('x_')) xParams[k] = v; }
      fetch(`${API}/api/haulmer/confirm`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(xParams)
      }).catch(() => {});
      setPayStep('success');
      window.history.replaceState({}, '', `/delivery/${code}`);
    } else {
      window.history.replaceState({}, '', `/delivery/${code}`);
    }
  }, []);

  useEffect(() => {
    Promise.all([
      fetch(`${API}/api/public/${code}`),
      fetch(`${API}/api/public/delivery-settings/${code}`)
    ]).then(async ([storeRes, dsRes]) => {
      if (!storeRes.ok) throw new Error('Tienda no encontrada');
      const storeData = await storeRes.json();
      setStore(storeData.store || storeData);
      setProducts((storeData.products || []).filter((p, i, a) => a.findIndex(x => x.id === p.id) === i));
      setCategories(storeData.categories || []);
      if (dsRes.ok) {
        const ds = await dsRes.json();
        setDeliverySettings(ds);
        if (ds.payment_cash !== false) setPaymentMethod('cash');
        else if (ds.payment_card) setPaymentMethod('card');
      }
    }).catch(() => {}).finally(() => setLoading(false));
  }, [code]);

  const haversineKm = (lat1, lng1, lat2, lng2) => {
    const R = 6371, dLat = (lat2 - lat1) * Math.PI / 180, dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  };

  const detectGPS = () => {
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(pos => {
      const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      setCustomerCoords(coords);
      if (deliverySettings?.fee_type === 'per_km' && deliverySettings?.lat && deliverySettings?.lng) {
        const km = haversineKm(deliverySettings.lat, deliverySettings.lng, coords.lat, coords.lng);
        const freeKm = Number(deliverySettings.free_km) || 0;
        const perKm = Number(deliverySettings.fee_per_km) || 0;
        const fee = Math.max(0, Math.round((Math.max(0, km - freeKm)) * perKm));
        setCalculatedFee(fee);
      }
      setGpsLoading(false);
    }, () => { alert('No se pudo obtener ubicación'); setGpsLoading(false); }, { enableHighAccuracy: true });
  };

  const distanceKm = customerCoords && deliverySettings?.lat && deliverySettings?.lng
    ? Math.round(haversineKm(deliverySettings.lat, deliverySettings.lng, customerCoords.lat, customerCoords.lng) * 10) / 10
    : null;

  const cartTotal = cart.reduce((s, i) => s + Number(i.price) * i.qty, 0);
  const deliveryFee = calculatedFee !== null ? calculatedFee : (Number(deliverySettings?.fee) || 0);
  const finalTotal = cartTotal + deliveryFee;
  const minOrder = Number(deliverySettings?.min_order) || 0;
  const cartItemCount = cart.reduce((s, i) => s + i.qty, 0);

  const addToCart = (item) => {
    const extraIds = (item.selectedExtras || []).map(e => e.id).sort((a, b) => a - b);
    const key = `${item.id}_${extraIds.join(',')}`;
    setCart(prev => {
      const existing = prev.find(i => i.cartKey === key);
      if (existing) return prev.map(i => i.cartKey === key ? { ...i, qty: i.qty + item.qty } : i);
      return [...prev, { ...item, cartKey: key }];
    });
  };

  const handleCheckout = () => {
    if (!customer) { setPendingCheckout(true); setShowAuth(true); return; }
    setShowCheckout(true);
  };

  const handleAuth = (c, t) => {
    setCustomer(c);
    localStorage.setItem('deliveryToken', t);
    setShowAuth(false);
    if (pendingCheckout) { setPendingCheckout(false); setShowCheckout(true); }
  };

  const placeOrder = async () => {
    if (!deliveryAddress.trim()) return;
    setPlacing(true);
    try {
      const orderBody = {
        store_id: store.id,
        order_type: 'delivery',
        payment_method: paymentMethod === 'card' ? 'card' : 'cash',
        source: 'delivery_app',
        delivery_address: deliveryAddress,
        delivery_fee: deliveryFee,
        delivery_customer_id: customer.id,
        customer_name: customer.name,
        customer_phone: customer.phone,
        customer_email: customer.email,
        total: finalTotal.toFixed(2),
        items: cart.map(i => ({
          product_id: i.id, quantity: i.qty, unit_price: i.price,
          selected_ingredients: i.selectedIngredients || [],
          selected_extras: i.selectedExtras || []
        })),
        delivery: true
      };

      const orderRes = await fetch(`${API}/api/orders`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderBody)
      });
      const order = await orderRes.json();
      if (!orderRes.ok) throw new Error(order.error || 'Error al crear pedido');

      if (paymentMethod === 'card') {
        const hRes = await fetch(`${API}/api/haulmer/payment`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            store_id: store.id, order_id: order.id,
            amount: Math.round(finalTotal),
            description: `Delivery #${order.id}`,
            return_url: `/delivery/${code}`,
            customer_email: customer.email,
            customer_name: customer.name,
            customer_phone: customer.phone
          })
        });
        const hData = await hRes.json();
        if (!hData.success) throw new Error(hData.error || 'Error generando pago Haulmer');
        localStorage.setItem('deliveryLastEstimated', String(deliverySettings?.estimated_minutes || 45));
        window.location.href = hData.paymentUrl;
        return;
      }

      setPayStep('success');
      setCart([]);
      localStorage.setItem('deliveryLastOrderId', String(order.id));
    } catch (e) { alert(e.message); }
    finally { setPlacing(false); }
  };

  const categoriesWithProducts = categories
    .map(cat => ({ ...cat, products: products.filter(p => String(p.category_id) === String(cat.id)) }))
    .filter(c => c.products.length > 0);
  const uncategorized = products.filter(p => !p.category_id || !categories.find(c => String(c.id) === String(p.category_id)));

  // ── Loading ──────────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div style={{ minHeight: '100vh', background: '#f4f4f6', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: 48, height: 48, border: '3px solid #e5e7eb', borderTopColor: '#D4AF37', borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto 16px' }} />
          <p style={{ color: '#9ca3af', fontWeight: 600, fontSize: 14, margin: 0 }}>Cargando menú...</p>
        </div>
      </div>
    );
  }

  if (!store) {
    return (
      <div style={{ minHeight: '100vh', background: '#f4f4f6', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center', color: '#6b7280' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>🍽️</div>
          <div style={{ fontWeight: 700, color: '#374151', fontSize: 18 }}>Restaurante no encontrado</div>
        </div>
      </div>
    );
  }

  const logoSrc = store.logo_url ? (store.logo_url.startsWith('http') ? store.logo_url : `${API}${store.logo_url}`) : null;
  const hasCategoryBar = categoriesWithProducts.length > 1;

  // ── Render ───────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight: '100vh', background: '#f4f4f6', fontFamily: "'Inter', system-ui, -apple-system, sans-serif", paddingBottom: cart.length > 0 ? 100 : 48 }}>

      {/* ── Sticky Header ─────────────────────────────────────────────────────── */}
      <header style={{
        background: 'rgba(255,255,255,0.97)', backdropFilter: 'blur(12px)',
        borderBottom: '1px solid rgba(0,0,0,0.07)',
        position: 'sticky', top: 0, zIndex: 50,
        boxShadow: '0 2px 16px rgba(0,0,0,0.06)'
      }}>
        <div style={{ maxWidth: 700, margin: '0 auto', padding: '0 16px', display: 'flex', alignItems: 'center', gap: 12, height: 58 }}>
          <button
            onClick={() => navigate('/delivery')}
            style={{ background: '#f3f4f6', border: 'none', borderRadius: 12, color: '#374151', width: 38, height: 38, cursor: 'pointer', fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}
          >←</button>

          {logoSrc && (
            <img src={logoSrc} alt="" style={{ width: 38, height: 38, borderRadius: 10, objectFit: 'cover', flexShrink: 0, boxShadow: '0 2px 8px rgba(0,0,0,0.12)' }} />
          )}

          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 800, fontSize: 16, color: '#111', lineHeight: 1.2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{store.name}</div>
            {deliverySettings && (
              <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 1 }}>
                🚚 {deliverySettings.fee > 0 ? `$${deliverySettings.fee}` : 'Gratis'} · ⏱ ~{deliverySettings.estimated_minutes || 45} min
              </div>
            )}
          </div>

          {customer ? (
            <button
              onClick={() => navigate('/delivery/account')}
              style={{ background: 'rgba(212,175,55,0.1)', border: '1.5px solid rgba(212,175,55,0.3)', borderRadius: 10, color: '#C49B1E', padding: '7px 12px', cursor: 'pointer', fontSize: 12, fontWeight: 700, flexShrink: 0, whiteSpace: 'nowrap' }}
            >
              👤 {customer.name?.split(' ')[0]}
            </button>
          ) : (
            <button
              onClick={() => { setPendingCheckout(false); setShowAuth(true); }}
              style={{ background: 'rgba(212,175,55,0.1)', border: '1.5px solid rgba(212,175,55,0.3)', borderRadius: 10, color: '#C49B1E', padding: '7px 12px', cursor: 'pointer', fontSize: 12, fontWeight: 700, flexShrink: 0 }}
            >Ingresar</button>
          )}
        </div>
      </header>

      {/* ── Hero Banner ───────────────────────────────────────────────────────── */}
      <div style={{ position: 'relative', height: 200, background: '#111', overflow: 'hidden' }}>
        {logoSrc && (
          <img src={logoSrc} alt={store.name} style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: 0.65 }} />
        )}
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(to top, rgba(0,0,0,0.82) 0%, rgba(0,0,0,0.25) 55%, transparent 100%)',
          display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', padding: '18px 20px'
        }}>
          <h1 style={{ color: '#fff', fontSize: 22, fontWeight: 900, margin: '0 0 10px', textShadow: '0 1px 4px rgba(0,0,0,0.4)' }}>{store.name}</h1>
          {deliverySettings && (
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <span style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(8px)', color: '#fff', borderRadius: 20, padding: '5px 12px', fontSize: 12, fontWeight: 700, border: '1px solid rgba(255,255,255,0.2)' }}>
                🚚 {deliverySettings.fee > 0 ? `Envío $${deliverySettings.fee}` : 'Envío gratis'}
              </span>
              <span style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(8px)', color: '#fff', borderRadius: 20, padding: '5px 12px', fontSize: 12, fontWeight: 700, border: '1px solid rgba(255,255,255,0.2)' }}>
                ⏱ ~{deliverySettings.estimated_minutes || 45} min
              </span>
              {minOrder > 0 && (
                <span style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(8px)', color: '#fff', borderRadius: 20, padding: '5px 12px', fontSize: 12, fontWeight: 700, border: '1px solid rgba(255,255,255,0.2)' }}>
                  🛒 Mínimo ${minOrder}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── Category Pills ────────────────────────────────────────────────────── */}
      {hasCategoryBar && (
        <div style={{
          background: '#fff', borderBottom: '1px solid rgba(0,0,0,0.06)',
          position: 'sticky', top: 58, zIndex: 40,
          overflowX: 'auto', scrollbarWidth: 'none'
        }}>
          <style>{`.cat-bar::-webkit-scrollbar { display: none; }`}</style>
          <div className="cat-bar" style={{ display: 'flex', gap: 6, padding: '10px 16px', whiteSpace: 'nowrap', maxWidth: 700, margin: '0 auto' }}>
            {categoriesWithProducts.map(cat => (
              <button
                key={cat.id}
                onClick={() => {
                  setActiveCategory(cat.id);
                  const el = document.getElementById(`cat-${cat.id}`);
                  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }}
                style={{
                  padding: '7px 16px', borderRadius: 20, border: 'none', cursor: 'pointer',
                  fontSize: 13, fontWeight: 700, whiteSpace: 'nowrap', flexShrink: 0,
                  background: activeCategory === cat.id ? '#D4AF37' : 'rgba(0,0,0,0.06)',
                  color: activeCategory === cat.id ? '#000' : '#374151',
                  transition: 'all 0.15s'
                }}
              >{cat.name}</button>
            ))}
          </div>
        </div>
      )}

      {/* ── Menu ──────────────────────────────────────────────────────────────── */}
      <div style={{ maxWidth: 700, margin: '0 auto', padding: '20px 16px 0' }}>
        {categoriesWithProducts.map(cat => (
          <div
            key={cat.id}
            id={`cat-${cat.id}`}
            style={{ marginBottom: 32, scrollMarginTop: hasCategoryBar ? 112 : 70 }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              <div style={{ width: 4, height: 20, background: '#D4AF37', borderRadius: 2, flexShrink: 0 }} />
              <h2 style={{ fontSize: 18, fontWeight: 800, color: '#111', margin: 0, letterSpacing: -0.3 }}>{cat.name}</h2>
              <div style={{ flex: 1, height: 1, background: 'rgba(0,0,0,0.08)' }} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {cat.products.map(p => (
                <ProductCard key={p.id} product={p} cart={cart} onSelect={() => setSelectedProduct(p)} />
              ))}
            </div>
          </div>
        ))}

        {uncategorized.length > 0 && (
          <div style={{ marginBottom: 32 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              <div style={{ width: 4, height: 20, background: '#D4AF37', borderRadius: 2, flexShrink: 0 }} />
              <h2 style={{ fontSize: 18, fontWeight: 800, color: '#111', margin: 0 }}>Otros</h2>
              <div style={{ flex: 1, height: 1, background: 'rgba(0,0,0,0.08)' }} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {uncategorized.map(p => (
                <ProductCard key={p.id} product={p} cart={cart} onSelect={() => setSelectedProduct(p)} />
              ))}
            </div>
          </div>
        )}

        {products.length === 0 && (
          <div style={{ textAlign: 'center', padding: '80px 20px', color: '#9ca3af' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>🍽️</div>
            <p style={{ fontWeight: 700, color: '#374151', fontSize: 16, margin: '0 0 8px' }}>Sin productos disponibles</p>
            <p style={{ fontSize: 14, margin: 0 }}>El menú estará disponible próximamente</p>
          </div>
        )}
      </div>

      {/* ── Floating Cart ─────────────────────────────────────────────────────── */}
      {cart.length > 0 && (
        <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, padding: '12px 16px 32px', background: 'linear-gradient(to top, #f4f4f6 72%, transparent)', zIndex: 40 }}>
          <div style={{ maxWidth: 700, margin: '0 auto' }}>
            <button
              onClick={handleCheckout}
              disabled={cartTotal < minOrder}
              style={{
                width: '100%', padding: '16px 20px', borderRadius: 16, border: 'none',
                background: cartTotal >= minOrder ? 'linear-gradient(135deg, #D4AF37 0%, #B8952D 100%)' : '#d1d5db',
                color: cartTotal >= minOrder ? '#000' : '#9ca3af',
                fontWeight: 800, fontSize: 15, cursor: cartTotal >= minOrder ? 'pointer' : 'not-allowed',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                boxShadow: cartTotal >= minOrder ? '0 6px 24px rgba(212,175,55,0.5)' : 'none',
                transition: 'all 0.15s'
              }}
            >
              <div style={{ background: 'rgba(0,0,0,0.15)', borderRadius: 10, padding: '4px 12px', fontSize: 13, fontWeight: 900 }}>
                {cartItemCount} {cartItemCount === 1 ? 'ítem' : 'ítems'}
              </div>
              <span>{cartTotal < minOrder ? `Mínimo $${minOrder}` : 'Ver pedido'}</span>
              <span style={{ fontWeight: 900, fontSize: 16 }}>${finalTotal.toFixed(0)}</span>
            </button>
          </div>
        </div>
      )}

      {/* Product Modal */}
      {selectedProduct && <ProductModal product={selectedProduct} onAdd={addToCart} onClose={() => setSelectedProduct(null)} />}

      {/* Auth Modal */}
      {showAuth && <DeliveryAuthModal onAuth={handleAuth} onClose={() => setShowAuth(false)} />}

      {/* ── Checkout Modal ────────────────────────────────────────────────────── */}
      {showCheckout && payStep !== 'success' && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.65)', zIndex: 9999, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
          <div style={{ background: '#f4f4f6', borderRadius: '24px 24px 0 0', width: '100%', maxWidth: 500, maxHeight: '92vh', overflowY: 'auto', boxShadow: '0 -8px 40px rgba(0,0,0,0.2)' }}>

            {/* Header */}
            <div style={{ background: '#fff', borderRadius: '24px 24px 0 0', padding: '14px 20px 16px', position: 'sticky', top: 0, zIndex: 10, borderBottom: '1px solid #f0f0f0' }}>
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 14 }}>
                <div style={{ width: 40, height: 4, background: '#e5e7eb', borderRadius: 2 }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h2 style={{ margin: 0, fontSize: 18, fontWeight: 900, color: '#111' }}>Confirmar pedido</h2>
                <button onClick={() => setShowCheckout(false)} style={{ background: '#f3f4f6', border: 'none', borderRadius: '50%', width: 34, height: 34, color: '#6b7280', fontSize: 18, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>×</button>
              </div>
            </div>

            <div style={{ padding: '14px 14px 44px', display: 'flex', flexDirection: 'column', gap: 10 }}>

              {/* Order summary */}
              <div style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
                <div style={{ padding: '14px 16px 0', fontWeight: 800, fontSize: 12, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: 0.6 }}>Tu pedido</div>
                <div style={{ padding: '10px 16px 0' }}>
                  {cart.map(item => (
                    <div key={item.cartKey} style={{ padding: '9px 0', borderBottom: '1px solid #f3f4f6' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: '#111', fontWeight: 600 }}>
                        <span>{item.qty}× {item.name}</span>
                        <span>${(item.price * item.qty).toFixed(0)}</span>
                      </div>
                      {item.selectedExtras?.length > 0 && (
                        <div style={{ fontSize: 12, color: '#D4AF37', marginTop: 2, fontWeight: 500 }}>+ {item.selectedExtras.map(e => e.name).join(', ')}</div>
                      )}
                      {item.selectedIngredients?.length > 0 && (
                        <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 1 }}>{item.selectedIngredients.map(i => i.name).join(', ')}</div>
                      )}
                    </div>
                  ))}
                </div>
                <div style={{ padding: '12px 16px 16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: '#6b7280', marginBottom: 5 }}>
                    <span>Subtotal</span><span>${cartTotal.toFixed(0)}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: deliveryFee === 0 ? '#16a34a' : '#6b7280', marginBottom: 8 }}>
                    <span>Envío</span><span>{deliveryFee > 0 ? `$${deliveryFee}` : '🎉 Gratis'}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 19, fontWeight: 900, color: '#111', paddingTop: 8, borderTop: '1.5px solid #f0f0f0' }}>
                    <span>Total</span><span style={{ color: '#D4AF37' }}>${finalTotal.toFixed(0)}</span>
                  </div>
                </div>
              </div>

              {/* Address */}
              <div style={{ background: '#fff', borderRadius: 16, padding: '14px 16px', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
                <div style={{ fontWeight: 800, fontSize: 12, color: '#9ca3af', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.6 }}>Dirección de entrega</div>
                <input
                  type="text" placeholder="Ej: Av. Siempre Viva 742, piso 3"
                  value={deliveryAddress}
                  onChange={e => setDeliveryAddress(e.target.value)}
                  style={{ width: '100%', padding: '13px 14px', background: '#f9fafb', border: '1.5px solid #e5e7eb', borderRadius: 12, color: '#111', fontSize: 14, outline: 'none', boxSizing: 'border-box', marginBottom: 10 }}
                />
                <button onClick={detectGPS} disabled={gpsLoading} style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  background: customerCoords ? '#f0fdf4' : '#f9fafb',
                  border: customerCoords ? '1px solid #bbf7d0' : '1.5px solid #e5e7eb',
                  borderRadius: 10, padding: '9px 14px', cursor: gpsLoading ? 'default' : 'pointer',
                  color: customerCoords ? '#15803d' : '#6b7280', fontSize: 13, fontWeight: 600, transition: 'all 0.15s'
                }}>
                  📍 {gpsLoading ? 'Detectando...' : customerCoords ? '✓ Ubicación detectada' : 'Detectar mi ubicación GPS'}
                </button>
                {distanceKm !== null && (
                  <div style={{ marginTop: 8, background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 10, padding: '8px 12px', fontSize: 13, color: '#92400e' }}>
                    📏 Distancia al local: <strong>{distanceKm} km</strong>
                    {deliverySettings?.fee_type === 'per_km' && <span> · Envío calculado: <strong>${deliveryFee}</strong></span>}
                  </div>
                )}
              </div>

              {/* Customer info */}
              <div style={{ background: '#fff', borderRadius: 16, padding: '14px 16px', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
                <div style={{ fontWeight: 800, fontSize: 12, color: '#9ca3af', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.6 }}>Datos de contacto</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 5, fontSize: 13, color: '#374151' }}>
                  <div>👤 <strong>{customer?.name}</strong></div>
                  {customer?.phone && <div>📞 {customer.phone}</div>}
                  <div>📧 {customer?.email}</div>
                </div>
              </div>

              {/* Payment */}
              <div style={{ background: '#fff', borderRadius: 16, padding: '14px 16px', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
                <div style={{ fontWeight: 800, fontSize: 12, color: '#9ca3af', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.6 }}>Método de pago</div>
                {deliverySettings?.payment_cash !== false && deliverySettings?.payment_card ? (
                  <div style={{ display: 'flex', gap: 8 }}>
                    {[
                      { value: 'cash', label: '💵 Efectivo', desc: 'Al recibir' },
                      { value: 'card', label: '💳 Tarjeta Tuu', desc: 'Terminal contra entrega' }
                    ].map(opt => (
                      <div key={opt.value} onClick={() => setPaymentMethod(opt.value)} style={{
                        flex: 1, padding: '12px', borderRadius: 12, cursor: 'pointer',
                        border: paymentMethod === opt.value ? '2px solid #D4AF37' : '1.5px solid #e5e7eb',
                        background: paymentMethod === opt.value ? 'rgba(212,175,55,0.06)' : '#f9fafb',
                        transition: 'all 0.15s'
                      }}>
                        <div style={{ fontWeight: 700, fontSize: 13, color: '#111' }}>{opt.label}</div>
                        <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>{opt.desc}</div>
                      </div>
                    ))}
                  </div>
                ) : deliverySettings?.payment_card && deliverySettings?.payment_cash === false ? (
                  <div style={{ background: '#f0f9ff', border: '1px solid #bae6fd', borderRadius: 10, padding: '10px 14px', fontSize: 13, color: '#0369a1', fontWeight: 600 }}>
                    💳 Tarjeta con terminal Tuu (contra entrega)
                  </div>
                ) : (
                  <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 10, padding: '10px 14px', fontSize: 13, color: '#15803d', fontWeight: 600 }}>
                    💵 Efectivo contra entrega
                  </div>
                )}
              </div>

              <button
                onClick={placeOrder}
                disabled={!deliveryAddress.trim() || placing}
                style={{
                  padding: '16px', marginTop: 4,
                  background: !deliveryAddress.trim() || placing ? '#d1d5db' : 'linear-gradient(135deg, #D4AF37 0%, #B8952D 100%)',
                  color: !deliveryAddress.trim() || placing ? '#9ca3af' : '#000',
                  border: 'none', borderRadius: 16, fontWeight: 800, fontSize: 16,
                  cursor: !deliveryAddress.trim() || placing ? 'not-allowed' : 'pointer',
                  boxShadow: deliveryAddress.trim() && !placing ? '0 6px 24px rgba(212,175,55,0.5)' : 'none',
                  transition: 'all 0.15s'
                }}
              >
                {placing ? '⏳ Enviando pedido...' : `🚀 Confirmar pedido · $${finalTotal.toFixed(0)}`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Success Screen ────────────────────────────────────────────────────── */}
      {payStep === 'success' && (
        <div style={{ position: 'fixed', inset: 0, background: '#fff', zIndex: 9999, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '24px 24px 56px' }}>
          <div style={{ textAlign: 'center', maxWidth: 360, width: '100%' }}>
            <div style={{
              width: 104, height: 104,
              background: 'linear-gradient(135deg, rgba(212,175,55,0.12), rgba(212,175,55,0.04))',
              borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
              margin: '0 auto 26px', fontSize: 50,
              border: '2px solid rgba(212,175,55,0.25)',
              boxShadow: '0 8px 40px rgba(212,175,55,0.18)'
            }}>🎉</div>

            <h2 style={{ color: '#111', fontSize: 26, fontWeight: 900, margin: '0 0 10px' }}>¡Pedido enviado!</h2>
            <p style={{ color: '#6b7280', fontSize: 14, lineHeight: 1.7, margin: '0 0 28px' }}>
              Tu pedido llegó al restaurante.<br />En breve lo confirman y comienzan a prepararlo.
            </p>

            <div style={{ background: '#f4f4f6', borderRadius: 20, padding: '20px 24px', marginBottom: 24, border: '1px solid rgba(0,0,0,0.06)' }}>
              <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.6, fontWeight: 700 }}>Tiempo estimado de entrega</div>
              <div style={{ fontSize: 40, fontWeight: 900, color: '#D4AF37', lineHeight: 1 }}>
                ~{deliverySettings?.estimated_minutes || parseInt(localStorage.getItem('deliveryLastEstimated') || '45')} min
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, width: '100%' }}>
              {localStorage.getItem('deliveryLastOrderId') && (
                <button
                  onClick={() => navigate(`/delivery/track/${localStorage.getItem('deliveryLastOrderId')}`)}
                  style={{
                    background: 'linear-gradient(135deg, #D4AF37 0%, #B8952D 100%)',
                    color: '#000', border: 'none', borderRadius: 16,
                    padding: '16px', fontWeight: 800, fontSize: 15, cursor: 'pointer',
                    boxShadow: '0 6px 24px rgba(212,175,55,0.4)', width: '100%'
                  }}
                >📍 Seguir mi pedido</button>
              )}
              <button
                onClick={() => { setPayStep('address'); setShowCheckout(false); navigate('/delivery'); }}
                style={{ background: '#f3f4f6', color: '#374151', border: 'none', borderRadius: 16, padding: '14px', fontWeight: 700, fontSize: 14, cursor: 'pointer', width: '100%' }}
              >Volver al inicio</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
