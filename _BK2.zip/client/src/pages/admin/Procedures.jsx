import { useEffect, useState, useRef } from 'react';
import { useStore } from '../../components/Layout';
import { useAuth } from '../../context/AuthContext';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faClipboardList, faPlus, faEdit, faTrash, faBrain,
  faImage, faSave, faTimes, faChevronUp, faChevronDown,
  faSpinner, faArrowLeft, faLightbulb, faGripLines,
  faEye, faEyeSlash, faCheck, faTable, faPrint, faSearch, faPalette
} from '@fortawesome/free-solid-svg-icons';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { Table as TiptapTable, TableRow, TableHeader, TableCell } from '@tiptap/extension-table';
import { TextAlign } from '@tiptap/extension-text-align';
import { TextStyle } from '@tiptap/extension-text-style';
import { Color } from '@tiptap/extension-color';
import { Highlight } from '@tiptap/extension-highlight';

const API = 'https://srservi2.srautomatic.com';
const GOLD = '#D4AF37';

const emptyStep = () => ({ title: '', instruction: '', tip: '', image_url: '' });
const emptyDesign = () => ({ theme: 'dark', bgColor: '#111111', accentColor: '#D4AF37', coverImage: '' });

const THEMES = [
  { id: 'dark',    name: 'Dark Pro',      bg: '#111111', accent: '#D4AF37', text: '#fff' },
  { id: 'white',   name: 'Clásico',       bg: '#ffffff', accent: '#111111', text: '#111' },
  { id: 'gold',    name: 'Gold Rush',     bg: '#7a5c00', accent: '#FFD700', text: '#fff' },
  { id: 'red',     name: 'Bistro Rojo',   bg: '#991b1b', accent: '#fca5a5', text: '#fff' },
  { id: 'green',   name: 'Cocina Verde',  bg: '#14532d', accent: '#86efac', text: '#fff' },
  { id: 'blue',    name: 'Azul Marino',   bg: '#1e3a8a', accent: '#93c5fd', text: '#fff' },
  { id: 'purple',  name: 'Morado Chef',   bg: '#4c1d95', accent: '#c4b5fd', text: '#fff' },
  { id: 'slate',   name: 'Pizarra',       bg: '#1e293b', accent: '#94a3b8', text: '#fff' },
];

const stripHtml = (html) => (html || '').replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').trim();

/* ── Editor de texto enriquecido (TipTap) ── */
function RichEditor({ value, onChange }) {
  const editor = useEditor({
    extensions: [
      StarterKit.configure({ heading: false }),
      TiptapTable.configure({ resizable: false }),
      TableRow,
      TableHeader,
      TableCell,
      TextAlign.configure({ types: ['paragraph'] }),
      TextStyle,
      Color,
      Highlight.configure({ multicolor: false }),
    ],
    content: value || '<p></p>',
    onUpdate: ({ editor }) => onChange(editor.getHTML()),
  });

  /* Sync cuando cambia externamente (ej: generación de IA) */
  useEffect(() => {
    if (!editor) return;
    const normalized = (value && !value.startsWith('<')) ? `<p>${value}</p>` : (value || '');
    if (normalized !== editor.getHTML()) {
      editor.commands.setContent(normalized, false);
    }
  }, [editor, value]);

  if (!editor) return null;

  const inTable = editor.isActive('table');

  const Btn = ({ onClick, active, children, title }) => (
    <button type="button" onClick={onClick} title={title}
      style={{
        padding: '2px 7px', borderRadius: 5, border: '1px solid',
        borderColor: active ? GOLD : '#d1d5db',
        background: active ? '#fffdf0' : '#fff',
        color: active ? '#92400e' : '#374151',
        fontWeight: 700, fontSize: 12, cursor: 'pointer',
        lineHeight: '20px', whiteSpace: 'nowrap'
      }}>
      {children}
    </button>
  );

  const Sep = () => <div style={{ width: 1, height: 20, background: '#e5e7eb', margin: '0 2px', flexShrink: 0 }} />;

  return (
    <div className="rich-editor-wrapper">
      {/* Barra de herramientas */}
      <div style={{
        background: '#f9fafb', borderBottom: '1px solid #e5e7eb',
        padding: '6px 10px', display: 'flex', gap: 4, flexWrap: 'wrap', alignItems: 'center'
      }}>
        <Btn active={editor.isActive('bold')} onClick={() => editor.chain().focus().toggleBold().run()} title="Negrita"><b>N</b></Btn>
        <Btn active={editor.isActive('italic')} onClick={() => editor.chain().focus().toggleItalic().run()} title="Cursiva"><i>C</i></Btn>
        <Btn active={editor.isActive('strike')} onClick={() => editor.chain().focus().toggleStrike().run()} title="Tachado"><s>T</s></Btn>
        <Sep />
        <Btn active={editor.isActive('bulletList')} onClick={() => editor.chain().focus().toggleBulletList().run()} title="Lista con viñetas">• Lista</Btn>
        <Btn active={editor.isActive('orderedList')} onClick={() => editor.chain().focus().toggleOrderedList().run()} title="Lista numerada">1. Lista</Btn>
        <Sep />
        <Btn active={false}
          onClick={() => editor.chain().focus().insertTable({ rows: 4, cols: 3, withHeaderRow: true }).run()}
          title="Insertar tabla (3 columnas, 4 filas)">
          ⊞ Tabla
        </Btn>
        {inTable && (
          <>
            <Sep />
            <Btn active={false} onClick={() => editor.chain().focus().addColumnAfter().run()} title="Añadir columna">+Col</Btn>
            <Btn active={false} onClick={() => editor.chain().focus().deleteColumn().run()} title="Eliminar columna">−Col</Btn>
            <Btn active={false} onClick={() => editor.chain().focus().addRowAfter().run()} title="Añadir fila">+Fila</Btn>
            <Btn active={false} onClick={() => editor.chain().focus().deleteRow().run()} title="Eliminar fila">−Fila</Btn>
            <Btn active={false} onClick={() => editor.chain().focus().deleteTable().run()} title="Eliminar tabla" style={{ color: '#ef4444' }}>✕ Tabla</Btn>
          </>
        )}
        <Sep />
        <Btn active={editor.isActive('highlight')} onClick={() => editor.chain().focus().toggleHighlight().run()} title="Resaltar texto">◨ Resaltar</Btn>
      </div>
      <EditorContent editor={editor} className="rich-editor-content" />
    </div>
  );
}

function imgSrc(url) {
  if (!url) return '';
  return url.startsWith('http') ? url : API + url;
}

/* ── Zona de imagen de un paso ── */
function ImageSearchModal({ onSelect, onClose }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const search = async () => {
    if (!query.trim()) return;
    setLoading(true); setSearched(true);
    try {
      const res = await fetch(
        `https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(query)}&action=process&json=1&fields=product_name,image_url&page_size=30`
      );
      const data = await res.json();
      setResults((data.products || []).filter(p => p.image_url));
    } catch { setResults([]); }
    finally { setLoading(false); }
  };

  return (
    <div onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      style={{ position: 'fixed', inset: 0, zIndex: 99999, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ background: '#fff', borderRadius: 16, width: '100%', maxWidth: 640, maxHeight: '85vh', display: 'flex', flexDirection: 'column', boxShadow: '0 20px 60px rgba(0,0,0,0.3)' }} onClick={e => e.stopPropagation()}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ fontWeight: 800, fontSize: 15, flex: 1 }}>Buscar imagen</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 22, color: '#aaa', lineHeight: 1 }}>×</button>
        </div>
        <div style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb', display: 'flex', gap: 8 }}>
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && search()}
            placeholder="Ej: tomate, queso, mayonesa..."
            autoFocus
            style={{ flex: 1, padding: '9px 12px', border: '1.5px solid #e5e7eb', borderRadius: 9, fontSize: 14, outline: 'none' }}
            onFocus={e => e.target.style.borderColor = GOLD}
            onBlur={e => e.target.style.borderColor = '#e5e7eb'}
          />
          <button onClick={search} disabled={loading}
            style={{ padding: '9px 20px', borderRadius: 9, border: 'none', background: '#111', color: '#fff', fontWeight: 700, fontSize: 13, cursor: loading ? 'default' : 'pointer', opacity: loading ? 0.7 : 1 }}>
            {loading ? <FontAwesomeIcon icon={faSpinner} spin /> : 'Buscar'}
          </button>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: 14 }}>
          {loading && <div style={{ textAlign: 'center', padding: 40, color: '#888' }}>Buscando imágenes...</div>}
          {!loading && searched && !results.length && (
            <div style={{ textAlign: 'center', padding: 40, color: '#aaa' }}>Sin resultados para "{query}"</div>
          )}
          {!loading && !searched && (
            <div style={{ textAlign: 'center', padding: 40, color: '#bbb', fontSize: 13 }}>
              <FontAwesomeIcon icon={faSearch} style={{ fontSize: 28, display: 'block', margin: '0 auto 12px' }} />
              Escribí un ingrediente y presioná Buscar
            </div>
          )}
          {!loading && results.length > 0 && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))', gap: 10 }}>
              {results.map((p, i) => (
                <div key={i} onClick={() => { onSelect(p.image_url); onClose(); }}
                  style={{ cursor: 'pointer', borderRadius: 10, overflow: 'hidden', border: '2px solid #f0f0f0', transition: 'all 0.15s', background: '#fafafa' }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = GOLD; e.currentTarget.style.transform = 'scale(1.03)'; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = '#f0f0f0'; e.currentTarget.style.transform = 'scale(1)'; }}
                >
                  <div style={{ width: '100%', height: 120, background: '#f5f5f5', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <img src={p.image_url} alt={p.product_name || ''}
                      style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', display: 'block' }}
                      onError={e => { e.target.parentElement.parentElement.style.display = 'none'; }}
                    />
                  </div>
                  {p.product_name && (
                    <div style={{ fontSize: 10, padding: '4px 6px', color: '#555', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {p.product_name}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
        <div style={{ padding: '8px 16px', borderTop: '1px solid #f0f0f0', fontSize: 10, color: '#bbb', textAlign: 'center' }}>
          Fotos de Open Food Facts · Licencia libre
        </div>
      </div>
    </div>
  );
}

function ImageZone({ stepIdx, imageUrl, uploading, onUpload, onClear, onSelectUrl }) {
  const ref = useRef();
  const [dragging, setDragging] = useState(false);
  const [showSearch, setShowSearch] = useState(false);

  const handleDrop = (e) => {
    e.preventDefault(); setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) onUpload(stepIdx, file);
  };

  if (imageUrl) {
    return (
      <div style={{ position: 'relative', borderRadius: 12, overflow: 'hidden', marginTop: 12 }}>
        <img src={imgSrc(imageUrl)} alt="paso"
          style={{ width: '100%', maxHeight: 260, objectFit: 'cover', display: 'block' }} />
        <button onClick={onClear}
          style={{
            position: 'absolute', top: 8, right: 8,
            background: 'rgba(0,0,0,0.55)', border: 'none', borderRadius: 8,
            color: '#fff', width: 30, height: 30, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13
          }}>
          <FontAwesomeIcon icon={faTimes} />
        </button>
      </div>
    );
  }

  return (
    <div style={{ marginTop: 12 }}>
      {showSearch && (
        <ImageSearchModal
          onSelect={(url) => { onSelectUrl(stepIdx, url); setShowSearch(false); }}
          onClose={() => setShowSearch(false)}
        />
      )}
      <div
        onClick={() => ref.current?.click()}
        onDragOver={e => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        style={{
          borderRadius: 12, border: `2px dashed ${dragging ? GOLD : '#d1d5db'}`,
          background: dragging ? '#fffdf0' : '#f9fafb',
          padding: '18px 16px', textAlign: 'center', cursor: 'pointer',
          transition: 'all 0.15s'
        }}
      >
        <input ref={ref} type="file" accept="image/*" style={{ display: 'none' }}
          onChange={e => onUpload(stepIdx, e.target.files[0])} />
        {uploading ? (
          <div style={{ color: '#888', fontSize: 13 }}>
            <FontAwesomeIcon icon={faSpinner} spin style={{ marginRight: 7, color: GOLD }} />
            Subiendo imagen...
          </div>
        ) : (
          <>
            <FontAwesomeIcon icon={faImage} style={{ fontSize: 22, color: '#d1d5db', display: 'block', margin: '0 auto 7px' }} />
            <div style={{ fontSize: 13, color: '#6b7280', fontWeight: 600 }}>Subir desde mi dispositivo</div>
            <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>Clic o arrastra · PNG, JPG, WEBP</div>
          </>
        )}
      </div>
      <button
        onClick={e => { e.stopPropagation(); setShowSearch(true); }}
        style={{ marginTop: 7, width: '100%', padding: '9px', border: '1.5px solid #e5e7eb', borderRadius: 10, background: '#fff', cursor: 'pointer', fontSize: 12, color: '#6b7280', fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, transition: 'border-color 0.15s' }}
        onMouseEnter={e => e.currentTarget.style.borderColor = GOLD}
        onMouseLeave={e => e.currentTarget.style.borderColor = '#e5e7eb'}
      >
        <FontAwesomeIcon icon={faSearch} style={{ color: GOLD }} />
        Buscar imagen en internet
      </button>
    </div>
  );
}

/* ── Panel de diseño Photoshop-like ── */
function DesignPanel({ design, onChange, storeId, token }) {
  const d = design || emptyDesign();
  const [uploading, setUploading] = useState(false);
  const coverRef = useRef();

  const set = (key, val) => onChange({ ...d, [key]: val });
  const applyTheme = (theme) => onChange({ ...d, theme: theme.id, bgColor: theme.bg, accentColor: theme.accent });

  const uploadCover = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData(); fd.append('image', file); fd.append('store_id', storeId);
      const res = await fetch(`${API}/api/upload`, { method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: fd });
      if (res.ok) { const data = await res.json(); set('coverImage', data.url || data.path || data.file || ''); }
    } finally { setUploading(false); }
  };

  const textColor = THEMES.find(t => t.id === d.theme)?.text || '#fff';

  return (
    <div style={{ background: '#fff', border: '1.5px solid #e5e7eb', borderRadius: 16, padding: '20px', marginBottom: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 18 }}>
        <FontAwesomeIcon icon={faPalette} style={{ color: GOLD, fontSize: 15 }} />
        <span style={{ fontWeight: 800, fontSize: 14, color: '#111' }}>Diseño de la guía</span>
      </div>

      {/* Temas preset */}
      <div style={{ marginBottom: 18 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 10 }}>Temas preset</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {THEMES.map(theme => (
            <button key={theme.id} onClick={() => applyTheme(theme)} title={theme.name}
              style={{
                position: 'relative', width: 56, height: 40, borderRadius: 10, cursor: 'pointer', overflow: 'hidden', flexShrink: 0,
                border: `2.5px solid ${d.theme === theme.id ? GOLD : '#e5e7eb'}`,
                background: theme.bg,
                boxShadow: d.theme === theme.id ? `0 0 0 3px ${GOLD}40` : 'none',
                transition: 'border-color 0.15s, box-shadow 0.15s'
              }}>
              <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 10, background: theme.accent, opacity: 0.9 }} />
              {d.theme === theme.id && (
                <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <FontAwesomeIcon icon={faCheck} style={{ color: theme.text, fontSize: 13, filter: 'drop-shadow(0 1px 2px rgba(0,0,0,0.5))' }} />
                </div>
              )}
            </button>
          ))}
        </div>
        <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 6 }}>
          {THEMES.find(t => t.id === d.theme)?.name || 'Personalizado'}
        </div>
      </div>

      {/* Colores personalizados */}
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <div style={{ flex: 1, minWidth: 140 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 8 }}>Fondo del encabezado</div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <input type="color" value={d.bgColor} onChange={e => set('bgColor', e.target.value)}
              style={{ width: 40, height: 36, border: '1.5px solid #e5e7eb', borderRadius: 8, cursor: 'pointer', padding: 2 }} />
            <input type="text" value={d.bgColor} onChange={e => set('bgColor', e.target.value)}
              placeholder="#111111" maxLength={7}
              style={{ flex: 1, padding: '8px 10px', border: '1.5px solid #e5e7eb', borderRadius: 8, fontSize: 13, fontFamily: 'monospace', outline: 'none', boxSizing: 'border-box' }}
              onFocus={e => e.target.style.borderColor = GOLD}
              onBlur={e => e.target.style.borderColor = '#e5e7eb'}
            />
          </div>
        </div>
        <div style={{ flex: 1, minWidth: 140 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 8 }}>Color de acento</div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <input type="color" value={d.accentColor} onChange={e => set('accentColor', e.target.value)}
              style={{ width: 40, height: 36, border: '1.5px solid #e5e7eb', borderRadius: 8, cursor: 'pointer', padding: 2 }} />
            <input type="text" value={d.accentColor} onChange={e => set('accentColor', e.target.value)}
              placeholder="#D4AF37" maxLength={7}
              style={{ flex: 1, padding: '8px 10px', border: '1.5px solid #e5e7eb', borderRadius: 8, fontSize: 13, fontFamily: 'monospace', outline: 'none', boxSizing: 'border-box' }}
              onFocus={e => e.target.style.borderColor = GOLD}
              onBlur={e => e.target.style.borderColor = '#e5e7eb'}
            />
          </div>
        </div>
      </div>

      {/* Imagen de portada */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 8 }}>Imagen de portada</div>
        <input ref={coverRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={e => uploadCover(e.target.files[0])} />
        {d.coverImage ? (
          <div style={{ position: 'relative', borderRadius: 12, overflow: 'hidden', height: 110 }}>
            <img src={imgSrc(d.coverImage)} alt="portada" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
            <button onClick={() => set('coverImage', '')}
              style={{ position: 'absolute', top: 8, right: 8, background: 'rgba(0,0,0,0.55)', border: 'none', borderRadius: 8, color: '#fff', width: 30, height: 30, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13 }}>
              <FontAwesomeIcon icon={faTimes} />
            </button>
          </div>
        ) : (
          <button onClick={() => coverRef.current?.click()}
            style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '14px 16px', border: '2px dashed #d1d5db', borderRadius: 12, background: '#f9fafb', cursor: 'pointer', color: '#6b7280', fontSize: 13, fontWeight: 600, justifyContent: 'center', boxSizing: 'border-box', transition: 'border-color 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.borderColor = GOLD}
            onMouseLeave={e => e.currentTarget.style.borderColor = '#d1d5db'}
          >
            <FontAwesomeIcon icon={uploading ? faSpinner : faImage} spin={uploading} />
            {uploading ? 'Subiendo...' : 'Subir imagen de portada'}
          </button>
        )}
      </div>

      {/* Previsualización mini */}
      <div style={{ borderRadius: 12, overflow: 'hidden', border: '1px solid #e5e7eb' }}>
        <div style={{ background: d.bgColor, padding: '14px 16px', position: 'relative' }}>
          {d.coverImage && (
            <div style={{ position: 'absolute', inset: 0, backgroundImage: `url(${imgSrc(d.coverImage)})`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.28 }} />
          )}
          <div style={{ position: 'relative' }}>
            <div style={{ color: d.accentColor, fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 3 }}>Guía de preparación</div>
            <div style={{ color: textColor, fontSize: 14, fontWeight: 800 }}>Vista previa del encabezado</div>
          </div>
        </div>
        <div style={{ background: '#f9fafb', padding: '8px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 26, height: 26, borderRadius: '50%', background: d.accentColor, flexShrink: 0 }} />
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#111' }}>Paso 1 — Descripción</div>
            <div style={{ fontSize: 11, color: '#888' }}>Instrucción del paso...</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Modal de confirmación de borrado ── */
function DeleteConfirmModal({ title, onConfirm, onCancel }) {
  return (
    <div onClick={onCancel}
      style={{ position: 'fixed', inset: 0, zIndex: 99999, background: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div onClick={e => e.stopPropagation()}
        style={{ background: '#fff', borderRadius: 16, padding: '24px 24px 20px', width: '100%', maxWidth: 380, boxShadow: '0 8px 40px rgba(0,0,0,0.18)' }}>
        <div style={{ fontWeight: 800, fontSize: 16, color: '#111', marginBottom: 10 }}>¿Eliminar procedimiento?</div>
        <div style={{ fontSize: 14, color: '#6b7280', marginBottom: 20, lineHeight: 1.5 }}>
          <strong>"{title}"</strong> se eliminará permanentemente. Esta acción no se puede deshacer.
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onCancel}
            style={{ flex: 1, padding: '11px', borderRadius: 9, border: '1.5px solid #e5e7eb', background: '#fff', color: '#374151', fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>
            Cancelar
          </button>
          <button onClick={onConfirm}
            style={{ flex: 1, padding: '11px', borderRadius: 9, border: 'none', background: '#ef4444', color: '#fff', fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>
            Eliminar
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── Card de un paso en el editor ── */
function StepCard({ step, index, total, onChange, onMove, onRemove, onUpload, onSelectUrl, uploadingStep,
  isDragging, isDragOver, onDragStart, onDragOver, onDrop, onDragEnd }) {
  const [showTip, setShowTip] = useState(!!step.tip);

  const field = (label, key, multiline = false, placeholder = '') => (
    <div style={{ marginBottom: 12 }}>
      <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 5 }}>
        {label}
      </label>
      {multiline ? (
        <textarea
          value={step[key]}
          onChange={e => onChange(index, key, e.target.value)}
          placeholder={placeholder}
          rows={3}
          style={{
            width: '100%', padding: '10px 12px', border: '1.5px solid #e5e7eb',
            borderRadius: 9, fontSize: 14, outline: 'none', resize: 'vertical',
            boxSizing: 'border-box', fontFamily: 'inherit', lineHeight: 1.5,
            transition: 'border-color 0.15s'
          }}
          onFocus={e => e.target.style.borderColor = GOLD}
          onBlur={e => e.target.style.borderColor = '#e5e7eb'}
        />
      ) : (
        <input
          type="text"
          value={step[key]}
          onChange={e => onChange(index, key, e.target.value)}
          placeholder={placeholder}
          style={{
            width: '100%', padding: '10px 12px', border: '1.5px solid #e5e7eb',
            borderRadius: 9, fontSize: 14, outline: 'none',
            boxSizing: 'border-box', transition: 'border-color 0.15s'
          }}
          onFocus={e => e.target.style.borderColor = GOLD}
          onBlur={e => e.target.style.borderColor = '#e5e7eb'}
        />
      )}
    </div>
  );

  return (
    <div
      draggable
      onDragStart={e => { e.stopPropagation(); onDragStart(index); }}
      onDragOver={e => { e.preventDefault(); e.stopPropagation(); onDragOver(index); }}
      onDrop={e => { e.preventDefault(); e.stopPropagation(); onDrop(index); }}
      onDragEnd={onDragEnd}
      style={{
        background: '#fff', borderRadius: 16,
        border: `1.5px solid ${isDragOver ? GOLD : '#e5e7eb'}`,
        boxShadow: isDragging ? 'none' : isDragOver ? `0 0 0 3px ${GOLD}40` : '0 2px 8px rgba(0,0,0,0.05)',
        opacity: isDragging ? 0.45 : 1,
        transform: isDragOver ? 'scale(1.01)' : 'scale(1)',
        transition: 'border-color 0.15s, box-shadow 0.15s, transform 0.12s, opacity 0.15s',
        overflow: 'hidden'
      }}>
      {/* Cabecera del paso */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '14px 18px', background: '#f9fafb',
        borderBottom: '1px solid #f0f0f0'
      }}>
        <FontAwesomeIcon icon={faGripLines}
          style={{ color: '#c4c9d4', fontSize: 15, cursor: 'grab', flexShrink: 0, marginRight: 2 }} />
        <div style={{
          width: 36, height: 36, borderRadius: '50%',
          background: GOLD, color: '#000', fontWeight: 900,
          fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0
        }}>
          {index + 1}
        </div>
        <span style={{ fontWeight: 700, fontSize: 14, color: '#374151', flex: 1 }}>
          Paso {index + 1}
        </span>
        <div style={{ display: 'flex', gap: 4 }}>
          {total > 1 && (
            <button onClick={() => onRemove(index)}
              style={{ width: 30, height: 30, borderRadius: 7, border: '1px solid #fecaca', background: '#fef2f2', cursor: 'pointer', color: '#ef4444', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12 }}>
              <FontAwesomeIcon icon={faTrash} />
            </button>
          )}
        </div>
      </div>

      {/* Contenido del paso */}
      <div style={{ padding: '18px 18px 14px' }}>
        {field('Título del paso', 'title', false, 'Ej: Preparar los ingredientes')}

        {/* Editor rico de instrucción */}
        <div style={{ marginBottom: 12 }}>
          <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 5 }}>
            Instrucción
          </label>
          <RichEditor
            value={step.instruction}
            onChange={(html) => onChange(index, 'instruction', html)}
          />
        </div>

        {/* Imagen */}
        <ImageZone
          stepIdx={index}
          imageUrl={step.image_url}
          uploading={uploadingStep === index}
          onUpload={onUpload}
          onClear={() => onChange(index, 'image_url', '')}
          onSelectUrl={onSelectUrl}
        />

        {/* Consejo (toggle) */}
        <div style={{ marginTop: 12 }}>
          <button
            onClick={() => setShowTip(v => !v)}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              background: 'none', border: 'none', cursor: 'pointer',
              fontSize: 12, color: showTip ? '#92400e' : '#9ca3af',
              fontWeight: 600, padding: 0
            }}
          >
            <FontAwesomeIcon icon={faLightbulb} style={{ color: showTip ? GOLD : '#d1d5db' }} />
            {showTip ? 'Ocultar consejo' : 'Agregar consejo (opcional)'}
          </button>
          {showTip && (
            <div style={{ marginTop: 8 }}>
              <input
                type="text"
                value={step.tip}
                onChange={e => onChange(index, 'tip', e.target.value)}
                placeholder="Ej: Asegúrate de que la plancha esté bien caliente"
                style={{
                  width: '100%', padding: '9px 12px', border: '1.5px solid #fde68a',
                  borderRadius: 9, fontSize: 13, outline: 'none',
                  boxSizing: 'border-box', background: '#fffdf0'
                }}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ── Editor de una tabla individual ── */
function SingleTableEditor({ table: initialTable, storeId, token, onSave, onBack, saving }) {
  const { selectedStore } = useStore() || {};
  const [table, setTable] = useState(initialTable);
  const [editingCell, setEditingCell] = useState(null);
  const [cellForm, setCellForm] = useState({ name: '', note: '', image_url: '' });
  const [uploadingCell, setUploadingCell] = useState(false);
  const [searchingCellImg, setSearchingCellImg] = useState(false);
  const [newColName, setNewColName] = useState('');
  const [addingCol, setAddingCol] = useState(false);
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 640);
  const [mobileActiveCol, setMobileActiveCol] = useState(null);

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 640);
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  useEffect(() => {
    const cols = table.columns || [];
    if (isMobile && cols.length > 0 && (!mobileActiveCol || !cols.find(c => c.id === mobileActiveCol))) {
      setMobileActiveCol(cols[0].id);
    }
  }, [isMobile, table.columns]);

  const addColumn = () => {
    if (!newColName.trim()) return;
    const id = 'c' + Date.now();
    setTable(t => ({ ...t, columns: [...(t.columns || []), { id, name: newColName.trim(), rows: t.rows || 8 }] }));
    setNewColName(''); setAddingCol(false);
    if (isMobile) setMobileActiveCol(id);
  };
  const removeColumn = (id) => setTable(t => {
    const cells = { ...t.cells };
    Object.keys(cells).forEach(k => { if (k.startsWith(id + '_')) delete cells[k]; });
    return { ...t, columns: t.columns.filter(c => c.id !== id), cells };
  });
  const renameColumn = (id, name) => setTable(t => ({ ...t, columns: t.columns.map(c => c.id === id ? { ...c, name } : c) }));
  const setColumnRows = (id, rows) => setTable(t => ({ ...t, columns: t.columns.map(c => c.id === id ? { ...c, rows } : c) }));
  const cellKey = (colId, rowIdx) => `${colId}_${rowIdx}`;
  const getCell = (colId, rowIdx) => (table.cells || {})[cellKey(colId, rowIdx)] || {};
  const openCell = (colId, rowIdx) => { const cell = getCell(colId, rowIdx); setCellForm({ name: cell.name || '', note: cell.note || '', image_url: cell.image_url || '' }); setEditingCell({ colId, rowIdx }); };
  const saveCell = () => { setTable(t => ({ ...t, cells: { ...t.cells, [cellKey(editingCell.colId, editingCell.rowIdx)]: { ...cellForm } } })); setEditingCell(null); };
  const clearCell = () => { const cells = { ...table.cells }; delete cells[cellKey(editingCell.colId, editingCell.rowIdx)]; setTable(t => ({ ...t, cells })); setEditingCell(null); };
  const uploadCellImage = async (file) => {
    if (!file) return;
    setUploadingCell(true);
    try {
      const fd = new FormData(); fd.append('image', file); fd.append('store_id', storeId);
      const res = await fetch(`${API}/api/upload`, { method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: fd });
      if (res.ok) { const data = await res.json(); setCellForm(f => ({ ...f, image_url: data.url || data.path || data.file || '' })); }
    } finally { setUploadingCell(false); }
  };

  const downloadPrepTablePDF = () => {
    const cols = table.columns || [];
    const defaultRows = table.rows || 8;
    const maxRows = cols.length > 0 ? Math.max(1, ...cols.map(c => c.rows || defaultRows)) : defaultRows;
    const isLandscape = true;
    const storeName = selectedStore?.name || 'SRServi';
    const headerCells = cols.map(col => `<th>${col.name}</th>`).join('');
    const bodyRows = Array.from({ length: maxRows }, (_, rowIdx) => {
      const tds = cols.map(col => {
        const colRows = col.rows || defaultRows;
        if (rowIdx >= colRows) return `<td class="empty"></td>`;
        const cell = (table.cells || {})[`${col.id}_${rowIdx}`] || {};
        const imgUrl = cell.image_url ? (cell.image_url.startsWith('http') ? cell.image_url : API + cell.image_url) : null;
        if (!imgUrl && !cell.name && !cell.note) return `<td><span class="empty-cell">—</span></td>`;
        let textPart = '';
        if (cell.name) textPart += `<div class="cell-name">${cell.name}</div>`;
        if (cell.note) textPart += `<div class="cell-note">${cell.note}</div>`;
        if (imgUrl && textPart) {
          return `<td><div class="cell-row"><img src="${imgUrl}" class="cell-img"><div class="cell-text">${textPart}</div></div></td>`;
        } else if (imgUrl) {
          return `<td><img src="${imgUrl}" class="cell-img-only"></td>`;
        } else {
          return `<td>${textPart}</td>`;
        }
      }).join('');
      return `<tr><td class="row-num">${rowIdx + 1}</td>${tds}</tr>`;
    }).join('');
    const css = `*{box-sizing:border-box;margin:0;padding:0}body{font-family:Arial,sans-serif;font-size:12px;color:#111;padding:10px}.hdr{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:14px;padding-bottom:10px;border-bottom:3px solid #000}.hdr h1{font-size:18px;font-weight:800}.hdr p{font-size:11px;color:#666;margin-top:3px}.hdr-r{text-align:right;font-size:11px;color:#666}table{width:100%;border-collapse:collapse}th{background:#111;color:#D4AF37;padding:8px 10px;font-size:11px;font-weight:800;text-align:center;border:1px solid #333}td{padding:6px 10px;border:1px solid #ddd;vertical-align:middle;text-align:left}.row-num{font-weight:800;font-size:13px;color:#D4AF37;background:#111;width:32px;text-align:center}.empty{background:#f5f5f5}.cell-row{display:flex;align-items:center;gap:10px}.cell-img{width:70px;height:70px;object-fit:cover;border-radius:8px;flex-shrink:0}.cell-img-only{width:70px;height:70px;object-fit:cover;border-radius:8px;display:block}.cell-text{flex:1;min-width:0}.cell-name{font-weight:700;font-size:12px;line-height:1.3;color:#111}.cell-note{font-size:10px;color:#666;margin-top:3px}.empty-cell{color:#ccc}.footer{margin-top:14px;padding-top:10px;border-top:1px solid #ddd;font-size:10px;color:#888;text-align:center}@media print{body{padding:0}@page{size:A4 landscape;margin:12mm}}`;
    const date = new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
    const html = `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>${table.title || 'Tabla de preparación'}</title><style>${css}</style></head><body><div class="hdr"><div><h1>${table.title || 'Tabla de preparación'}</h1><p>${storeName}</p></div><div class="hdr-r"><p>${date}</p></div></div><table><thead><tr><th>#</th>${headerCells}</tr></thead><tbody>${bodyRows}</tbody></table><div class="footer">SRServi — ${storeName} — ${new Date().toLocaleString('es-ES')}</div></body></html>`;
    const win = window.open('', '_blank', 'width=900,height=700');
    if (!win) { alert('Permite ventanas emergentes para generar el PDF.'); return; }
    win.document.write(html);
    win.document.close();
    setTimeout(() => win.print(), 700);
  };

  const colRowsList = (table.columns || []).map(c => c.rows || table.rows || 8);
  const maxRows = colRowsList.length > 0 ? Math.max(1, ...colRowsList) : (table.rows || 8);
  const rowArr = Array.from({ length: maxRows }, (_, i) => i);
  const inputStyle = { width: '100%', padding: '9px 12px', border: '1.5px solid #e5e7eb', borderRadius: 8, fontSize: 14, outline: 'none', boxSizing: 'border-box' };
  const labelStyle = { display: 'block', fontSize: 11, fontWeight: 700, color: '#9ca3af', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.5px' };

  return (
    <div>
      {/* Back + save bar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
        <button onClick={onBack} style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer', color: '#6b7280', fontWeight: 600, fontSize: 13, padding: 0 }}>
          <FontAwesomeIcon icon={faArrowLeft} /> Tablas
        </button>
        <div style={{ flex: 1 }} />
        <button onClick={downloadPrepTablePDF} style={{ padding: '9px 16px', borderRadius: 9, border: '1.5px solid #D4AF37', background: '#fff', color: '#111', fontWeight: 700, fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7 }}>
          <FontAwesomeIcon icon={faPrint} style={{ color: '#D4AF37' }} />
          PDF A4
        </button>
        <button onClick={() => onSave(table)} disabled={saving} style={{ padding: '9px 20px', borderRadius: 9, border: 'none', background: '#111', color: '#fff', fontWeight: 700, fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7 }}>
          <FontAwesomeIcon icon={saving ? faSpinner : faSave} spin={saving} />
          {saving ? 'Guardando...' : 'Guardar'}
        </button>
      </div>

      {/* Título */}
      <div style={{ marginBottom: 18 }}>
        <label style={labelStyle}>Título</label>
        <input value={table.title || ''} onChange={e => setTable(t => ({ ...t, title: e.target.value }))}
          style={{ ...inputStyle, fontSize: 15, fontWeight: 700 }} />
      </div>

      {/* Columnas (filas por columna) */}
      <div style={{ marginBottom: 20 }}>
        <label style={labelStyle}>Columnas — nombre y filas de cada una</label>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: isMobile ? 8 : 6, alignItems: 'center' }}>
          {(table.columns || []).map(col => (
            <div key={col.id} style={{ display: 'flex', alignItems: 'center', background: '#f3f4f6', border: '1.5px solid #e5e7eb', borderRadius: isMobile ? 12 : 8, overflow: 'hidden' }}>
              <input value={col.name} onChange={e => renameColumn(col.id, e.target.value)}
                style={{ padding: isMobile ? '10px 12px' : '5px 8px', border: 'none', background: 'transparent', fontSize: isMobile ? 14 : 13, fontWeight: 600, outline: 'none', width: Math.max(isMobile ? 80 : 60, col.name.length * 8 + 16) }} />
              <div style={{ width: 1, height: 22, background: '#d1d5db', margin: '0 2px' }} />
              <input type="number" min="1" max="30" value={col.rows || table.rows || 8}
                onChange={e => setColumnRows(col.id, Math.max(1, Math.min(30, parseInt(e.target.value) || 1)))}
                style={{ width: isMobile ? 44 : 34, padding: isMobile ? '10px 4px' : '5px 3px', border: 'none', background: 'transparent', fontSize: isMobile ? 14 : 12, fontWeight: 700, outline: 'none', textAlign: 'center', color: '#6b7280' }} />
              <span style={{ fontSize: 10, color: '#aaa', paddingRight: 4 }}>fil</span>
              <button onClick={() => removeColumn(col.id)} style={{ padding: isMobile ? '10px 12px' : '5px 7px', border: 'none', background: 'transparent', cursor: 'pointer', color: '#ef4444', fontSize: isMobile ? 16 : 13 }}>×</button>
            </div>
          ))}
          {addingCol ? (
            <div style={{ display: 'flex', gap: 6, width: isMobile ? '100%' : 'auto' }}>
              <input autoFocus value={newColName} onChange={e => setNewColName(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') addColumn(); if (e.key === 'Escape') { setAddingCol(false); setNewColName(''); } }}
                placeholder="Nombre de la columna..." style={{ padding: isMobile ? '12px 14px' : '5px 9px', border: `1.5px solid ${GOLD}`, borderRadius: isMobile ? 12 : 8, fontSize: isMobile ? 15 : 13, outline: 'none', flex: isMobile ? 1 : 'none', width: isMobile ? 'auto' : 120 }} />
              <button onClick={addColumn} style={{ padding: isMobile ? '12px 18px' : '5px 10px', borderRadius: isMobile ? 12 : 8, border: 'none', background: GOLD, color: '#000', fontWeight: 700, fontSize: isMobile ? 14 : 12, cursor: 'pointer' }}>OK</button>
              <button onClick={() => { setAddingCol(false); setNewColName(''); }} style={{ padding: isMobile ? '12px 14px' : '5px 9px', borderRadius: isMobile ? 12 : 8, border: '1px solid #e5e7eb', background: '#fff', cursor: 'pointer', color: '#888', fontSize: isMobile ? 16 : 13 }}>✕</button>
            </div>
          ) : (
            <button onClick={() => setAddingCol(true)} style={{ padding: isMobile ? '10px 16px' : '5px 10px', border: '1.5px dashed #d1d5db', borderRadius: isMobile ? 12 : 8, background: 'transparent', color: '#9ca3af', fontSize: isMobile ? 14 : 12, cursor: 'pointer' }}>
              <FontAwesomeIcon icon={faPlus} style={{ marginRight: 6 }} />Columna
            </button>
          )}
        </div>
      </div>

      {/* Grid */}
      {!(table.columns || []).length ? (
        <div style={{ textAlign: 'center', padding: '40px 24px', border: '2px dashed #e5e7eb', borderRadius: 14, color: '#9ca3af', fontSize: 14 }}>
          Agrega columnas para armar la tabla
        </div>
      ) : isMobile ? (
        /* ── Vista móvil: tabs de columna + filas como cards ── */
        <div>
          {/* Tabs de columnas scrolleables */}
          <div style={{ display: 'flex', overflowX: 'auto', gap: 8, marginBottom: 16, WebkitOverflowScrolling: 'touch', paddingBottom: 4, scrollbarWidth: 'none' }}>
            {table.columns.map(col => (
              <button key={col.id} onClick={() => setMobileActiveCol(col.id)} style={{
                padding: '10px 20px', borderRadius: 24, border: 'none', cursor: 'pointer',
                whiteSpace: 'nowrap', flexShrink: 0,
                background: mobileActiveCol === col.id ? '#111' : '#f3f4f6',
                color: mobileActiveCol === col.id ? '#fff' : '#374151',
                fontWeight: 700, fontSize: 14,
                boxShadow: mobileActiveCol === col.id ? '0 2px 8px rgba(0,0,0,0.2)' : 'none',
                transition: 'all 0.15s'
              }}>
                {col.name}
              </button>
            ))}
          </div>
          {/* Filas de la columna activa */}
          {mobileActiveCol && (() => {
            const col = table.columns.find(c => c.id === mobileActiveCol);
            if (!col) return null;
            const colRows = col.rows || table.rows || 8;
            return (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {Array.from({ length: colRows }, (_, rowIdx) => {
                  const cell = getCell(col.id, rowIdx);
                  const hasContent = cell.name || cell.image_url;
                  return (
                    <div key={rowIdx} onClick={() => openCell(col.id, rowIdx)} style={{
                      display: 'flex', alignItems: 'center', gap: 12,
                      padding: '12px 14px', borderRadius: 14,
                      border: hasContent ? '1.5px solid #e5e7eb' : '1.5px dashed #d1d5db',
                      background: '#fff', cursor: 'pointer', minHeight: 68,
                      boxShadow: hasContent ? '0 1px 4px rgba(0,0,0,0.06)' : 'none',
                      transition: 'border-color 0.15s'
                    }}>
                      <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#111', color: GOLD, fontWeight: 900, fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        {rowIdx + 1}
                      </div>
                      {cell.image_url && (
                        <img src={cell.image_url.startsWith('http') ? cell.image_url : API + cell.image_url} alt="" style={{ width: 56, height: 56, objectFit: 'cover', borderRadius: 10, flexShrink: 0 }} />
                      )}
                      <div style={{ flex: 1, minWidth: 0 }}>
                        {hasContent ? (
                          <>
                            {cell.name && <div style={{ fontWeight: 700, fontSize: 14, color: '#111', lineHeight: 1.3 }}>{cell.name}</div>}
                            {cell.note && <div style={{ fontSize: 12, color: '#6b7280', marginTop: 2 }}>{cell.note}</div>}
                          </>
                        ) : (
                          <div style={{ color: '#bbb', fontSize: 13 }}>Tocar para agregar...</div>
                        )}
                      </div>
                      <span style={{ color: '#ccc', fontSize: 22, flexShrink: 0 }}>›</span>
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>
      ) : (
        /* ── Vista desktop: tabla con scroll horizontal ── */
        <div style={{ overflowX: 'auto', borderRadius: 12, border: '1.5px solid #e5e7eb' }}>
          <table style={{ borderCollapse: 'collapse', minWidth: '100%', background: '#fff' }}>
            <thead>
              <tr>
                <th style={{ padding: '10px 14px', background: '#111', color: '#fff', fontSize: 12, fontWeight: 700, borderRight: '1px solid #333', width: 36, textAlign: 'center' }}>#</th>
                {table.columns.map(col => (
                  <th key={col.id} style={{ padding: '10px 16px', background: '#111', color: GOLD, fontSize: 12, fontWeight: 700, borderRight: '1px solid #333', textAlign: 'left', whiteSpace: 'nowrap', minWidth: 180 }}>{col.name}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rowArr.map(rowIdx => (
                <tr key={rowIdx} style={{ borderBottom: '1px solid #f0f0f0' }}>
                  <td style={{ padding: '8px 14px', fontWeight: 800, fontSize: 14, color: '#111', textAlign: 'center', background: '#fafafa', borderRight: '1px solid #e5e7eb' }}>{rowIdx + 1}</td>
                  {table.columns.map(col => {
                    const colRows = col.rows || table.rows || 8;
                    if (rowIdx >= colRows) {
                      return <td key={col.id} style={{ padding: '8px 10px', borderRight: '1px solid #f0f0f0', background: '#f3f4f6', minWidth: 180 }} />;
                    }
                    const cell = getCell(col.id, rowIdx);
                    const active = editingCell?.colId === col.id && editingCell?.rowIdx === rowIdx;
                    return (
                      <td key={col.id} onClick={() => openCell(col.id, rowIdx)}
                        style={{ padding: '8px 12px', cursor: 'pointer', borderRight: '1px solid #f0f0f0', background: active ? '#fffdf0' : '#fff', transition: 'background 0.1s', verticalAlign: 'middle', textAlign: 'left', minWidth: 180 }}>
                        {(cell.name || cell.image_url) ? (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                            {cell.image_url && <img src={cell.image_url.startsWith('http') ? cell.image_url : API + cell.image_url} alt="" style={{ width: 82, height: 82, objectFit: 'cover', borderRadius: 10, flexShrink: 0 }} />}
                            <div style={{ flex: 1, minWidth: 0 }}>
                              {cell.name && <div style={{ fontSize: 13, fontWeight: 700, color: '#111', lineHeight: 1.3 }}>{cell.name}</div>}
                              {cell.note && <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>{cell.note}</div>}
                            </div>
                          </div>
                        ) : <span style={{ color: '#d1d5db', fontSize: 18 }}>+</span>}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal celda */}
      {editingCell && (
        <div onClick={e => { if (e.target === e.currentTarget) setEditingCell(null); }}
          style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: isMobile ? 'flex-end' : 'center', justifyContent: 'center', padding: isMobile ? 0 : 20 }}>
          <div style={{ background: '#fff', borderRadius: isMobile ? '20px 20px 0 0' : 16, padding: isMobile ? '20px 20px 32px' : '20px 20px 18px', width: '100%', maxWidth: isMobile ? '100%' : 360, boxShadow: '0 -4px 40px rgba(0,0,0,0.18)' }} onClick={e => e.stopPropagation()}>
            {/* Handle bar en mobile */}
            {isMobile && <div style={{ width: 40, height: 4, borderRadius: 4, background: '#d1d5db', margin: '0 auto 20px' }} />}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <div style={{ fontWeight: 800, fontSize: isMobile ? 16 : 14, color: '#111' }}>{table.columns.find(c => c.id === editingCell.colId)?.name} — Fila {editingCell.rowIdx + 1}</div>
              <button onClick={() => setEditingCell(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#aaa', fontSize: 24, lineHeight: 1, padding: '4px 8px' }}>×</button>
            </div>
            <div style={{ marginBottom: 14 }}>
              <label style={labelStyle}>Imagen</label>
              {cellForm.image_url ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <img src={cellForm.image_url.startsWith('http') ? cellForm.image_url : API + cellForm.image_url} alt="" style={{ width: isMobile ? 90 : 72, height: isMobile ? 90 : 72, objectFit: 'cover', borderRadius: 12 }} />
                  <button onClick={() => setCellForm(f => ({ ...f, image_url: '' }))} style={{ padding: isMobile ? '10px 18px' : '5px 10px', border: '1px solid #fecaca', borderRadius: 10, background: '#fef2f2', color: '#ef4444', cursor: 'pointer', fontSize: isMobile ? 14 : 12, fontWeight: 600 }}>Quitar</button>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {searchingCellImg && (
                    <ImageSearchModal
                      onSelect={(url) => { setCellForm(f => ({ ...f, image_url: url })); setSearchingCellImg(false); }}
                      onClose={() => setSearchingCellImg(false)}
                    />
                  )}
                  <label style={{ display: 'flex', alignItems: 'center', gap: 10, padding: isMobile ? '14px 16px' : '9px 12px', border: '1.5px dashed #d1d5db', borderRadius: 12, cursor: 'pointer', color: '#9ca3af', fontSize: isMobile ? 15 : 13 }}>
                    <FontAwesomeIcon icon={uploadingCell ? faSpinner : faImage} spin={uploadingCell} />
                    {uploadingCell ? 'Subiendo...' : 'Subir desde mi dispositivo'}
                    <input type="file" accept="image/*" style={{ display: 'none' }} onChange={e => uploadCellImage(e.target.files[0])} />
                  </label>
                  <button onClick={() => setSearchingCellImg(true)}
                    style={{ display: 'flex', alignItems: 'center', gap: 10, padding: isMobile ? '14px 16px' : '9px 12px', border: '1.5px solid #e5e7eb', borderRadius: 12, cursor: 'pointer', color: '#6b7280', fontSize: isMobile ? 15 : 13, background: '#fff', fontWeight: 600 }}
                  >
                    <FontAwesomeIcon icon={faSearch} style={{ color: GOLD }} />
                    Buscar imagen en internet
                  </button>
                </div>
              )}
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={labelStyle}>Nombre</label>
              <input value={cellForm.name} onChange={e => setCellForm(f => ({ ...f, name: e.target.value }))} placeholder="Ej: Mayonesa"
                style={{ ...inputStyle, padding: isMobile ? '13px 14px' : inputStyle.padding, fontSize: isMobile ? 15 : 14 }} />
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={labelStyle}>Cantidad / nota</label>
              <input value={cellForm.note} onChange={e => setCellForm(f => ({ ...f, note: e.target.value }))} placeholder="Ej: 2 cdas"
                style={{ ...inputStyle, padding: isMobile ? '13px 14px' : inputStyle.padding, fontSize: isMobile ? 15 : 14 }} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={saveCell} style={{ flex: 1, padding: isMobile ? '15px' : '11px', borderRadius: 12, border: 'none', background: '#111', color: '#fff', fontWeight: 700, fontSize: isMobile ? 16 : 14, cursor: 'pointer' }}>Guardar</button>
              <button onClick={clearCell} style={{ padding: isMobile ? '15px 20px' : '11px 14px', borderRadius: 12, border: '1px solid #fecaca', background: '#fef2f2', color: '#ef4444', cursor: 'pointer', fontSize: isMobile ? 18 : 16 }}><FontAwesomeIcon icon={faTrash} /></button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Administrador de múltiples tablas ── */
function PrepTableEditor({ storeId, token }) {
  const [tables, setTables] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingTable, setEditingTable] = useState(null); // null = lista, object = editor

  const load = async () => {
    if (!storeId || !token) return;
    setLoading(true);
    try {
      const res = await fetch(`${API}/api/prep-tables?store_id=${storeId}`, { headers: { Authorization: 'Bearer ' + token } });
      if (res.ok) {
        const data = await res.json();
        if (data.length === 0) {
          const c1 = 'c_ingr', c2 = 'c_cant', c3 = 'c_paso', c4 = 'c_tip';
          const defaultTableData = {
            store_id: storeId,
            title: 'Receta de Pan Casero',
            columns: [
              { id: c1, name: 'Ingrediente', rows: 8 },
              { id: c2, name: 'Cantidad', rows: 8 },
              { id: c3, name: 'Paso', rows: 8 },
              { id: c4, name: 'Consejo', rows: 6 },
            ],
            rows: 8,
            cells: {
              [`${c1}_0`]: { name: 'Harina de trigo', note: 'Tipo 000 o 0000' },
              [`${c1}_1`]: { name: 'Agua', note: 'Tibia, ~37 °C' },
              [`${c1}_2`]: { name: 'Levadura seca', note: 'O 21 g fresca' },
              [`${c1}_3`]: { name: 'Azúcar', note: 'Activa la levadura' },
              [`${c1}_4`]: { name: 'Sal', note: 'No mezclar con la levadura' },
              [`${c1}_5`]: { name: 'Aceite de oliva', note: 'O manteca derretida' },
              [`${c1}_6`]: { name: 'Huevo', note: 'Para barnizar la superficie' },
              [`${c1}_7`]: { name: 'Semillas', note: 'Sésamo, lino (opcional)' },
              [`${c2}_0`]: { name: '500 g', note: '' },
              [`${c2}_1`]: { name: '300 ml', note: '' },
              [`${c2}_2`]: { name: '7 g (1 sobre)', note: '' },
              [`${c2}_3`]: { name: '1 cucharada', note: '' },
              [`${c2}_4`]: { name: '1 cucharadita', note: '' },
              [`${c2}_5`]: { name: '2 cucharadas', note: '' },
              [`${c2}_6`]: { name: '1 unidad', note: '' },
              [`${c2}_7`]: { name: 'A gusto', note: '' },
              [`${c3}_0`]: { name: 'Activar levadura', note: 'Mezclar levadura + azúcar + agua tibia. Esperar 10 min hasta que espume.' },
              [`${c3}_1`]: { name: 'Mezclar secos', note: 'Harina + sal en un bowl grande. Hacer un hueco en el centro.' },
              [`${c3}_2`]: { name: 'Integrar', note: 'Verter la levadura activada y el aceite en el hueco. Mezclar hasta unir.' },
              [`${c3}_3`]: { name: 'Amasar', note: '10–15 min sobre mesa enharinada hasta masa lisa y elástica.' },
              [`${c3}_4`]: { name: '1er reposo', note: 'Cubrir con film o repasador húmedo. Dejar 1 hora en lugar tibio.' },
              [`${c3}_5`]: { name: 'Formado', note: 'Desgasificar la masa y darle forma. Colocar en bandeja aceitada.' },
              [`${c3}_6`]: { name: '2do reposo', note: 'Dejar 30 min más tapados hasta que dupliquen volumen.' },
              [`${c3}_7`]: { name: 'Hornear', note: '200 °C por 25–30 min. Barnizar con huevo batido antes de entrar al horno.' },
              [`${c4}_0`]: { name: 'Temperatura del agua', note: 'Si está muy caliente mata la levadura. Probar con el dedo: debe sentirse tibia.' },
              [`${c4}_1`]: { name: 'Test de la ventana', note: 'Estirar masa: si se transparenta sin romperse, el amasado es correcto.' },
              [`${c4}_2`]: { name: 'Lugar para levar', note: 'El horno apagado con la luz encendida mantiene ~28 °C, ideal para levar.' },
              [`${c4}_3`]: { name: 'Vapor en el horno', note: 'Poner un vaso de agua en el fondo del horno para corteza crujiente.' },
              [`${c4}_4`]: { name: 'Comprobar cocción', note: 'Golpear la base del pan: si suena hueco, está listo.' },
              [`${c4}_5`]: { name: 'Conservación', note: 'Guardar en bolsa de tela hasta 3 días a temperatura ambiente, o congelar hasta 1 mes.' },
            }
          };
          const createRes = await fetch(`${API}/api/prep-tables`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
            body: JSON.stringify(defaultTableData)
          });
          if (createRes.ok) {
            const refreshRes = await fetch(`${API}/api/prep-tables?store_id=${storeId}`, { headers: { Authorization: 'Bearer ' + token } });
            if (refreshRes.ok) setTables(await refreshRes.json());
          }
        } else {
          setTables(data);
        }
      }
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [storeId, token]);

  const newTable = async () => {
    const res = await fetch(`${API}/api/prep-tables`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify({ store_id: storeId, title: 'Nueva tabla', columns: [], rows: 8, cells: {} })
    });
    const data = await res.json();
    await load();
    setEditingTable({ id: data.id, title: 'Nueva tabla', columns: [], rows: 8, cells: {} });
  };

  const saveTable = async (tableData) => {
    setSaving(true);
    try {
      await fetch(`${API}/api/prep-tables/${tableData.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
        body: JSON.stringify({ store_id: storeId, ...tableData })
      });
      await load();
      setEditingTable(null);
    } finally { setSaving(false); }
  };

  const deleteTable = async (id) => {
    if (!confirm('¿Eliminar esta tabla?')) return;
    await fetch(`${API}/api/prep-tables/${id}?store_id=${storeId}`, { method: 'DELETE', headers: { Authorization: 'Bearer ' + token } });
    load();
  };

  if (loading) return <div style={{ padding: 32, textAlign: 'center', color: '#aaa' }}>Cargando...</div>;

  if (editingTable) {
    return <SingleTableEditor table={editingTable} storeId={storeId} token={token} onSave={saveTable} onBack={() => setEditingTable(null)} saving={saving} />;
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
        <button onClick={newTable} style={{ padding: '9px 18px', borderRadius: 9, border: 'none', background: '#111', color: '#fff', fontWeight: 700, fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7 }}>
          <FontAwesomeIcon icon={faPlus} /> Nueva tabla
        </button>
      </div>

      {tables.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 24px', border: '2px dashed #e5e7eb', borderRadius: 14, color: '#9ca3af' }}>
          <FontAwesomeIcon icon={faTable} style={{ fontSize: 36, marginBottom: 12, display: 'block' }} />
          <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 6, color: '#374151' }}>Sin tablas todavía</div>
          <div style={{ fontSize: 13, marginBottom: 18 }}>Crea una tabla visual para que tus trabajadores vean las preparaciones</div>
          <button onClick={newTable} style={{ padding: '9px 18px', borderRadius: 9, border: 'none', background: GOLD, color: '#000', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
            <FontAwesomeIcon icon={faPlus} style={{ marginRight: 7 }} />Crear primera tabla
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {tables.map(t => (
            <div key={t.id} style={{ background: '#fff', border: '1.5px solid #e5e7eb', borderRadius: 12, overflow: 'hidden', display: 'flex', alignItems: 'stretch' }}>
              <button onClick={() => setEditingTable(t)} style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
                <div style={{ width: 40, height: 40, borderRadius: 9, background: '#f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <FontAwesomeIcon icon={faTable} style={{ color: '#6b7280', fontSize: 16 }} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 14, color: '#111', lineHeight: 1.2 }}>{t.title}</div>
                  <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 2 }}>
                    {(t.columns || []).length} columna{(t.columns || []).length !== 1 ? 's' : ''}
                    {(t.columns || []).length > 0 && ` · hasta ${Math.max(...(t.columns || []).map(c => c.rows || t.rows || 8))} filas`}
                  </div>
                </div>
                <FontAwesomeIcon icon={faChevronDown} style={{ transform: 'rotate(-90deg)', color: '#bbb', fontSize: 11, flexShrink: 0 }} />
              </button>
              <button onClick={() => deleteTable(t.id)} style={{ padding: '14px 16px', background: 'none', border: 'none', borderLeft: '1px solid #f3f4f6', cursor: 'pointer', color: '#ef4444', flexShrink: 0 }}>
                <FontAwesomeIcon icon={faTrash} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}


/* ── Editor de creación personalizada (canvas 1920×1080) ── */
const CW = 1920, CH = 1080;
const FONTS = ['Arial', 'Impact', 'Georgia', 'Verdana', 'Trebuchet MS', 'Courier New', 'Times New Roman'];

function CustomCreationEditor({ storeId, token }) {
  const [creations, setCreations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(null);
  const [selected, setSelected] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [scale, setScale] = useState(0.5);
  const [saveOk, setSaveOk] = useState(false);
  const canvasWrapRef = useRef();
  const bgRef = useRef();
  const imgElemRef = useRef();
  const dragRef = useRef(null);
  const [uploadingImg, setUploadingImg] = useState(false);

  const load = async () => {
    if (!storeId || !token) return;
    setLoading(true);
    try {
      const res = await fetch(`${API}/api/custom-creations?store_id=${storeId}`, { headers: { Authorization: 'Bearer ' + token } });
      if (res.ok) setCreations(await res.json());
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [storeId, token]);

  useEffect(() => {
    if (!editing) return;
    const update = () => { if (canvasWrapRef.current) setScale(canvasWrapRef.current.offsetWidth / CW); };
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, [editing]);

  const newCreation = () => {
    setEditing({ id: null, title: 'Nueva creación', background_image: '', elements: [] });
    setSelected(null);
  };

  const openEdit = (c) => { setEditing({ ...c, elements: c.elements || [] }); setSelected(null); };

  const save = async () => {
    if (!editing) return;
    setSaving(true);
    try {
      const isNew = !editing.id;
      const url = isNew ? `${API}/api/custom-creations` : `${API}/api/custom-creations/${editing.id}`;
      const res = await fetch(url, {
        method: isNew ? 'POST' : 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
        body: JSON.stringify({ store_id: storeId, title: editing.title, background_image: editing.background_image, elements: editing.elements })
      });
      if (res.ok) {
        const data = await res.json();
        if (isNew && data.id) setEditing(p => ({ ...p, id: data.id }));
        setSaveOk(true); setTimeout(() => setSaveOk(false), 1800);
        await load();
      }
    } finally { setSaving(false); }
  };

  const del = async (id) => {
    if (!confirm('¿Eliminar esta creación?')) return;
    await fetch(`${API}/api/custom-creations/${id}?store_id=${storeId}`, { method: 'DELETE', headers: { Authorization: 'Bearer ' + token } });
    load();
  };

  const uploadBg = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData(); fd.append('image', file); fd.append('store_id', storeId);
      const res = await fetch(`${API}/api/upload`, { method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: fd });
      if (res.ok) { const d = await res.json(); setEditing(p => ({ ...p, background_image: d.url || d.path || d.file || '' })); }
    } finally { setUploading(false); }
  };

  const addText = () => {
    const el = { id: 'el_' + Date.now(), type: 'text', x: CW / 2 - 180, y: CH / 2 - 50, text: 'Texto nuevo', fontSize: 90, color: '#ffffff', fontWeight: '700', fontFamily: 'Arial', textShadow: '3px 3px 10px rgba(0,0,0,0.85)', opacity: 1 };
    setEditing(p => ({ ...p, elements: [...p.elements, el] }));
    setSelected(el.id);
  };

  const addImage = async (file) => {
    if (!file) return;
    setUploadingImg(true);
    try {
      const fd = new FormData(); fd.append('image', file); fd.append('store_id', storeId);
      const res = await fetch(`${API}/api/upload`, { method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: fd });
      if (res.ok) {
        const d = await res.json();
        const url = d.url || d.path || d.file || '';
        const el = { id: 'el_' + Date.now(), type: 'image', x: CW / 2 - 200, y: CH / 2 - 150, imgUrl: url, width: 400, height: 300, opacity: 1 };
        setEditing(p => ({ ...p, elements: [...p.elements, el] }));
        setSelected(el.id);
      }
    } finally { setUploadingImg(false); }
  };

  const updateElem = (id, key, val) => setEditing(p => ({ ...p, elements: p.elements.map(el => el.id === id ? { ...el, [key]: val } : el) }));
  const deleteElem = (id) => { setEditing(p => ({ ...p, elements: p.elements.filter(el => el.id !== id) })); setSelected(null); };

  const startDrag = (e, id) => {
    e.preventDefault(); e.stopPropagation();
    const el = editing.elements.find(el => el.id === id);
    if (!el) return;
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    dragRef.current = { id, startX: cx, startY: cy, origX: el.x, origY: el.y };
    setSelected(id);
  };

  const onMove = (e) => {
    if (!dragRef.current) return;
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    const { id, startX, startY, origX, origY } = dragRef.current;
    const dx = (cx - startX) / scale;
    const dy = (cy - startY) / scale;
    setEditing(p => ({ ...p, elements: p.elements.map(el => el.id === id ? { ...el, x: origX + dx, y: origY + dy } : el) }));
  };

  const endDrag = () => { dragRef.current = null; };

  const selectedEl = editing?.elements.find(el => el.id === selected);
  const lbStyle = { display: 'block', fontSize: 10, fontWeight: 700, color: '#6b7280', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.4px' };
  const inputStyle = { width: '100%', padding: '7px 10px', border: '1.5px solid #e5e7eb', borderRadius: 8, fontSize: 13, outline: 'none', boxSizing: 'border-box' };

  if (loading) return <div style={{ padding: 32, textAlign: 'center', color: '#aaa' }}>Cargando...</div>;

  /* ── Lista de creaciones ── */
  if (!editing) return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
        <button onClick={newCreation} style={{ padding: '9px 18px', borderRadius: 9, border: 'none', background: '#111', color: '#fff', fontWeight: 700, fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7 }}>
          <FontAwesomeIcon icon={faPlus} /> Nueva creación
        </button>
      </div>
      {creations.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 24px', border: '2px dashed #e5e7eb', borderRadius: 14, color: '#9ca3af' }}>
          <FontAwesomeIcon icon={faPalette} style={{ fontSize: 36, marginBottom: 12, display: 'block', margin: '0 auto 12px' }} />
          <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 6, color: '#374151' }}>Sin creaciones todavía</div>
          <div style={{ fontSize: 13, marginBottom: 18 }}>Diseñá imágenes 1920×1080 con textos y foto de fondo para mostrar en el panel de trabajadores</div>
          <button onClick={newCreation} style={{ padding: '9px 18px', borderRadius: 9, border: 'none', background: GOLD, color: '#000', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
            <FontAwesomeIcon icon={faPlus} style={{ marginRight: 7 }} />Crear primera creación
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {creations.map(c => (
            <div key={c.id} style={{ background: '#fff', border: '1.5px solid #e5e7eb', borderRadius: 12, overflow: 'hidden', display: 'flex', alignItems: 'stretch' }}>
              <div style={{ width: 130, flexShrink: 0, background: '#111', position: 'relative', overflow: 'hidden', minHeight: 70 }}>
                {c.background_image ? (
                  <img src={imgSrc(c.background_image)} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
                ) : (
                  <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 70 }}>
                    <FontAwesomeIcon icon={faPalette} style={{ color: '#555', fontSize: 22 }} />
                  </div>
                )}
              </div>
              <button onClick={() => openEdit(c)} style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 14, color: '#111' }}>{c.title}</div>
                  <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 3 }}>
                    {(c.elements || []).length} elemento{(c.elements || []).length !== 1 ? 's' : ''} · 1920×1080
                  </div>
                </div>
                <FontAwesomeIcon icon={faChevronDown} style={{ transform: 'rotate(-90deg)', color: '#bbb', fontSize: 11 }} />
              </button>
              <button onClick={() => del(c.id)} style={{ padding: '14px 16px', background: 'none', border: 'none', borderLeft: '1px solid #f3f4f6', cursor: 'pointer', color: '#ef4444', flexShrink: 0 }}>
                <FontAwesomeIcon icon={faTrash} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  /* ── Editor canvas ── */
  return (
    <div onMouseMove={onMove} onMouseUp={endDrag} onTouchMove={e => { e.preventDefault(); onMove(e); }} onTouchEnd={endDrag}
      style={{ userSelect: 'none', touchAction: 'none' }}>

      {/* Toolbar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
        <button onClick={() => { setEditing(null); setSelected(null); }}
          style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer', color: '#6b7280', fontWeight: 600, fontSize: 13, padding: 0 }}>
          <FontAwesomeIcon icon={faArrowLeft} /> Creaciones
        </button>
        <div style={{ width: 1, height: 20, background: '#e5e7eb' }} />
        <input value={editing.title} onChange={e => setEditing(p => ({ ...p, title: e.target.value }))}
          style={{ flex: 1, minWidth: 100, padding: '7px 12px', border: '1.5px solid #e5e7eb', borderRadius: 8, fontSize: 14, fontWeight: 700, outline: 'none' }}
          onFocus={e => e.target.style.borderColor = GOLD} onBlur={e => e.target.style.borderColor = '#e5e7eb'}
        />
        <div style={{ width: 1, height: 20, background: '#e5e7eb' }} />
        <input ref={bgRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={e => uploadBg(e.target.files[0])} />
        <button onClick={() => bgRef.current?.click()}
          style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px', borderRadius: 8, border: '1.5px solid #e5e7eb', background: '#fff', color: '#374151', fontWeight: 600, fontSize: 12, cursor: 'pointer', whiteSpace: 'nowrap' }}>
          <FontAwesomeIcon icon={uploading ? faSpinner : faImage} spin={uploading} style={{ color: GOLD }} />
          {uploading ? 'Subiendo...' : 'Fondo'}
        </button>
        {editing.background_image && (
          <button onClick={() => setEditing(p => ({ ...p, background_image: '' }))}
            style={{ padding: '8px 10px', borderRadius: 8, border: '1px solid #fecaca', background: '#fef2f2', color: '#ef4444', cursor: 'pointer', fontSize: 13 }}>
            <FontAwesomeIcon icon={faTimes} />
          </button>
        )}
        <button onClick={addText}
          style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px', borderRadius: 8, border: 'none', background: '#f3f4f6', color: '#374151', fontWeight: 700, fontSize: 12, cursor: 'pointer', whiteSpace: 'nowrap' }}>
          <FontAwesomeIcon icon={faPlus} /> Texto
        </button>
        <input ref={imgElemRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={e => { addImage(e.target.files[0]); e.target.value = ''; }} />
        <button onClick={() => imgElemRef.current?.click()} disabled={uploadingImg}
          style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px', borderRadius: 8, border: 'none', background: '#f3f4f6', color: '#374151', fontWeight: 700, fontSize: 12, cursor: 'pointer', whiteSpace: 'nowrap', opacity: uploadingImg ? 0.6 : 1 }}>
          <FontAwesomeIcon icon={uploadingImg ? faSpinner : faImage} spin={uploadingImg} style={{ color: '#6366f1' }} />
          {uploadingImg ? 'Subiendo...' : 'Imagen'}
        </button>
        <button onClick={save} disabled={saving}
          style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 18px', borderRadius: 8, border: 'none', background: saveOk ? '#16a34a' : '#111', color: '#fff', fontWeight: 700, fontSize: 13, cursor: 'pointer', whiteSpace: 'nowrap', transition: 'background 0.2s' }}>
          <FontAwesomeIcon icon={saveOk ? faCheck : saving ? faSpinner : faSave} spin={saving} />
          {saveOk ? 'Guardado' : saving ? 'Guardando...' : 'Guardar'}
        </button>
      </div>

      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start', flexWrap: 'wrap' }}>
        {/* Canvas */}
        <div ref={canvasWrapRef} style={{ flex: '1 1 380px', minWidth: 0 }}>
          <div style={{ width: '100%', position: 'relative', paddingTop: `${(CH / CW) * 100}%`, borderRadius: 10, overflow: 'hidden', border: '2px solid #333', background: '#111', cursor: 'default' }}>
            <div style={{ position: 'absolute', inset: 0 }} onClick={() => setSelected(null)}>
              {/* Inner canvas at full 1920×1080, scaled down */}
              <div style={{ position: 'absolute', top: 0, left: 0, width: CW, height: CH, transformOrigin: 'top left', transform: `scale(${scale})` }}>
                {editing.background_image ? (
                  <img src={imgSrc(editing.background_image)} alt="fondo"
                    style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', display: 'block', pointerEvents: 'none' }} />
                ) : (
                  <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 60%, #0f3460 100%)' }} />
                )}
                {editing.elements.map(el => el.type === 'image' ? (
                  <div key={el.id}
                    onMouseDown={e => startDrag(e, el.id)}
                    onTouchStart={e => startDrag(e, el.id)}
                    onClick={e => { e.stopPropagation(); setSelected(el.id); }}
                    style={{
                      position: 'absolute', left: el.x, top: el.y,
                      width: el.width, height: el.height,
                      opacity: el.opacity, cursor: 'move',
                      outline: selected === el.id ? `3px solid ${GOLD}` : 'none',
                      outlineOffset: 4, borderRadius: 4, overflow: 'hidden',
                    }}>
                    <img src={imgSrc(el.imgUrl)} alt="" style={{ width: '100%', height: '100%', objectFit: 'contain', display: 'block', pointerEvents: 'none' }} />
                  </div>
                ) : (
                  <div key={el.id}
                    onMouseDown={e => startDrag(e, el.id)}
                    onTouchStart={e => startDrag(e, el.id)}
                    onClick={e => { e.stopPropagation(); setSelected(el.id); }}
                    style={{
                      position: 'absolute', left: el.x, top: el.y,
                      fontSize: el.fontSize, color: el.color, fontWeight: el.fontWeight,
                      fontFamily: el.fontFamily, textShadow: el.textShadow,
                      opacity: el.opacity, lineHeight: 1.15, whiteSpace: 'pre-wrap',
                      cursor: 'move', padding: 8, boxSizing: 'border-box',
                      outline: selected === el.id ? `3px solid ${GOLD}` : 'none',
                      outlineOffset: 6, borderRadius: 4,
                    }}>
                    {el.text}
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div style={{ fontSize: 11, color: '#9ca3af', textAlign: 'center', marginTop: 6 }}>
            Canvas 1920×1080 · Arrastrá los textos para posicionarlos · Clic en vacío para deseleccionar
          </div>
        </div>

        {/* Panel de propiedades */}
        {selectedEl ? (
          <div style={{ flex: '0 0 260px', background: '#fff', border: '1.5px solid #e5e7eb', borderRadius: 14, padding: 16, minWidth: 220, maxHeight: '80vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <span style={{ fontWeight: 800, fontSize: 13 }}>{selectedEl.type === 'image' ? '🖼 Imagen' : '✏️ Texto'}</span>
              <button onClick={() => deleteElem(selectedEl.id)} style={{ padding: '5px 9px', borderRadius: 7, border: '1px solid #fecaca', background: '#fef2f2', color: '#ef4444', cursor: 'pointer', fontSize: 12 }}>
                <FontAwesomeIcon icon={faTrash} />
              </button>
            </div>

            {selectedEl.type === 'image' ? (
              /* ── Propiedades de imagen ── */
              <>
                <div style={{ marginBottom: 12 }}>
                  <img src={imgSrc(selectedEl.imgUrl)} alt="" style={{ width: '100%', borderRadius: 8, objectFit: 'contain', maxHeight: 100, background: '#f3f4f6' }} />
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={lbStyle}>Ancho: {Math.round(selectedEl.width)}px</label>
                  <input type="range" min={50} max={CW} value={selectedEl.width} onChange={e => updateElem(selectedEl.id, 'width', parseInt(e.target.value))}
                    style={{ width: '100%', accentColor: GOLD }} />
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={lbStyle}>Alto: {Math.round(selectedEl.height)}px</label>
                  <input type="range" min={50} max={CH} value={selectedEl.height} onChange={e => updateElem(selectedEl.id, 'height', parseInt(e.target.value))}
                    style={{ width: '100%', accentColor: GOLD }} />
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={lbStyle}>Opacidad: {Math.round(selectedEl.opacity * 100)}%</label>
                  <input type="range" min={10} max={100} value={Math.round(selectedEl.opacity * 100)} onChange={e => updateElem(selectedEl.id, 'opacity', parseInt(e.target.value) / 100)}
                    style={{ width: '100%', accentColor: GOLD }} />
                </div>
              </>
            ) : (
              /* ── Propiedades de texto ── */
              <>
                <div style={{ marginBottom: 12 }}>
                  <label style={lbStyle}>Texto</label>
                  <textarea value={selectedEl.text} onChange={e => updateElem(selectedEl.id, 'text', e.target.value)} rows={3}
                    style={{ ...inputStyle, resize: 'vertical', fontFamily: 'inherit' }}
                    onFocus={e => e.target.style.borderColor = GOLD} onBlur={e => e.target.style.borderColor = '#e5e7eb'} />
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={lbStyle}>Tamaño: {selectedEl.fontSize}px</label>
                  <input type="range" min={12} max={500} value={selectedEl.fontSize} onChange={e => updateElem(selectedEl.id, 'fontSize', parseInt(e.target.value))}
                    style={{ width: '100%', accentColor: GOLD }} />
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={lbStyle}>Color</label>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <input type="color" value={selectedEl.color} onChange={e => updateElem(selectedEl.id, 'color', e.target.value)}
                      style={{ width: 38, height: 34, border: '1.5px solid #e5e7eb', borderRadius: 7, cursor: 'pointer', padding: 2 }} />
                    <input type="text" value={selectedEl.color} onChange={e => updateElem(selectedEl.id, 'color', e.target.value)} maxLength={7}
                      style={{ ...inputStyle, fontFamily: 'monospace', flex: 1 }}
                      onFocus={e => e.target.style.borderColor = GOLD} onBlur={e => e.target.style.borderColor = '#e5e7eb'} />
                  </div>
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={lbStyle}>Peso</label>
                  <div style={{ display: 'flex', gap: 4 }}>
                    {[['400', 'Normal'], ['700', 'Bold'], ['900', 'Black']].map(([val, lbl]) => (
                      <button key={val} onClick={() => updateElem(selectedEl.id, 'fontWeight', val)}
                        style={{ flex: 1, padding: '6px 0', borderRadius: 7, border: `1.5px solid ${selectedEl.fontWeight === val ? GOLD : '#e5e7eb'}`, background: selectedEl.fontWeight === val ? '#fffdf0' : '#fff', cursor: 'pointer', fontWeight: val, fontSize: 11 }}>
                        {lbl}
                      </button>
                    ))}
                  </div>
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={lbStyle}>Fuente</label>
                  <select value={selectedEl.fontFamily} onChange={e => updateElem(selectedEl.id, 'fontFamily', e.target.value)} style={{ ...inputStyle }}>
                    {FONTS.map(f => <option key={f} value={f} style={{ fontFamily: f }}>{f}</option>)}
                  </select>
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={lbStyle}>Sombra</label>
                  <div style={{ display: 'flex', gap: 4 }}>
                    {[['', 'No'], ['2px 2px 5px rgba(0,0,0,0.7)', 'Leve'], ['3px 3px 14px rgba(0,0,0,0.95)', 'Fuerte']].map(([val, lbl]) => (
                      <button key={lbl} onClick={() => updateElem(selectedEl.id, 'textShadow', val)}
                        style={{ flex: 1, padding: '6px 0', borderRadius: 7, border: `1.5px solid ${selectedEl.textShadow === val ? GOLD : '#e5e7eb'}`, background: selectedEl.textShadow === val ? '#fffdf0' : '#fff', cursor: 'pointer', fontSize: 11 }}>
                        {lbl}
                      </button>
                    ))}
                  </div>
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={lbStyle}>Opacidad: {Math.round(selectedEl.opacity * 100)}%</label>
                  <input type="range" min={10} max={100} value={Math.round(selectedEl.opacity * 100)} onChange={e => updateElem(selectedEl.id, 'opacity', parseInt(e.target.value) / 100)}
                    style={{ width: '100%', accentColor: GOLD }} />
                </div>
              </>
            )}

            <div style={{ display: 'flex', gap: 8 }}>
              <div style={{ flex: 1 }}>
                <label style={lbStyle}>X</label>
                <input type="number" value={Math.round(selectedEl.x)} onChange={e => updateElem(selectedEl.id, 'x', parseInt(e.target.value) || 0)} style={{ ...inputStyle, fontSize: 12 }} />
              </div>
              <div style={{ flex: 1 }}>
                <label style={lbStyle}>Y</label>
                <input type="number" value={Math.round(selectedEl.y)} onChange={e => updateElem(selectedEl.id, 'y', parseInt(e.target.value) || 0)} style={{ ...inputStyle, fontSize: 12 }} />
              </div>
            </div>
          </div>
        ) : (
          <div style={{ flex: '0 0 260px', background: '#f9fafb', border: '2px dashed #e5e7eb', borderRadius: 14, padding: 24, minWidth: 220, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: '#9ca3af', textAlign: 'center', gap: 8 }}>
            <FontAwesomeIcon icon={faPalette} style={{ fontSize: 28 }} />
            <div style={{ fontSize: 13 }}>Hacé clic en un texto del canvas para editarlo</div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Componente principal ── */
export default function Procedures() {
  const { selectedStore } = useStore() || {};
  const { token } = useAuth();

  const [procedures, setProcedures] = useState([]);
  const [loading, setLoading] = useState(true);
  const [adminTab, setAdminTab] = useState('table'); // 'guides' | 'table'
  const [view, setView] = useState('list'); // 'list' | 'editor'
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ title: '', steps: [emptyStep()], design: emptyDesign() });
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [genProduct, setGenProduct] = useState('');
  const [genContext, setGenContext] = useState('');
  const [uploadingStep, setUploadingStep] = useState(null);
  const [lightboxImg, setLightboxImg] = useState(null);
  const [previewMode, setPreviewMode] = useState(false);
  const [saveOk, setSaveOk] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [dragIdx, setDragIdx] = useState(null);
  const [dragOverIdx, setDragOverIdx] = useState(null);
  const storeId = selectedStore?.id;

  const load = async () => {
    if (!storeId || !token) return;
    setLoading(true);
    try {
      const res = await fetch(`${API}/api/procedures?store_id=${storeId}`, {
        headers: { Authorization: 'Bearer ' + token }
      });
      if (res.ok) setProcedures(await res.json());
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [storeId, token]);

  const openNew = () => {
    setEditing(null);
    setForm({ title: '', steps: [emptyStep()], design: emptyDesign() });
    setGenProduct(''); setGenContext('');
    setPreviewMode(false); setSaveOk(false);
    setView('editor');
  };

  const openEdit = (proc) => {
    setEditing(proc);
    setForm({ title: proc.title, steps: proc.steps.length ? proc.steps : [emptyStep()], design: proc.design || emptyDesign() });
    setGenProduct(''); setGenContext('');
    setPreviewMode(false); setSaveOk(false);
    setView('editor');
  };

  const backToList = () => { setView('list'); setEditing(null); };

  const save = async () => {
    if (!form.title.trim()) return;
    setSaving(true);
    try {
      const url = editing ? `${API}/api/procedures/${editing.id}` : `${API}/api/procedures`;
      const method = editing ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
        body: JSON.stringify({ ...form, store_id: storeId })
      });
      if (res.ok) {
        setSaveOk(true);
        await load();
        setTimeout(() => { setSaveOk(false); backToList(); }, 900);
      }
    } finally { setSaving(false); }
  };

  const deleteProcedure = async (id) => {
    await fetch(`${API}/api/procedures/${id}?store_id=${storeId}`, {
      method: 'DELETE', headers: { Authorization: 'Bearer ' + token }
    });
    setConfirmDeleteId(null);
    if (view === 'editor') backToList();
    load();
  };

  const handleDropStep = (toIdx) => {
    if (dragIdx === null || dragIdx === toIdx) { setDragIdx(null); setDragOverIdx(null); return; }
    setForm(prev => {
      const steps = [...prev.steps];
      const [removed] = steps.splice(dragIdx, 1);
      steps.splice(toIdx, 0, removed);
      return { ...prev, steps };
    });
    setDragIdx(null); setDragOverIdx(null);
  };

  const generateWithAI = async () => {
    if (!genProduct.trim()) return;
    setGenerating(true);
    try {
      const res = await fetch(`${API}/api/brain/generate-procedure`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
        body: JSON.stringify({ store_id: storeId, product_name: genProduct, extra_context: genContext })
      });
      const data = await res.json();
      if (res.ok && data.steps) {
        setForm(prev => ({
          ...prev,
          title: data.title || `Procedimiento: ${genProduct}`,
          steps: data.steps.map(s => ({ title: s.title || '', instruction: s.instruction || '', tip: s.tip || '', image_url: '' }))
        }));
        setGenProduct(''); setGenContext('');
      } else {
        alert('León IA no disponible. Puedes crear los pasos manualmente.');
      }
    } finally { setGenerating(false); }
  };

  const updateStep = (i, field, value) => {
    setForm(prev => {
      const steps = [...prev.steps];
      steps[i] = { ...steps[i], [field]: value };
      return { ...prev, steps };
    });
  };

  const addStep = () => setForm(prev => ({ ...prev, steps: [...prev.steps, emptyStep()] }));

  const removeStep = (i) => setForm(prev => ({ ...prev, steps: prev.steps.filter((_, idx) => idx !== i) }));

  const moveStep = (i, dir) => {
    setForm(prev => {
      const steps = [...prev.steps];
      const j = i + dir;
      if (j < 0 || j >= steps.length) return prev;
      [steps[i], steps[j]] = [steps[j], steps[i]];
      return { ...prev, steps };
    });
  };

  const uploadImage = async (stepIdx, file) => {
    if (!file) return;
    setUploadingStep(stepIdx);
    try {
      const fd = new FormData();
      fd.append('image', file);
      fd.append('store_id', storeId);
      const res = await fetch(`${API}/api/upload`, {
        method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: fd
      });
      if (res.ok) {
        const data = await res.json();
        updateStep(stepIdx, 'image_url', data.url || data.path || data.file || '');
      }
    } finally { setUploadingStep(null); }
  };

  /* ── Vista lista ── */
  if (loading) return <div className="loading">Cargando procedimientos...</div>;

  if (view === 'list') {
    return (
      <>
        <header className="admin-header">
          <div>
            <h1>Procedimientos</h1>
            <p className="text-sm text-muted">Guías y tabla de preparación</p>
          </div>
          {adminTab === 'guides' && (
            <button className="btn btn-primary" onClick={openNew}>
              <FontAwesomeIcon icon={faPlus} /> Nueva guía
            </button>
          )}
        </header>

        {/* Tabs */}
        <div style={{ padding: '0 24px', borderBottom: '1px solid #f0f0f0', display: 'flex', gap: 0, background: '#fff' }}>
          {[
            { key: 'guides', icon: faClipboardList, label: 'Guías paso a paso', hidden: true },
            { key: 'table', icon: faTable, label: 'Tabla de preparación', hidden: false },
            { key: 'custom', icon: faPalette, label: 'Creación personalizada', hidden: true }
          ].map(tab => (
            <button key={tab.key} onClick={() => setAdminTab(tab.key)} style={{
              padding: '12px 18px', border: 'none', background: 'none', cursor: 'pointer',
              fontSize: 13, fontWeight: adminTab === tab.key ? 700 : 500,
              color: adminTab === tab.key ? '#111' : '#9ca3af',
              borderBottom: adminTab === tab.key ? '2px solid #111' : '2px solid transparent',
              display: tab.hidden ? 'none' : 'flex', alignItems: 'center', gap: 7, marginBottom: -1
            }}>
              <FontAwesomeIcon icon={tab.icon} />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="admin-main">
          {adminTab === 'table' ? (
            <PrepTableEditor storeId={storeId} token={token} />
          ) : adminTab === 'custom' ? (
            <CustomCreationEditor storeId={storeId} token={token} />
          ) : procedures.length === 0 ? (
            <div style={{
              textAlign: 'center', padding: '60px 24px',
              background: '#fff', borderRadius: 16, border: '1px solid #f0f0f0'
            }}>
              <FontAwesomeIcon icon={faClipboardList} style={{ fontSize: 40, color: '#d1d5db', marginBottom: 14, display: 'block' }} />
              <div style={{ fontWeight: 700, fontSize: 16, color: '#374151', marginBottom: 6 }}>Sin guías todavía</div>
              <div style={{ fontSize: 14, color: '#9ca3af', marginBottom: 20 }}>
                Crea guías paso a paso para que tus trabajadores sepan exactamente cómo preparar cada producto.
              </div>
              <button className="btn btn-primary" onClick={openNew}>
                <FontAwesomeIcon icon={faPlus} /> Crear primera guía
              </button>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 14 }}>
              {procedures.map(proc => {
                const d = proc.design || emptyDesign();
                const accent = d.accentColor || GOLD;
                const coverImg = d.coverImage || proc.steps?.find(s => s.image_url)?.image_url || '';
                return (
                  <div key={proc.id} style={{
                    background: '#fff', borderRadius: 14, border: '1px solid #f0f0f0',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.05)', overflow: 'hidden',
                    display: 'flex', flexDirection: 'column'
                  }}>
                    {/* Barra de color del tema */}
                    <div style={{ height: 4, background: accent }} />
                    {/* Contenido: info izquierda, imagen derecha */}
                    <div style={{ display: 'flex', alignItems: 'stretch', flex: 1 }}>
                      <div style={{ flex: 1, padding: '16px 16px 12px', minWidth: 0 }}>
                        <div style={{ fontWeight: 800, fontSize: 15, color: '#111', marginBottom: 8, lineHeight: 1.3 }}>
                          {proc.title}
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 3, marginBottom: 8 }}>
                          {(proc.steps || []).slice(0, 3).map((s, i) => (
                            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                              <div style={{ width: 18, height: 18, borderRadius: '50%', background: accent, color: d.theme === 'white' ? '#111' : '#000', fontWeight: 900, fontSize: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{i + 1}</div>
                              <span style={{ fontSize: 12, color: '#6b7280', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                {s.title || stripHtml(s.instruction)?.slice(0, 30) || 'Paso'}
                              </span>
                            </div>
                          ))}
                          {proc.steps?.length > 3 && (
                            <span style={{ fontSize: 11, color: '#9ca3af', paddingLeft: 24 }}>+{proc.steps.length - 3} pasos más</span>
                          )}
                        </div>
                      </div>
                      {/* Imagen derecha */}
                      {coverImg ? (
                        <div style={{ width: 100, flexShrink: 0, position: 'relative', overflow: 'hidden' }}>
                          <img src={imgSrc(coverImg)} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
                        </div>
                      ) : (
                        <div style={{ width: 100, flexShrink: 0, background: d.bgColor || '#111', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <FontAwesomeIcon icon={faClipboardList} style={{ fontSize: 28, color: accent, opacity: 0.6 }} />
                        </div>
                      )}
                    </div>
                    <div style={{ padding: '10px 14px', borderTop: '1px solid #f5f5f5', display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                      <button onClick={() => openEdit(proc)}
                        style={{ padding: '7px 14px', borderRadius: 8, border: '1px solid #e5e7eb', background: '#fff', fontSize: 12, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, color: '#374151' }}>
                        <FontAwesomeIcon icon={faEdit} /> Editar
                      </button>
                      <button onClick={() => setConfirmDeleteId(proc.id)}
                        style={{ padding: '7px 10px', borderRadius: 8, border: '1px solid #fecaca', background: '#fef2f2', fontSize: 12, cursor: 'pointer', color: '#ef4444', display: 'flex', alignItems: 'center' }}>
                        <FontAwesomeIcon icon={faTrash} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      {confirmDeleteId && (
        <DeleteConfirmModal
          title={procedures.find(p => p.id === confirmDeleteId)?.title || ''}
          onConfirm={() => deleteProcedure(confirmDeleteId)}
          onCancel={() => setConfirmDeleteId(null)}
        />
      )}
      </>
    );
  }

  /* ── Vista editor (página completa) ── */
  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc' }}>

      {/* Barra superior del editor */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 100,
        background: '#fff', borderBottom: '1px solid #e5e7eb',
        padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap'
      }}>
        <button onClick={backToList}
          style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer', color: '#6b7280', fontWeight: 600, fontSize: 13, padding: 0 }}>
          <FontAwesomeIcon icon={faArrowLeft} /> Volver
        </button>
        <div style={{ width: 1, height: 20, background: '#e5e7eb' }} />
        <span style={{ fontWeight: 700, fontSize: 15, color: '#111', flex: 1 }}>
          {editing ? 'Editar guía' : 'Nueva guía'}
        </span>
        {editing && (
          <button onClick={() => setConfirmDeleteId(editing.id)}
            style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px', borderRadius: 8, border: '1.5px solid #fecaca', background: '#fef2f2', color: '#ef4444', fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>
            <FontAwesomeIcon icon={faTrash} />
            Eliminar
          </button>
        )}
        <button
          onClick={() => setPreviewMode(v => !v)}
          style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '8px 14px', borderRadius: 8,
            border: `1.5px solid ${previewMode ? GOLD : '#e5e7eb'}`,
            background: previewMode ? '#fffdf0' : '#fff',
            color: previewMode ? '#92400e' : '#6b7280',
            fontWeight: 600, fontSize: 13, cursor: 'pointer'
          }}>
          <FontAwesomeIcon icon={previewMode ? faEyeSlash : faEye} />
          {previewMode ? 'Editar' : 'Vista previa'}
        </button>
        <button onClick={save} disabled={saving || !form.title.trim()}
          style={{
            display: 'flex', alignItems: 'center', gap: 7,
            padding: '9px 20px', borderRadius: 8, border: 'none',
            background: saveOk ? '#16a34a' : saving ? '#555' : '#111',
            color: '#fff', fontWeight: 700, fontSize: 14, cursor: 'pointer',
            transition: 'background 0.2s', opacity: !form.title.trim() ? 0.5 : 1
          }}>
          <FontAwesomeIcon icon={saveOk ? faCheck : saving ? faSpinner : faSave} spin={saving} />
          {saveOk ? 'Guardado' : saving ? 'Guardando...' : 'Guardar'}
        </button>
      </div>

      <div style={{ maxWidth: 720, margin: '0 auto', padding: '28px 20px 80px' }}>

        {previewMode ? (
          /* ── VISTA PREVIA ── */
          <div style={{ background: '#fff', borderRadius: 16, border: '1px solid #e5e7eb', overflow: 'hidden' }}>
            <div style={{ background: form.design?.bgColor || '#111', padding: '20px 24px', position: 'relative' }}>
              {form.design?.coverImage && (
                <div style={{ position: 'absolute', inset: 0, backgroundImage: `url(${imgSrc(form.design.coverImage)})`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.28 }} />
              )}
              <div style={{ position: 'relative' }}>
                <div style={{ color: form.design?.accentColor || GOLD, fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 }}>
                  Guía de preparación
                </div>
                <div style={{ color: THEMES.find(t => t.id === (form.design?.theme || 'dark'))?.text || '#fff', fontSize: 20, fontWeight: 800 }}>
                  {form.title || 'Sin título'}
                </div>
                <div style={{ color: (form.design?.accentColor || GOLD) + 'aa', fontSize: 12, marginTop: 4 }}>
                  {form.steps.length} paso{form.steps.length !== 1 ? 's' : ''}
                </div>
              </div>
            </div>
            <div style={{ padding: '24px' }}>
              {form.steps.map((step, i) => (
                <div key={i} style={{ display: 'flex', gap: 14, marginBottom: 28, alignItems: 'flex-start' }}>
                  {/* Imagen a la izquierda */}
                  {step.image_url && (
                    <div onClick={() => setLightboxImg(imgSrc(step.image_url))}
                      style={{ width: 120, flexShrink: 0, borderRadius: 10, overflow: 'hidden', cursor: 'zoom-in' }}>
                      <img src={imgSrc(step.image_url)} alt=""
                        style={{ width: '100%', objectFit: 'cover', display: 'block', borderRadius: 10 }} />
                    </div>
                  )}
                  {/* Texto a la derecha */}
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                      <div style={{
                        width: 36, height: 36, borderRadius: '50%', background: GOLD,
                        color: '#000', fontWeight: 900, fontSize: 16, flexShrink: 0,
                        display: 'flex', alignItems: 'center', justifyContent: 'center'
                      }}>{i + 1}</div>
                      {step.title && <div style={{ fontWeight: 700, fontSize: 15, color: '#111', lineHeight: 1.2 }}>{step.title}</div>}
                    </div>
                    {step.instruction && (
                      <div className="rich-content"
                        style={{ fontSize: 14, color: '#444', lineHeight: 1.6, marginBottom: 8 }}
                        dangerouslySetInnerHTML={{ __html: step.instruction }}
                      />
                    )}
                    {step.tip && (
                      <div style={{ fontSize: 13, color: '#92400e', background: '#fffdf0', borderLeft: `3px solid ${GOLD}`, padding: '6px 12px', borderRadius: '0 8px 8px 0' }}>
                        💡 {step.tip}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* ── EDITOR ── */
          <>
            {/* León IA */}
            {!editing && (
              <div style={{
                background: '#fffdf0', border: `1.5px solid ${GOLD}60`,
                borderRadius: 14, padding: '18px 20px', marginBottom: 24
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
                  <FontAwesomeIcon icon={faBrain} style={{ color: GOLD, fontSize: 16 }} />
                  <span style={{ fontWeight: 800, fontSize: 14, color: '#7a5c00' }}>Generar con León IA</span>
                  <span style={{ fontSize: 12, color: '#a0804a', marginLeft: 4 }}>— escribe el nombre del producto y la IA crea los pasos</span>
                </div>
                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                  <input
                    value={genProduct}
                    onChange={e => setGenProduct(e.target.value)}
                    placeholder="Nombre del producto (ej: Hamburguesa Clásica)"
                    style={{
                      flex: 2, minWidth: 180, padding: '10px 13px', border: '1.5px solid #e5c84a',
                      borderRadius: 9, fontSize: 13, outline: 'none', background: '#fff'
                    }}
                  />
                  <input
                    value={genContext}
                    onChange={e => setGenContext(e.target.value)}
                    placeholder="Detalles extras (opcional)"
                    style={{
                      flex: 1, minWidth: 120, padding: '10px 13px', border: '1.5px solid #e5c84a',
                      borderRadius: 9, fontSize: 13, outline: 'none', background: '#fff'
                    }}
                  />
                  <button onClick={generateWithAI} disabled={generating || !genProduct.trim()}
                    style={{
                      padding: '10px 18px', borderRadius: 9, border: 'none',
                      background: generating || !genProduct.trim() ? '#ccc' : GOLD,
                      color: '#000', fontWeight: 700, fontSize: 13, cursor: 'pointer',
                      display: 'flex', alignItems: 'center', gap: 7, whiteSpace: 'nowrap'
                    }}>
                    <FontAwesomeIcon icon={generating ? faSpinner : faBrain} spin={generating} />
                    {generating ? 'Generando...' : 'Generar pasos'}
                  </button>
                </div>
              </div>
            )}

            {/* Panel de diseño */}
            <DesignPanel
              design={form.design}
              onChange={d => setForm(p => ({ ...p, design: d }))}
              storeId={storeId}
              token={token}
            />

            {/* Título */}
            <div style={{ marginBottom: 24 }}>
              <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 8 }}>
                Título de la guía
              </label>
              <input
                value={form.title}
                onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
                placeholder="Ej: Cómo preparar la Hamburguesa Clásica"
                style={{
                  width: '100%', padding: '13px 16px', border: '2px solid #e5e7eb',
                  borderRadius: 12, fontSize: 18, fontWeight: 700, outline: 'none',
                  boxSizing: 'border-box', transition: 'border-color 0.15s'
                }}
                onFocus={e => e.target.style.borderColor = GOLD}
                onBlur={e => e.target.style.borderColor = '#e5e7eb'}
              />
            </div>

            {/* Pasos */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {form.steps.map((step, i) => (
                <StepCard
                  key={i}
                  step={step}
                  index={i}
                  total={form.steps.length}
                  onChange={updateStep}
                  onMove={moveStep}
                  onRemove={removeStep}
                  onUpload={uploadImage}
                  onSelectUrl={(stepIdx, url) => updateStep(stepIdx, 'image_url', url)}
                  uploadingStep={uploadingStep}
                  isDragging={dragIdx === i}
                  isDragOver={dragOverIdx === i && dragIdx !== i}
                  onDragStart={setDragIdx}
                  onDragOver={setDragOverIdx}
                  onDrop={handleDropStep}
                  onDragEnd={() => { setDragIdx(null); setDragOverIdx(null); }}
                />
              ))}
            </div>

            {/* Agregar paso */}
            <button onClick={addStep}
              style={{
                width: '100%', marginTop: 16, padding: '14px',
                border: '2px dashed #d1d5db', borderRadius: 14,
                background: 'transparent', color: '#9ca3af',
                fontSize: 14, fontWeight: 600, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                transition: 'all 0.15s'
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = GOLD; e.currentTarget.style.color = GOLD; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = '#d1d5db'; e.currentTarget.style.color = '#9ca3af'; }}
            >
              <FontAwesomeIcon icon={faPlus} /> Agregar paso
            </button>
          </>
        )}
      </div>

      {/* Modal eliminar */}
      {confirmDeleteId && (
        <DeleteConfirmModal
          title={procedures.find(p => p.id === confirmDeleteId)?.title || editing?.title || ''}
          onConfirm={() => deleteProcedure(confirmDeleteId)}
          onCancel={() => setConfirmDeleteId(null)}
        />
      )}

      {/* Lightbox */}
      {lightboxImg && (
        <div onClick={() => setLightboxImg(null)}
          style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(0,0,0,0.92)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'zoom-out', padding: 20 }}>
          <img src={lightboxImg} alt="" style={{ maxWidth: '100%', maxHeight: '100%', borderRadius: 10, objectFit: 'contain' }} />
          <button onClick={() => setLightboxImg(null)}
            style={{ position: 'fixed', top: 18, right: 18, background: 'rgba(255,255,255,0.15)', border: 'none', borderRadius: '50%', width: 38, height: 38, color: '#fff', fontSize: 18, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            ✕
          </button>
        </div>
      )}
    </div>
  );
}
