import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import path from 'path';
import http from 'http';
import { Server } from 'socket.io';
import { MercadoPagoConfig, Preference, Payment } from 'mercadopago';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import fs from 'fs';
import QRCode from 'qrcode';
import AdmZip from 'adm-zip';
import { startBuild, getBuildJob, getCachedApk } from './android-build.js';
import { execFile, execSync } from 'child_process';
import speakeasy from 'speakeasy';
import bcrypt from 'bcryptjs';
import nodemailer from 'nodemailer';
import * as XLSX from 'xlsx';
import PluginManager from './plugins/PluginManager.js';
import { initLeonIA } from './leon_ia/autostart.js';
import { generatePromoImage, startInstagramLogin, completeInstagramVerify, postToInstagram, deleteInstagramSession } from './instagram-service.js';
import { initInstagramService } from './instagram_autostart.js';

import { getInstagramConfig, saveInstagramConfig, getActiveInstagramConfigs, updateInstagramPosted, saveInstagramSession, clearInstagramSession, getTikTokConfig, saveTikTokConfig, saveTikTokSession, clearTikTokTokens, getActiveTikTokConfigs, updateTikTokPosted, createScheduledMessage, getScheduledMessages, cancelScheduledMessage, getPendingScheduledMessages, markScheduledMessageSent, markScheduledMessageFailed, getWorkersWithPhone } from './database.js';
import { runSrBrain, runSrBrainForStore } from './sr_brain.js';
import { initWhatsApp, getWhatsAppStatus, sendWhatsAppMessage, getWhatsAppGroups, disconnectWhatsApp, reconnectWhatsApp, getAutoStartStoreIds, setBotEnabled, getBotEnabled, getBotPhone } from './whatsapp.js';
import cron from 'node-cron';

const __serverDir = path.dirname(fileURLToPath(import.meta.url));
import {
  initDatabase,
  createUser,
  authenticateUser,
  getUserByCode,
  getUserById,
  getStores,
  createStore,
  updateStore,
  deleteStore,
  duplicateStore,
  getStoreById,
  getStoreByCode,
  verifyStoreOwnership,
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  getIngredients,
  createIngredient,
  updateIngredient,
  setIngredientActive,
  getDuplicateComplementInfo,
  deleteIngredient,
  deleteAllIngredients,
  deduplicateIngredients,
  getExtras,
  createExtra,
  updateExtra,
  setExtraActive,
  deleteExtra,
  deleteAllExtras,
  deduplicateExtras,
  setProductComplementsPrivate,
  getStoreConfigurations,
  getStoreConfigurationById,
  createStoreConfiguration,
  updateStoreConfiguration,
  deleteStoreConfiguration,
  getCoupons,
  createCoupon,
  updateCoupon,
  deleteCoupon,
  validateCouponForStore,
  getProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  getComplementGroups,
  createComplementGroup,
  updateComplementGroup,
  deleteComplementGroup,
  reorderComplementGroups,
  createComplementOption,
  updateComplementOption,
  deleteComplementOption,
  reorderComplementOptions,
  setProductComplementGroups,
  getProductComplementGroupIds,
  getStoreExpenses,
  addStoreExpense,
  deleteStoreExpense,
  getIncomeStatement,
  getProductById,
  getProductByBarcode,
  searchProducts,
  getPublicProducts,
  getCombos,
  getPublicCombos,
  createCombo,
  updateCombo,
  deleteCombo,
  getInventory,
  updateInventory,
  setInventoryStock,
  updateProductsOrder,
  updateCategoriesOrder,
  updateIngredientsOrder,
  updateExtrasOrder,
  createOrder,
  getOrders,
  getWhatsAppOrders,
  updateUserSettings,
  createWorker,
  getWorkers,
  deleteWorker,
  authenticateWorker,
  getWorkerOrders,
  updateOrderStatus,
  approveCashPayment,
  processMercadoPagoPayment,
  processSumUpPayment,
  getSumUpCheckoutStatus,
  confirmCardPayment,
  getMercadoPagoOrderStatus,
  cancelMercadoPagoOrder,
  createMercadoPagoTerminal,
  getMercadoPagoTerminals,
  getMercadoPagoTerminalsByStore,
  getMercadoPagoTerminalById,
  getMercadoPagoTerminalByPin,
  getMercadoPagoTerminalForStore,
  updateMercadoPagoTerminal,
  deleteMercadoPagoTerminal,
  createPosTerminal,
  getPosTerminals,
  getPosTerminalsByStore,
  getPosTerminalById,
  getPosTerminalByPin,
  getPosTerminalForStore,
  updatePosTerminal,
  deletePosTerminal,
  authenticateSuperadmin,
  getAllUsers,
  updateUserBySuperadmin,
  deleteUserBySuperadmin,
  getAllStores,
  updateStoreBySuperadmin,
  deleteStoreBySuperadmin,
  createSuperadmin,
  getAllPlans,
  getAllSubscriptions,
  getSubscriptionHistory,
  getUserPlan,
  canUserCreateStore,
  assignPlanToUser,
  assignPremiumByAdmin,
  getPlanById,
  getAnalytics,
  getSalesByDay,
  getTopProducts,
  getOrdersByHour,
  getRecentOrders,
  getWorkerPaymentMethods,
  createWorkerPaymentMethod,
  updateWorkerPaymentMethod,
  deleteWorkerPaymentMethod,
  setStoreEditPin,
  verifyStoreEditPin,
  getStoreEditPin,
  setTotpSecret,
  enableTotp,
  disableTotp,
  updateUserPassword,
  getUserByEmail,
  setVerificationCode,
  markEmailVerified,
  updateUserHeartbeat,
  getChatGptKey,
  saveChatGptKey,
  openCashRegister,
  closeCashRegister,
  getOpenCashRegister,
  getAllOpenCashRegisters,
  getTodayOrdersForStore,
  getCashRegisterHistory,
  addCashMovement,
  getCashMovements,
  deleteCashMovement,
  getCashRegisterFinancials,
  generateUniqueOrderNumber,
  getAiConfig,
  saveAiConfig,
  getAiActivityLog,
  logAiActivity,
  getProcedures,
  getProcedureById,
  createProcedure,
  updateProcedure,
  deleteProcedure,
  getPrepTables,
  createPrepTable,
  updatePrepTable,
  deletePrepTable,
  updateWorkerPhone,
  pool,
  getAttendancePersons,
  getAttendancePersonByRut,
  createAttendancePerson,
  deleteAttendancePerson,
  createAttendanceRecord,
  getAttendanceRecords,
  getAttendanceRecordsRange,
  getLastAttendanceRecord,
  getSalesConfig,
  upsertSalesConfig,
  getSalesForMonth,
  upsertSaleRecord,
  deleteSaleRecord,
  getSalesFromOrders,
  getRestaurantTables,
  getRestaurantTablesWithStatus,
  createRestaurantTable,
  updateRestaurantTable,
  deleteRestaurantTable,
  getDeliverySettings,
  upsertDeliverySettings,
  getNearbyDeliveryStores,
  findOrCreateDeliveryCustomer,
  setDeliveryCustomerCode,
  verifyDeliveryCustomerCode,
  completeDeliveryCustomerProfile,
  createDeliverySession,
  getDeliveryCustomerByToken,
  getPendingDeliveryOrders,
  updateDeliveryOrderStatus,
  getStoreBySubdomain,
  setStoreSubdomain,
  clearStoreSubdomain,
  getStoreSubdomain,
  getRoles,
  getRoleById,
  createRole,
  updateRole,
  deleteRole,
  getSubAccounts,
  createSubAccount,
  updateSubAccount,
  deleteSubAccount,
  authenticateSubAccount,
  ensureDefaultRolesAndAccounts,
  registerDeliveryCustomer,
  loginDeliveryCustomer,
  getCustomerOrders,
  getDeliveryOrderForTracking,
  updateDeliveryCustomerProfile,
  getOrderItems,
  getDailySales,
  getPeopleCounterConfig,
  savePeopleCounterConfig,
  savePeopleCounterEvent,
  getPeopleCounterStats,
  savePeopleCounterRTSP,
  getPeopleCounterRTSP,
  getStoresWithRTSP,
  getUserApps,
  getLoyaltyConfig,
  saveLoyaltyConfig,
  getLoyalCustomers,
  createLoyalCustomer,
  incrementLoyalCustomerPurchases,
  deleteLoyalCustomer
} from './database.js';
import { registerSubdomain, unregisterSubdomain } from './nginx-manager.js';

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});
const PORT = process.env.SERVER_PORT || 8888;
const HOST = process.env.SERVER_HOST || '127.0.0.1';
const JWT_SECRET = process.env.JWT_SECRET || 'srservi-secret-key-2024';
const BASE_URL = process.env.BASE_URL || 'https://srservi2.srautomatic.com';

const HAULMER_API_URL = 'https://core.payment.haulmer.com/api/v1/payment';

function haulmerSignGlobal(data, secret) {
  const keys = Object.keys(data).filter(k => k.startsWith('x_')).sort();
  const str = keys.filter(k => data[k] != null && data[k] !== '').map(k => k + data[k]).join('');
  return crypto.createHmac('sha256', secret).update(str).digest('hex');
}

const mailer = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || '163.227.179.59',
  port: parseInt(process.env.EMAIL_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  },
  tls: { rejectUnauthorized: false }
});

const mpClient = new MercadoPagoConfig({
  accessToken: process.env.MP_ACCESS_TOKEN,
  options: { timeout: 10000 }
});

console.log('MercadoPago Token configured:', !!process.env.MP_ACCESS_TOKEN);

app.use(cors());
app.use(express.json({ limit: '5mb' }));

const userSockets = new Map();

// ── Presence tracking ──────────────────────────────────────────────────────
// socketId → { store_code, panel, connected_at, store_name? }
const presenceMap = new Map();

function buildPresenceSessions() {
  return Array.from(presenceMap.values());
}

function broadcastPresence() {
  io.emit('presence_update', { sessions: buildPresenceSessions() });
}

io.on('connection', (socket) => {
  console.log('Cliente conectado:', socket.id);

  socket.on('register_store', (storeId) => {
    userSockets.set(storeId, socket.id);
    socket.storeId = storeId;
    socket.join(`store_${storeId}`);
    console.log(`Socket ${socket.id} registrado para tienda ${storeId} (room: store_${storeId})`);
  });

  socket.on('presence_join', ({ store_code, panel, store_name }) => {
    if (!store_code || !panel) return;
    presenceMap.set(socket.id, {
      store_code: String(store_code).toUpperCase(),
      panel,
      store_name: store_name || null,
      connected_at: Date.now()
    });
    broadcastPresence();
  });

  socket.on('disconnect', () => {
    if (socket.storeId) {
      userSockets.delete(socket.storeId);
    }
    if (presenceMap.has(socket.id)) {
      presenceMap.delete(socket.id);
      broadcastPresence();
    }
    console.log('Cliente desconectado:', socket.id);
  });
});

export const emitProductUpdate = (storeId, event, product) => {
  const socketId = userSockets.get(storeId);
  if (socketId) {
    io.to(socketId).emit(event, product);
  }
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 1024 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file) {
      return cb(null, false);
    }
    const allowedMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif'];
    const allowedExts = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
    
    const mimetype = allowedMimes.includes(file.mimetype);
    const extname = allowedExts.includes(path.extname(file.originalname).toLowerCase());
    
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Solo se permiten imágenes (jpeg, jpg, png, webp, gif)'));
  }
});

const apkStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = 'uploads/apks';
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});
const apkUpload = multer({ storage: apkStorage, limits: { fileSize: 500 * 1024 * 1024 } });

const excelUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (['.xlsx', '.xls', '.csv'].includes(ext)) cb(null, true);
    else cb(new Error('Solo se permiten archivos Excel (.xlsx, .xls) o CSV (.csv)'));
  }
});

// Archivos públicos (verificación de dominio, etc.)
app.use(express.static(path.join(__serverDir, 'public')));

// Descargas de las apps AforoBridge (Windows .zip / Android .apk)
app.use('/downloads', express.static(path.join(__serverDir, 'public', 'downloads'), {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.apk'))
      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', `attachment; filename="${path.basename(filePath)}"`);
  }
}));

app.use('/uploads', express.static('uploads', {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.apk')) {
      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
      res.setHeader('Content-Disposition', `attachment; filename="${path.basename(filePath)}"`);
    }
  }
}));
// Serve plugin static files with path traversal protection
app.use('/api/plugins/static', (req, res, next) => {
  // Block path traversal attempts
  if (req.path.includes('..') || req.path.includes('server.js') || req.path.includes('.env')) {
    return res.status(403).json({ error: 'Access denied' });
  }
  // Only allow specific file extensions
  const allowed = ['.js', '.css', '.png', '.jpg', '.jpeg', '.svg', '.webp', '.gif', '.woff', '.woff2', '.ttf', '.json'];
  const ext = path.extname(req.path).toLowerCase();
  if (ext && !allowed.includes(ext)) {
    return res.status(403).json({ error: 'File type not allowed' });
  }
  next();
}, express.static(path.join(__serverDir, 'plugins', 'installed')));

async function sendCashRegisterReport(storeId, closedBy = 'manual', register = null) {
  try {
    const [storeRows] = await pool.execute(
      'SELECT s.*, u.email as owner_email, u.username as owner_username FROM stores s JOIN users u ON s.user_id = u.id WHERE s.id = ?',
      [storeId]
    );
    if (!storeRows.length) return;
    const store = storeRows[0];
    const ownerEmail = store.owner_email;
    if (!ownerEmail) return;

    // Fetch register if not provided (e.g. auto-close cron)
    if (!register) {
      const [regRows] = await pool.execute(
        'SELECT * FROM cash_registers WHERE store_id = ? ORDER BY opened_at DESC LIMIT 1',
        [storeId]
      );
      register = regRows[0] || null;
    }

    const orders = await getTodayOrdersForStore(storeId);
    const currSym = store.currency_symbol || '$';
    const fmt = d => d ? new Date(d).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }) : '—';
    const tl = t => ({ serve: 'Aquí', takeout: 'Para llevar', delivery: 'Delivery', pedidosya: 'PedidosYa', rappi: 'Rappi', mostrador: 'Mostrador' })[t] || t || 'Aquí';
    const sl = s => ({ pending: 'Pendiente', preparing: 'En preparación', ready: 'Listo', completed: 'Completado' })[s] || s || '';
    const ds = new Date().toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    const closedByLabel = { manual: 'Manual (trabajador)', admin: 'Administrador', auto: 'Automático (medianoche)' }[closedBy] || closedBy;

    const totalVendido = orders.reduce((s, o) => s + Number(o.total || 0), 0);
    const openingAmount = register ? Number(register.opening_amount || 0) : 0;
    const diferencia = totalVendido - openingAmount;

    // Estado de resultados (ingresos / egresos) de esta caja
    const fin = register ? await getCashRegisterFinancials(storeId, register) : null;
    const ventasEfectivo = fin ? fin.ventas_efectivo : 0;
    const ventasTarjeta = fin ? fin.ventas_tarjeta : 0;
    const totalIngresos = fin ? fin.total_ventas : totalVendido;
    const totalEgresos = fin ? fin.total_egresos : 0;
    const resultadoNeto = fin ? fin.resultado_neto : totalVendido;
    const efectivoEsperado = fin ? fin.efectivo_esperado : openingAmount;
    const movements = fin ? fin.movements : [];
    const f$ = n => `${currSym}${Number(n || 0).toFixed(2)}`;

    // Sheet 1: Resumen de caja
    const resumenData = [
      ['INFORME DE APERTURA Y CIERRE DE CAJA'],
      [store.name],
      [ds],
      [],
      ['APERTURA'],
      ['Trabajador', register ? (register.worker_name || '—') : '—'],
      ['Hora de apertura', register ? fmt(register.opened_at) : '—'],
      ['Monto inicial', `${currSym}${openingAmount.toFixed(2)}`],
      [],
      ['CIERRE'],
      ['Hora de cierre', register ? fmt(register.closed_at) : fmt(new Date())],
      ['Cerrado por', closedByLabel],
      ['Total vendido', `${currSym}${totalVendido.toFixed(2)}`],
      ['Diferencia (vendido - apertura)', `${currSym}${diferencia.toFixed(2)}`],
      [],
      ['ESTADO DE RESULTADOS'],
      ['Apertura (efectivo inicial)', f$(openingAmount)],
      ['Ventas en efectivo', f$(ventasEfectivo)],
      ['Ventas con tarjeta', f$(ventasTarjeta)],
      ['Total ventas (ingresos)', f$(totalIngresos)],
      ['Total egresos', `- ${f$(totalEgresos)}`],
      ['Resultado neto (ventas - egresos)', f$(resultadoNeto)],
      ['Efectivo esperado en caja', f$(efectivoEsperado)],
      [],
      ['Total pedidos del día', orders.length],
      ['Pedidos completados', orders.filter(o => o.status === 'completed').length],
    ];
    const wsResumen = XLSX.utils.aoa_to_sheet(resumenData);
    wsResumen['!cols'] = [{ wch: 35 }, { wch: 22 }];

    // Hoja de egresos (se adjunta más abajo, tras crear el workbook)
    let wsEgresos = null;
    if (movements.length) {
      const egresosData = [['Hora', 'Categoría', 'Descripción', 'Registrado por', 'Monto']];
      for (const m of movements) {
        egresosData.push([
          fmt(m.created_at),
          m.category || 'gasto',
          m.description || '—',
          m.worker_name || '—',
          f$(m.amount)
        ]);
      }
      egresosData.push([]);
      egresosData.push(['', '', '', 'Total egresos', f$(totalEgresos)]);
      wsEgresos = XLSX.utils.aoa_to_sheet(egresosData);
      wsEgresos['!cols'] = [{ wch: 10 }, { wch: 16 }, { wch: 40 }, { wch: 18 }, { wch: 14 }];
    }

    // Sheet 2: Detalle de pedidos
    const wsData = [
      ['#', 'Tipo', 'Entrada', 'Salida', 'Estado', 'Atendido por', 'Productos', 'Total']
    ];
    for (const o of orders) {
      wsData.push([
        o.order_number || String(o.id),
        tl(o.order_type),
        fmt(o.created_at),
        fmt(o.completed_at),
        sl(o.status),
        o.completed_by_name || '—',
        o.items_text || '—',
        `${currSym}${Number(o.total || 0).toFixed(2)}`
      ]);
    }

    const completados = orders.filter(o => o.status === 'completed').length;
    wsData.push([]);
    wsData.push(['Total pedidos', orders.length, '', '', '', '', '', '']);
    wsData.push(['Completados', completados, '', '', '', '', '', '']);
    wsData.push(['Total vendido', '', '', '', '', '', '', `${currSym}${totalVendido.toFixed(2)}`]);

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, wsResumen, 'Resumen de Caja');
    if (wsEgresos) XLSX.utils.book_append_sheet(wb, wsEgresos, 'Egresos');
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    ws['!cols'] = [{ wch: 10 }, { wch: 12 }, { wch: 10 }, { wch: 10 }, { wch: 14 }, { wch: 18 }, { wch: 50 }, { wch: 12 }];
    XLSX.utils.book_append_sheet(wb, ws, 'Pedidos');
    const xlsxBuffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    const subject = closedBy === 'auto'
      ? `[SRServi] Cierre automático de caja — ${store.name} — ${ds}`
      : `[SRServi] Cierre de caja — ${store.name} — ${ds}`;

    await mailer.sendMail({
      from: `"SRServi" <${process.env.EMAIL_USER}>`,
      to: ownerEmail,
      subject,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#000;padding:20px;text-align:center">
            <h1 style="color:#D4AF37;margin:0;font-size:24px">SRServi</h1>
          </div>
          <div style="padding:24px;background:#f9f9f9">
            <h2 style="color:#111;margin-top:0">Informe de Caja — ${store.name}</h2>
            <p style="color:#444">${ds}</p>
            ${closedBy === 'auto' ? '<p style="color:#e55;font-weight:bold">La caja fue cerrada automáticamente a medianoche.</p>' : ''}
            <table style="width:100%;border-collapse:collapse;margin:16px 0">
              <tr style="background:#222;color:#D4AF37"><td colspan="2" style="padding:8px;font-weight:700;font-size:13px">APERTURA</td></tr>
              <tr style="background:#f9f9f9"><td style="padding:8px">Trabajador</td><td style="padding:8px;text-align:right">${register ? (register.worker_name || '—') : '—'}</td></tr>
              <tr style="background:#f0f0f0"><td style="padding:8px">Hora de apertura</td><td style="padding:8px;text-align:right">${register ? fmt(register.opened_at) : '—'}</td></tr>
              <tr style="background:#f9f9f9"><td style="padding:8px">Monto inicial</td><td style="padding:8px;text-align:right">${currSym}${openingAmount.toFixed(2)}</td></tr>
              <tr style="background:#222;color:#D4AF37"><td colspan="2" style="padding:8px;font-weight:700;font-size:13px;margin-top:8px">CIERRE</td></tr>
              <tr style="background:#f0f0f0"><td style="padding:8px">Hora de cierre</td><td style="padding:8px;text-align:right">${register ? fmt(register.closed_at) : fmt(new Date())}</td></tr>
              <tr style="background:#f9f9f9"><td style="padding:8px">Cerrado por</td><td style="padding:8px;text-align:right">${closedByLabel}</td></tr>
              <tr style="background:#D4AF37"><td style="padding:8px;font-weight:700">Total pedidos</td><td style="padding:8px;text-align:right;font-weight:700">${orders.length}</td></tr>
              <tr style="background:#f0f0f0"><td style="padding:8px">Completados</td><td style="padding:8px;text-align:right">${completados}</td></tr>
              <tr style="background:#fff"><td style="padding:8px;font-weight:700">Total vendido</td><td style="padding:8px;text-align:right;font-weight:700;color:#16a34a">${currSym}${totalVendido.toFixed(2)}</td></tr>
              <tr style="background:#f0f0f0"><td style="padding:8px">Diferencia</td><td style="padding:8px;text-align:right;color:${diferencia >= 0 ? '#16a34a' : '#dc2626'}">${diferencia >= 0 ? '+' : ''}${currSym}${diferencia.toFixed(2)}</td></tr>
            </table>
            <table style="width:100%;border-collapse:collapse;margin:16px 0">
              <tr style="background:#222;color:#D4AF37"><td colspan="2" style="padding:8px;font-weight:700;font-size:13px">ESTADO DE RESULTADOS</td></tr>
              <tr style="background:#f9f9f9"><td style="padding:8px">Apertura (efectivo inicial)</td><td style="padding:8px;text-align:right">${f$(openingAmount)}</td></tr>
              <tr style="background:#f0f0f0"><td style="padding:8px">Ventas en efectivo</td><td style="padding:8px;text-align:right">${f$(ventasEfectivo)}</td></tr>
              <tr style="background:#f9f9f9"><td style="padding:8px">Ventas con tarjeta</td><td style="padding:8px;text-align:right">${f$(ventasTarjeta)}</td></tr>
              <tr style="background:#fff"><td style="padding:8px;font-weight:700">Total ventas (ingresos)</td><td style="padding:8px;text-align:right;font-weight:700;color:#16a34a">${f$(totalIngresos)}</td></tr>
              <tr style="background:#f0f0f0"><td style="padding:8px">Total egresos</td><td style="padding:8px;text-align:right;color:#dc2626">- ${f$(totalEgresos)}</td></tr>
              <tr style="background:#fff"><td style="padding:8px;font-weight:700">Resultado neto</td><td style="padding:8px;text-align:right;font-weight:700;color:${resultadoNeto >= 0 ? '#16a34a' : '#dc2626'}">${f$(resultadoNeto)}</td></tr>
              <tr style="background:#D4AF37"><td style="padding:8px;font-weight:700">Efectivo esperado en caja</td><td style="padding:8px;text-align:right;font-weight:700">${f$(efectivoEsperado)}</td></tr>
            </table>
            <p style="color:#666;font-size:13px">Encontrarás el detalle completo en el archivo Excel adjunto.</p>
          </div>
          <div style="background:#111;padding:12px;text-align:center;font-size:11px;color:#666">SRServi &mdash; ${store.name}</div>
        </div>
      `,
      attachments: [{
        filename: `caja_${store.name.replace(/[^a-z0-9]/gi, '_')}_${new Date().toISOString().slice(0, 10)}.xlsx`,
        content: xlsxBuffer,
        contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      }]
    });
    console.log(`[Caja] Email enviado a ${ownerEmail} para tienda ${store.name}`);
  } catch (e) {
    console.error('[Caja] Error enviando email:', e.message);
  }
}

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token requerido' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Token inválido' });
    }
    req.user = user;
    next();
  });
};

app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, password, business_name, country } = req.body;
    const email = (req.body.email || '').toLowerCase().trim();
    const phone = (req.body.phone || '').trim();

    if (!username || !email || !password || !country || !phone) {
      return res.status(400).json({ error: 'Todos los campos son requeridos' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });
    }

    const [existingEmail] = await pool.execute('SELECT id FROM users WHERE email = ?', [email]);
    if (existingEmail.length > 0) {
      return res.status(400).json({ error: 'Ya existe una cuenta con ese correo electrónico' });
    }

    const [existingUsername] = await pool.execute('SELECT id FROM users WHERE username = ?', [username]);
    if (existingUsername.length > 0) {
      return res.status(400).json({ error: 'Ese nombre de usuario ya está en uso' });
    }

    const user = await createUser(username, email, password, business_name, country, phone);

    const storeName = business_name || username;
    const newStore = await createStore(user.id, {
      name: storeName,
      primary_color: '#000000',
      secondary_color: '#FFFFFF',
      accent_color: '#D4AF37',
      header_color: '#000000',
      currency_code: 'USD',
      currency_symbol: '$',
      currency_name: 'Dólar Estadounidense'
    });
    await createStoreConfiguration(newStore.id, {
      name: 'Default Config',
      accept_cash: true,
      accept_card: true,
      is_active: true,
      is_default: true,
      allow_serve: true,
      allow_takeout: true
    });

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expires = new Date(Date.now() + 15 * 60 * 1000);
    await setVerificationCode(user.id, code, expires);

    await mailer.sendMail({
      from: `"SRServi" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: 'Activa tu cuenta SRServi',
      html: `<div style="font-family:sans-serif;max-width:480px;margin:auto">
        <h2 style="color:#D4AF37">Bienvenido a SRServi</h2>
        <p>Tu código de activación es:</p>
        <div style="font-size:36px;font-weight:900;letter-spacing:10px;text-align:center;padding:20px;background:#f5f5f5;border-radius:8px">${code}</div>
        <p style="color:#888;font-size:12px">Expira en 15 minutos. Si no creaste esta cuenta, ignora este correo.</p>
      </div>`
    });

    res.json({ requiresVerification: true, email });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const password = req.body.password;
    const email = (req.body.email || '').toLowerCase().trim();

    if (!email || !password) {
      return res.status(400).json({ error: 'Email y contraseña son requeridos' });
    }

    // Check sub-account first
    let subAccount = null;
    try { subAccount = await authenticateSubAccount(email, password); } catch (e) {
      if (e.message === 'Cuenta desactivada') return res.status(403).json({ error: e.message });
    }
    if (subAccount) {
      // JWT uses owner_id as "id" so existing store-ownership checks work transparently
      const token = jwt.sign({
        id: subAccount.owner_id,
        sub_account_id: subAccount.id,
        email: subAccount.email,
        name: subAccount.name,
        role_id: subAccount.role_id,
        permissions: subAccount.role_permissions || {},
        is_sub_account: true,
        type: 'sub_account'
      }, JWT_SECRET, { expiresIn: '7d' });
      return res.json({
        user: {
          id: subAccount.owner_id,
          sub_account_id: subAccount.id,
          name: subAccount.name,
          email: subAccount.email,
          is_sub_account: true,
          permissions: subAccount.role_permissions || {}
        },
        token
      });
    }

    const user = await authenticateUser(email, password);

    if (!user) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    if (user.is_banned) {
      return res.status(403).json({
        error: 'Tu cuenta ha sido suspendida. Contacta a soporte@srautomatic.com para la apelación. La revisión puede demorar entre 1 semana y 1 mes.'
      });
    }

    if (!user.email_verified) {
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      const expires = new Date(Date.now() + 15 * 60 * 1000);
      await setVerificationCode(user.id, code, expires);
      try {
        await mailer.sendMail({
          from: `"SRServi" <${process.env.EMAIL_USER}>`,
          to: email,
          subject: 'Activa tu cuenta SRServi',
          html: `<div style="font-family:sans-serif;max-width:480px;margin:auto">
            <h2 style="color:#D4AF37">Activa tu cuenta</h2>
            <p>Tu código de activación es:</p>
            <div style="font-size:36px;font-weight:900;letter-spacing:10px;text-align:center;padding:20px;background:#f5f5f5;border-radius:8px">${code}</div>
            <p style="color:#888;font-size:12px">Expira en 15 minutos.</p>
          </div>`
        });
      } catch (mailErr) {
        console.error('Error enviando correo de verificación:', mailErr.message);
      }
      return res.json({ requiresVerification: true, email });
    }

    if (user.totp_enabled && user.totp_secret) {
      const tempToken = jwt.sign({ id: user.id, type: '2fa_pending' }, JWT_SECRET, { expiresIn: '5m' });
      return res.json({ requiresTwoFactor: true, tempToken });
    }

    const token = jwt.sign({ id: user.id, email: user.email, type: 'user' }, JWT_SECRET, { expiresIn: '7d' });
    const { totp_secret, totp_enabled, email_verified, ...safeUser } = user;
    res.json({ user: safeUser, token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/verify-email', async (req, res) => {
  try {
    const email = (req.body.email || '').toLowerCase().trim();
    const { code } = req.body;
    if (!email || !code) return res.status(400).json({ error: 'Datos incompletos' });

    const user = await getUserByEmail(email);
    if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });
    if (user.email_verified) return res.status(400).json({ error: 'La cuenta ya está verificada' });

    if (!user.verification_code || user.verification_code !== String(code).trim()) {
      return res.status(401).json({ error: 'Código incorrecto' });
    }
    if (!user.verification_expires || new Date() > new Date(user.verification_expires)) {
      return res.status(401).json({ error: 'El código expiró. Solicita uno nuevo.' });
    }

    await markEmailVerified(user.id);

    const fullUser = await getUserById(user.id);
    const token = jwt.sign({ id: user.id, email: user.email, type: 'user' }, JWT_SECRET, { expiresIn: '7d' });
    const { totp_secret, totp_enabled, ...safeUser } = fullUser;
    res.json({ user: safeUser, token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/resend-verification', async (req, res) => {
  try {
    const email = (req.body.email || '').toLowerCase().trim();
    if (!email) return res.status(400).json({ error: 'Email requerido' });

    const user = await getUserByEmail(email);
    if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });
    if (user.email_verified) return res.status(400).json({ error: 'La cuenta ya está verificada' });

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expires = new Date(Date.now() + 15 * 60 * 1000);
    await setVerificationCode(user.id, code, expires);

    await mailer.sendMail({
      from: `"SRServi" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: 'Activa tu cuenta SRServi',
      html: `<div style="font-family:sans-serif;max-width:480px;margin:auto">
        <h2 style="color:#D4AF37">Activa tu cuenta</h2>
        <p>Tu nuevo código de activación es:</p>
        <div style="font-size:36px;font-weight:900;letter-spacing:10px;text-align:center;padding:20px;background:#f5f5f5;border-radius:8px">${code}</div>
        <p style="color:#888;font-size:12px">Expira en 15 minutos.</p>
      </div>`
    });

    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/2fa/verify', async (req, res) => {
  try {
    const { tempToken, code } = req.body;
    if (!tempToken || !code) return res.status(400).json({ error: 'Datos incompletos' });

    let payload;
    try {
      payload = jwt.verify(tempToken, JWT_SECRET);
    } catch {
      return res.status(401).json({ error: 'Token expirado o inválido' });
    }
    if (payload.type !== '2fa_pending') return res.status(401).json({ error: 'Token inválido' });

    const user = await getUserById(payload.id);
    if (!user || !user.totp_secret) return res.status(401).json({ error: 'Usuario no encontrado' });

    const valid = speakeasy.totp.verify({
      secret: user.totp_secret,
      encoding: 'base32',
      token: String(code).replace(/\s/g, ''),
      window: 1
    });

    if (!valid) return res.status(401).json({ error: 'Código incorrecto' });

    const token = jwt.sign({ id: user.id, email: user.email, type: 'user' }, JWT_SECRET, { expiresIn: '7d' });
    const { totp_secret, totp_enabled, password, ...safeUser } = user;
    res.json({ user: safeUser, token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/auth/2fa/status', authenticateToken, async (req, res) => {
  try {
    const user = await getUserById(req.user.id);
    res.json({ enabled: Boolean(user?.totp_enabled) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/auth/2fa/setup', authenticateToken, async (req, res) => {
  try {
    const user = await getUserById(req.user.id);
    if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });

    const secret = speakeasy.generateSecret({
      name: `SRServi (${user.email})`,
      issuer: 'SRServi',
      length: 20
    });

    await setTotpSecret(req.user.id, secret.base32);

    res.json({
      secret: secret.base32,
      otpauthUrl: secret.otpauth_url
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/2fa/enable', authenticateToken, async (req, res) => {
  try {
    const { code } = req.body;
    if (!code) return res.status(400).json({ error: 'Código requerido' });

    const user = await getUserById(req.user.id);
    if (!user || !user.totp_secret) return res.status(400).json({ error: 'Primero genera el QR de configuración' });

    const valid = speakeasy.totp.verify({
      secret: user.totp_secret,
      encoding: 'base32',
      token: String(code).replace(/\s/g, ''),
      window: 1
    });

    if (!valid) return res.status(401).json({ error: 'Código incorrecto. Asegúrate de haber escaneado el QR.' });

    await enableTotp(req.user.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/2fa/disable', authenticateToken, async (req, res) => {
  try {
    const { code } = req.body;
    if (!code) return res.status(400).json({ error: 'Código requerido' });

    const user = await getUserById(req.user.id);
    if (!user || !user.totp_secret) return res.status(400).json({ error: '2FA no está configurado' });

    const valid = speakeasy.totp.verify({
      secret: user.totp_secret,
      encoding: 'base32',
      token: String(code).replace(/\s/g, ''),
      window: 1
    });

    if (!valid) return res.status(401).json({ error: 'Código incorrecto' });

    await disableTotp(req.user.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/2fa/recover', async (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email || !code) return res.status(400).json({ error: 'Email y código son requeridos' });

    const user = await getUserByEmail(email);
    if (!user) return res.status(404).json({ error: 'No existe una cuenta con ese email' });
    if (!user.totp_enabled || !user.totp_secret) {
      return res.status(400).json({ error: 'Esta cuenta no tiene verificación en 2 pasos activada' });
    }

    const valid = speakeasy.totp.verify({
      secret: user.totp_secret,
      encoding: 'base32',
      token: String(code).replace(/\s/g, ''),
      window: 1
    });

    if (!valid) return res.status(401).json({ error: 'Código incorrecto' });

    const recoveryToken = jwt.sign({ id: user.id, type: 'password_recovery' }, JWT_SECRET, { expiresIn: '10m' });
    res.json({ recoveryToken });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/2fa/reset-password', async (req, res) => {
  try {
    const { recoveryToken, newPassword } = req.body;
    if (!recoveryToken || !newPassword) return res.status(400).json({ error: 'Datos incompletos' });
    if (newPassword.length < 6) return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });

    let payload;
    try {
      payload = jwt.verify(recoveryToken, JWT_SECRET);
    } catch {
      return res.status(401).json({ error: 'Token expirado. Vuelve a verificar con tu app.' });
    }
    if (payload.type !== 'password_recovery') return res.status(401).json({ error: 'Token inválido' });

    const hashed = await bcrypt.hash(newPassword, 10);
    await updateUserPassword(payload.id, hashed);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/forgot-password', async (req, res) => {
  try {
    const email = (req.body.email || '').toLowerCase().trim();
    if (!email) return res.status(400).json({ error: 'Email requerido' });

    const user = await getUserByEmail(email);
    // Always respond OK to avoid user enumeration
    if (!user) return res.json({ success: true });

    const resetToken = jwt.sign({ id: user.id, type: 'email_reset' }, JWT_SECRET, { expiresIn: '15m' });
    const resetUrl = `${BASE_URL}/reset-password?token=${resetToken}`;

    await mailer.sendMail({
      from: `"SRServi" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: 'Restablecer contraseña — SRServi',
      html: `
        <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:32px;background:#fff;border-radius:12px;border:1px solid #e0e0e0">
          <div style="text-align:center;margin-bottom:24px">
            <div style="display:inline-flex;align-items:center;justify-content:center;width:56px;height:56px;border-radius:50%;background:#000;margin-bottom:12px">
              <span style="color:#D4AF37;font-weight:900;font-size:20px">SR</span>
            </div>
            <h2 style="margin:0;font-size:22px;color:#111">Restablecer contraseña</h2>
          </div>
          <p style="color:#444;font-size:15px;line-height:1.6">
            Recibimos una solicitud para restablecer la contraseña de tu cuenta <strong>${email}</strong>.
          </p>
          <div style="text-align:center;margin:28px 0">
            <a href="${resetUrl}" style="display:inline-block;background:#D4AF37;color:#000;font-weight:800;font-size:16px;padding:14px 32px;border-radius:10px;text-decoration:none">
              Restablecer contraseña
            </a>
          </div>
          <p style="color:#888;font-size:13px">Este enlace expira en <strong>15 minutos</strong>. Si no solicitaste esto, ignora este correo.</p>
          <hr style="border:none;border-top:1px solid #eee;margin:24px 0">
          <p style="color:#bbb;font-size:12px;text-align:center">SRServi · support@srautomatic.com</p>
        </div>
      `
    });

    res.json({ success: true });
  } catch (error) {
    console.error('Error enviando email de reset:', error.message);
    res.status(500).json({ error: 'No se pudo enviar el correo. Intenta de nuevo.' });
  }
});

app.post('/api/auth/reset-password', async (req, res) => {
  try {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) return res.status(400).json({ error: 'Datos incompletos' });
    if (newPassword.length < 6) return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });

    let payload;
    try {
      payload = jwt.verify(token, JWT_SECRET);
    } catch {
      return res.status(401).json({ error: 'El enlace expiró o es inválido. Solicita uno nuevo.' });
    }
    if (payload.type !== 'email_reset') return res.status(401).json({ error: 'Token inválido' });

    const hashed = await bcrypt.hash(newPassword, 10);
    await updateUserPassword(payload.id, hashed);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Lookup a code: returns whether it's a store code or a client (user) code.
// If it's a client code, returns the list of stores for that user so the
// customer can pick one without memorizing every store code.
app.get('/api/public/lookup/:code', async (req, res) => {
  try {
    const code = (req.params.code || '').toUpperCase();
    if (!code) return res.status(400).json({ error: 'Código requerido' });

    // First, try to match it against a store code (most common case)
    const store = await getStoreByCode(code);
    if (store) {
      if (store.is_banned) {
        return res.status(403).json({
          error: 'Esta tienda ha sido suspendida. Contacta a soporte@srautomatic.com para la apelación.'
        });
      }
      return res.json({ type: 'store', id: store.id, code: store.code, name: store.name });
    }

    // Otherwise, try to match it against a client (user) code
    const [userRows] = await pool.execute(
      'SELECT id, business_name, username, is_banned FROM users WHERE code = ?',
      [code]
    );
    if (userRows.length === 0) {
      return res.status(404).json({ error: 'Código no encontrado' });
    }
    const user = userRows[0];
    if (user.is_banned) {
      return res.status(403).json({
        error: 'Esta cuenta ha sido suspendida. Contacta a soporte@srautomatic.com para la apelación.'
      });
    }

    const stores = await getStores(user.id);
    const userPlanForLookup = await getUserPlan(user.id);
    const isPremiumForLookup = !!(userPlanForLookup && userPlanForLookup.plan_name && userPlanForLookup.plan_name !== 'Gratis');
    const visibleStores = stores
      .filter(s => !s.is_banned)
      .map(s => ({
        id: s.id,
        code: s.code,
        name: s.name,
        primary_color: s.primary_color || '#000000',
        secondary_color: s.secondary_color || '#FFFFFF',
        accent_color: s.accent_color || '#D4AF37',
        logo_url: isPremiumForLookup ? (s.logo_url || null) : null
      }));

    if (visibleStores.length === 0) {
      return res.status(404).json({ error: 'Este cliente aún no tiene tiendas disponibles' });
    }

    return res.json({
      type: 'client',
      client: {
        name: user.business_name || user.username
      },
      stores: visibleStores
    });
  } catch (error) {
    console.error('❌ Error en /api/public/lookup:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.post('/api/auth/heartbeat', authenticateToken, async (req, res) => {
  try {
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress || '';
    let country = null;
    if (ip && ip !== '::1' && ip !== '127.0.0.1') {
      try {
        const geoRes = await fetch(`http://ip-api.com/json/${ip}?fields=country`);
        if (geoRes.ok) {
          const geo = await geoRes.json();
          if (geo.country) country = geo.country;
        }
      } catch {}
    }
    await updateUserHeartbeat(req.user.id, country);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/public/:code/plan-info', async (req, res) => {
  try {
    const { code } = req.params;
    const store = await getStoreByCode(code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const userPlan = await getUserPlan(store.user_id);
    const planName = userPlan?.plan_name || 'Gratis';
    const maxPrinters = planName === 'Personalizado' ? 10 : planName === 'Empresas' ? 5 : 1;
    res.json({ planName, maxPrinters });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/public/:code', async (req, res) => {
  try {
    const { code } = req.params;
    const store = await getStoreByCode(code.toUpperCase());

    if (!store) {
      return res.status(404).json({ error: 'Código no encontrado' });
    }
    
    if (store.is_banned) {
      return res.status(403).json({ 
        error: 'Esta tienda ha sido suspendida. Contacta a soporte@srautomatic.com para la apelación. La revisión puede demorar entre 1 semana y 1 mes.' 
      });
    }
    
    const products = await getPublicProducts(store.id);
    const categories = await getCategories(store.id);
    const openRegister = await getOpenCashRegister(store.id);
    let combos = [];
    try { combos = await getPublicCombos(store.id); } catch (e) { console.warn('getPublicCombos:', e.message); }

    // Premium check — logo and custom styles only for active paid plans
    const userPlan = await getUserPlan(store.user_id);
    const isPremium = !!(userPlan && userPlan.plan_name && userPlan.plan_name !== 'Gratis');

    // Smart mode: get top selling product IDs (last 30 days)
    let topSellingIds = [];
    try {
      const [topRows] = await pool.execute(
        `SELECT oi.product_id, SUM(oi.quantity) as total_sold
         FROM order_items oi
         JOIN orders o ON oi.order_id = o.id
         WHERE o.store_id = ? AND o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
         GROUP BY oi.product_id
         ORDER BY total_sold DESC
         LIMIT 5`,
        [store.id]
      );
      topSellingIds = topRows.map(r => r.product_id);
    } catch { /* ignore if table doesn't exist */ }

    res.json({
      store: {
        id: store.id,
        code: store.code,
        name: store.name,
        primary_color: store.primary_color || '#000000',
        secondary_color: store.secondary_color || '#FFFFFF',
        accent_color: store.accent_color || '#D4AF37',
        header_color: store.header_color || '#000000',
        logo_url: isPremium ? (store.logo_url || null) : null,
        currency_code: store.currency_code || 'USD',
        currency_symbol: store.currency_symbol || '$',
        currency_name: store.currency_name || 'Dólar Estadounidense',
        smart_mode: store.smart_mode ?? true,
        inactivity_timeout: store.inactivity_timeout ?? 120,
        hide_decimals: store.hide_decimals ?? false,
        show_top_selling: store.show_top_selling ?? true,
        complements_label: store.complements_label || null,
        extras_label: store.extras_label || null
      },
      products,
      categories,
      combos,
      cash_register_open: !!openRegister,
      top_selling: (store.smart_mode !== false && store.smart_mode !== 0) && (store.show_top_selling !== false && store.show_top_selling !== 0) ? topSellingIds : []
    });
  } catch (error) {
    console.error('❌ Error en /api/public:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/public/:code/mercado-pago-terminals', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Código no encontrado' });
    const all = await getPosTerminalsByStore(store.id);
    res.json(all.filter(t => t.provider === 'mercadopago'));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/public/terminals/:storeId', async (req, res) => {
  try {
    const all = await getPosTerminalsByStore(parseInt(req.params.storeId));
    const terminals = all.filter(t => t.provider === 'mercadopago');
    res.json(terminals);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/public/pos-devices/:storeCode', async (req, res) => {
  try {
    const { storeCode } = req.params;
    const store = await getStoreByCode((storeCode || '').toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });

    const terminals = await getPosTerminalsByStore(store.id);
    const formatted = terminals.map(t => ({
      id: t.id,
      name: t.name,
      provider: t.provider,
      device_id: t.device_id,
      serial: t.device_id,
      pos_pin: t.pos_pin
    }));

    res.json(formatted);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/stores/code/:code', authenticateToken, async (req, res) => {
  try {
    const code = (req.params.code || '').toUpperCase();
    const store = await getStoreByCode(code);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    res.json(store);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/public/:code/coupons/validate', async (req, res) => {
  try {
    const { code } = req.params;
    const { coupon_code, subtotal } = req.body;
    const store = await getStoreByCode(code.toUpperCase());

    if (!store) {
      return res.status(404).json({ error: 'Código no encontrado' });
    }

    const result = await validateCouponForStore(store.id, coupon_code, Number(subtotal) || 0);
    res.json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/user', authenticateToken, async (req, res) => {
  try {
    const user = await getUserById(req.user.id);
    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    // Ensure support_pin exists
    if (!user.support_pin) {
      const pin = String(Math.floor(100000 + Math.random() * 900000));
      try {
        await pool.execute('SHOW COLUMNS FROM users LIKE ?', ['support_pin']).then(async ([cols]) => {
          if (cols.length === 0) await pool.execute('ALTER TABLE users ADD COLUMN support_pin VARCHAR(6) DEFAULT NULL');
        });
        await pool.execute('UPDATE users SET support_pin = ? WHERE id = ?', [pin, req.user.id]);
        user.support_pin = pin;
      } catch {}
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/user/settings', authenticateToken, async (req, res) => {
  try {
    const { primary_color, secondary_color, accent_color, header_color, currency_code, currency_symbol, currency_name } = req.body;
     
    const user = await updateUserSettings(req.user.id, {
      primary_color,
      secondary_color,
      accent_color,
      header_color,
      currency_code,
      currency_symbol,
      currency_name
    });
     
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
 });

app.get('/api/user/chatgpt-key', authenticateToken, async (req, res) => {
  try {
    const key = await getChatGptKey(req.user.id);
    res.json({ has_key: !!key, key_preview: key ? `sk-...${key.slice(-4)}` : null });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/user/chatgpt-key', authenticateToken, async (req, res) => {
  try {
    const { api_key } = req.body;
    await saveChatGptKey(req.user.id, api_key || null);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/stores', authenticateToken, async (req, res) => {
  try {
    const stores = await getStores(req.user.id);
    res.json(stores);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/stores/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const storeId = parseInt(id);
    if (req.user.type === 'worker') {
      if (req.user.store_id !== storeId) return res.status(403).json({ error: 'Sin acceso' });
      const store = await getStoreById(storeId);
      if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
      return res.json(store);
    }
    const stores = await getStores(req.user.id);
    const store = stores.find(s => s.id === storeId);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    res.json(store);
  } catch (error) {
    console.error('Error fetching store:', error);
    res.status(500).json({ error: error.message });
  }
});

// Generic image upload — used by Procedures and other modules
app.post('/api/upload', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No se recibió imagen' });
    const url = `/uploads/${req.file.filename}`;
    res.json({ url });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/stores', authenticateToken, upload.single('logo'), async (req, res) => {
  try {
    const { name, primary_color, secondary_color, accent_color, header_color, currency_code, currency_symbol, currency_name } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'Nombre es requerido' });
    }
    const logo_url = req.file ? `/uploads/${req.file.filename}` : null;
    const store = await createStore(req.user.id, {
      name,
      primary_color,
      secondary_color,
      accent_color,
      header_color,
      currency_code,
      currency_symbol,
      currency_name,
      logo_url
    });
    await createStoreConfiguration(store.id, {
      name: 'Default Config',
      accept_cash: true,
      accept_card: true,
      is_active: true,
      is_default: true,
      allow_serve: true,
      allow_takeout: true
    });
    res.json(store);
  } catch (error) {
    if (error.code === 'STORE_LIMIT_REACHED') {
      return res.status(403).json({ 
        error: error.message,
        code: 'STORE_LIMIT_REACHED',
        maxStores: error.maxStores,
        currentPlan: error.currentPlan
      });
    }
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/stores/:id', authenticateToken, upload.single('logo'), async (req, res) => {
  try {
    const { name, primary_color, secondary_color, accent_color, header_color, currency_code, currency_symbol, currency_name, remove_logo, worker_accept_cash, worker_accept_card, smart_mode, inactivity_timeout, hide_decimals, show_top_selling, paid_order_status, complements_label, extras_label, worker_show_prices } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'Nombre es requerido' });
    }
    let logo_url;
    if (remove_logo === 'true') {
      logo_url = null;
    } else if (req.file) {
      logo_url = `/uploads/${req.file.filename}`;
    }
    const store = await updateStore(req.params.id, req.user.id, {
      name,
      primary_color,
      secondary_color,
      accent_color,
      header_color,
      currency_code,
      currency_symbol,
      currency_name,
      logo_url,
      worker_accept_cash,
      worker_accept_card,
      smart_mode,
      inactivity_timeout,
      hide_decimals,
      show_top_selling,
      paid_order_status,
      complements_label,
      extras_label,
      worker_show_prices
    });
    res.json(store);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/stores/:id', authenticateToken, async (req, res) => {
  try {
    await deleteStore(req.params.id, req.user.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/stores/:id/duplicate', authenticateToken, async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'Nombre es requerido' });
    const store = await duplicateStore(req.params.id, req.user.id, name);
    res.json(store);
  } catch (error) {
    if (error.code === 'STORE_LIMIT_REACHED') {
      return res.status(403).json({ error: error.message, code: 'STORE_LIMIT_REACHED', maxStores: error.maxStores, currentPlan: error.currentPlan });
    }
    res.status(500).json({ error: error.message });
  }
});

// Store Edit PIN endpoints
app.put('/api/stores/:id/edit-pin', authenticateToken, async (req, res) => {
  try {
    const { pin } = req.body;
    const storeId = parseInt(req.params.id);
    const isOwner = await verifyStoreOwnership(storeId, req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    await setStoreEditPin(storeId, req.user.id, pin);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/stores/:id/edit-pin', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const isOwner = await verifyStoreOwnership(storeId, req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const pin = await getStoreEditPin(storeId);
    res.json({ pin });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/public/:code/verify-edit-pin', async (req, res) => {
  try {
    const { code } = req.params;
    const { pin } = req.body;
    const store = await getStoreByCode(code.toUpperCase());
    if (!store) {
      return res.status(404).json({ error: 'Tienda no encontrada' });
    }
    const valid = await verifyStoreEditPin(store.id, pin);
    res.json({ valid });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/public/:code/products/order', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    if (!req.body.products) return res.status(400).json({ error: 'products es requerido' });
    await updateProductsOrder(auth.store.id, req.body.products);
    emitProductUpdate(auth.store.id, 'products_reordered', { products: req.body.products });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/public/:code/categories/order', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    if (!req.body.categories) return res.status(400).json({ error: 'categories es requerido' });
    await updateCategoriesOrder(auth.store.id, req.body.categories);
    io.to(`store_${auth.store.id}`).emit('category_updated');
    io.emit('category_updated');
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// ---- Store Devices (unique device IDs) ----

// Register/update a device (called by store on load)
app.post('/api/public/:code/register-device', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const { device_uid } = req.body;
    if (!device_uid) return res.status(400).json({ error: 'device_uid requerido' });
    await pool.execute(
      `INSERT INTO store_devices (device_uid, store_id) VALUES (?, ?)
       ON DUPLICATE KEY UPDATE last_seen = NOW()`,
      [device_uid, store.id]
    );
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// List devices for a store (admin)
app.get('/api/store-devices', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.json([]);
    const isOwner = await verifyStoreOwnership(storeId, req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso' });
    const [rows] = await pool.execute(
      'SELECT * FROM store_devices WHERE store_id = ? ORDER BY last_seen DESC', [storeId]
    );
    res.json(rows);
  } catch (error) {
    if (error.message?.includes("doesn't exist")) return res.json([]);
    res.status(500).json({ error: error.message });
  }
});

// Update device (label, config, restart time)
app.put('/api/store-devices/:id', authenticateToken, async (req, res) => {
  try {
    const { label, config_id, restart_time } = req.body;
    // Add columns if missing
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM store_devices');
      const names = cols.map(c => c.Field);
      if (!names.includes('config_id')) await pool.execute('ALTER TABLE store_devices ADD COLUMN config_id INT DEFAULT NULL');
      if (!names.includes('restart_time')) await pool.execute('ALTER TABLE store_devices ADD COLUMN restart_time VARCHAR(10) DEFAULT NULL');
      if (!names.includes('pending_restart')) await pool.execute('ALTER TABLE store_devices ADD COLUMN pending_restart BOOLEAN DEFAULT FALSE');
    } catch { /* ignore */ }

    const fields = [];
    const values = [];
    if (label !== undefined) { fields.push('label = ?'); values.push(label || null); }
    if (config_id !== undefined) { fields.push('config_id = ?'); values.push(config_id || null); }
    if (restart_time !== undefined) { fields.push('restart_time = ?'); values.push(restart_time || null); }
    if (fields.length === 0) return res.json({ success: true });

    // Mark pending_restart when config changes
    if (config_id !== undefined || restart_time !== undefined) {
      fields.push('pending_restart = TRUE');
    }

    values.push(parseInt(req.params.id));
    await pool.execute(`UPDATE store_devices SET ${fields.join(', ')} WHERE id = ?`, values);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete device (tótem)
app.delete('/api/store-devices/:id', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT store_id FROM store_devices WHERE id = ?', [parseInt(req.params.id)]);
    if (!rows.length) return res.json({ success: true });
    const isOwner = await verifyStoreOwnership(rows[0].store_id, req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso' });
    await pool.execute('DELETE FROM store_devices WHERE id = ?', [parseInt(req.params.id)]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Legacy label endpoint
app.put('/api/store-devices/:id/label', authenticateToken, async (req, res) => {
  try {
    const { label } = req.body;
    await pool.execute('UPDATE store_devices SET label = ? WHERE id = ?', [label || null, parseInt(req.params.id)]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Public: get device config (called by Store on load)
app.get('/api/public/device-config/:deviceUid/:storeId', async (req, res) => {
  try {
    // Add columns if missing
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM store_devices');
      const names = cols.map(c => c.Field);
      if (!names.includes('config_id')) await pool.execute('ALTER TABLE store_devices ADD COLUMN config_id INT DEFAULT NULL');
      if (!names.includes('restart_time')) await pool.execute('ALTER TABLE store_devices ADD COLUMN restart_time VARCHAR(10) DEFAULT NULL');
      if (!names.includes('pending_restart')) await pool.execute('ALTER TABLE store_devices ADD COLUMN pending_restart BOOLEAN DEFAULT FALSE');
    } catch { /* ignore */ }

    const [rows] = await pool.execute(
      'SELECT config_id, restart_time, pending_restart FROM store_devices WHERE device_uid = ? AND store_id = ?',
      [req.params.deviceUid, parseInt(req.params.storeId)]
    );
    if (rows.length === 0) return res.json({ config_id: null, restart_time: null, pending_restart: false });

    // Clear pending restart flag after reading
    if (rows[0].pending_restart) {
      await pool.execute(
        'UPDATE store_devices SET pending_restart = FALSE WHERE device_uid = ? AND store_id = ?',
        [req.params.deviceUid, parseInt(req.params.storeId)]
      );
    }

    res.json(rows[0]);
  } catch (error) {
    res.json({ config_id: null, restart_time: null, pending_restart: false });
  }
});

// Validate admin token for store editor
app.post('/api/public/:code/validate-admin', async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) return res.json({ valid: false });
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.json({ valid: false });
    if (store.user_id !== decoded.id) return res.json({ valid: false });
    res.json({ valid: true });
  } catch {
    res.json({ valid: false });
  }
});

// Public extras/ingredients CRUD with admin token
app.get('/api/public/:code/extras', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const [rows] = await pool.execute(
      `SELECT e.*, c.name as category_name FROM extras e LEFT JOIN categories c ON e.category_id = c.id WHERE e.store_id = ? AND e.owner_product_id IS NULL ORDER BY e.sort_order, e.name`,
      [store.id]
    );
    res.json(rows);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.get('/api/public/:code/ingredients', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const [rows] = await pool.execute(
      `SELECT i.*, c.name as category_name FROM ingredients i LEFT JOIN categories c ON i.category_id = c.id WHERE i.store_id = ? AND i.owner_product_id IS NULL ORDER BY i.sort_order, i.name`,
      [store.id]
    );
    res.json(rows);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Complementos PRIVADOS de un producto (lista única) — incluye su included_by_default
app.get('/api/public/:code/products/:id/own-complements', async (req, res) => {
  try {
    const productId = parseInt(req.params.id);
    const [ings] = await pool.execute(
      `SELECT i.*, pi.included_by_default AS included_by_default
       FROM ingredients i INNER JOIN product_ingredients pi ON pi.ingredient_id = i.id AND pi.product_id = ?
       ORDER BY i.sort_order, i.name`, [productId]
    );
    const [exts] = await pool.execute(
      `SELECT e.* FROM extras e INNER JOIN product_extras pe ON pe.extra_id = e.id AND pe.product_id = ?
       ORDER BY e.sort_order, e.name`, [productId]
    );
    res.json({ ingredients: ings, extras: exts });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.post('/api/public/:code/extras', upload.single('image'), async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const decoded = jwt.verify(req.body.token, process.env.JWT_SECRET || 'your-secret-key');
    if (store.user_id !== decoded.id) return res.status(403).json({ error: 'No autorizado' });
    const image = req.file ? `/uploads/${req.file.filename}` : null;
    const catId = req.body.category_id && req.body.category_id !== '' && req.body.category_id !== 'null' ? parseInt(req.body.category_id) : null;
    const ownerProductId = req.body.owner_product_id ? parseInt(req.body.owner_product_id) : null;
    // is_active explícito si viene; si no, privados activos y compartidos nuevos desactivados.
    const isActive = req.body.is_active !== undefined
      ? (req.body.is_active === 'true' || req.body.is_active === true ? 1 : 0)
      : (ownerProductId ? 1 : 0);
    const [result] = await pool.execute(
      'INSERT INTO extras (store_id, user_id, name, price, category_id, image, is_active, owner_product_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [store.id, store.user_id, req.body.name, parseFloat(req.body.price) || 0, catId, image, isActive, ownerProductId]
    );
    try {
      await pool.execute('UPDATE extras SET stock = ?, unlimited_stock = ? WHERE id = ?',
        [parseInt(req.body.stock) || 0, req.body.unlimited_stock === 'true' ? 1 : 0, result.insertId]);
    } catch { /* stock columns may not exist yet */ }
    emitProductUpdate(store.id, 'extra_created', { id: result.insertId });
    res.json({ id: result.insertId, name: req.body.name });
  } catch (error) { console.error('Error creating extra:', error); res.status(500).json({ error: error.message }); }
});

app.post('/api/public/:code/ingredients', upload.single('image'), async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const decoded = jwt.verify(req.body.token, process.env.JWT_SECRET || 'your-secret-key');
    if (store.user_id !== decoded.id) return res.status(403).json({ error: 'No autorizado' });
    const image = req.file ? `/uploads/${req.file.filename}` : null;
    const catId = req.body.category_id && req.body.category_id !== '' && req.body.category_id !== 'null' ? parseInt(req.body.category_id) : null;
    const ownerProductId = req.body.owner_product_id ? parseInt(req.body.owner_product_id) : null;
    // is_active explícito si viene; si no, privados activos y compartidos nuevos desactivados.
    const isActive = req.body.is_active !== undefined
      ? (req.body.is_active === 'true' || req.body.is_active === true ? 1 : 0)
      : (ownerProductId ? 1 : 0);
    const [result] = await pool.execute(
      'INSERT INTO ingredients (store_id, user_id, name, price, category_id, image, is_active, owner_product_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [store.id, store.user_id, req.body.name, parseFloat(req.body.price) || 0, catId, image, isActive, ownerProductId]
    );
    try {
      await pool.execute('UPDATE ingredients SET stock = ?, unlimited_stock = ? WHERE id = ?',
        [parseInt(req.body.stock) || 0, req.body.unlimited_stock === 'true' ? 1 : 0, result.insertId]);
    } catch { /* stock columns may not exist yet */ }
    emitProductUpdate(store.id, 'ingredient_created', { id: result.insertId });
    res.json({ id: result.insertId, name: req.body.name });
  } catch (error) { console.error('Error creating ingredient:', error); res.status(500).json({ error: error.message }); }
});

app.put('/api/public/:code/extras/:id', upload.single('image'), async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const decoded = jwt.verify(req.body.token, process.env.JWT_SECRET || 'your-secret-key');
    if (store.user_id !== decoded.id) return res.status(403).json({ error: 'No autorizado' });
    const catId = req.body.category_id && req.body.category_id !== '' && req.body.category_id !== 'null' ? parseInt(req.body.category_id) : null;
    let imageUpdate = '';
    let params = [req.body.name, parseFloat(req.body.price) || 0, catId];
    if (req.file) {
      imageUpdate = ', image = ?';
      params.push(`/uploads/${req.file.filename}`);
    }
    params.push(parseInt(req.params.id), store.id);
    await pool.execute(`UPDATE extras SET name = ?, price = ?, category_id = ?${imageUpdate} WHERE id = ? AND store_id = ?`, params);
    emitProductUpdate(store.id, 'extra_updated', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { console.error('Error updating extra:', error); res.status(500).json({ error: error.message }); }
});

app.put('/api/public/:code/ingredients/:id', upload.single('image'), async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const decoded = jwt.verify(req.body.token, process.env.JWT_SECRET || 'your-secret-key');
    if (store.user_id !== decoded.id) return res.status(403).json({ error: 'No autorizado' });
    const catId = req.body.category_id && req.body.category_id !== '' && req.body.category_id !== 'null' ? parseInt(req.body.category_id) : null;
    let imageUpdate = '';
    let params = [req.body.name, parseFloat(req.body.price) || 0, catId];
    if (req.file) {
      imageUpdate = ', image = ?';
      params.push(`/uploads/${req.file.filename}`);
    }
    params.push(parseInt(req.params.id), store.id);
    await pool.execute(`UPDATE ingredients SET name = ?, price = ?, category_id = ?${imageUpdate} WHERE id = ? AND store_id = ?`, params);
    emitProductUpdate(store.id, 'ingredient_updated', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { console.error('Error updating ingredient:', error); res.status(500).json({ error: error.message }); }
});

app.delete('/api/public/:code/extras/:id', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const decoded = jwt.verify(req.body.token, process.env.JWT_SECRET || 'your-secret-key');
    if (store.user_id !== decoded.id) return res.status(403).json({ error: 'No autorizado' });
    await pool.execute('DELETE FROM extras WHERE id = ? AND store_id = ?', [parseInt(req.params.id), store.id]);
    emitProductUpdate(store.id, 'extra_deleted', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.delete('/api/public/:code/ingredients/:id', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const decoded = jwt.verify(req.body.token, process.env.JWT_SECRET || 'your-secret-key');
    if (store.user_id !== decoded.id) return res.status(403).json({ error: 'No autorizado' });
    await pool.execute('DELETE FROM ingredients WHERE id = ? AND store_id = ?', [parseInt(req.params.id), store.id]);
    emitProductUpdate(store.id, 'ingredient_deleted', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Store custom styles (premium)
app.get('/api/public/:code/prep-times', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const [rows] = await pool.execute(`
      SELECT oi.product_id,
             ROUND(AVG(TIMESTAMPDIFF(MINUTE, o.created_at, o.completed_at))) AS avg_minutes,
             COUNT(*) AS total_orders
      FROM order_items oi
      JOIN orders o ON oi.order_id = o.id
      WHERE o.store_id = ?
        AND o.status = 'completed'
        AND o.completed_at IS NOT NULL
        AND o.created_at IS NOT NULL
        AND TIMESTAMPDIFF(MINUTE, o.created_at, o.completed_at) > 0
        AND TIMESTAMPDIFF(MINUTE, o.created_at, o.completed_at) < 180
      GROUP BY oi.product_id
      HAVING total_orders >= 2
    `, [store.id]);
    const result = {};
    rows.forEach(r => { result[r.product_id] = Number(r.avg_minutes); });
    res.json(result);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.get('/api/public/:code/styles', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    try {
      const [rows] = await pool.execute('SELECT visual_settings, custom_css FROM store_styles WHERE store_id = ?', [store.id]);
      if (rows.length > 0) {
        return res.json({ visual_settings: rows[0].visual_settings || '{}', custom_css: rows[0].custom_css || '' });
      }
    } catch { /* table may not exist */ }
    res.json({ visual_settings: '{}', custom_css: '' });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/public/:code/styles', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    // Ensure table
    await pool.execute(`CREATE TABLE IF NOT EXISTS store_styles (
      id INT PRIMARY KEY AUTO_INCREMENT,
      store_id INT UNIQUE NOT NULL,
      visual_settings JSON,
      custom_css TEXT,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
    )`);

    const { visual_settings, custom_css } = req.body;
    await pool.execute(
      `INSERT INTO store_styles (store_id, visual_settings, custom_css) VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE visual_settings = VALUES(visual_settings), custom_css = VALUES(custom_css)`,
      [auth.store.id, JSON.stringify(visual_settings || {}), custom_css || '']
    );
    res.json({ success: true });
  } catch (error) { console.error('Error saving styles:', error); res.status(500).json({ error: error.message }); }
});

// Update the customizable "Complementos"/"Extras" labels from the totem editor
app.put('/api/public/:code/labels', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });

    // Ensure columns exist
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM stores');
      const names = cols.map(c => c.Field);
      if (!names.includes('complements_label')) await pool.execute("ALTER TABLE stores ADD COLUMN complements_label VARCHAR(100) DEFAULT NULL");
      if (!names.includes('extras_label')) await pool.execute("ALTER TABLE stores ADD COLUMN extras_label VARCHAR(100) DEFAULT NULL");
    } catch { /* ignore */ }

    const sets = [];
    const params = [];
    if (req.body.complements_label !== undefined) {
      const v = (req.body.complements_label || '').toString().trim();
      sets.push('complements_label = ?');
      params.push(v ? v.slice(0, 100) : null);
    }
    if (req.body.extras_label !== undefined) {
      const v = (req.body.extras_label || '').toString().trim();
      sets.push('extras_label = ?');
      params.push(v ? v.slice(0, 100) : null);
    }
    if (sets.length === 0) return res.json({ success: true });

    params.push(auth.store.id);
    await pool.execute(`UPDATE stores SET ${sets.join(', ')} WHERE id = ?`, params);
    res.json({ success: true });
  } catch (error) { console.error('Error saving labels:', error); res.status(500).json({ error: error.message }); }
});

// ── Secciones dinámicas (grupos de complementos) — endpoints públicos (editor del tótem) ──
app.get('/api/public/:code/complement-groups', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const groups = await getComplementGroups(store.id);
    res.json(groups);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.post('/api/public/:code/complement-groups', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    if (!req.body.name || !req.body.name.trim()) return res.status(400).json({ error: 'Nombre requerido' });
    const r = await createComplementGroup(auth.store.id, req.body);
    emitProductUpdate(auth.store.id, 'complement_group_created', { id: r.id });
    res.json(r);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/public/:code/complement-groups/reorder', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    await reorderComplementGroups(auth.store.id, req.body.ids || []);
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/public/:code/complement-groups/:id', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    await updateComplementGroup(parseInt(req.params.id), auth.store.id, req.body);
    emitProductUpdate(auth.store.id, 'complement_group_updated', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.delete('/api/public/:code/complement-groups/:id', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    await deleteComplementGroup(parseInt(req.params.id), auth.store.id);
    emitProductUpdate(auth.store.id, 'complement_group_deleted', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.post('/api/public/:code/complement-options', upload.single('image'), async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    const image = req.file ? `/uploads/${req.file.filename}` : null;
    const r = await createComplementOption(auth.store.id, parseInt(req.body.group_id), {
      name: req.body.name, price: req.body.price, image,
      stock: req.body.stock, unlimited_stock: req.body.unlimited_stock === 'true' || req.body.unlimited_stock === true
    });
    emitProductUpdate(auth.store.id, 'complement_option_created', { id: r.id });
    res.json(r);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/public/:code/complement-options/:id', upload.single('image'), async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    const data = {
      name: req.body.name, price: req.body.price,
      stock: req.body.stock, unlimited_stock: req.body.unlimited_stock === 'true' || req.body.unlimited_stock === true
    };
    if (req.file) data.image = `/uploads/${req.file.filename}`;
    await updateComplementOption(parseInt(req.params.id), auth.store.id, data);
    emitProductUpdate(auth.store.id, 'complement_option_updated', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.delete('/api/public/:code/complement-options/:id', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    await deleteComplementOption(parseInt(req.params.id), auth.store.id);
    emitProductUpdate(auth.store.id, 'complement_option_deleted', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Asignar secciones dinámicas a un producto (desde el tótem)
app.put('/api/public/:code/products/:id/complement-groups', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    await setProductComplementGroups(parseInt(req.params.id), req.body.group_ids || []);
    emitProductUpdate(auth.store.id, 'product_updated', { id: parseInt(req.params.id) });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// ── Clasificación QR settings ──
app.get('/api/store-clasificacion', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
    const [storeRows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
    if (!storeRows.length) return res.status(403).json({ error: 'No autorizado' });
    const [rows] = await pool.execute('SELECT * FROM store_clasificacion WHERE store_id = ?', [store_id]);
    res.json(rows[0] || {});
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/store-clasificacion', authenticateToken, upload.fields([
  { name: 'image1', maxCount: 1 },
  { name: 'image2', maxCount: 1 },
  { name: 'image3', maxCount: 1 },
]), async (req, res) => {
  try {
    await pool.execute(`CREATE TABLE IF NOT EXISTS store_clasificacion (
      id INT PRIMARY KEY AUTO_INCREMENT,
      store_id INT NOT NULL UNIQUE,
      google_url VARCHAR(500),
      google_qr_desc TEXT,
      ideal_qr_desc TEXT,
      promo_gift_text VARCHAR(500),
      promo_image1 VARCHAR(500),
      promo_image2 VARCHAR(500),
      promo_image3 VARCHAR(500),
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
    )`);
    // Add promo_image3 column if missing (migration)
    try { await pool.execute(`ALTER TABLE store_clasificacion ADD COLUMN promo_image3 VARCHAR(500)`); } catch {}
    const { store_id, google_url, google_qr_desc, ideal_qr_desc, promo_gift_text, image1_existing, image2_existing, image3_existing } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
    const [storeRows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
    if (!storeRows.length) return res.status(403).json({ error: 'No autorizado' });
    const image1Url = req.files?.image1?.[0] ? `/uploads/${req.files.image1[0].filename}` : (image1_existing || null);
    const image2Url = req.files?.image2?.[0] ? `/uploads/${req.files.image2[0].filename}` : (image2_existing || null);
    const image3Url = req.files?.image3?.[0] ? `/uploads/${req.files.image3[0].filename}` : (image3_existing || null);
    await pool.execute(
      `INSERT INTO store_clasificacion (store_id, google_url, google_qr_desc, ideal_qr_desc, promo_gift_text, promo_image1, promo_image2, promo_image3)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         google_url = VALUES(google_url), google_qr_desc = VALUES(google_qr_desc),
         ideal_qr_desc = VALUES(ideal_qr_desc), promo_gift_text = VALUES(promo_gift_text),
         promo_image1 = VALUES(promo_image1), promo_image2 = VALUES(promo_image2), promo_image3 = VALUES(promo_image3)`,
      [store_id, google_url || '', google_qr_desc || '', ideal_qr_desc || '', promo_gift_text || '', image1Url, image2Url, image3Url]
    );
    res.json({ success: true, promo_image1: image1Url, promo_image2: image2Url, promo_image3: image3Url });
  } catch (e) { console.error('Error saving clasificacion:', e); res.status(500).json({ error: e.message }); }
});

// Update product stock from editor
app.put('/api/public/:code/products/:id/stock', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const decoded = jwt.verify(req.body.token, process.env.JWT_SECRET || 'your-secret-key');
    if (store.user_id !== decoded.id) return res.status(403).json({ error: 'No autorizado' });
    const productId = parseInt(req.params.id);
    const { stock, unlimited_stock } = req.body;
    await pool.execute(
      'INSERT INTO inventory (product_id, stock, unlimited_stock) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE stock = ?, unlimited_stock = ?',
      [productId, parseInt(stock) || 0, unlimited_stock ? 1 : 0, parseInt(stock) || 0, unlimited_stock ? 1 : 0]
    );
    emitProductUpdate(store.id, 'inventory_updated', { product_id: productId, stock: parseInt(stock) || 0, unlimited_stock: !!unlimited_stock });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Helper: verify PIN or admin token for public store routes
async function verifyStoreAccess(code, body) {
  const store = await getStoreByCode(code.toUpperCase());
  if (!store) return { error: 'Tienda no encontrada', status: 404 };

  // Try admin token first
  if (body.token) {
    try {
      const decoded = jwt.verify(body.token, process.env.JWT_SECRET || 'your-secret-key');
      if (decoded.id === store.user_id) return { store, authorized: true };
    } catch {}
  }

  // Try PIN
  if (body.pin) {
    const valid = await verifyStoreEditPin(store.id, body.pin);
    if (valid) return { store, authorized: true };
  }

  return { error: 'No autorizado', status: 403 };
}

// Global restart all totems for a store
app.post('/api/public/:code/restart-all', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    const store = auth.store;

    // Mark all devices for this store as pending restart
    try {
      await pool.execute('SHOW COLUMNS FROM store_devices LIKE ?', ['pending_restart']);
    } catch {
      try { await pool.execute('ALTER TABLE store_devices ADD COLUMN pending_restart BOOLEAN DEFAULT FALSE'); } catch {}
    }
    await pool.execute('UPDATE store_devices SET pending_restart = TRUE WHERE store_id = ?', [store.id]);

    // Emit to store room and also broadcast globally so all connected clients are notified
    io.to(`store_${store.id}`).emit('totem_restart', { store_id: store.id });
    io.emit('totem_restart', { store_id: store.id });

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Public product management with PIN or admin token
app.post('/api/public/:code/products', upload.single('image'), async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    if (!req.body.name || !req.body.price) return res.status(400).json({ error: 'Nombre y precio requeridos' });

    const imageUrl = req.file ? `/uploads/${req.file.filename}` : (req.body.image_url || null);
    const product = await createProduct(auth.store.id, {
      name: req.body.name, description: req.body.description || '',
      barcode: req.body.barcode || null,
      price: parseFloat(req.body.price) || 0, category_id: req.body.category_id || null, image: imageUrl,
      has_extras: req.body.has_extras === 'true' || req.body.has_extras === true,
      has_ingredients: req.body.has_ingredients === 'true' || req.body.has_ingredients === true,
      max_extras: parseInt(req.body.max_extras) || 0,
      max_ingredients: parseInt(req.body.max_ingredients) || 0
    });

    await pool.execute(
      'INSERT INTO inventory (product_id, stock, unlimited_stock) VALUES (?, 0, TRUE) ON DUPLICATE KEY UPDATE unlimited_stock = TRUE',
      [product.id]
    );

    emitProductUpdate(auth.store.id, 'product_created', product);
    res.json(product);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/public/:code/products/:id', upload.single('image'), async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    if (!req.body.name) return res.status(400).json({ error: 'Nombre requerido' });

    let imageUrl;
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    } else if (req.body.image_url) {
      imageUrl = req.body.image_url;
    } else if (req.body.keep_image === 'true') {
      const existing = await getProductById(req.params.id);
      imageUrl = existing?.image || null;
    } else {
      imageUrl = null;
    }

    const product = await updateProduct(parseInt(req.params.id), auth.store.id, {
      name: req.body.name, description: req.body.description || '',
      barcode: req.body.barcode || null,
      price: parseFloat(req.body.price) || 0, category_id: req.body.category_id || null, image: imageUrl,
      has_extras: req.body.has_extras === 'true' || req.body.has_extras === true,
      has_ingredients: req.body.has_ingredients === 'true' || req.body.has_ingredients === true,
      max_extras: parseInt(req.body.max_extras) || 0,
      max_ingredients: parseInt(req.body.max_ingredients) || 0
    });
    emitProductUpdate(auth.store.id, 'product_updated', product);
    res.json(product);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.delete('/api/public/:code/products/:id', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    await deleteProduct(parseInt(req.params.id), auth.store.id);
    emitProductUpdate(auth.store.id, 'product_deleted', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Public category management with PIN or admin token
app.post('/api/public/:code/categories', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    if (!req.body.name) return res.status(400).json({ error: 'Nombre es requerido' });
    const category = await createCategory(auth.store.id, { name: req.body.name, description: req.body.description || '' });
    emitProductUpdate(auth.store.id, 'category_created', category);
    res.json(category);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/public/:code/categories/:id', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    if (!req.body.name) return res.status(400).json({ error: 'Nombre es requerido' });
    const category = await updateCategory(parseInt(req.params.id), auth.store.id, { name: req.body.name, description: req.body.description || '' });
    emitProductUpdate(auth.store.id, 'category_updated', category);
    res.json(category);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Sync product complements (ingredients + extras)
app.put('/api/public/:code/products/:id/complements', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    const productId = parseInt(req.params.id);
    const { ingredient_ids = [], extra_ids = [], default_ingredient_ids = [] } = req.body;
    const defaultSet = new Set((default_ingredient_ids || []).map(id => parseInt(id)));

    // Mark that this product has explicit complement configuration
    await pool.execute('UPDATE products SET complements_configured = TRUE WHERE id = ?', [productId]);

    // Sync ingredients
    await pool.execute('DELETE FROM product_ingredients WHERE product_id = ?', [productId]);
    for (const ingId of ingredient_ids) {
      const iid = parseInt(ingId);
      await pool.execute('INSERT INTO product_ingredients (product_id, ingredient_id, included_by_default) VALUES (?, ?, ?)', [productId, iid, defaultSet.has(iid)]);
    }

    // Sync extras
    await pool.execute('DELETE FROM product_extras WHERE product_id = ?', [productId]);
    for (const extId of extra_ids) {
      await pool.execute('INSERT INTO product_extras (product_id, extra_id) VALUES (?, ?)', [productId, parseInt(extId)]);
    }

    res.json({ success: true });
  } catch (error) { console.error('Error syncing complements:', error); res.status(500).json({ error: error.message }); }
});

// Activar / desactivar "lista única" (complementos privados de este producto)
app.put('/api/public/:code/products/:id/complements-private', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    const result = await setProductComplementsPrivate(parseInt(req.params.id), auth.store.id, !!req.body.private);
    emitProductUpdate(auth.store.id, 'product_updated', { id: parseInt(req.params.id) });
    res.json(result);
  } catch (error) { console.error('Error lista única:', error); res.status(500).json({ error: error.message }); }
});

// Get product complement associations
app.get('/api/public/:code/products/:id/complements', async (req, res) => {
  try {
    const productId = parseInt(req.params.id);
    const [prodRows] = await pool.execute(
      'SELECT store_id, complements_configured FROM products WHERE id = ?', [productId]
    );
    if (prodRows.length === 0) return res.json({ ingredient_ids: [], extra_ids: [] });
    const { store_id, complements_configured } = prodRows[0];

    if (complements_configured) {
      const [ings] = await pool.execute('SELECT ingredient_id, included_by_default FROM product_ingredients WHERE product_id = ?', [productId]);
      const [exts] = await pool.execute('SELECT extra_id FROM product_extras WHERE product_id = ?', [productId]);
      return res.json({
        ingredient_ids: ings.map(r => r.ingredient_id),
        default_ingredient_ids: ings.filter(r => r.included_by_default).map(r => r.ingredient_id),
        extra_ids: exts.map(r => r.extra_id)
      });
    }

    // Not yet configured — return only shared (non-private) ingredients/extras so editor shows all selected
    const [ings] = await pool.execute('SELECT id FROM ingredients WHERE store_id = ? AND (owner_product_id IS NULL)', [store_id]);
    const [exts] = await pool.execute('SELECT id FROM extras WHERE store_id = ? AND (owner_product_id IS NULL)', [store_id]);
    res.json({ ingredient_ids: ings.map(r => r.id), extra_ids: exts.map(r => r.id) });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.delete('/api/public/:code/categories/:id', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    await deleteCategory(parseInt(req.params.id), auth.store.id);
    emitProductUpdate(auth.store.id, 'category_deleted', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.get('/api/plans', async (req, res) => {
  try {
    const plans = await getAllPlans();
    res.json(plans);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/my-plan', authenticateToken, async (req, res) => {
  try {
    const plan = await getUserPlan(req.user.id);
    const storeInfo = await canUserCreateStore(req.user.id);
    res.json({ 
      plan,
      ...storeInfo
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/can-create-store', authenticateToken, async (req, res) => {
  try {
    const canCreate = await canUserCreateStore(req.user.id);
    res.json(canCreate);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/subscribe-plan', authenticateToken, async (req, res) => {
  try {
    const { planId, billingCycle } = req.body;
    if (!planId) {
      return res.status(400).json({ error: 'Plan es requerido' });
    }
    const result = await assignPlanToUser(req.user.id, planId, billingCycle || 'monthly');
    res.json({ success: true, message: `Te has suscrito al plan ${result.plan}`, plan: result.plan });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/create-subscription-preference', authenticateToken, async (req, res) => {
  try {
    const { planId, billingCycle } = req.body;
    
    if (!planId) {
      return res.status(400).json({ error: 'Plan es requerido' });
    }
    
    const plan = await getPlanById(planId);
    if (!plan) {
      return res.status(404).json({ error: 'Plan no encontrado' });
    }
    
    if (plan.price_monthly === 0 && plan.price_yearly === 0) {
      const result = await assignPlanToUser(req.user.id, planId, billingCycle || 'monthly');
      return res.json({ 
        success: true, 
        message: `Te has suscrito al plan ${result.plan}`,
        plan: result.plan,
        isFree: true 
      });
    }
    
    const price = billingCycle === 'yearly' ? plan.price_yearly : plan.price_monthly;
    const user = await getUserById(req.user.id);
    
    console.log('=== Creating MercadoPago Preference ===');
    console.log('User:', user.email);
    console.log('Plan:', plan.name, '- Price:', price, 'USD');
    console.log('Billing Cycle:', billingCycle);
    
    const clientUrl = process.env.CLIENT_URL || 'http://localhost:5173';
    
    const preference = {
      items: [
        {
          id: `plan-${plan.id}-${billingCycle}`,
          title: `Suscripción ${plan.name} - ${billingCycle === 'yearly' ? 'Anual' : 'Mensual'}`,
          description: `Acceso al plan ${plan.name} - ${plan.description}`,
          quantity: 1,
          currency_id: 'USD',
          unit_price: Number(price)
        }
      ],
      payer: {
        email: user.email,
        name: user.name || user.username
      },
      external_reference: `subscription-${req.user.id}-${planId}-${billingCycle}-${Date.now()}`,
      notification_url: `${process.env.BASE_URL || 'http://localhost:3001'}/api/mercadopago-webhook`,
      back_urls: {
        success: `${clientUrl}/admin/plans?payment=success`,
        failure: `${clientUrl}/admin/plans?payment=failure`,
        pending: `${clientUrl}/admin/plans?payment=pending`
      }
    };
    
    console.log('Calling MercadoPago API...');
    console.log('Preference:', JSON.stringify(preference, null, 2));
    
    const preferenceClient = new Preference(mpClient);
    const response = await preferenceClient.create({ body: preference });
    
    console.log('MercadoPago Response Success:', !!response.id);
    console.log('Init Point:', response.init_point);
    
    const initPoint = response.init_point;
    
    if (!initPoint) {
      console.error('No se получил init_point en la respuesta:', response);
      return res.status(500).json({ 
        error: 'Error al crear el enlace de pago. La respuesta de MercadoPago no contiene init_point.',
        details: response,
        hint: 'Verifica que tu cuenta de MercadoPago esté activa y tengas permisos para cobrar.'
      });
    }
    
    res.json({
      success: true,
      init_point: initPoint,
      preference_id: response.id
    });
    
  } catch (error) {
    console.error('=== MercadoPago Error ===');
    console.error('Error Message:', error.message);
    console.error('Error Status:', error.status);
    console.error('Error Cause:', error.cause);
    console.error('Error Response:', error.response?.data);
    
    let errorMessage = 'Error al crear la preferencia de pago';
    let errorHint = '';
    
    if (error.message?.includes('401') || error.message?.includes('invalid_token')) {
      errorMessage = 'Token de MercadoPago inválido o expirado.';
      errorHint = 'Ve a https://dashboard.mercadopago.com/apps y regenera tus tokens.';
    } else if (error.message?.includes('forbidden') || error.message?.includes('403')) {
      errorMessage = 'Tu cuenta de MercadoPago no tiene permisos para esta operación.';
      errorHint = 'Verifica que tu cuenta esté verificada y activa.';
    } else if (error.response?.data?.message) {
      errorMessage = error.response.data.message;
      if (error.response.data.cause) {
        errorHint = JSON.stringify(error.response.data.cause);
      }
    }
    
    res.status(500).json({ error: errorMessage, hint: errorHint, details: error.message });
  }
});

app.post('/api/mercadopago-webhook', async (req, res) => {
  try {
    const { type, data } = req.body;
    
    if (type === 'payment') {
      const paymentId = data.id;
      
      const paymentClient = new Payment(mpClient);
      const payment = await paymentClient.get({ id: paymentId });
      
      if (payment.status === 'approved') {
        const externalRef = payment.external_reference;
        if (externalRef && externalRef.startsWith('subscription-')) {
          const parts = externalRef.split('-');
          const userId = parseInt(parts[1]);
          const planId = parseInt(parts[2]);
          const billingCycle = parts[3];

          await assignPlanToUser(userId, planId, billingCycle);
          console.log(`Suscripción activada para usuario ${userId} - Plan ${planId}`);

          // Notificar a todos los superadmins por email
          try {
            const [user, stores, superadmins, planInfo] = await Promise.all([
              getUserById(userId),
              getStores(userId),
              pool.execute('SELECT email FROM superadmin').then(([r]) => r),
              pool.execute('SELECT name FROM plans WHERE id = ?', [planId]).then(([r]) => r[0])
            ]);

            const storeName = stores.length > 0
              ? stores.map(s => s.name).join(', ')
              : '(sin tienda registrada)';

            const subject = `🎉 Nueva suscripción Premium — ${user?.username || `Usuario #${userId}`}`;
            const html = `<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4f4f5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:32px 16px">
    <tr><td align="center">
      <table width="520" cellpadding="0" cellspacing="0" style="max-width:520px;width:100%;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08)">

        <tr>
          <td style="background:#111;padding:28px 32px">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="color:#D4AF37;font-size:24px;font-weight:800">SR</span><span style="color:#fff;font-size:24px;font-weight:800">Servi</span></td>
              <td align="right"><span style="background:#D4AF37;color:#000;font-size:11px;font-weight:700;padding:4px 12px;border-radius:20px">NUEVO PREMIUM</span></td>
            </tr></table>
          </td>
        </tr>

        <tr>
          <td style="padding:32px 32px 24px">
            <div style="font-size:32px;margin-bottom:8px">🎉</div>
            <h1 style="margin:0 0 6px;font-size:20px;font-weight:800;color:#111">Nueva suscripción activada</h1>
            <p style="margin:0;font-size:14px;color:#888">${new Date().toLocaleString('es-AR')}</p>
          </td>
        </tr>

        <tr>
          <td style="padding:0 32px 32px">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-radius:12px;overflow:hidden;border:1px solid #f0f0f0">
              <tr style="background:#fafafa">
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:12px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:0.5px;width:110px">Usuario</td>
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:14px;font-weight:700;color:#111">${user?.username || `#${userId}`}</td>
              </tr>
              <tr>
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:12px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:0.5px">Email</td>
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:14px;color:#444">${user?.email || '—'}</td>
              </tr>
              <tr style="background:#fafafa">
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:12px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:0.5px">Tienda(s)</td>
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:14px;color:#444">${storeName}</td>
              </tr>
              <tr>
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:12px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:0.5px">Plan</td>
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0">
                  <span style="background:#D4AF37;color:#000;font-weight:700;font-size:12px;padding:3px 12px;border-radius:20px">${planInfo?.name || `#${planId}`}</span>
                </td>
              </tr>
              <tr style="background:#fafafa">
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:12px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:0.5px">Ciclo</td>
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:14px;color:#444">${billingCycle === 'yearly' ? '🔄 Anual' : '🔄 Mensual'}</td>
              </tr>
              <tr>
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:12px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:0.5px">Monto</td>
                <td style="padding:14px 18px;border-bottom:1px solid #f0f0f0;font-size:18px;font-weight:800;color:#111">$${payment.transaction_amount} <span style="font-size:13px;font-weight:500;color:#888">${payment.currency_id || ''}</span></td>
              </tr>
              <tr style="background:#fafafa">
                <td style="padding:14px 18px;font-size:12px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:0.5px">Payment ID</td>
                <td style="padding:14px 18px;font-size:12px;color:#888;font-family:monospace">${payment.id}</td>
              </tr>
            </table>
          </td>
        </tr>

        <tr>
          <td style="background:#fafafa;border-top:1px solid #f0f0f0;padding:16px 32px;text-align:center">
            <p style="margin:0;font-size:12px;color:#bbb">SRServi · Panel de administración</p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;

            const emails = superadmins.map(s => s.email).filter(Boolean);
            await Promise.all(emails.map(to =>
              mailer.sendMail({ from: `"SRServi" <${process.env.EMAIL_USER}>`, to, subject, html })
                .catch(e => console.error(`[Subscription] Error enviando email a ${to}:`, e.message))
            ));
            console.log(`[Subscription] Notificación enviada a superadmins:`, emails);
          } catch (notifyErr) {
            console.error('[Subscription] Error al notificar superadmins:', notifyErr.message);
          }
        }
      }
    }
    
    res.status(200).json({ received: true });
  } catch (error) {
    console.error('Error en webhook de MercadoPago:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/verify-payment', authenticateToken, async (req, res) => {
  try {
    const { payment_id } = req.body;
    
    if (!payment_id) {
      const userPlan = await getUserPlan(req.user.id);
      res.json({
        success: true,
        activated: userPlan && userPlan.plan_name && userPlan.plan_name !== 'Gratis'
      });
      return;
    }
    
    const paymentClient = new Payment(mpClient);
    const payment = await paymentClient.get({ id: payment_id });
    
    if (payment.status === 'approved') {
      const userPlan = await getUserPlan(req.user.id);
      res.json({
        success: true,
        activated: userPlan && userPlan.plan_name && userPlan.plan_name !== 'Gratis',
        plan: userPlan?.plan_name
      });
    } else {
      res.json({
        success: false,
        activated: false,
        status: payment.status
      });
    }
  } catch (error) {
    const userPlan = await getUserPlan(req.user.id);
    res.json({
      success: true,
      activated: userPlan && userPlan.plan_name && userPlan.plan_name !== 'Gratis'
    });
  }
});

app.get('/api/get-mp-public-key', async (req, res) => {
  try {
    res.json({
      public_key: process.env.MP_PUBLIC_KEY
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/verify-mp-credentials', authenticateToken, async (req, res) => {
  try {
    const accessToken = process.env.MP_ACCESS_TOKEN;
    const environment = process.env.MP_ENVIRONMENT || 'sandbox';
    
    if (!accessToken) {
      return res.json({
        valid: false,
        error: 'Token de acceso no configurado'
      });
    }
    
    const response = await fetch('https://api.mercadopago.com/users/me', {
      headers: {
        'Authorization': `Bearer ${accessToken}`
      }
    });
    
    if (response.ok) {
      const userData = await response.json();
      return res.json({
        valid: true,
        environment,
        user_id: userData.id,
        nickname: userData.nickname,
        email: userData.email,
        site_id: userData.site_id
      });
    } else {
      const errorData = await response.json();
      return res.json({
        valid: false,
        error: errorData.message || 'Token inválido',
        status: response.status,
        environment
      });
    }
  } catch (error) {
    res.json({
      valid: false,
      error: error.message
    });
  }
});

// ==================== QR MercadoPago por tienda ====================

// Guardar/obtener token MP de la tienda
app.get('/api/stores/:id/mp-config', authenticateToken, async (req, res) => {
  try {
    const isOwner = await verifyStoreOwnership(parseInt(req.params.id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso' });
    const [rows] = await pool.execute('SELECT mp_access_token FROM stores WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Tienda no encontrada' });
    const hasToken = !!rows[0].mp_access_token;
    res.json({ configured: hasToken, token_preview: hasToken ? '****' + rows[0].mp_access_token.slice(-6) : null });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/stores/:id/mp-config', authenticateToken, async (req, res) => {
  try {
    const isOwner = await verifyStoreOwnership(parseInt(req.params.id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso' });
    const { mp_access_token } = req.body;

    if (mp_access_token) {
      // Verificar que el token sea válido
      const verifyRes = await fetch('https://api.mercadopago.com/users/me', {
        headers: { 'Authorization': `Bearer ${mp_access_token}` }
      });
      if (!verifyRes.ok) return res.status(400).json({ error: 'Token de MercadoPago inválido' });
    }

    await pool.execute('UPDATE stores SET mp_access_token = ? WHERE id = ?', [mp_access_token || null, req.params.id]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Crear preferencia QR para una orden
app.post('/api/store/:code/qr-payment', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    if (!store.mp_access_token) return res.status(400).json({ error: 'MercadoPago no configurado para esta tienda' });

    const { order_id, amount, description } = req.body;
    if (!amount) return res.status(400).json({ error: 'Monto requerido' });

    const externalRef = `qr-${store.code}-${order_id || Date.now()}`;

    const prefResponse = await fetch('https://api.mercadopago.com/checkout/preferences', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${store.mp_access_token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        items: [{
          title: description || `Pedido ${store.name}`,
          quantity: 1,
          currency_id: store.currency_code || 'CLP',
          unit_price: Number(amount)
        }],
        external_reference: externalRef,
        notification_url: `${process.env.SERVER_URL || 'https://srservi2.srautomatic.com'}/api/store/${store.code}/qr-webhook`
      })
    });

    if (!prefResponse.ok) {
      const err = await prefResponse.json();
      return res.status(400).json({ error: 'Error creando preferencia', details: err });
    }

    const pref = await prefResponse.json();

    // Actualizar la orden con la referencia si existe
    if (order_id) {
      await pool.execute('UPDATE orders SET external_reference = ?, mp_order_id = ? WHERE id = ?', [externalRef, pref.id, order_id]);
    }

    res.json({
      preference_id: pref.id,
      init_point: pref.init_point,
      sandbox_init_point: pref.sandbox_init_point,
      qr_data: pref.init_point,
      external_reference: externalRef
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Webhook para confirmar pago QR
app.post('/api/store/:code/qr-webhook', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code);
    if (!store || !store.mp_access_token) return res.status(200).send('OK');

    const { type, data } = req.body;
    if (type === 'payment') {
      const paymentRes = await fetch(`https://api.mercadopago.com/v1/payments/${data.id}`, {
        headers: { 'Authorization': `Bearer ${store.mp_access_token}` }
      });
      if (paymentRes.ok) {
        const payment = await paymentRes.json();
        if (payment.status === 'approved' && payment.external_reference) {
          const [orders] = await pool.execute(
            'SELECT id FROM orders WHERE external_reference = ? AND store_id = ?',
            [payment.external_reference, store.id]
          );
          if (orders.length > 0) {
            await pool.execute(
              "UPDATE orders SET payment_process = 1, cash_approved = TRUE, status = 'preparing', reference_id = ?, sequence_id = ? WHERE id = ?",
              [payment.id?.toString(), payment.external_reference, orders[0].id]
            );
            const socketId = userSockets.get(store.id);
            if (socketId) {
              io.to(socketId).emit('qr_payment_completed', { order_id: orders[0].id, payment_id: payment.id });
            }
          }
        }
      }
    }
    res.status(200).send('OK');
  } catch (error) {
    console.error('QR Webhook error:', error);
    res.status(200).send('OK');
  }
});

app.get('/api/analytics/summary', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    const dateRange = req.query.range || 'week';
    if (!storeId) {
      return res.status(400).json({ error: 'Store ID es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const analytics = await getAnalytics(parseInt(storeId), dateRange);
    res.json(analytics);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics/sales-by-day', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    const dateRange = req.query.range || 'week';
    if (!storeId) {
      return res.status(400).json({ error: 'Store ID es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const sales = await getSalesByDay(parseInt(storeId), dateRange);
    res.json(sales);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics/sales-by-dow', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    const dateRange = req.query.range || 'month';
    if (!storeId) return res.status(400).json({ error: 'Store ID es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });

    const rows = await leonGetSalesByDayOfWeek(parseInt(storeId), dateRange);
    // MySQL DAYOFWEEK: 1=Sun,2=Mon,...,7=Sat → display Mon(2)..Sun(1)
    const DOW_ORDER = [2, 3, 4, 5, 6, 7, 1];
    const DOW_NAMES = ['', 'Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    const map = {};
    rows.forEach(r => { map[r.day_num] = r; });
    const result = DOW_ORDER.map(dn => ({
      day_num: dn,
      day_name: DOW_NAMES[dn],
      orders: parseInt(map[dn]?.orders || 0),
      revenue: parseFloat(map[dn]?.revenue || 0),
    }));
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics/top-products', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    const dateRange = req.query.range || 'week';
    const limit = parseInt(req.query.limit) || 10;
    if (!storeId) {
      return res.status(400).json({ error: 'Store ID es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const products = await getTopProducts(parseInt(storeId), limit, dateRange);
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics/orders-by-hour', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    const dateRange = req.query.range || 'week';
    if (!storeId) {
      return res.status(400).json({ error: 'Store ID es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const orders = await getOrdersByHour(parseInt(storeId), dateRange);
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics/recent-orders', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    const limit = parseInt(req.query.limit) || 10;
    if (!storeId) {
      return res.status(400).json({ error: 'Store ID es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const orders = await getRecentOrders(parseInt(storeId), limit);
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics/ventas-dia', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    const date = req.query.date || new Date().toISOString().split('T')[0];
    if (!storeId) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const data = await getDailySales(parseInt(storeId), date);
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== LEÓN IA ====================

const LEON_GREETINGS = [
  '¡Hola! Soy **León IA** 🦁, tu asistente de negocios.\n\nHablame de forma natural y te ayudo. Por ejemplo:\n\n• "¿Qué días vendo más?" 📅\n• "¿Qué productos se venden más?" 📈\n• "¿Qué hago con lo que no se mueve?" 📉\n• "¿Cuánto hice este mes?" 💰\n• "¿A qué hora tengo más clientes?" ⏰\n• "¿Tengo algo agotado?" 📦\n• "Dame recomendaciones" 🎯',
  '¡Buenas! Soy **León IA** 🦁. Listo para analizar tu negocio.\n\nPregúntame lo que necesites — entiendo lenguaje natural. Por ejemplo: "¿qué días vendo más?", "¿cómo van las ventas?", "¿qué no se está vendiendo?"',
  'Hola de nuevo 👋. Soy **León IA**, tu asesor de ventas inteligente.\n\nDime qué quieres saber y te respondo al instante. Puedo analizar días, horarios, productos, ingresos, stock y más.',
];

function leonDetectIntent(text, history = []) {
  const t = text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const has = (...words) => words.some(w => t.includes(w));

  // Detectar follow-ups con contexto del historial
  const lastLeonMsg = [...history].reverse().find(m => m.role === 'leon');
  const lastIntent = lastLeonMsg?.intent || null;

  const words = t.trim().split(/\s+/);
  const isShort = words.length <= 6;

  // Plan de acción: detectar afirmativa después de worst_products, o solicitud explícita
  const isAffirmative = isShort && has('si', 'dale', 'claro', 'adelante', 'bueno', 'ok dale', 'va', 'hazlo', 'hacelo');
  if (has('plan de accion', 'plan detallado', 'plan de mejora', 'estrategia detallada', 'como lo mejoro paso a paso', 'que pasos sigo'))
    return 'action_plan';
  if (isAffirmative && (lastIntent === 'worst_products' || lastIntent === 'action_plan'))
    return 'action_plan';

  // Follow-up de contexto: frases explícitas o muy cortas con marcadores
  const hasFollowUpMarker = has('y ese mes', 'y este mes', 'y ayer', 'dime mas', 'mas detalles', 'ampliame', 'profundiza');
  const isVagueShort = isShort && has('y eso', 'y esos', 'que mas', 'algo mas');
  if ((hasFollowUpMarker || isVagueShort) && lastIntent && lastIntent !== 'greeting' && lastIntent !== 'unknown' && lastIntent !== 'action_plan')
    return lastIntent;

  if (has('hola', 'buenos dias', 'buenas tardes', 'buenas noches', 'como estas', 'quien eres', 'que eres', 'que puedes hacer', 'que sabes hacer', 'ayuda', 'para que sirves', 'que haces', 'presentate'))
    return 'greeting';

  // Extras e ingredientes — van ANTES que top_products para evitar colisión con "más vendidos"
  if (has('extra') && has('mas vendido', 'mas pedido', 'mas solicitado', 'popular', 'top', 'mas elegido', 'mas piden', 'eligen', 'solicitado', 'mas elegido', 'mas comprado'))
    return 'extras_analysis';
  if (has('extras mas pedidos', 'extras mas solicitados', 'que extras piden', 'extras populares', 'extra mas elegido', 'que extra eligen', 'extras top', 'extras mas vendidos', 'extras favoritos', 'que extra piden'))
    return 'extras_analysis';
  if ((has('complemento') || has('ingrediente')) && has('mas vendido', 'mas pedido', 'mas solicitado', 'popular', 'top', 'mas elegido', 'mas piden', 'eligen', 'solicitado', 'mas comprado'))
    return 'ingredients_analysis';
  if (has('complementos mas pedidos', 'complementos mas solicitados', 'que complementos piden', 'complementos populares', 'complemento mas elegido', 'que complemento eligen', 'ingredientes mas pedidos', 'ingredientes populares', 'complementos mas vendidos', 'ingredientes mas vendidos', 'complementos favoritos'))
    return 'ingredients_analysis';
  if (has('que extras tengo', 'lista de extras', 'mis extras', 'ver extras', 'cuales son mis extras', 'extras de mi tienda', 'extras disponibles', 'extras configurados', 'tengo extras'))
    return 'extras_catalog';
  if (has('que complementos tengo', 'lista de complementos', 'mis complementos', 'ver complementos', 'cuales son mis complementos', 'complementos de mi tienda', 'complementos disponibles', 'que ingredientes tengo', 'lista de ingredientes', 'mis ingredientes', 'complementos configurados'))
    return 'ingredients_catalog';

  if (has('menos vendido', 'poco vendido', 'no se vende', 'bajo rendimiento', 'peor', 'que hago con', 'descontinuar', 'eliminar producto', 'mal vendido', 'baja rotacion', 'no vendo', 'no se mueve', 'que falla', 'que no funciona', 'los peores', 'minimo vendido', 'casi no vendo'))
    return 'worst_products';
  if (has('mas vendido', 'top producto', 'mejor vendido', 'estrella', 'popular', 'cuales vendo mas', 'productos top', 'mas exitoso', 'que se vende mas', 'lider', 'numero uno', 'cuales son los mas', 'que producto vendo mas', 'que productos salen mas', 'que se pide mas', 'los que mas', 'favorito de los clientes', 'el mas pedido', 'ranking de producto'))
    return 'top_products';
  if (has('ingreso', 'ganancia', 'cuanto vendi', 'cuanto gane', 'dinero', 'venta total', 'facturacion', 'revenue', 'recaude', 'cuanto saque', 'cuanto hice', 'cuanto llevo', 'plata', 'cuanto genere', 'total de ventas', 'que tal las ventas', 'numeros de venta', 'cuanta plata', 'cuanto cobre'))
    return 'revenue';

  // Días de la semana — va ANTES que peak_hours para no confundir "día" con "hora"
  if (has('que dia vendo mas', 'que dias vendo mas', 'mejor dia de la semana', 'mejores dias', 'dias mas activos', 'dia mas activo', 'dias con mas ventas', 'dias de mayor venta', 'que dia es el mejor', 'cuales son los mejores dias', 'en que dia vendo', 'dia de la semana', 'dias de la semana', 'por dia de la semana', 'rendimiento por dia', 'ventas por dia de semana', 'que dia hay mas gente', 'dia mas concurrido', 'dias top', 'cuando vendo mas los dias'))
    return 'best_days';
  if (has('dia', 'dias') && has('mejor', 'mas venta', 'mas activo', 'mas pedido', 'mas movimiento', 'mayor', 'top'))
    return 'best_days';
  // "que dia se vende mas", "cual dia se vende mas", "que dias venden mas", etc.
  if (has('dia', 'dias') && has('vend') && has('mas'))
    return 'best_days';

  if (has('hora', 'pico', 'momento del dia', 'horario', 'mejor hora', 'hora punta', 'a que hora', 'horario pico', 'rush', 'cuando vendo mas en el dia', 'horas de mayor'))
    return 'peak_hours';
  // "cuando vendo" sin contexto de día → peak_hours
  if (has('cuando vendo') && !has('dia', 'dias', 'semana', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo'))
    return 'peak_hours';

  if (has('stock', 'inventario', 'agotado', 'por acabarse', 'sin stock', 'quedan pocos', 'me queda', 'sin existencia', 'que reponer', 'que comprar', 'necesito reponer', 'queda poco', 'critico de stock', 'falta stock'))
    return 'stock_alert';
  if (has('categoria', 'categorias', 'que categoria', 'por categoria', 'seccion', 'secciones', 'por seccion', 'rubros', 'rubro'))
    return 'category_analysis';
  if (has('resumen', 'como voy', 'como estoy', 'estado', 'balance', 'panorama', 'reporte', 'resumen general', 'dashboard', 'pantallazo', 'overview', 'dame un resumen', 'informe', 'como van las cosas', 'como va todo'))
    return 'summary';
  if (has('recomienda', 'consejo', 'sugerencia', 'que puedo hacer', 'estrategia', 'que hago', 'como mejoro', 'ideas', 'ayudame a mejorar', 'que deberia', 'que me sugieres', 'tips', 'mejoras', 'puntos de mejora', 'que esta fallando', 'que esta mal', 'como optimizo', 'dame consejos'))
    return 'recommendations';
  if (has('pedido', 'orden', 'compra', 'cuantos pedidos', 'cuantas ordenes', 'ordenes del dia', 'pedidos de hoy', 'cuantas ventas', 'cuantos pedidos hubo'))
    return 'orders_summary';
  // Análisis de producto específico — debe ir antes del fallback
  if (has('analiza ', 'analiza el ', 'analiza la ', 'analiza los ', 'analiza las ',
          'como va ', 'como esta ', 'como va el ', 'como esta el ', 'como va la ', 'como esta la ',
          'dime sobre ', 'info de ', 'informacion de ', 'rendimiento de ',
          'cuanto vende ', 'cuanto se vende ', 'ventas de ', 'datos de ',
          'que tal el ', 'que tal la ', 'que tal los ', 'que pasa con ', 'profundiza en '))
    return 'product_analysis';
  // Si el contexto anterior pedía analizar un producto específico
  if (lastIntent === 'action_plan' && words.length >= 2 && !has('no', 'nada', 'no gracias'))
    return 'product_analysis';

  if (has('gracias', 'ok', 'perfecto', 'genial', 'excelente', 'entendido', 'listo'))
    return 'thanks';
  return 'unknown';
}

function leonExtractProductName(text) {
  const t = text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const prefixes = [
    'analiza el producto ', 'analiza la producto ', 'analiza los productos ',
    'analiza el ', 'analiza la ', 'analiza los ', 'analiza las ', 'analiza ',
    'como va el producto ', 'como va la ', 'como va el ', 'como va ',
    'como esta el ', 'como esta la ', 'como esta ',
    'dime sobre el ', 'dime sobre la ', 'dime sobre ',
    'informacion de ', 'info de ', 'rendimiento de ',
    'cuanto vende el ', 'cuanto vende la ', 'cuanto vende ',
    'cuanto se vende el ', 'cuanto se vende la ', 'cuanto se vende ',
    'ventas de el ', 'ventas de la ', 'ventas de ',
    'datos de el ', 'datos de la ', 'datos de ',
    'que tal el ', 'que tal la ', 'que tal los ', 'que tal ',
    'que pasa con el ', 'que pasa con la ', 'que pasa con ',
    'profundiza en el ', 'profundiza en la ', 'profundiza en ',
  ];
  for (const p of prefixes) {
    if (t.startsWith(p)) return t.slice(p.length).trim();
  }
  // Quitar artículos sueltos al inicio
  return t.replace(/^(el|la|los|las|un|una)\s+/, '').trim();
}

function leonDetectRange(text) {
  const t = text.toLowerCase();
  if (t.includes('hoy') || t.includes('dia') || t.includes('today')) return 'today';
  if (t.includes('mes') || t.includes('month') || t.includes('30 dias')) return 'month';
  if (t.includes('año') || t.includes('year') || t.includes('365')) return 'year';
  return 'week';
}

function leonRangeLabel(range) {
  return { today: 'hoy', week: 'esta semana', month: 'este mes', year: 'este año' }[range] || 'esta semana';
}

async function leonGetAllProducts(storeId) {
  // inventory no tiene store_id — se une sólo por product_id
  const [rows] = await pool.execute(
    `SELECT p.id, p.name, p.price,
            COALESCE(i.stock, 0) AS stock,
            COALESCE(i.unlimited_stock, 0) AS unlimited_stock
     FROM products p
     LEFT JOIN inventory i ON p.id = i.product_id
     WHERE p.store_id = ?
     ORDER BY p.sort_order ASC`,
    [storeId]
  );
  return rows;
}

async function leonGetWorstProducts(storeId, range) {
  let interval = '7 DAY';
  if (range === 'today') interval = '1 DAY';
  else if (range === 'month') interval = '30 DAY';
  else if (range === 'year') interval = '365 DAY';

  // Subconsulta para ventas del periodo — evita ambigüedad de columnas
  const [sold] = await pool.execute(
    `SELECT p.id, p.name, p.price,
            COALESCE(SUM(oi.quantity), 0) AS total_sold
     FROM products p
     LEFT JOIN order_items oi ON oi.product_id = p.id
     LEFT JOIN orders o ON oi.order_id = o.id
       AND o.store_id = ?
       AND o.status IN ('paid','processed','completed','approved')
       AND o.created_at >= DATE_SUB(NOW(), INTERVAL ${interval})
     WHERE p.store_id = ?
     GROUP BY p.id, p.name, p.price
     ORDER BY total_sold ASC
     LIMIT 8`,
    [storeId, storeId]
  );
  return sold;
}

async function leonGetTopProductsWithRevenue(storeId, range, limit = 5) {
  let interval = '7 DAY';
  if (range === 'today') interval = '1 DAY';
  else if (range === 'month') interval = '30 DAY';
  else if (range === 'year') interval = '365 DAY';

  const [rows] = await pool.execute(
    `SELECT p.id, p.name,
            SUM(oi.quantity) AS total_sold,
            SUM(oi.quantity * oi.unit_price) AS revenue
     FROM order_items oi
     JOIN orders o ON oi.order_id = o.id
     JOIN products p ON oi.product_id = p.id
     WHERE o.store_id = ?
       AND o.status IN ('paid','processed','completed','approved')
       AND o.created_at >= DATE_SUB(NOW(), INTERVAL ${interval})
     GROUP BY p.id, p.name
     ORDER BY total_sold DESC
     LIMIT ${parseInt(limit)}`,
    [storeId]
  );
  return rows;
}

async function leonGetCategoryRevenue(storeId, range) {
  let interval = '7 DAY';
  if (range === 'today') interval = '1 DAY';
  else if (range === 'month') interval = '30 DAY';
  else if (range === 'year') interval = '365 DAY';

  const [rows] = await pool.execute(
    `SELECT COALESCE(c.name,'Sin categoría') as category,
            COUNT(DISTINCT o.id) as orders,
            SUM(oi.quantity) as total_sold,
            SUM(oi.quantity*oi.unit_price) as revenue
     FROM order_items oi
     JOIN orders o ON oi.order_id=o.id
     JOIN products p ON oi.product_id=p.id
     LEFT JOIN categories c ON p.category_id=c.id
     WHERE o.store_id=? AND o.status IN ('paid','processed','completed','approved')
       AND o.created_at>=DATE_SUB(NOW(),INTERVAL ${interval})
     GROUP BY c.id, c.name
     ORDER BY revenue DESC`,
    [storeId]
  );
  return rows;
}

async function leonGetAllExtras(storeId) {
  const [rows] = await pool.execute(
    `SELECT id, name, price FROM extras WHERE store_id = ? ORDER BY sort_order ASC, name ASC`,
    [storeId]
  );
  return rows;
}

async function leonGetAllIngredients(storeId) {
  const [rows] = await pool.execute(
    `SELECT id, name, price FROM ingredients WHERE store_id = ? ORDER BY sort_order ASC, name ASC`,
    [storeId]
  );
  return rows;
}

async function leonGetTopExtras(storeId, range) {
  let interval = '7 DAY';
  if (range === 'today') interval = '1 DAY';
  else if (range === 'month') interval = '30 DAY';
  else if (range === 'year') interval = '365 DAY';

  const [items] = await pool.execute(
    `SELECT oi.selected_extras
     FROM order_items oi
     JOIN orders o ON oi.order_id = o.id
     WHERE o.store_id = ?
       AND o.status IN ('paid','processed','completed','approved')
       AND o.created_at >= DATE_SUB(NOW(), INTERVAL ${interval})
       AND oi.selected_extras IS NOT NULL AND oi.selected_extras != '[]'`,
    [storeId]
  );
  const counts = {};
  for (const row of items) {
    try {
      const arr = JSON.parse(row.selected_extras || '[]');
      for (const entry of arr) {
        const name = typeof entry === 'string' ? entry : (entry.name || '');
        if (name) counts[name] = (counts[name] || 0) + 1;
      }
    } catch {}
  }
  return Object.entries(counts)
    .map(([name, total]) => ({ name, total }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 10);
}

async function leonGetSalesByDayOfWeek(storeId, range) {
  let interval = '30 DAY';
  if (range === 'week') interval = '7 DAY';
  else if (range === 'month') interval = '30 DAY';
  else if (range === 'year') interval = '365 DAY';

  const DAY_NAMES = ['', 'Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const [rows] = await pool.execute(
    `SELECT DAYOFWEEK(o.created_at) AS day_num,
            COUNT(*) AS orders,
            SUM(o.total) AS revenue
     FROM orders o
     WHERE o.store_id = ?
       AND o.status IN ('paid','processed','completed','approved')
       AND o.created_at >= DATE_SUB(NOW(), INTERVAL ${interval})
     GROUP BY DAYOFWEEK(o.created_at)
     ORDER BY orders DESC`,
    [storeId]
  );
  return rows.map(r => ({ ...r, day_name: DAY_NAMES[r.day_num] || 'Desconocido' }));
}

async function leonGetTopIngredients(storeId, range) {
  let interval = '7 DAY';
  if (range === 'today') interval = '1 DAY';
  else if (range === 'month') interval = '30 DAY';
  else if (range === 'year') interval = '365 DAY';

  const [items] = await pool.execute(
    `SELECT oi.selected_ingredients
     FROM order_items oi
     JOIN orders o ON oi.order_id = o.id
     WHERE o.store_id = ?
       AND o.status IN ('paid','processed','completed','approved')
       AND o.created_at >= DATE_SUB(NOW(), INTERVAL ${interval})
       AND oi.selected_ingredients IS NOT NULL AND oi.selected_ingredients != '[]'`,
    [storeId]
  );
  const counts = {};
  for (const row of items) {
    try {
      const arr = JSON.parse(row.selected_ingredients || '[]');
      for (const entry of arr) {
        const name = typeof entry === 'string' ? entry : (entry.name || '');
        if (name) counts[name] = (counts[name] || 0) + 1;
      }
    } catch {}
  }
  return Object.entries(counts)
    .map(([name, total]) => ({ name, total }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 10);
}

async function leonGetProductAnalysis(storeId, productName) {
  // Buscar producto por nombre (fuzzy)
  const [prods] = await pool.execute(
    `SELECT p.id, p.name, p.price, p.description,
            COALESCE(i.stock, 0) AS stock,
            COALESCE(i.unlimited_stock, 0) AS unlimited_stock,
            c.name AS category_name
     FROM products p
     LEFT JOIN inventory i ON p.id = i.product_id
     LEFT JOIN categories c ON p.category_id = c.id
     WHERE p.store_id = ? AND LOWER(p.name) LIKE ?
     LIMIT 5`,
    [storeId, `%${productName.toLowerCase()}%`]
  );
  if (!prods.length) return null;

  const prod = prods[0];

  // Ventas por período
  const periods = { week: '7 DAY', month: '30 DAY', year: '365 DAY' };
  const salesData = {};
  for (const [key, interval] of Object.entries(periods)) {
    const [rows] = await pool.execute(
      `SELECT COALESCE(SUM(oi.quantity), 0) AS total_sold,
              COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS revenue,
              COUNT(DISTINCT o.id) AS orders
       FROM order_items oi
       JOIN orders o ON oi.order_id = o.id
       WHERE oi.product_id = ? AND o.store_id = ?
         AND o.status IN ('paid','processed','completed','approved')
         AND o.created_at >= DATE_SUB(NOW(), INTERVAL ${interval})`,
      [prod.id, storeId]
    );
    salesData[key] = rows[0];
  }

  // Ranking entre todos los productos (semana)
  const [ranking] = await pool.execute(
    `SELECT p.id, SUM(oi.quantity) AS total_sold
     FROM products p
     LEFT JOIN order_items oi ON oi.product_id = p.id
     LEFT JOIN orders o ON oi.order_id = o.id
       AND o.store_id = ? AND o.status IN ('paid','processed','completed','approved')
       AND o.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
     WHERE p.store_id = ?
     GROUP BY p.id
     ORDER BY total_sold DESC`,
    [storeId, storeId]
  );
  const rank = ranking.findIndex(r => r.id === prod.id) + 1;
  const total = ranking.length;

  // Ventas por día últimos 7 días
  const [byDay] = await pool.execute(
    `SELECT DATE(o.created_at) AS date, SUM(oi.quantity) AS qty
     FROM order_items oi
     JOIN orders o ON oi.order_id = o.id
     WHERE oi.product_id = ? AND o.store_id = ?
       AND o.status IN ('paid','processed','completed','approved')
       AND o.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
     GROUP BY DATE(o.created_at)
     ORDER BY date ASC`,
    [prod.id, storeId]
  );

  return { prod, salesData, rank, total, byDay, allMatches: prods };
}

function r(text, chart = null) { return { text, chart }; }

function leonBuildResponse(intent, range, data, storeName) {
  const rl = leonRangeLabel(range);
  const fmt = (n) => Number(n || 0).toFixed(2);
  const store = storeName ? ` de **${storeName}**` : '';

  switch (intent) {
    case 'greeting':
      return r(LEON_GREETINGS[Math.floor(Math.random() * LEON_GREETINGS.length)]);

    case 'thanks':
      return r('¡De nada! 😊 Si necesitas analizar algo más, aquí estoy. Puedes preguntarme sobre ventas, stock, ingresos o cualquier cosa de tu negocio.');

    case 'top_products': {
      const { products } = data;
      if (!products || !products.length)
        return r(`No encontré ventas registradas ${rl}. ¿Tienes pedidos completados en ese período? Intenta con un rango mayor, por ejemplo "¿cuáles son los más vendidos este mes?".`);
      const medals = ['🥇', '🥈', '🥉', '4.', '5.'];
      const list = products.map((p, i) =>
        `${medals[i] || `${i+1}.`} **${p.name}** — ${p.total_sold} unidades · $${fmt(p.revenue)}`
      ).join('\n');
      const leader = products[0];
      const chart = {
        type: 'bar',
        title: `Top productos ${rl}`,
        labels: products.map(p => p.name.length > 14 ? p.name.slice(0, 13) + '…' : p.name),
        values: products.map(p => Number(p.total_sold)),
        unit: 'uds',
        color: '#D4AF37',
      };
      return r(`Ranking de productos ${rl}${store}:\n\n${list}\n\n📈 **${leader.name}** lidera con **${leader.total_sold} unidades** vendidas. ¿Quieres saber cuáles son los que peor van?`, chart);
    }

    case 'worst_products': {
      const { worst } = data;
      if (!worst || !worst.length)
        return r(`No hay productos registrados todavía. Agrega productos desde el **Editor Tótem** para empezar a analizar.`);
      const zeroes = worst.filter(p => Number(p.total_sold) === 0);
      const low = worst.filter(p => Number(p.total_sold) > 0 && Number(p.total_sold) <= 3);
      const rest = worst.filter(p => Number(p.total_sold) > 3);
      if (!zeroes.length && !low.length && rest.length)
        return r(`Buenas noticias 🎉 — todos tus productos se están vendiendo ${rl}. El de menor rotación es **${rest[0].name}** con ${rest[0].total_sold} unidades, pero sigue activo.\n\nSi quieres mejorar aún más, dime "dame recomendaciones".`);
      let resp = `Productos con bajo rendimiento ${rl}:\n\n`;
      if (zeroes.length) {
        resp += `🔴 **Sin ninguna venta (${zeroes.length}):**\n`;
        resp += zeroes.map(p => `• ${p.name} — $${fmt(p.price)}`).join('\n');
        resp += `\n\n`;
      }
      if (low.length) {
        resp += `🟡 **Ventas muy bajas — 1 a 3 unidades (${low.length}):**\n`;
        resp += low.map(p => `• ${p.name} — ${p.total_sold} unid.`).join('\n');
        resp += `\n\n`;
      }
      resp += `¿Quieres que te dé un plan de acción detallado para mejorarlos?`;
      const chart = {
        type: 'bar',
        title: `Ventas ${rl} (menores)`,
        labels: worst.map(p => p.name.length > 14 ? p.name.slice(0, 13) + '…' : p.name),
        values: worst.map(p => Number(p.total_sold)),
        unit: 'uds',
        color: '#ef4444',
      };
      return r(resp, chart);
    }

    case 'action_plan': {
      const { worst } = data;
      const zeroes = (worst || []).filter(p => Number(p.total_sold) === 0);
      const low = (worst || []).filter(p => Number(p.total_sold) > 0 && Number(p.total_sold) <= 3);
      let resp = `Plan de acción para tus productos con bajo rendimiento:\n\n`;

      if (zeroes.length) {
        resp += `**Para los productos sin ninguna venta:**\n\n`;
        resp += `**Semana 1 — Visibilidad:**\n`;
        resp += `• Mueve estos productos al inicio del tótem\n`;
        resp += `• Agrega una foto atractiva si no tienen imagen\n`;
        resp += `• Aplica un descuento del 25% con etiqueta "Oferta"\n\n`;
        resp += `**Semana 2 — Promoción activa:**\n`;
        resp += `• Crea un combo con tu producto estrella (ej: "Lleva X + Y con descuento")\n`;
        resp += `• Si tienes vendedores, pídeles que lo sugieran al cliente\n\n`;
        resp += `**Semana 3 — Evaluación:**\n`;
        resp += `• Si sigue sin venderse, bájale el precio definitivamente\n`;
        resp += `• Si después de 30 días no se mueve, considera eliminarlo del menú\n\n`;
      }
      if (low.length) {
        resp += `**Para los de ventas muy bajas:**\n\n`;
        resp += `• Prueba la promoción "2 x 1" o "segunda unidad al 50%"\n`;
        resp += `• Agrégalos como "sugerido" en el tótem junto a los más vendidos\n`;
        resp += `• Revisa si el precio es competitivo comparado con productos similares\n`;
        resp += `• Cambia el nombre o la descripción para hacerlos más atractivos\n\n`;
      }
      if (!zeroes.length && !low.length)
        resp += `No tengo datos recientes de productos con bajo rendimiento. Pregúntame primero "¿qué productos se venden menos?" para obtener el análisis.`;

      resp += `\n¿Quieres que analice algún producto específico en profundidad?`;
      return r(resp);
    }

    case 'revenue': {
      const { summary, salesByDay } = data;
      if (!summary) return r(`No pude obtener los ingresos. Intenta de nuevo.`);
      const bestDay = salesByDay && salesByDay.length
        ? salesByDay.reduce((a, b) => Number(a.revenue) > Number(b.revenue) ? a : b)
        : null;
      const trend = salesByDay && salesByDay.length >= 2
        ? Number(salesByDay[salesByDay.length-1].revenue) > Number(salesByDay[0].revenue) ? '📈 tendencia al alza' : '📉 tendencia a la baja'
        : null;
      let resp = `Ingresos ${rl}${store}:\n\n`;
      resp += `💰 **Total facturado:** $${fmt(summary.revenue)}\n`;
      resp += `📦 **Pedidos completados:** ${summary.completedOrders}\n`;
      resp += `🎯 **Ticket promedio:** $${fmt(summary.avgOrder)}\n`;
      if (bestDay) resp += `📅 **Mejor día:** ${bestDay.date} — $${fmt(bestDay.revenue)}\n`;
      if (trend) resp += `${trend}\n`;
      resp += summary.pendingOrders > 0
        ? `\n⚠️ Tienes **${summary.pendingOrders} pedidos pendientes** sin procesar.`
        : `\n✅ Sin pedidos pendientes. ¡Todo al día!`;
      resp += `\n\n¿Quieres ver qué productos generaron más ingresos o comparar con otro período?`;
      const chart = salesByDay && salesByDay.length ? {
        type: 'bar',
        title: `Ingresos por día ${rl}`,
        labels: salesByDay.map(d => {
          const dt = new Date(d.date);
          return `${dt.getDate()}/${dt.getMonth()+1}`;
        }),
        values: salesByDay.map(d => Number(d.revenue)),
        unit: '$',
        color: '#22c55e',
        highlight: salesByDay.indexOf(bestDay),
      } : null;
      return r(resp, chart);
    }

    case 'peak_hours': {
      const { byHour } = data;
      if (!byHour || !byHour.length)
        return r(`No hay datos de horarios ${rl}. Necesitas tener pedidos completados para ver este análisis.`);
      // Completar horas faltantes con 0
      const hourMap = {};
      byHour.forEach(h => { hourMap[Number(h.hour)] = Number(h.orders); });
      const allHours = Array.from({ length: 24 }, (_, i) => ({ hour: i, orders: hourMap[i] || 0 }));
      const sorted = [...byHour].sort((a, b) => Number(b.orders) - Number(a.orders));
      const peak = sorted[0];
      const quiet = sorted[sorted.length - 1];
      const top3 = sorted.slice(0, 3).map(h => `• **${h.hour}:00 hs** — ${h.orders} pedidos`).join('\n');
      const resp = `Distribución de ventas por hora ${rl}:\n\n⏰ **Horas pico:**\n${top3}\n\n🎯 Tu **hora pico es las ${peak.hour}:00 hs** con ${peak.orders} pedidos. Ten stock completo, personal disponible y sistema listo antes de esa hora.\n\n💤 La hora más tranquila: **${quiet.hour}:00 hs** — ideal para hacer inventario.`;
      const activoHours = allHours.filter(h => h.orders > 0);
      const chart = activoHours.length ? {
        type: 'bar',
        title: `Pedidos por hora ${rl}`,
        labels: activoHours.map(h => `${h.hour}h`),
        values: activoHours.map(h => h.orders),
        unit: 'pedidos',
        color: '#a78bfa',
        highlight: activoHours.findIndex(h => h.hour === Number(peak.hour)),
      } : null;
      return r(resp, chart);
    }

    case 'stock_alert': {
      const { allProducts } = data;
      if (!allProducts || !allProducts.length)
        return r(`No encontré productos en tu tienda. Agrega productos desde el **Editor Tótem** para ver el inventario.`);
      const outOfStock = allProducts.filter(p => !Number(p.unlimited_stock) && Number(p.stock) === 0);
      const lowStock = allProducts.filter(p => !Number(p.unlimited_stock) && Number(p.stock) > 0 && Number(p.stock) <= 3);
      const unlimited = allProducts.filter(p => Number(p.unlimited_stock));
      const ok = allProducts.filter(p => !Number(p.unlimited_stock) && Number(p.stock) > 3);
      let resp = `Estado del inventario${store}:\n\n`;
      if (!outOfStock.length && !lowStock.length) {
        resp += `✅ Todo en orden. Sin agotados ni stock crítico.\n`;
        if (unlimited.length) resp += `♾️ **${unlimited.length}** con stock ilimitado · `;
        if (ok.length) resp += `📦 **${ok.length}** con stock normal.`;
        resp += `\n\n¿Quieres analizar ventas para anticipar cuándo reponer?`;
        return r(resp);
      }
      if (outOfStock.length) {
        resp += `🔴 **Agotados (${outOfStock.length}):**\n` + outOfStock.map(p => `• ${p.name}`).join('\n') + `\n\n`;
      }
      if (lowStock.length) {
        resp += `🟡 **Stock crítico ≤ 3 uds (${lowStock.length}):**\n` + lowStock.map(p => `• ${p.name} — **${p.stock}** uds`).join('\n') + `\n\n`;
      }
      resp += `💡 Actualiza el stock desde **Productos** en el panel antes de que afecte tus ventas.`;
      return r(resp);
    }

    case 'category_analysis': {
      const { catRevenue } = data;
      if (!catRevenue || !catRevenue.length)
        return r(`No hay ventas por categoría ${rl}. Necesitas pedidos completados para ver este análisis.`);
      const total = catRevenue.reduce((s, c) => s + Number(c.revenue), 0);
      const list = catRevenue.map((c, i) => {
        const pct = total > 0 ? ((Number(c.revenue) / total) * 100).toFixed(0) : 0;
        return `${i+1}. **${c.category}** — $${fmt(c.revenue)} · ${pct}% · ${c.total_sold} uds`;
      }).join('\n');
      const top = catRevenue[0];
      const bottom = catRevenue[catRevenue.length - 1];
      let resp = `Análisis por categoría ${rl}:\n\n${list}\n\n`;
      resp += `🏆 **${top.category}** lidera con $${fmt(top.revenue)}.`;
      if (catRevenue.length > 1)
        resp += `\n💤 **${bottom.category}** tiene el menor rendimiento — refuérzala con nuevos productos o promociones.`;
      const chart = {
        type: 'bar',
        title: `Ingresos por categoría ${rl}`,
        labels: catRevenue.map(c => c.category.length > 12 ? c.category.slice(0, 11) + '…' : c.category),
        values: catRevenue.map(c => Number(c.revenue)),
        unit: '$',
        color: '#D4AF37',
      };
      return r(resp, chart);
    }

    case 'summary': {
      const { summary, salesByDay } = data;
      if (!summary) return r(`No pude generar el resumen. Intenta de nuevo.`);
      const convRate = summary.totalOrders > 0
        ? ((summary.completedOrders / summary.totalOrders) * 100).toFixed(0) : '0';
      const bestDay = salesByDay && salesByDay.length
        ? salesByDay.reduce((a, b) => Number(a.revenue) > Number(b.revenue) ? a : b)
        : null;
      let resp = `Resumen${store} ${rl}:\n\n`;
      resp += `📦 **${summary.completedOrders}** pedidos completados · **${convRate}%** conversión\n`;
      resp += `💰 **$${fmt(summary.revenue)}** ingresos · **$${fmt(summary.avgOrder)}** ticket promedio\n`;
      if (bestDay) resp += `📅 Mejor día: **${bestDay.date}** — $${fmt(bestDay.revenue)}\n`;
      resp += summary.pendingOrders > 0
        ? `\n⚠️ **${summary.pendingOrders} pedidos pendientes** sin procesar.`
        : `\n✅ Sin pedidos pendientes.`;
      resp += `\n\n¿Quieres profundizar en ventas, stock, horarios o recomendaciones?`;
      const chart = salesByDay && salesByDay.length ? {
        type: 'bar',
        title: `Ventas por día ${rl}`,
        labels: salesByDay.map(d => {
          const dt = new Date(d.date);
          return `${dt.getDate()}/${dt.getMonth()+1}`;
        }),
        values: salesByDay.map(d => Number(d.revenue)),
        unit: '$',
        color: '#22c55e',
        highlight: salesByDay.indexOf(bestDay),
      } : null;
      return r(resp, chart);
    }

    case 'orders_summary': {
      const { summary, recentOrders } = data;
      if (!summary) return r(`No pude obtener los pedidos. Intenta de nuevo.`);
      const statusMap = { paid:'pagado', processed:'procesado', completed:'completado', approved:'aprobado', pending:'pendiente', cancelled:'cancelado', waiting:'esperando' };
      let resp = `Pedidos ${rl}:\n\n`;
      resp += `✅ **Completados:** ${summary.completedOrders}\n`;
      resp += `⏳ **Pendientes:** ${summary.pendingOrders}\n`;
      resp += `❌ **Cancelados:** ${summary.cancelledOrders}\n`;
      resp += `📊 **Total:** ${summary.totalOrders}\n`;
      if (recentOrders && recentOrders.length) {
        resp += `\n**Últimos pedidos:**\n`;
        resp += recentOrders.slice(0, 5).map(o =>
          `• #${o.id} — $${fmt(o.total)} — ${statusMap[o.status] || o.status}`
        ).join('\n');
      }
      if (summary.pendingOrders > 0)
        resp += `\n\n⚠️ Tienes ${summary.pendingOrders} pedidos sin procesar. Ve a **Pedidos** para gestionarlos.`;
      return r(resp);
    }

    case 'recommendations': {
      const { summary, worst, topProds, allProducts } = data;
      if (!summary) return r(`No pude generar recomendaciones. Intenta de nuevo.`);
      const zeroSales = worst ? worst.filter(p => Number(p.total_sold) === 0) : [];
      const outOfStock = allProducts ? allProducts.filter(p => !Number(p.unlimited_stock) && Number(p.stock) === 0) : [];
      const convRate = summary.totalOrders > 0 ? (summary.completedOrders / summary.totalOrders) * 100 : 100;
      let tips = [];
      if (outOfStock.length > 0)
        tips.push(`🔴 **Urgente — ${outOfStock.length} productos agotados.** Estás perdiendo ventas ahora mismo. Recarga el inventario.`);
      if (zeroSales.length > 0)
        tips.push(`💤 **${zeroSales.length} productos sin ventas esta semana** (${zeroSales.slice(0, 2).map(p => p.name).join(', ')}${zeroSales.length > 2 ? '...' : ''}). Crea promociones o quítalos del tótem.`);
      if (topProds && topProds.length)
        tips.push(`⭐ **${topProds[0].name}** es tu producto estrella. Mantenlo visible y con stock siempre.`);
      if (convRate < 70)
        tips.push(`📉 Tu tasa de conversión es ${convRate.toFixed(0)}%. Revisa el proceso de pago o los precios.`);
      if (Number(summary.avgOrder) < 8)
        tips.push(`💡 Ticket promedio bajo ($${fmt(summary.avgOrder)}). Prueba combos o sugeridos en el tótem.`);
      if (!tips.length)
        tips.push(`✅ Tu negocio está funcionando bien esta semana. Considera expandir tu catálogo si la demanda lo permite.`);
      return r(`Recomendaciones para tu negocio esta semana:\n\n${tips.join('\n\n')}\n\n¿Quieres un plan de acción detallado para algún punto?`);
    }

    case 'product_analysis': {
      const { productAnalysis, productName } = data;
      if (!productAnalysis)
        return r(`No encontré ningún producto con el nombre "**${productName}**" en tu tienda. Verifica que el nombre esté bien escrito o usa parte del nombre, por ejemplo "coca" en lugar de "coca cola".`);
      const { prod, salesData, rank, total, byDay } = productAnalysis;
      const fmtP = (n) => Number(n||0).toFixed(2);
      let resp = `Análisis de **${prod.name}**:\n\n`;
      resp += `💰 **Precio:** $${fmtP(prod.price)}`;
      if (prod.category_name) resp += ` · 📂 **Categoría:** ${prod.category_name}`;
      resp += `\n`;
      resp += Number(prod.unlimited_stock) ? `♾️ Stock ilimitado\n` : `📦 **Stock actual:** ${prod.stock} unidades\n`;
      resp += `\n**Ventas:**\n`;
      resp += `• Esta semana: **${salesData.week.total_sold} uds** · $${fmtP(salesData.week.revenue)}\n`;
      resp += `• Este mes: **${salesData.month.total_sold} uds** · $${fmtP(salesData.month.revenue)}\n`;
      resp += `• Este año: **${salesData.year.total_sold} uds** · $${fmtP(salesData.year.revenue)}\n`;
      resp += `\n📊 **Ranking esta semana:** #${rank} de ${total} productos`;
      if (rank === 1) resp += ` 🥇 ¡Es tu producto estrella!`;
      else if (rank <= 3) resp += ` 🏆 Está en el top 3.`;
      else if (rank > total * 0.8) resp += ` ⚠️ Está en el grupo de menor rendimiento.`;
      const chartPA = byDay && byDay.length ? {
        type: 'bar', title: `${prod.name} — ventas por día`,
        labels: byDay.map(d => { const dt = new Date(d.date); return `${dt.getDate()}/${dt.getMonth()+1}`; }),
        values: byDay.map(d => Number(d.qty)),
        unit: 'uds', color: '#D4AF37',
        highlight: byDay.reduce((mi, d, i, a) => Number(d.qty) > Number(a[mi].qty) ? i : mi, 0),
      } : null;
      resp += `\n\n¿Quieres recomendaciones específicas para este producto?`;
      return r(resp, chartPA);
    }

    case 'extras_analysis': {
      const { topExtras } = data;
      if (!topExtras || !topExtras.length)
        return r(`No encontré extras solicitados ${rl}. Asegúrate de tener pedidos completados en ese período donde los clientes hayan elegido extras.`);
      const medals = ['🥇', '🥈', '🥉', '4.', '5.', '6.', '7.', '8.', '9.', '10.'];
      const list = topExtras.map((e, i) => `${medals[i] || `${i+1}.`} **${e.name}** — pedido ${e.total} ${e.total === 1 ? 'vez' : 'veces'}`).join('\n');
      const chart = {
        type: 'bar',
        title: `Extras más pedidos ${rl}`,
        labels: topExtras.map(e => e.name.length > 14 ? e.name.slice(0, 13) + '…' : e.name),
        values: topExtras.map(e => e.total),
        unit: 'veces',
        color: '#D4AF37',
      };
      return r(`Extras más solicitados por tus clientes ${rl}:\n\n${list}\n\n💡 Asegúrate de tener siempre disponibles los más pedidos. ¿Quieres ver los complementos también?`, chart);
    }

    case 'ingredients_analysis': {
      const { topIngredients } = data;
      if (!topIngredients || !topIngredients.length)
        return r(`No encontré complementos solicitados ${rl}. Asegúrate de tener pedidos completados donde los clientes hayan elegido complementos.`);
      const medals = ['🥇', '🥈', '🥉', '4.', '5.', '6.', '7.', '8.', '9.', '10.'];
      const list = topIngredients.map((i, idx) => `${medals[idx] || `${idx+1}.`} **${i.name}** — pedido ${i.total} ${i.total === 1 ? 'vez' : 'veces'}`).join('\n');
      const chart = {
        type: 'bar',
        title: `Complementos más pedidos ${rl}`,
        labels: topIngredients.map(i => i.name.length > 14 ? i.name.slice(0, 13) + '…' : i.name),
        values: topIngredients.map(i => i.total),
        unit: 'veces',
        color: '#a78bfa',
      };
      return r(`Complementos más solicitados por tus clientes ${rl}:\n\n${list}\n\n💡 Los más elegidos son los que no deben faltar. ¿Quieres ver los extras también?`, chart);
    }

    case 'extras_catalog': {
      const { allExtras } = data;
      if (!allExtras || !allExtras.length)
        return r(`Tu tienda no tiene extras configurados todavía. Puedes agregarlos desde el **Editor Tótem** en la sección de Extras.`);
      const list = allExtras.map(e => {
        const price = Number(e.price) > 0 ? ` — $${Number(e.price).toFixed(2)}` : ' — sin costo adicional';
        return `• **${e.name}**${price}`;
      }).join('\n');
      return r(`Extras disponibles en tu tienda (${allExtras.length}):\n\n${list}\n\n¿Quieres saber cuáles son los más pedidos por tus clientes?`);
    }

    case 'ingredients_catalog': {
      const { allIngredients } = data;
      if (!allIngredients || !allIngredients.length)
        return r(`Tu tienda no tiene complementos configurados todavía. Puedes agregarlos desde el **Editor Tótem** en la sección de Complementos.`);
      const list = allIngredients.map(i => {
        const price = Number(i.price) > 0 ? ` — $${Number(i.price).toFixed(2)}` : ' — sin costo adicional';
        return `• **${i.name}**${price}`;
      }).join('\n');
      return r(`Complementos disponibles en tu tienda (${allIngredients.length}):\n\n${list}\n\n¿Quieres saber cuáles son los más pedidos por tus clientes?`);
    }

    case 'best_days': {
      const { byDayOfWeek } = data;
      if (!byDayOfWeek || !byDayOfWeek.length)
        return r(`No hay suficientes datos de ventas para analizar los días de la semana. Necesitas pedidos completados en el período seleccionado.`);
      const sorted = [...byDayOfWeek].sort((a, b) => Number(b.orders) - Number(a.orders));
      const best = sorted[0];
      const worst = sorted[sorted.length - 1];
      const medals = ['🥇','🥈','🥉','4.','5.','6.','7.'];
      const list = sorted.map((d, i) =>
        `${medals[i] || `${i+1}.`} **${d.day_name}** — ${d.orders} pedidos · $${Number(d.revenue || 0).toFixed(2)}`
      ).join('\n');
      const allDays = ['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];
      const presentDays = new Set(sorted.map(d => d.day_name));
      const missingDays = allDays.filter(d => !presentDays.has(d));
      let resp = `Rendimiento por día de la semana ${rl}${store}:\n\n${list}\n\n`;
      resp += `🏆 **${best.day_name}** es tu mejor día con **${best.orders} pedidos**.`;
      if (missingDays.length)
        resp += `\n💤 Sin ventas registradas: ${missingDays.join(', ')}.`;
      resp += `\n\n💡 Asegúrate de tener stock completo y personal suficiente los **${sorted.slice(0,2).map(d => d.day_name).join(' y ')}**.`;
      const chartDays = {
        type: 'bar',
        title: `Pedidos por día de la semana ${rl}`,
        labels: sorted.map(d => d.day_name.slice(0, 3)),
        values: sorted.map(d => Number(d.orders)),
        unit: 'pedidos',
        color: '#D4AF37',
        highlight: 0,
      };
      return r(resp, chartDays);
    }

    default:
      return r(`No entendí bien esa pregunta 🤔. Puedes preguntarme de forma natural, por ejemplo:\n\n• "¿Qué días vendo más?"\n• "¿Cuáles son los más vendidos esta semana?"\n• "¿Cuánto gané este mes?"\n• "¿A qué hora vendo más?"\n• "¿Tengo productos sin stock?"\n• "¿Qué extras piden más mis clientes?"\n• "Dame un resumen"\n• "¿Qué me recomiendas?"\n\nPrueba reformulando tu pregunta.`);
  }
}

const LEON_PYTHON_URL = 'http://127.0.0.1:7777';
let leonPythonAvailable = null; // null = no comprobado, true/false

async function checkLeonPython() {
  try {
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 2000);
    const r = await fetch(`${LEON_PYTHON_URL}/health`, { signal: ctrl.signal });
    clearTimeout(timeout);
    const data = await r.json();
    leonPythonAvailable = data.ollama === true;
    return leonPythonAvailable;
  } catch {
    leonPythonAvailable = false;
    return false;
  }
}
// Comprobar periódicamente (más frecuente al inicio para detectar cuando Ollama termina de bajar el modelo)
checkLeonPython();
let _leonCheckCount = 0;
const _leonCheckInterval = setInterval(() => {
  _leonCheckCount++;
  checkLeonPython();
  // Después de 20 chequeos (10 min) pasar a cada 2 min
  if (_leonCheckCount >= 20) {
    clearInterval(_leonCheckInterval);
    setInterval(checkLeonPython, 120000);
  }
}, 30000);

app.post('/api/leon-ia/chat', authenticateToken, async (req, res) => {
  try {
    const { question, store_id, history = [] } = req.body;
    if (!question || !store_id) return res.status(400).json({ error: 'Faltan parámetros' });

    // ── Intentar servicio Python con Ollama ──────────────────────────────────
    if (leonPythonAvailable) {
      try {
        const ctrl = new AbortController();
        const timeout = setTimeout(() => ctrl.abort(), 90000);
        const pyRes = await fetch(`${LEON_PYTHON_URL}/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ question, store_id: parseInt(store_id), history }),
          signal: ctrl.signal
        });
        clearTimeout(timeout);
        if (pyRes.ok) {
          const pyData = await pyRes.json();
          return res.json({
            answer: pyData.answer,
            chart: pyData.chart || null,
            intent: 'ai',
            ai_powered: true,
            model: pyData.model || 'ollama'
          });
        }
      } catch (pyErr) {
        leonPythonAvailable = false; // marcar como caído
        console.warn('León Python no disponible, usando sistema clásico:', pyErr.message);
      }
    }

    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'Sin acceso' });

    const storeId = parseInt(store_id);
    const storeData = await getStoreById(storeId);
    const storeName = storeData?.name || null;

    const intent = leonDetectIntent(question, history);
    const detectedRange = leonDetectRange(question);
    const lastRange = history.slice().reverse().find(m => m.range && m.role === 'leon')?.range;
    const isExplicitRange = /\b(hoy|semana|mes|año|ayer)\b/i.test(question);
    const range = isExplicitRange ? detectedRange : (detectedRange !== 'week' ? detectedRange : 'week');

    let data = {};

    if (intent === 'greeting' || intent === 'thanks' || intent === 'unknown') {
      // sin BD
    } else if (intent === 'top_products') {
      data.products = await leonGetTopProductsWithRevenue(storeId, range, 5);
    } else if (intent === 'worst_products') {
      data.worst = await leonGetWorstProducts(storeId, range);
    } else if (intent === 'action_plan') {
      data.worst = await leonGetWorstProducts(storeId, range);
    } else if (intent === 'revenue') {
      data.summary = await getAnalytics(storeId, range);
      data.salesByDay = await getSalesByDay(storeId, range);
    } else if (intent === 'peak_hours') {
      data.byHour = await getOrdersByHour(storeId, range);
    } else if (intent === 'stock_alert') {
      data.allProducts = await leonGetAllProducts(storeId);
    } else if (intent === 'category_analysis') {
      data.catRevenue = await leonGetCategoryRevenue(storeId, range);
    } else if (intent === 'summary') {
      data.summary = await getAnalytics(storeId, range);
      data.salesByDay = await getSalesByDay(storeId, range);
    } else if (intent === 'orders_summary') {
      data.summary = await getAnalytics(storeId, range);
      data.recentOrders = await getRecentOrders(storeId, 5);
    } else if (intent === 'recommendations') {
      data.summary = await getAnalytics(storeId, 'week');
      data.worst = await leonGetWorstProducts(storeId, 'week');
      data.topProds = await leonGetTopProductsWithRevenue(storeId, 'week', 3);
      data.allProducts = await leonGetAllProducts(storeId);
    } else if (intent === 'product_analysis') {
      const productName = leonExtractProductName(question);
      data.productName = productName;
      data.productAnalysis = await leonGetProductAnalysis(storeId, productName);
    } else if (intent === 'extras_analysis') {
      data.topExtras = await leonGetTopExtras(storeId, range);
    } else if (intent === 'ingredients_analysis') {
      data.topIngredients = await leonGetTopIngredients(storeId, range);
    } else if (intent === 'extras_catalog') {
      data.allExtras = await leonGetAllExtras(storeId);
    } else if (intent === 'ingredients_catalog') {
      data.allIngredients = await leonGetAllIngredients(storeId);
    } else if (intent === 'best_days') {
      data.byDayOfWeek = await leonGetSalesByDayOfWeek(storeId, range === 'today' ? 'month' : range);
    } else {
      data.summary = await getAnalytics(storeId, range);
    }

    const leonAnswer = leonBuildResponse(intent, range, data, storeName);

    const chatgptKey = await getChatGptKey(req.user.id);
    if (chatgptKey) {
      try {
        const systemPrompt = `Eres León IA 🦁, el asistente de negocios inteligente de SRServi para la tienda "${storeName}".

PERSONALIDAD: Eres directo, amigable y útil. Hablas como un asesor de negocios experto pero accesible. Entiendes lenguaje natural coloquial en español latinoamericano (por ejemplo "plata" = dinero, "se mueve" = se vende, "no sale" = no se vende, "qué tal va" = cómo está el rendimiento).

REGLAS:
- Responde siempre en español
- Sé concreto y accionable (no filosófico)
- Usa los datos que tienes, no inventes números
- Si el usuario pregunta algo que no está en los datos, dilo honestamente y sugiere qué preguntar
- Usa emojis con moderación
- Máximo 5 oraciones salvo que el usuario pida detalle
- Si el usuario dice algo vago como "y eso?", "qué más?", "cuéntame más", expande sobre lo último que se habló

DATOS ACTUALES DE LA TIENDA (período: ${leonRangeLabel(range)}):
${JSON.stringify(data, null, 2)}

ANÁLISIS PREVIO DE LEÓN: ${leonAnswer.text}`;

        const messages = [
          { role: 'system', content: systemPrompt },
          ...history.slice(-6).map(m => ({ role: m.role === 'leon' ? 'assistant' : 'user', content: m.text })),
          { role: 'user', content: question },
        ];

        const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${chatgptKey}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ model: 'gpt-4o-mini', messages, max_tokens: 500, temperature: 0.7 }),
        });
        if (openaiRes.ok) {
          const openaiData = await openaiRes.json();
          const aiAnswer = openaiData.choices?.[0]?.message?.content;
          if (aiAnswer) {
            return res.json({ answer: aiAnswer, chart: leonAnswer.chart || null, intent, range, ai_powered: true });
          }
        }
      } catch (_) { /* fall through to León */ }
    }

    res.json({ answer: leonAnswer.text, chart: leonAnswer.chart || null, intent, range });
  } catch (error) {
    console.error('León IA error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ==================== FIN LEÓN IA ====================

app.post('/api/superadmin/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email y contraseña son requeridos' });
    }
    const superadmin = await authenticateSuperadmin(email, password);
    if (!superadmin) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }
    // Ensure columns exist
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM superadmin');
      const names = cols.map(c => c.Field);
      if (!names.includes('username')) await pool.execute('ALTER TABLE superadmin ADD COLUMN username VARCHAR(255) DEFAULT NULL');
      if (!names.includes('avatar')) await pool.execute('ALTER TABLE superadmin ADD COLUMN avatar TEXT DEFAULT NULL');
    } catch {}
    let username = superadmin.email;
    let avatar = null;
    try {
      const [rows] = await pool.execute('SELECT username, avatar FROM superadmin WHERE id = ?', [superadmin.id]);
      if (rows[0]?.username) username = rows[0].username;
      if (rows[0]?.avatar) avatar = rows[0].avatar;
    } catch {}
    const token = jwt.sign({ id: superadmin.id, isSuperadmin: true, username }, JWT_SECRET, { expiresIn: '24h' });
    res.json({ token, superadmin: { id: superadmin.id, email: superadmin.email, username, avatar } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/superadmin/setup', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email y contraseña son requeridos' });
    }
    await createSuperadmin(email, password);
    res.json({ success: true, message: 'Superadmin creado' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const authenticateSuperadminToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Token requerido' });
  }
  
  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ error: 'Token inválido' });
    }
    if (!decoded.isSuperadmin) {
      return res.status(403).json({ error: 'Acceso denegado' });
    }
    req.superadmin = decoded;
    next();
  });
};

// Superadmin: update my profile (name + avatar)
app.put('/api/superadmin/profile', authenticateSuperadminToken, upload.single('avatar'), async (req, res) => {
  try {
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM superadmin');
      const names = cols.map(c => c.Field);
      if (!names.includes('username')) await pool.execute('ALTER TABLE superadmin ADD COLUMN username VARCHAR(255) DEFAULT NULL');
      if (!names.includes('avatar')) await pool.execute('ALTER TABLE superadmin ADD COLUMN avatar TEXT DEFAULT NULL');
    } catch {}
    const updates = [];
    const params = [];
    if (req.body.username) { updates.push('username = ?'); params.push(req.body.username); }
    if (req.file) { updates.push('avatar = ?'); params.push(`/uploads/${req.file.filename}`); }
    if (updates.length > 0) {
      params.push(req.superadmin.id);
      await pool.execute(`UPDATE superadmin SET ${updates.join(', ')} WHERE id = ?`, params);
    }
    const [rows] = await pool.execute('SELECT id, email, username, avatar FROM superadmin WHERE id = ?', [req.superadmin.id]);
    res.json(rows[0] || {});
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Superadmin: get my profile
app.get('/api/superadmin/profile', authenticateSuperadminToken, async (req, res) => {
  try {
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM superadmin');
      const names = cols.map(c => c.Field);
      if (!names.includes('username')) await pool.execute('ALTER TABLE superadmin ADD COLUMN username VARCHAR(255) DEFAULT NULL');
      if (!names.includes('avatar')) await pool.execute('ALTER TABLE superadmin ADD COLUMN avatar TEXT DEFAULT NULL');
    } catch {}
    const [rows] = await pool.execute('SELECT id, email, username, avatar FROM superadmin WHERE id = ?', [req.superadmin.id]);
    res.json(rows[0] || {});
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Superadmin: create new superadmin account
app.post('/api/superadmin/create', authenticateSuperadminToken, async (req, res) => {
  try {
    const { email, password, username } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email y contraseña requeridos' });
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM superadmin LIKE ?', ['username']);
      if (cols.length === 0) await pool.execute('ALTER TABLE superadmin ADD COLUMN username VARCHAR(255) DEFAULT NULL');
    } catch {}
    await createSuperadmin(email, password);
    if (username) await pool.execute('UPDATE superadmin SET username = ? WHERE email = ?', [username, email]);
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Superadmin: list all superadmins
app.get('/api/superadmin/list', authenticateSuperadminToken, async (req, res) => {
  try {
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM superadmin LIKE ?', ['username']);
      if (cols.length === 0) await pool.execute('ALTER TABLE superadmin ADD COLUMN username VARCHAR(255) DEFAULT NULL');
    } catch {}
    const [rows] = await pool.execute('SELECT id, email, username, avatar, created_at FROM superadmin ORDER BY id');
    res.json(rows);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Superadmin: delete superadmin (can't delete yourself)
app.delete('/api/superadmin/account/:id', authenticateSuperadminToken, async (req, res) => {
  try {
    if (parseInt(req.params.id) === req.superadmin.id) return res.status(400).json({ error: 'No puedes eliminarte a ti mismo' });
    await pool.execute('DELETE FROM superadmin WHERE id = ?', [parseInt(req.params.id)]);
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.get('/api/superadmin/users', authenticateSuperadminToken, async (req, res) => {
  try {
    const users = await getAllUsers();
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/superadmin/user-apps', authenticateSuperadminToken, async (req, res) => {
  try {
    const data = await getUserApps();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/superadmin/users/:id', authenticateSuperadminToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { email, password, is_banned } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email es requerido' });
    }
    await updateUserBySuperadmin(id, { email, password, is_banned });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/superadmin/users/:id', authenticateSuperadminToken, async (req, res) => {
  try {
    const { id } = req.params;
    await deleteUserBySuperadmin(id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/superadmin/notify-existing-premiums', authenticateSuperadminToken, async (req, res) => {
  try {
    // Traer todos los usuarios con plan activo y que no sea "Gratis"
    const [premiumRows] = await pool.execute(`
      SELECT u.id as user_id, u.username, u.email, p.name as plan_name,
             up.billing_cycle, up.starts_at, up.ends_at, up.created_at as subscribed_at
      FROM user_plans up
      JOIN users u ON u.id = up.user_id
      JOIN plans p ON p.id = up.plan_id
      WHERE up.is_active = TRUE AND up.ends_at > NOW() AND p.name != 'Gratis'
      ORDER BY up.created_at DESC
    `);

    if (premiumRows.length === 0) {
      return res.json({ success: true, sent: 0, message: 'No hay usuarios premium activos' });
    }

    // Obtener tiendas de todos los usuarios de una sola vez
    const userIds = [...new Set(premiumRows.map(r => r.user_id))];
    const placeholders = userIds.map(() => '?').join(',');
    const [storeRows] = await pool.execute(
      `SELECT user_id, name FROM stores WHERE user_id IN (${placeholders})`,
      userIds
    );
    const storesByUser = {};
    storeRows.forEach(s => {
      if (!storesByUser[s.user_id]) storesByUser[s.user_id] = [];
      storesByUser[s.user_id].push(s.name);
    });

    // Armar cards del email (una por usuario, más legible que tabla en email)
    const cards = premiumRows.map((u, i) => {
      const tiendas = (storesByUser[u.user_id] || []).join(', ') || '—';
      const ciclo = u.billing_cycle === 'yearly' ? '🔄 Anual' : u.billing_cycle === 'forever' ? '♾️ Para siempre' : '🔄 Mensual';
      const hasta = u.ends_at ? new Date(u.ends_at).toLocaleDateString('es-AR') : '—';
      const desde = u.subscribed_at ? new Date(u.subscribed_at).toLocaleDateString('es-AR') : '—';
      const isEven = i % 2 === 0;
      return `
        <tr style="background:${isEven ? '#ffffff' : '#fafafa'}">
          <td style="padding:14px 16px;border-bottom:1px solid #f0f0f0;vertical-align:top">
            <div style="font-weight:700;font-size:14px;color:#111;margin-bottom:2px">${u.username}</div>
            <div style="font-size:12px;color:#888">${u.email}</div>
          </td>
          <td style="padding:14px 16px;border-bottom:1px solid #f0f0f0;vertical-align:top;font-size:13px;color:#444">${tiendas}</td>
          <td style="padding:14px 16px;border-bottom:1px solid #f0f0f0;vertical-align:top;text-align:center">
            <span style="display:inline-block;background:#D4AF37;color:#000;font-weight:700;font-size:11px;padding:3px 10px;border-radius:20px">${u.plan_name}</span>
          </td>
          <td style="padding:14px 16px;border-bottom:1px solid #f0f0f0;vertical-align:top;font-size:12px;color:#666;white-space:nowrap">${ciclo}</td>
          <td style="padding:14px 16px;border-bottom:1px solid #f0f0f0;vertical-align:top;font-size:12px;color:#888;white-space:nowrap">${desde}</td>
          <td style="padding:14px 16px;border-bottom:1px solid #f0f0f0;vertical-align:top;font-size:12px;color:#888;white-space:nowrap">${hasta}</td>
        </tr>`;
    }).join('');

    const html = `<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4f4f5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:32px 16px">
    <tr><td align="center">
      <table width="680" cellpadding="0" cellspacing="0" style="max-width:680px;width:100%;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08)">

        <!-- Header -->
        <tr>
          <td style="background:#111;padding:28px 32px">
            <table width="100%" cellpadding="0" cellspacing="0">
              <tr>
                <td>
                  <span style="color:#D4AF37;font-size:24px;font-weight:800;letter-spacing:-0.5px">SR</span><span style="color:#fff;font-size:24px;font-weight:800;letter-spacing:-0.5px">Servi</span>
                </td>
                <td align="right">
                  <span style="background:#D4AF37;color:#000;font-size:11px;font-weight:700;padding:4px 12px;border-radius:20px;letter-spacing:0.5px">REPORTE</span>
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- Title -->
        <tr>
          <td style="padding:28px 32px 0">
            <h1 style="margin:0 0 6px;font-size:22px;font-weight:800;color:#111">Usuarios Premium activos</h1>
            <p style="margin:0;font-size:14px;color:#888">Generado el <strong style="color:#555">${new Date().toLocaleDateString('es-AR', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}</strong></p>
          </td>
        </tr>

        <!-- Stats bar -->
        <tr>
          <td style="padding:20px 32px">
            <table cellpadding="0" cellspacing="0" style="background:#f8f8f8;border-radius:12px;padding:16px 20px;width:100%">
              <tr>
                <td style="text-align:center;padding:0 16px">
                  <div style="font-size:32px;font-weight:800;color:#111">${premiumRows.length}</div>
                  <div style="font-size:11px;color:#888;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">Suscripciones</div>
                </td>
                <td style="width:1px;background:#e5e5e5"></td>
                <td style="text-align:center;padding:0 16px">
                  <div style="font-size:32px;font-weight:800;color:#D4AF37">${premiumRows.filter(u => u.billing_cycle === 'yearly').length}</div>
                  <div style="font-size:11px;color:#888;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">Anuales</div>
                </td>
                <td style="width:1px;background:#e5e5e5"></td>
                <td style="text-align:center;padding:0 16px">
                  <div style="font-size:32px;font-weight:800;color:#555">${premiumRows.filter(u => u.billing_cycle !== 'yearly' && u.billing_cycle !== 'forever').length}</div>
                  <div style="font-size:11px;color:#888;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">Mensuales</div>
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- Table -->
        <tr>
          <td style="padding:0 32px 32px">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-radius:12px;overflow:hidden;border:1px solid #f0f0f0">
              <thead>
                <tr style="background:#f5f5f5">
                  <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.5px">Usuario</th>
                  <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.5px">Tienda(s)</th>
                  <th style="padding:10px 16px;text-align:center;font-size:11px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.5px">Plan</th>
                  <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.5px">Ciclo</th>
                  <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.5px">Desde</th>
                  <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.5px">Hasta</th>
                </tr>
              </thead>
              <tbody>${cards}</tbody>
            </table>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background:#fafafa;border-top:1px solid #f0f0f0;padding:16px 32px;text-align:center">
            <p style="margin:0;font-size:12px;color:#bbb">SRServi · Panel de administración · ${new Date().toLocaleString('es-AR')}</p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;

    const [superadmins] = await pool.execute('SELECT email FROM superadmin');
    const emails = superadmins.map(s => s.email).filter(Boolean);

    await Promise.all(emails.map(to =>
      mailer.sendMail({
        from: `"SRServi" <${process.env.EMAIL_USER}>`,
        to,
        subject: `📋 Usuarios Premium activos — ${premiumRows.length} suscripciones`,
        html
      })
    ));

    res.json({ success: true, sent: emails.length, total_premiums: premiumRows.length });
  } catch (error) {
    console.error('Error notificando premiums existentes:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/superadmin/impersonate/:userId', authenticateSuperadminToken, async (req, res) => {
  try {
    const user = await getUserById(req.params.userId);
    if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });
    const token = jwt.sign({ id: user.id, email: user.email, type: 'user' }, JWT_SECRET, { expiresIn: '7d' });
    const { totp_secret, totp_enabled, email_verified, password, ...safeUser } = user;
    res.json({ token, user: safeUser });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/superadmin/stores', authenticateSuperadminToken, async (req, res) => {
  try {
    const stores = await getAllStores();
    res.json(stores);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/superadmin/stores/:id', authenticateSuperadminToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { is_banned } = req.body;
    await updateStoreBySuperadmin(id, { is_banned });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/superadmin/stores/:id', authenticateSuperadminToken, async (req, res) => {
  try {
    const { id } = req.params;
    await deleteStoreBySuperadmin(id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/superadmin/subscriptions', authenticateSuperadminToken, async (req, res) => {
  try {
    const subscriptions = await getSubscriptionHistory();
    console.log('📋 Suscripciones encontradas:', subscriptions.length);
    res.json(subscriptions || []);
  } catch (error) {
    console.error('❌ Error en subscriptions:', error);
    res.json([]);
  }
});

app.post('/api/superadmin/assign-premium', authenticateSuperadminToken, async (req, res) => {
  try {
    const { user_id, plan_id, forever, ends_at } = req.body;
    if (!user_id || !plan_id) {
      return res.status(400).json({ error: 'user_id y plan_id son requeridos' });
    }
    const result = await assignPremiumByAdmin(user_id, plan_id, forever, ends_at);
    res.json(result);
  } catch (error) {
    console.error('Error asignando premium:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/categories', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const parsedId = parseInt(storeId);
    console.log(`[Categories] GET store_id=${storeId} parsed=${parsedId}`);
    const categories = await getCategories(parsedId);
    console.log(`[Categories] Found ${categories.length} categories`);
    res.json(categories);
  } catch (error) {
    console.error(`[Categories] GET Error:`, error.message);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/categories', authenticateToken, async (req, res) => {
  try {
    const { store_id, name, description } = req.body;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!name) {
      return res.status(400).json({ error: 'Nombre es requerido' });
    }
    const category = await createCategory(parseInt(store_id), { name, description });
    emitProductUpdate(parseInt(store_id), 'category_created', category);
    res.json(category);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/categories/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id, name, description } = req.body;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!name) {
      return res.status(400).json({ error: 'Nombre es requerido' });
    }
    const category = await updateCategory(parseInt(req.params.id), parseInt(store_id), { name, description });
    emitProductUpdate(parseInt(store_id), 'category_updated', category);
    res.json(category);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/categories/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const categoryId = req.params.id;
    await deleteCategory(parseInt(categoryId), parseInt(store_id));
    emitProductUpdate(parseInt(store_id), 'category_deleted', { id: categoryId });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/ingredients', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const ingredients = await getIngredients(parseInt(storeId));
    res.json(ingredients);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/ingredients', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { store_id, name, price, category_id, stock, unlimited_stock, stock_unit } = req.body;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!name) {
      return res.status(400).json({ error: 'Nombre es requerido' });
    }
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;
    const ingredient = await createIngredient(parseInt(store_id), { name, price, category_id, image: imageUrl, stock: parseInt(stock) || 0, unlimited_stock: unlimited_stock === 'true' || unlimited_stock === true, stock_unit: stock_unit || 'unidades' });
    emitProductUpdate(parseInt(store_id), 'ingredient_created', ingredient);
    res.json(ingredient);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/ingredients/reorder', authenticateToken, async (req, res) => {
  try {
    const { store_id, items } = req.body;
    if (!store_id || !items) return res.status(400).json({ error: 'store_id e items son requeridos' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    await updateIngredientsOrder(parseInt(store_id), items);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/ingredients/:id', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { store_id, name, price, category_id, stock, unlimited_stock, stock_unit } = req.body;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!name) {
      return res.status(400).json({ error: 'Nombre es requerido' });
    }
    let imageUrl;
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    } else {
      const existing = await pool.execute('SELECT image FROM ingredients WHERE id = ?', [req.params.id]);
      imageUrl = existing[0][0]?.image || null;
    }
    const ingredient = await updateIngredient(parseInt(req.params.id), parseInt(store_id), {
      name,
      price,
      category_id,
      image: imageUrl,
      stock: stock !== undefined ? parseInt(stock) : 0,
      unlimited_stock: unlimited_stock === 'true' || unlimited_stock === true,
      stock_unit: stock_unit || 'unidades',
    });
    req.app.get('io').to(`store_${store_id}`).emit('inventory_updated', { product_id: parseInt(req.params.id), stock: ingredient.stock, unlimited_stock: ingredient.unlimited_stock });
    emitProductUpdate(parseInt(store_id), 'ingredient_updated', ingredient);
    res.json(ingredient);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/complements/duplicate-info', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const duplicates = await getDuplicateComplementInfo(parseInt(store_id));
    console.log(`[duplicate-info] store=${store_id} found=${duplicates.length}`, duplicates);
    res.json(duplicates);
  } catch (error) {
    console.error('[duplicate-info] error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/ingredients/all', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const deleted = await deleteAllIngredients(parseInt(store_id));
    emitProductUpdate(parseInt(store_id), 'ingredients_deleted_all', {});
    res.json({ success: true, deleted });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/ingredients/duplicates', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const deleted = await deduplicateIngredients(parseInt(store_id));
    emitProductUpdate(parseInt(store_id), 'ingredients_deduplicated', {});
    res.json({ success: true, deleted });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/ingredients/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const ingredientId = req.params.id;
    await deleteIngredient(parseInt(ingredientId), parseInt(store_id));
    emitProductUpdate(parseInt(store_id), 'ingredient_deleted', { id: ingredientId });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Activar / desactivar implemento (visibilidad en store y worker panel)
app.patch('/api/ingredients/:id/active', authenticateToken, async (req, res) => {
  try {
    const { store_id, is_active } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const result = await setIngredientActive(parseInt(req.params.id), parseInt(store_id), !!is_active);
    emitProductUpdate(parseInt(store_id), 'ingredient_updated', result);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/extras', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const extras = await getExtras(parseInt(storeId));
    res.json(extras);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/extras', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { store_id, name, price, category_id, stock, unlimited_stock, stock_unit } = req.body;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!name) {
      return res.status(400).json({ error: 'Nombre es requerido' });
    }
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;
    const extra = await createExtra(parseInt(store_id), { name, price, category_id, image: imageUrl, stock: parseInt(stock) || 0, unlimited_stock: unlimited_stock === 'true' || unlimited_stock === true, stock_unit: stock_unit || 'unidades' });
    emitProductUpdate(parseInt(store_id), 'extra_created', extra);
    res.json(extra);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/extras/reorder', authenticateToken, async (req, res) => {
  try {
    const { store_id, items } = req.body;
    if (!store_id || !items) return res.status(400).json({ error: 'store_id e items son requeridos' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    await updateExtrasOrder(parseInt(store_id), items);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/extras/:id', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { store_id, name, price, category_id, stock, unlimited_stock, stock_unit } = req.body;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!name) {
      return res.status(400).json({ error: 'Nombre es requerido' });
    }
    let imageUrl;
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    } else {
      const existing = await pool.execute('SELECT image FROM extras WHERE id = ?', [req.params.id]);
      imageUrl = existing[0][0]?.image || null;
    }
    const extra = await updateExtra(parseInt(req.params.id), parseInt(store_id), {
      name,
      price,
      category_id,
      image: imageUrl,
      stock: stock !== undefined ? parseInt(stock) : 0,
      unlimited_stock: unlimited_stock === 'true' || unlimited_stock === true,
      stock_unit: stock_unit || 'unidades',
    });
    req.app.get('io').to(`store_${store_id}`).emit('inventory_updated', { product_id: parseInt(req.params.id), stock: extra.stock, unlimited_stock: extra.unlimited_stock });
    emitProductUpdate(parseInt(store_id), 'extra_updated', extra);
    res.json(extra);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/extras/all', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const deleted = await deleteAllExtras(parseInt(store_id));
    emitProductUpdate(parseInt(store_id), 'extras_deleted_all', {});
    res.json({ success: true, deleted });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/extras/duplicates', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const deleted = await deduplicateExtras(parseInt(store_id));
    emitProductUpdate(parseInt(store_id), 'extras_deduplicated', {});
    res.json({ success: true, deleted });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/extras/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const extraId = req.params.id;
    await deleteExtra(parseInt(extraId), parseInt(store_id));
    emitProductUpdate(parseInt(store_id), 'extra_deleted', { id: extraId });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Activar / desactivar extra (visibilidad en store y worker panel)
app.patch('/api/extras/:id/active', authenticateToken, async (req, res) => {
  try {
    const { store_id, is_active } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const result = await setExtraActive(parseInt(req.params.id), parseInt(store_id), !!is_active);
    emitProductUpdate(parseInt(store_id), 'extra_updated', result);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/store-configurations', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const configurations = await getStoreConfigurations(parseInt(storeId));
    res.json(configurations);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/store-configurations', authenticateToken, async (req, res) => {
  try {
    const { store_id, name, description, accept_cash, accept_card, is_active, is_default, is_minimarket, default_minimarket_terminal, allow_serve, allow_takeout, hide_decimals, allow_table_service, tip_percentage, delivery_enabled, delivery_payment_methods } = req.body;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!name) {
      return res.status(400).json({ error: 'Nombre es requerido' });
    }
    const configuration = await createStoreConfiguration(parseInt(store_id), { name, description, accept_cash, accept_card, is_active, is_default, is_minimarket, default_minimarket_terminal, allow_serve, allow_takeout, hide_decimals, allow_table_service, tip_percentage, delivery_enabled, delivery_payment_methods });
    res.json(configuration);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/store-configurations/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id, name, description, accept_cash, accept_card, is_active, is_default, is_minimarket, default_minimarket_terminal, allow_serve, allow_takeout, hide_decimals, allow_table_service, tip_percentage, delivery_enabled, delivery_payment_methods } = req.body;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!name) {
      return res.status(400).json({ error: 'Nombre es requerido' });
    }
    const configuration = await updateStoreConfiguration(parseInt(req.params.id), parseInt(store_id), { name, description, accept_cash, accept_card, is_active, is_default, is_minimarket, default_minimarket_terminal, allow_serve, allow_takeout, hide_decimals, allow_table_service, tip_percentage, delivery_enabled, delivery_payment_methods });
    res.json(configuration);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/store-configurations/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const configId = req.params.id;
    await deleteStoreConfiguration(parseInt(configId), parseInt(store_id));
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Worker Payment Methods
app.get('/api/worker-payment-methods', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const methods = await getWorkerPaymentMethods(parseInt(storeId));
    res.json(methods);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/worker-payment-methods', authenticateToken, async (req, res) => {
  try {
    const { store_id, name, color } = req.body;
    if (!store_id || !name) return res.status(400).json({ error: 'store_id y name requeridos' });
    const method = await createWorkerPaymentMethod(parseInt(store_id), { name, color });
    res.json(method);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/worker-payment-methods/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id, name, color, is_active } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
    const method = await updateWorkerPaymentMethod(parseInt(req.params.id), parseInt(store_id), { name, color, is_active });
    res.json(method);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/worker-payment-methods/:id', authenticateToken, async (req, res) => {
  try {
    const store_id = req.query.store_id;
    if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
    await deleteWorkerPaymentMethod(parseInt(req.params.id), parseInt(store_id));
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Public endpoint for workers to see payment methods
app.get('/api/public/worker-payment-methods/:storeId', async (req, res) => {
  try {
    const methods = await getWorkerPaymentMethods(parseInt(req.params.storeId));
    res.json(methods.filter(m => m.is_active));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/public/:code/store-configurations/:id', async (req, res) => {
  try {
    const auth = await verifyStoreAccess(req.params.code, req.body);
    if (!auth.authorized) return res.status(auth.status || 403).json({ error: auth.error });
    const { name, description, accept_cash, accept_card, is_active, is_default, is_minimarket, default_minimarket_terminal, allow_serve, allow_takeout, hide_decimals } = req.body;
    if (!name) return res.status(400).json({ error: 'Nombre es requerido' });
    const configuration = await updateStoreConfiguration(parseInt(req.params.id), auth.store.id, { name, description, accept_cash, accept_card, is_active, is_default, is_minimarket, default_minimarket_terminal, allow_serve, allow_takeout, hide_decimals });
    res.json(configuration);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.get('/api/public/store-configurations/:storeId', async (req, res) => {
  try {
    const storeId = req.params.storeId;
    const configurations = await getStoreConfigurations(parseInt(storeId));
    const activeConfigs = configurations.filter(c => c.is_active);
    res.json(activeConfigs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/public/products/:storeId', async (req, res) => {
  try {
    const storeId = req.params.storeId;
    const products = await getPublicProducts(parseInt(storeId));
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/coupons', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const coupons = await getCoupons(parseInt(storeId));
    res.json(coupons);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/coupons', authenticateToken, async (req, res) => {
  try {
    const { store_id, code, name, discount_type, discount_value, min_order_total, usage_limit, is_active } = req.body;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!code || !name) {
      return res.status(400).json({ error: 'code y name son requeridos' });
    }
    const coupon = await createCoupon(parseInt(store_id), {
      code,
      name,
      discount_type,
      discount_value,
      min_order_total,
      usage_limit,
      is_active
    });
    res.json(coupon);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/coupons/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id, code, name, discount_type, discount_value, min_order_total, usage_limit, is_active } = req.body;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!code || !name) {
      return res.status(400).json({ error: 'code y name son requeridos' });
    }
    const coupon = await updateCoupon(parseInt(req.params.id), parseInt(store_id), {
      code,
      name,
      discount_type,
      discount_value,
      min_order_total,
      usage_limit,
      is_active
    });
    res.json(coupon);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/coupons/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    await deleteCoupon(parseInt(req.params.id), parseInt(store_id));
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/products', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const products = await getProducts(parseInt(storeId));
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/products/barcode/:barcode', authenticateToken, async (req, res) => {
  try {
    const { barcode } = req.params;
    const storeId = req.query.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const product = await getProductByBarcode(barcode, parseInt(storeId));
    if (!product) {
      return res.status(404).json({ error: 'Producto no encontrado' });
    }
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/products/search/:query', authenticateToken, async (req, res) => {
  try {
    const { query } = req.params;
    const storeId = req.query.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const products = await searchProducts(query, parseInt(storeId));
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all inventory for a store (products + ingredients + extras)
app.get('/api/inventory/store/:storeId', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.storeId);
    const isOwner = await verifyStoreOwnership(storeId, req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });

    const [products] = await pool.execute(`
      SELECT p.id, p.name, p.price, c.name AS category_name,
             COALESCE((SELECT stock        FROM inventory WHERE product_id = p.id LIMIT 1), 0)     AS stock,
             COALESCE((SELECT min_stock    FROM inventory WHERE product_id = p.id LIMIT 1), 0)     AS min_stock,
             COALESCE((SELECT unlimited_stock FROM inventory WHERE product_id = p.id LIMIT 1), 0)  AS unlimited_stock
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.store_id = ?
      ORDER BY p.name ASC
    `, [storeId]);

    const ingredients = await getIngredients(storeId);
    const extras = await getExtras(storeId);

    res.json({ products, ingredients, extras });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update ingredient stock/unlimited
app.put('/api/inventory/ingredient/:id/stock', authenticateToken, async (req, res) => {
  try {
    const { stock, unlimited_stock, store_id } = req.body;
    const ingId = parseInt(req.params.id);
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const s = Math.max(0, parseInt(stock) || 0);
    const u = unlimited_stock ? 1 : 0;
    await pool.execute(
      'UPDATE ingredients SET stock = ?, unlimited_stock = ? WHERE id = ? AND store_id = ?',
      [s, u, ingId, parseInt(store_id)]
    );
    req.app.get('io').to(`store_${store_id}`).emit('inventory_updated', { ingredient_id: ingId, stock: s, unlimited_stock: !!unlimited_stock });
    res.json({ stock: s, unlimited_stock: !!unlimited_stock });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update extra stock/unlimited
app.put('/api/inventory/extra/:id/stock', authenticateToken, async (req, res) => {
  try {
    const { stock, unlimited_stock, store_id } = req.body;
    const extId = parseInt(req.params.id);
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const s = Math.max(0, parseInt(stock) || 0);
    const u = unlimited_stock ? 1 : 0;
    await pool.execute(
      'UPDATE extras SET stock = ?, unlimited_stock = ? WHERE id = ? AND store_id = ?',
      [s, u, extId, parseInt(store_id)]
    );
    req.app.get('io').to(`store_${store_id}`).emit('inventory_updated', { extra_id: extId, stock: s, unlimited_stock: !!unlimited_stock });
    res.json({ stock: s, unlimited_stock: !!unlimited_stock });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/inventory/:productId', authenticateToken, async (req, res) => {
  try {
    const { productId } = req.params;
    const storeId = req.query.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const inventory = await getInventory(parseInt(productId));
    res.json(inventory);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/inventory/:productId', authenticateToken, async (req, res) => {
  try {
    const { productId } = req.params;
    const { adjustment, store_id } = req.body;
    if (adjustment === undefined) {
      return res.status(400).json({ error: 'adjustment es requerido' });
    }
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const updated = await updateInventory(parseInt(productId), parseInt(adjustment), parseInt(store_id));
    if (store_id) {
      req.app.get('io').to(`store_${store_id}`).emit('inventory_updated', { product_id: parseInt(productId), ...updated });
    }
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/inventory/:productId/stock', authenticateToken, async (req, res) => {
  try {
    const { productId } = req.params;
    const { stock, store_id } = req.body;
    if (stock === undefined) {
      return res.status(400).json({ error: 'stock es requerido' });
    }
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const updated = await setInventoryStock(parseInt(productId), parseInt(stock));
    if (store_id) {
      req.app.get('io').to(`store_${store_id}`).emit('inventory_updated', { product_id: parseInt(productId), ...updated });
    }
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/inventory/:productId/unlimited', authenticateToken, async (req, res) => {
  try {
    const { productId } = req.params;
    const { unlimited_stock, store_id } = req.body;
    if (unlimited_stock === undefined) {
      return res.status(400).json({ error: 'unlimited_stock es requerido' });
    }
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    await pool.execute(
      'INSERT INTO inventory (product_id, unlimited_stock) VALUES (?, ?) ON DUPLICATE KEY UPDATE unlimited_stock = ?',
      [parseInt(productId), unlimited_stock, unlimited_stock]
    );
    const updated = await getInventory(parseInt(productId));
    if (store_id) {
      req.app.get('io').to(`store_${store_id}`).emit('inventory_updated', { product_id: parseInt(productId), ...updated });
    }
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ─── RAW MATERIALS (Materias Primas) ─────────────────────────────────────────

app.get('/api/raw-materials/store/:storeId', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.storeId);
    const isOwner = await verifyStoreOwnership(storeId, req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No autorizado' });
    const [rows] = await pool.execute(
      'SELECT * FROM raw_materials WHERE store_id = ? ORDER BY name ASC',
      [storeId]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/raw-materials/store/:storeId', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.storeId);
    const isOwner = await verifyStoreOwnership(storeId, req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No autorizado' });
    const { name, quantity, unit, min_quantity, cost_per_unit } = req.body;
    if (!name) return res.status(400).json({ error: 'Nombre requerido' });
    const [result] = await pool.execute(
      'INSERT INTO raw_materials (store_id, name, quantity, unit, min_quantity, cost_per_unit) VALUES (?, ?, ?, ?, ?, ?)',
      [storeId, name.trim(), parseFloat(quantity) || 0, unit || 'unidades', parseFloat(min_quantity) || 0, parseFloat(cost_per_unit) || 0]
    );
    const [rows] = await pool.execute('SELECT * FROM raw_materials WHERE id = ?', [result.insertId]);
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/raw-materials/:id', authenticateToken, async (req, res) => {
  try {
    const { name, quantity, unit, min_quantity, cost_per_unit, store_id } = req.body;
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No autorizado' });
    await pool.execute(
      'UPDATE raw_materials SET name = ?, quantity = ?, unit = ?, min_quantity = ?, cost_per_unit = ? WHERE id = ? AND store_id = ?',
      [name.trim(), parseFloat(quantity) || 0, unit || 'unidades', parseFloat(min_quantity) || 0, parseFloat(cost_per_unit) || 0, parseInt(req.params.id), parseInt(store_id)]
    );
    const [rows] = await pool.execute('SELECT * FROM raw_materials WHERE id = ?', [parseInt(req.params.id)]);
    res.json(rows[0] || {});
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/raw-materials/:id/restock', authenticateToken, async (req, res) => {
  try {
    const { quantity, amount, store_id } = req.body;
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No autorizado' });
    // quantity = SET to exact value; amount (legacy) = ADD to existing
    const sql = quantity !== undefined
      ? 'UPDATE raw_materials SET quantity = ? WHERE id = ? AND store_id = ?'
      : 'UPDATE raw_materials SET quantity = quantity + ? WHERE id = ? AND store_id = ?';
    const val = quantity !== undefined ? parseFloat(quantity) : parseFloat(amount) || 0;
    await pool.execute(sql, [val, parseInt(req.params.id), parseInt(store_id)]);
    const [rows] = await pool.execute('SELECT * FROM raw_materials WHERE id = ?', [parseInt(req.params.id)]);
    res.json(rows[0] || {});
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/raw-materials/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.body;
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No autorizado' });
    await pool.execute('DELETE FROM product_recipes WHERE raw_material_id = ?', [parseInt(req.params.id)]);
    await pool.execute('DELETE FROM raw_materials WHERE id = ? AND store_id = ?', [parseInt(req.params.id), parseInt(store_id)]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── RECIPES (Recetas) ────────────────────────────────────────────────────────

app.get('/api/recipes/:itemType/:itemId', authenticateToken, async (req, res) => {
  try {
    const { itemType, itemId } = req.params;
    const [rows] = await pool.execute(
      `SELECT pr.id, pr.raw_material_id, pr.quantity_used, rm.name, rm.unit, rm.quantity AS stock, rm.cost_per_unit
       FROM product_recipes pr
       JOIN raw_materials rm ON rm.id = pr.raw_material_id
       WHERE pr.item_type = ? AND pr.item_id = ?`,
      [itemType, parseInt(itemId)]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/recipes/:itemType/:itemId', authenticateToken, async (req, res) => {
  try {
    const { itemType, itemId } = req.params;
    const { items, store_id } = req.body; // items: [{raw_material_id, quantity_used}]
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No autorizado' });
    await pool.execute('DELETE FROM product_recipes WHERE item_type = ? AND item_id = ?', [itemType, parseInt(itemId)]);
    for (const it of (items || [])) {
      if (!it.raw_material_id || !it.quantity_used) continue;
      await pool.execute(
        'INSERT INTO product_recipes (item_type, item_id, raw_material_id, quantity_used) VALUES (?, ?, ?, ?)',
        [itemType, parseInt(itemId), parseInt(it.raw_material_id), parseFloat(it.quantity_used)]
      );
    }
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── END RAW MATERIALS & RECIPES ─────────────────────────────────────────────

app.post('/api/market/create-payment', authenticateToken, async (req, res) => {
  try {
    const { store_id, terminal_id, amount, description } = req.body;

    if (!store_id || !terminal_id || !amount) {
      return res.status(400).json({ error: 'store_id, terminal_id y amount son requeridos' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }

    const terminal = await getMercadoPagoTerminalById(parseInt(terminal_id));
    if (!terminal) {
      return res.status(404).json({ error: 'Terminal no encontrada' });
    }

    const mercadopago_access_token = terminal.mercadopago_access_token;
    const mercadopago_terminal_id = terminal.mercadopago_terminal_id;

    if (!mercadopago_access_token || !mercadopago_terminal_id) {
      return res.status(400).json({ error: 'Terminal no configurada correctamente' });
    }

    const idempotencyKey = `MARKET-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    const payload = {
      type: 'point',
      external_reference: idempotencyKey,
      description: description || 'Venta Market POS',
      expiration_time: 'PT10M',
      transactions: {
        payments: [{
          amount: String(Math.round(amount))
        }]
      },
      config: {
        point: {
          terminal_id: mercadopago_terminal_id,
          print_on_terminal: 'no_ticket'
        }
      }
    };

    console.log('Enviando pago Point desde Market:', payload);

    const response = await fetch('https://api.mercadopago.com/v1/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${mercadopago_access_token}`,
        'X-Idempotency-Key': idempotencyKey
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Error de Mercado Pago:', errorText);
      return res.status(400).json({ error: `Error al procesar pago: ${errorText}` });
    }

    const mpResponse = await response.json();
    console.log('Respuesta de Mercado Pago:', mpResponse);

    res.json({
      id: mpResponse.id,
      payment_id: mpResponse.id,
      status: mpResponse.status,
      external_reference: mpResponse.external_reference,
      amount: amount,
      terminal_id: terminal_id
    });
  } catch (error) {
    console.error('Error procesando pago Market:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/market/payment-status/:mpOrderId', authenticateToken, async (req, res) => {
  try {
    const { mpOrderId } = req.params;
    const { store_id, terminal_id } = req.query;

    if (!mpOrderId) {
      return res.status(400).json({ error: 'mpOrderId es requerido' });
    }

    if (!store_id || !terminal_id) {
      return res.status(400).json({ error: 'store_id y terminal_id son requeridos' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }

    const terminal = await getMercadoPagoTerminalById(parseInt(terminal_id));
    if (!terminal) {
      return res.status(404).json({ error: 'Terminal no encontrada' });
    }

    const mercadopago_access_token = terminal.mercadopago_access_token;
    if (!mercadopago_access_token) {
      return res.status(400).json({ error: 'Mercado Pago no configurado en la terminal' });
    }

    const response = await fetch(`https://api.mercadopago.com/v1/orders/${mpOrderId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${mercadopago_access_token}`
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Error consultando estado de pago:', errorText);
      return res.status(400).json({ error: `Error al consultar estado: ${errorText}` });
    }

    const mpResponse = await response.json();
    console.log('Estado de pago Market:', mpResponse.status, mpResponse.id);

    const firstPayment = mpResponse.payments?.[0];
    const paymentStatus = firstPayment?.status || mpResponse.status;
    const paidAmount = firstPayment?.paid_amount || firstPayment?.amount?.toString() || '0';

    res.json({
      id: mpResponse.id,
      status: mpResponse.status,
      mp_status: mpResponse.status,
      payment_status: paymentStatus,
      paid_amount: paidAmount,
      external_reference: mpResponse.external_reference
    });
  } catch (error) {
    console.error('Error consultando estado de pago Market:', error);
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/products/order', authenticateToken, async (req, res) => {
  try {
    console.log('📦 Request body:', req.body);
    console.log('📦 Content-Type:', req.headers['content-type']);
    const { store_id, products } = req.body;
    console.log('📦 Received order update:', { store_id, products });
    if (!store_id || !products) {
      return res.status(400).json({ error: 'store_id y products son requeridos' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    await updateProductsOrder(parseInt(store_id), products);
    console.log('✅ Order saved to database');
    emitProductUpdate(parseInt(store_id), 'products_reordered', { products });
    res.json({ success: true });
  } catch (error) {
    console.error('❌ Error saving order:', error);
    res.status(500).json({ error: error.message });
  }
});

// --- Excel import endpoints ---

app.get('/api/products/excel-template', authenticateToken, (req, res) => {
  const wb = XLSX.utils.book_new();
  const rows = [
    ['Nombre', 'Descripcion', 'Precio', 'Categoria', 'Codigo_Barras', 'Imagen_URL'],
    ['Ejemplo Pizza', 'Pizza napolitana grande', '10.99', 'Comidas', '', 'https://ejemplo.com/pizza.jpg'],
    ['Ejemplo Bebida', 'Gaseosa 500ml', '2.50', 'Bebidas', '7891234567890', '']
  ];
  const ws = XLSX.utils.aoa_to_sheet(rows);
  ws['!cols'] = [{ wch: 28 }, { wch: 35 }, { wch: 12 }, { wch: 20 }, { wch: 20 }, { wch: 40 }];
  XLSX.utils.book_append_sheet(wb, ws, 'Productos');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', 'attachment; filename="plantilla_productos.xlsx"');
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

app.post('/api/products/excel-preview', authenticateToken, excelUpload.single('file'), async (req, res) => {
  try {
    const { store_id } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    if (!req.file) return res.status(400).json({ error: 'No se recibió ningún archivo' });

    const wb = XLSX.read(req.file.buffer, { type: 'buffer' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const raw = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });

    if (raw.length < 2) return res.status(400).json({ error: 'El archivo está vacío o solo tiene encabezados' });

    const header = raw[0].map(h => String(h).trim().toLowerCase());
    const colIdx = {
      nombre: header.findIndex(h => h === 'nombre'),
      descripcion: header.findIndex(h => h === 'descripcion' || h === 'descripción'),
      precio: header.findIndex(h => h === 'precio'),
      categoria: header.findIndex(h => h === 'categoria' || h === 'categoría'),
      barcode: header.findIndex(h => h === 'codigo_barras' || h === 'código_barras' || h === 'barcode' || h === 'codigo barras'),
      image_url: header.findIndex(h => h === 'imagen_url' || h === 'image_url' || h === 'imagen' || h === 'url_imagen')
    };

    if (colIdx.nombre === -1 || colIdx.precio === -1) {
      return res.status(400).json({ error: 'El archivo debe tener columnas "Nombre" y "Precio"' });
    }

    const rows = [];
    for (let i = 1; i < raw.length; i++) {
      const row = raw[i];
      const name = String(row[colIdx.nombre] ?? '').trim();
      const price = parseFloat(String(row[colIdx.precio] ?? '').replace(',', '.'));
      if (!name) continue;
      rows.push({
        name,
        description: colIdx.descripcion >= 0 ? String(row[colIdx.descripcion] ?? '').trim() : '',
        price: isNaN(price) ? 0 : price,
        category: colIdx.categoria >= 0 ? String(row[colIdx.categoria] ?? '').trim() : '',
        barcode: colIdx.barcode >= 0 ? String(row[colIdx.barcode] ?? '').trim() : '',
        image_url: colIdx.image_url >= 0 ? String(row[colIdx.image_url] ?? '').trim() : ''
      });
    }

    res.json({ rows, total: rows.length });
  } catch (error) {
    res.status(500).json({ error: 'Error al leer el archivo: ' + error.message });
  }
});

app.post('/api/products/excel-import', authenticateToken, async (req, res) => {
  try {
    const { store_id, rows } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    if (!Array.isArray(rows) || rows.length === 0) return res.status(400).json({ error: 'No hay productos para importar' });

    const [cats] = await pool.execute('SELECT id, name FROM categories WHERE store_id = ?', [parseInt(store_id)]);
    const catMap = {};
    cats.forEach(c => { catMap[c.name.trim().toLowerCase()] = c.id; });

    const results = { created: 0, skipped: 0, errors: [] };

    for (const row of rows) {
      try {
        if (!row.name || row.price === undefined) { results.skipped++; continue; }
        const catId = row.category ? (catMap[row.category.toLowerCase()] ?? null) : null;
        await createProduct(parseInt(store_id), {
          name: row.name,
          description: row.description || '',
          price: parseFloat(row.price) || 0,
          category_id: catId,
          barcode: row.barcode || null,
          image: row.image_url || null,
          has_extras: false,
          has_ingredients: false,
          max_extras: 0,
          max_ingredients: 0
        });
        results.created++;
      } catch (err) {
        results.errors.push({ name: row.name, error: err.message });
        results.skipped++;
      }
    }

    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// --- end Excel import ---

app.post('/api/products', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { store_id, name, barcode, description, price, category_id, has_extras, has_ingredients, max_extras, max_ingredients } = req.body;

    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!name || price === undefined) {
      return res.status(400).json({ error: 'Nombre y precio son requeridos' });
    }

    const imageUrl = req.file ? `/uploads/${req.file.filename}` : (req.body.image_url || null);

    const product = await createProduct(parseInt(store_id), {
      name,
      barcode,
      description,
      price,
      category_id,
      image: imageUrl,
      has_extras: has_extras === 'true' || has_extras === true,
      has_ingredients: has_ingredients === 'true' || has_ingredients === true,
      max_extras: parseInt(max_extras) || 0,
      max_ingredients: parseInt(max_ingredients) || 0
    });

    // Secciones dinámicas asignadas
    if (req.body.complement_group_ids !== undefined) {
      let gids = req.body.complement_group_ids;
      if (typeof gids === 'string') { try { gids = JSON.parse(gids); } catch { gids = []; } }
      await setProductComplementGroups(product.id, Array.isArray(gids) ? gids : []);
      product.complement_group_ids = await getProductComplementGroupIds(product.id);
    }

    emitProductUpdate(parseInt(store_id), 'product_created', product);
    if (pluginManager) pluginManager.hooks.emit('product_created', { store_id: parseInt(store_id), product });
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/products/:id', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { store_id, name, barcode, description, price, category_id, has_extras, has_ingredients, max_extras, max_ingredients } = req.body;

    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    if (!name || price === undefined) {
      return res.status(400).json({ error: 'Nombre y precio son requeridos' });
    }

    let imageUrl;
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    } else if (req.body.image_url) {
      imageUrl = req.body.image_url;
    } else {
      const existingProduct = await getProductById(req.params.id);
      imageUrl = existingProduct?.image || null;
    }

    const product = await updateProduct(parseInt(req.params.id), parseInt(store_id), {
      name,
      barcode,
      description,
      price,
      category_id,
      image: imageUrl,
      has_extras: has_extras === 'true' || has_extras === true,
      has_ingredients: has_ingredients === 'true' || has_ingredients === true,
      max_extras: parseInt(max_extras) || 0,
      max_ingredients: parseInt(max_ingredients) || 0
    });

    // Secciones dinámicas asignadas
    if (req.body.complement_group_ids !== undefined) {
      let gids = req.body.complement_group_ids;
      if (typeof gids === 'string') { try { gids = JSON.parse(gids); } catch { gids = []; } }
      await setProductComplementGroups(parseInt(req.params.id), Array.isArray(gids) ? gids : []);
      product.complement_group_ids = await getProductComplementGroupIds(parseInt(req.params.id));
    }

    emitProductUpdate(parseInt(store_id), 'product_updated', product);
    if (pluginManager) pluginManager.hooks.emit('product_updated', { store_id: parseInt(store_id), product });
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/products/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const productId = req.params.id;
    await deleteProduct(parseInt(productId), parseInt(store_id));
    emitProductUpdate(parseInt(store_id), 'product_deleted', { id: productId });
    if (pluginManager) pluginManager.hooks.emit('product_deleted', { store_id: parseInt(store_id), product_id: parseInt(productId) });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============ ESTADO DE RESULTADOS / GASTOS (admin) ============
app.get('/api/income-statement', authenticateToken, async (req, res) => {
  try {
    const { store_id, from, to } = req.query;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    res.json(await getIncomeStatement(parseInt(store_id), from || null, to || null));
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.get('/api/expenses', authenticateToken, async (req, res) => {
  try {
    const { store_id, from, to } = req.query;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    res.json(await getStoreExpenses(parseInt(store_id), from || null, to || null));
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.post('/api/expenses', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.body;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    const r = await addStoreExpense(parseInt(store_id), req.body);
    res.json(r);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.delete('/api/expenses/:id', authenticateToken, async (req, res) => {
  try {
    const store_id = req.query.store_id || req.body.store_id;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    await deleteStoreExpense(parseInt(req.params.id), parseInt(store_id));
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// ============ SECCIONES DINÁMICAS (admin) ============
async function requireStoreOwner(req, res, storeId) {
  if (!storeId) { res.status(400).json({ error: 'store_id es requerido' }); return false; }
  const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
  if (!isOwner) { res.status(403).json({ error: 'No tienes acceso a esta tienda' }); return false; }
  return true;
}

app.get('/api/complement-groups', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    if (!(await requireStoreOwner(req, res, storeId))) return;
    res.json(await getComplementGroups(parseInt(storeId)));
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.post('/api/complement-groups', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.body;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    if (!req.body.name || !req.body.name.trim()) return res.status(400).json({ error: 'Nombre requerido' });
    const r = await createComplementGroup(parseInt(store_id), req.body);
    emitProductUpdate(parseInt(store_id), 'complement_group_created', { id: r.id });
    res.json(r);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/complement-groups/reorder', authenticateToken, async (req, res) => {
  try {
    const { store_id, ids } = req.body;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    await reorderComplementGroups(parseInt(store_id), ids || []);
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/complement-groups/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.body;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    await updateComplementGroup(parseInt(req.params.id), parseInt(store_id), req.body);
    emitProductUpdate(parseInt(store_id), 'complement_group_updated', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.delete('/api/complement-groups/:id', authenticateToken, async (req, res) => {
  try {
    const store_id = req.query.store_id || req.body.store_id;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    await deleteComplementGroup(parseInt(req.params.id), parseInt(store_id));
    emitProductUpdate(parseInt(store_id), 'complement_group_deleted', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.post('/api/complement-options', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { store_id, group_id } = req.body;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    const image = req.file ? `/uploads/${req.file.filename}` : null;
    const r = await createComplementOption(parseInt(store_id), parseInt(group_id), {
      name: req.body.name, price: req.body.price, image,
      stock: req.body.stock, unlimited_stock: req.body.unlimited_stock === 'true' || req.body.unlimited_stock === true
    });
    emitProductUpdate(parseInt(store_id), 'complement_option_created', { id: r.id });
    res.json(r);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/complement-options/reorder', authenticateToken, async (req, res) => {
  try {
    const { store_id, ids } = req.body;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    await reorderComplementOptions(parseInt(store_id), ids || []);
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.put('/api/complement-options/:id', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { store_id } = req.body;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    const data = {
      name: req.body.name, price: req.body.price,
      stock: req.body.stock, unlimited_stock: req.body.unlimited_stock === 'true' || req.body.unlimited_stock === true
    };
    if (req.file) data.image = `/uploads/${req.file.filename}`;
    await updateComplementOption(parseInt(req.params.id), parseInt(store_id), data);
    emitProductUpdate(parseInt(store_id), 'complement_option_updated', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

app.delete('/api/complement-options/:id', authenticateToken, async (req, res) => {
  try {
    const store_id = req.query.store_id || req.body.store_id;
    if (!(await requireStoreOwner(req, res, store_id))) return;
    await deleteComplementOption(parseInt(req.params.id), parseInt(store_id));
    emitProductUpdate(parseInt(store_id), 'complement_option_deleted', { id: req.params.id });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// ============ COMBOS (admin) ============
function parseComboItems(raw) {
  if (raw === undefined || raw === null) return undefined;
  if (Array.isArray(raw)) return raw;
  if (typeof raw === 'string') {
    try { const parsed = JSON.parse(raw); return Array.isArray(parsed) ? parsed : []; }
    catch { return []; }
  }
  return [];
}

app.get('/api/combos', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const combos = await getCombos(parseInt(store_id));
    res.json(combos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/combos', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { store_id, name, description, is_active } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    if (!name) return res.status(400).json({ error: 'El nombre es requerido' });

    const imageUrl = req.file ? `/uploads/${req.file.filename}` : (req.body.image_url || null);
    const combo = await createCombo(parseInt(store_id), {
      name,
      description,
      image: imageUrl,
      is_active: is_active === undefined ? true : (is_active === 'true' || is_active === true),
      items: parseComboItems(req.body.items) || []
    });
    res.json(combo);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/combos/:id', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    const { store_id, name, description, is_active } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    if (!name) return res.status(400).json({ error: 'El nombre es requerido' });

    let imageUrl;
    if (req.file) imageUrl = `/uploads/${req.file.filename}`;
    else if (req.body.image_url) imageUrl = req.body.image_url;
    else imageUrl = req.body.existing_image || null;

    const combo = await updateCombo(parseInt(req.params.id), parseInt(store_id), {
      name,
      description,
      image: imageUrl,
      is_active: is_active === undefined ? true : (is_active === 'true' || is_active === true),
      items: parseComboItems(req.body.items)
    });
    res.json(combo);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/combos/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    await deleteCombo(parseInt(req.params.id), parseInt(store_id));
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const { store_id, items, order_type, payment_method, coupon_code, from_worker, delivery, table_number, persons, custom_total, total, terminal_id,
            source, delivery_address, delivery_customer_id, customer_email, customer_name, customer_phone, event_name, show_time } = req.body;

    if (!store_id || !items || items.length === 0) {
      return res.status(400).json({ error: 'Datos del pedido incompletos' });
    }

    // custom_total overrides computed total; fallback to `total` sent by client (includes tip)
    const resolvedTotal = custom_total ?? total ?? null;
    console.log('Creating order:', { store_id, order_type, payment_method, table_number, terminal_id, resolvedTotal, source });
    const order = await createOrder(parseInt(store_id), {
      order_type, payment_method, items, coupon_code, from_worker, delivery, table_number, persons: persons || null,
      custom_total: resolvedTotal, terminal_id: terminal_id ? parseInt(terminal_id) : null,
      source, delivery_address, delivery_customer_id, customer_email, customer_name, customer_phone,
      event_name: event_name || null, show_time: show_time || null
    });

    const socketId = userSockets.get(parseInt(store_id));
    if (socketId) {
      io.to(socketId).emit('new_order', order);
    }
    // Broadcast para superadmin
    io.emit('superadmin_new_order', {
      id: order.id, order_number: order.order_number, store_id: order.store_id,
      total: order.total, payment_method: order.payment_method, created_at: order.created_at
    });

    if (pluginManager) {
      pluginManager.hooks.emit('order_created', { store_id: parseInt(store_id), order });
      if (payment_method === 'cash') {
        pluginManager.hooks.emit('payment_completed', { store_id: parseInt(store_id), order, payment_method: 'cash' });
      }
    }

    // Imprimir comprobante en terminal MercadoPago para pedidos de efectivo
    if (payment_method === 'cash' && terminal_id) {
      (async () => {
        try {
          let apiKey, mpDeviceId;
          const posTerminal = await getPosTerminalForStore(parseInt(store_id), parseInt(terminal_id));
          if (posTerminal && posTerminal.provider === 'mercadopago') {
            apiKey = posTerminal.api_key;
            mpDeviceId = posTerminal.device_id;
          } else {
            const legacyTerminal = await getMercadoPagoTerminalForStore(parseInt(store_id), parseInt(terminal_id));
            if (legacyTerminal) {
              apiKey = legacyTerminal.mercadopago_access_token;
              mpDeviceId = legacyTerminal.mercadopago_terminal_id;
            }
          }
          if (!apiKey || !mpDeviceId) return;

          const cashItems = await getOrderItems(order.id);
          const now = new Date();
          const timeStr = now.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });

          let itemsContent = '';
          for (const item of cashItems) {
            const name = (item.product_name || item.name || `Producto ${item.product_id}`).substring(0, 28);
            const price = Number((item.unit_price || 0) * (item.quantity || 1)).toFixed(0);
            itemsContent += `{br}${item.quantity}x ${name}{br}{s}  $${price}{/s}`;
          }

          const total = Number(order.total || 0).toFixed(0);
          const content = `{br}{center}{w}Pedido #${order.order_number}{/w}{br}{center}${timeStr}{br}{br}--------------------------------${itemsContent}{br}--------------------------------{br}{center}{w}TOTAL: $${total}{/w}{br}{br}{center}Por favor pagar{br}{center}{w}con efectivo en caja{/w}{br}{br}`;

          const mpRes = await fetch('https://api.mercadopago.com/terminals/v1/actions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Idempotency-Key': `print-cash-${order.id}-${Date.now()}`,
              'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
              type: 'print',
              external_reference: `order-cash-${order.id}-${Date.now()}`,
              config: { point: { terminal_id: mpDeviceId, subtype: 'custom' } },
              content
            })
          });
          if (!mpRes.ok) {
            const errData = await mpRes.json().catch(() => ({}));
            console.error('[MP Print] Error al imprimir comprobante efectivo:', errData);
          }
        } catch (printErr) {
          console.error('[MP Print] Error al imprimir comprobante efectivo:', printErr.message);
        }
      })();
    }

    res.json(order);
  } catch (error) {
    console.error('❌ Error creando orden:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/orders/process-payment', async (req, res) => {
  try {
    const { store_id, items, order_type, payment_method, selected_terminal_id, coupon_code, table_number, custom_total } = req.body;

    if (!store_id || !items || items.length === 0) {
      return res.status(400).json({ error: 'Datos del pedido incompletos' });
    }

    if (payment_method === 'card') {
      console.log('Procesando pago con tarjeta:', { store_id, order_type, selected_terminal_id });

      // Detectar proveedor desde el terminal seleccionado
      let provider = 'mercadopago';
      if (selected_terminal_id) {
        const terminalInfo = await getPosTerminalForStore(parseInt(store_id), parseInt(selected_terminal_id));
        if (terminalInfo?.provider) provider = terminalInfo.provider;
      }
      console.log('Proveedor detectado:', provider);

      let paymentResult;
      if (provider === 'sumup') {
        paymentResult = await processSumUpPayment(parseInt(store_id), {
          items,
          order_type,
          selected_terminal_id: parseInt(selected_terminal_id),
          coupon_code
        });
        console.log('Checkout SumUp creado:', JSON.stringify(paymentResult));
      } else {
        paymentResult = await processMercadoPagoPayment(parseInt(store_id), {
          items,
          order_type,
          selected_terminal_id: selected_terminal_id ? parseInt(selected_terminal_id) : null,
          coupon_code
        });
        console.log('Pago Mercado Pago procesado:', JSON.stringify(paymentResult));
      }

      const order = await createOrder(parseInt(store_id), {
        order_type,
        payment_method: 'card',
        items,
        mp_order_id: paymentResult.mp_order_id,
        external_reference: paymentResult.external_reference,
        coupon_code,
        terminal_id: selected_terminal_id ? parseInt(selected_terminal_id) : null,
        table_number,
        custom_total
      });

      const socketId = userSockets.get(parseInt(store_id));
      if (socketId) {
        io.to(socketId).emit('new_order', order);
      }
      io.emit('superadmin_new_order', {
        id: order.id, order_number: order.order_number, store_id: order.store_id,
        total: order.total, payment_method: order.payment_method, created_at: order.created_at
      });

      if (pluginManager) {
        pluginManager.hooks.emit('order_created', { store_id: parseInt(store_id), order });
        pluginManager.hooks.emit('payment_started', { store_id: parseInt(store_id), order, payment_method: 'card' });
      }

      res.json({
        success: true,
        order,
        mp_status: paymentResult.status
      });
    } else {
      return res.status(400).json({ error: 'Metodo de pago no soportado para este endpoint' });
    }
  } catch (error) {
    console.error('❌ Error procesando pago:', error);
    const isValidationError = [
      'Configuracion de Mercado Pago',
      'Configuración de SumUp',
      'La máquina seleccionada',
      'La máquina SumUp',
      'Cupón'
    ].some(text => String(error.message || '').includes(text));
    res.status(isValidationError ? 400 : 500).json({ error: error.message });
  }
});

app.post('/api/mercadopago/print-cash-receipt', async (req, res) => {
  try {
    const { store_id, terminal_db_id, content } = req.body;
    if (!store_id || !terminal_db_id || !content) {
      return res.status(400).json({ error: 'store_id, terminal_db_id y content requeridos' });
    }

    // Try unified pos_terminals first, then legacy table
    let apiKey, mpDeviceId;
    const posTerminal = await getPosTerminalForStore(parseInt(store_id), parseInt(terminal_db_id));
    if (posTerminal && posTerminal.provider === 'mercadopago') {
      apiKey = posTerminal.api_key;
      mpDeviceId = posTerminal.device_id;
    } else {
      const legacyTerminal = await getMercadoPagoTerminalForStore(parseInt(store_id), parseInt(terminal_db_id));
      if (!legacyTerminal) return res.status(404).json({ error: 'Terminal no encontrada para esta tienda' });
      apiKey = legacyTerminal.mercadopago_access_token;
      mpDeviceId = legacyTerminal.mercadopago_terminal_id;
    }

    const payload = {
      type: 'print',
      external_reference: `cash-${terminal_db_id}-${Date.now()}`,
      config: { point: { terminal_id: mpDeviceId, subtype: 'image' } },
      content
    };

    const mpRes = await fetch('https://api.mercadopago.com/terminals/v1/actions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Idempotency-Key': `cash-print-${terminal_db_id}-${Date.now()}`,
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify(payload)
    });

    const mpData = await mpRes.json();
    if (!mpRes.ok) {
      console.error('MP print-cash-receipt error:', mpData);
      return res.status(mpRes.status).json({ error: mpData.message || 'Error al imprimir en terminal', details: mpData });
    }

    return res.json({ success: true, data: mpData });
  } catch (err) {
    console.error('Error print-cash-receipt:', err);
    return res.status(500).json({ error: 'Error interno del servidor' });
  }
});

app.get('/api/orders/:orderId/payment-status', async (req, res) => {
  try {
    const { orderId } = req.params;
    const storeId = req.query.store_id;
    console.log('>>> payment-status endpoint llamado | orderId:', orderId, '| storeId:', storeId);
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }

    const store = await getStoreById(parseInt(storeId));
    const [orders] = await pool.execute(
      'SELECT * FROM orders WHERE id = ? AND store_id = ?',
      [parseInt(orderId), parseInt(storeId)]
    );

    if (orders.length === 0) {
      return res.status(404).json({ error: 'Orden no encontrada' });
    }

    const order = orders[0];

    if (order.payment_method !== 'card') {
      const status = order.status === 'completed' ? 'approved' : 'pending';
      return res.json({ mp_status: status, payment_status: status, order_status: order.status, order, mp_full: null });
    }

    // ── SumUp: rama separada antes de cualquier lógica de MP ──
    if (order.terminal_id) {
      const terminal = await getPosTerminalForStore(parseInt(storeId), order.terminal_id);
      if (terminal?.provider === 'sumup') {
        if (!order.mp_order_id) {
          return res.json({ mp_status: 'pending', payment_status: 'pending', order_status: order.status, order, mp_full: null });
        }
        try {
          const sumupData = await getSumUpCheckoutStatus(order.mp_order_id, terminal.api_key);
          console.log('SumUp checkout status:', sumupData.id, sumupData.status);

          // SumUp statuses: PENDING → PAID / FAILED / EXPIRED
          const rawStatus = (sumupData.status || '').toUpperCase();

          if (rawStatus === 'FAILED' || rawStatus === 'EXPIRED') {
            await updateOrderStatus(parseInt(orderId), parseInt(storeId), 'canceled');
            const [canceledRows] = await pool.execute('SELECT * FROM orders WHERE id = ? AND store_id = ?', [parseInt(orderId), parseInt(storeId)]);
            return res.json({ mp_status: rawStatus.toLowerCase(), payment_status: 'canceled', paid_amount: '0', order_status: 'canceled', order: canceledRows[0], mp_full: sumupData });
          }

          const paymentStatus = rawStatus === 'PAID' ? 'approved' : 'pending';
          const paidAmount = rawStatus === 'PAID' ? String(sumupData.amount || order.total || '0') : '0';
          return res.json({ mp_status: rawStatus.toLowerCase(), payment_status: paymentStatus, paid_amount: paidAmount, order_status: order.status, order, mp_full: sumupData });
        } catch (err) {
          console.error('Error consultando SumUp:', err.message);
          return res.json({ mp_status: 'pending', payment_status: 'pending', order_status: order.status, order, mp_full: null });
        }
      }
    }

    let mercadopagoAccessToken = store?.mercadopago_access_token;
    if (order.terminal_id) {
      const [posRows] = await pool.execute(
        "SELECT api_key FROM pos_terminals WHERE id = ? AND provider = 'mercadopago'",
        [order.terminal_id]
      );
      if (posRows[0]?.api_key) mercadopagoAccessToken = posRows[0].api_key;
    }
    if (!mercadopagoAccessToken) {
      return res.json({ mp_status: 'pending', payment_status: 'pending', order_status: order.status, order, mp_full: null });
    }

    let mpStatus = null;
    let mpOrderId = order.mp_order_id;
    console.log('  mp_order_id desde DB:', mpOrderId, '| external_reference:', order.external_reference);

    if (mpOrderId) {
      try {
        console.log('  Llamando getMercadoPagoOrderStatus con:', mpOrderId);
        mpStatus = await getMercadoPagoOrderStatus(mpOrderId, mercadopagoAccessToken);
        console.log('  getMercadoPagoOrderStatus result status:', mpStatus?.status);
      } catch (err) {
        console.log('  [ERROR getMercadoPagoOrderStatus]:', err.message);
        mpStatus = null;
      }
    }

    console.log('  mpStatus después de consulta:', mpStatus ? mpStatus.status : 'null');
    console.log('  Intentando busqueda por external_reference:', order.external_reference);
    if (!mpStatus && order.external_reference) {
      try {
        const today = new Date();
        const beginDate = new Date(today.getFullYear(), today.getMonth(), today.getDate()).toISOString();
        const endDate = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1).toISOString();
        const searchUrl = `https://api.mercadopago.com/v1/orders?limit=50&begin_date=${beginDate}&end_date=${endDate}`;
        const searchRes = await fetch(searchUrl, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${mercadopagoAccessToken}`
          }
        });
        const searchData = await searchRes.json();
        console.log('=== MP ORDERS SEARCH ===');
        console.log('Total orders found:', (searchData.data || []).length);
        (searchData.data || []).forEach(o => {
          console.log('  MP Order:', o.id, '| status:', o.status, '| external_reference:', o.external_reference);
        });
        console.log('=== END MP ORDERS SEARCH ===');
        const found = (searchData.data || []).find(o => o.external_reference === order.external_reference);
        if (found) {
          mpOrderId = found.id;
          mpStatus = found;
          await pool.execute('UPDATE orders SET mp_order_id = ? WHERE id = ?', [mpOrderId, parseInt(orderId)]);
          console.log('mp_order_id actualizado desde busqueda:', mpOrderId, '| status:', found.status);
        }
      } catch (err) {
        console.log('Error buscando orden en MP:', err.message);
      }
    }

    if (!mpStatus) {
      return res.json({ mp_status: 'pending', payment_status: 'pending', order_status: order.status, order, mp_full: null });
    }

    // La nueva API de MP Point usa "processed" para pagos exitosos (no "approved").
    // "action_required" = pago procesado en terminal pero requiere confirmación manual → tratar como aprobado.
    const MP_APPROVED = ['processed', 'action_required'];
    const rawStatus = mpStatus.transactions?.payments?.[0]?.status || mpStatus.status;
    const paymentStatus = (MP_APPROVED.includes(rawStatus) || MP_APPROVED.includes(mpStatus.status)) ? 'approved' : rawStatus;
    const paidAmount =
      mpStatus.transactions?.payments?.[0]?.paid_amount ||
      mpStatus.transactions?.payments?.[0]?.amount ||
      (MP_APPROVED.includes(mpStatus.status) ? '1' : '0');

    if (mpStatus.status === 'canceled' || mpStatus.status === 'expired' || mpStatus.status === 'failed') {
      await updateOrderStatus(parseInt(orderId), parseInt(storeId), 'canceled');
      const [rows] = await pool.execute(
        'SELECT * FROM orders WHERE id = ? AND store_id = ?',
        [parseInt(orderId), parseInt(storeId)]
      );
      return res.json({
        mp_status: mpStatus.status,
        payment_status: paymentStatus,
        paid_amount: paidAmount,
        order_status: 'canceled',
        order: rows[0],
        mp_full: mpStatus
      });
    }

    const result = {
      mp_status: mpStatus.status,
      payment_status: paymentStatus,
      paid_amount: paidAmount,
      order_status: order.status,
      order: order,
      mp_full: mpStatus
    };
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/debug/order/:orderId', async (req, res) => {
  try {
    const { orderId } = req.params;
    const { store_id } = req.query;
    const [orders] = await pool.execute(
      'SELECT * FROM orders WHERE id = ? AND store_id = ?',
      [parseInt(orderId), parseInt(store_id)]
    );
    const [cols] = await pool.execute('SHOW COLUMNS FROM orders');
    res.json({ order: orders[0] || null, columns: cols.map(c => c.Field) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/orders/:orderId/confirm-payment', async (req, res) => {
  try {
    const { orderId } = req.params;
    const storeId = req.body.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }

    const updatedOrder = await confirmCardPayment(parseInt(orderId), parseInt(storeId));

    let orderItems = null;
    if (updatedOrder) {
      orderItems = await getOrderItems(parseInt(orderId));
    }

    const socketId = userSockets.get(parseInt(storeId));
    if (socketId && updatedOrder) {
      io.to(socketId).emit('payment_confirmed', { ...updatedOrder, items: orderItems });
    }

    if (pluginManager && updatedOrder) {
      pluginManager.hooks.emit('payment_completed', { store_id: parseInt(storeId), order: updatedOrder, payment_method: 'card' });
    }

    // Imprimir comprobante en terminal MercadoPago si corresponde
    if (updatedOrder?.terminal_id) {
      (async () => {
        try {
          let apiKey, mpDeviceId;
          const posTerminal = await getPosTerminalForStore(parseInt(storeId), updatedOrder.terminal_id);
          if (posTerminal && posTerminal.provider === 'mercadopago') {
            apiKey = posTerminal.api_key;
            mpDeviceId = posTerminal.device_id;
          } else {
            const legacyTerminal = await getMercadoPagoTerminalForStore(parseInt(storeId), updatedOrder.terminal_id);
            if (legacyTerminal) {
              apiKey = legacyTerminal.mercadopago_access_token;
              mpDeviceId = legacyTerminal.mercadopago_terminal_id;
            }
          }
          if (!apiKey || !mpDeviceId) return;

          const items = orderItems || await getOrderItems(parseInt(orderId));
          const now = new Date();
          const timeStr = now.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });

          let itemsContent = '';
          for (const item of items) {
            const name = (item.product_name || item.name || `Producto ${item.product_id}`).substring(0, 28);
            const price = Number((item.unit_price || 0) * (item.quantity || 1)).toFixed(0);
            itemsContent += `{br}${item.quantity}x ${name}{br}{s}  $${price}{/s}`;
          }

          const total = Number(updatedOrder.total || 0).toFixed(0);
          const content = `{br}{center}{w}Pedido #${updatedOrder.order_number}{/w}{br}{center}${timeStr}{br}{br}--------------------------------${itemsContent}{br}--------------------------------{br}{center}{w}TOTAL: $${total}{/w}{br}{br}{center}Pago con tarjeta{br}{br}`;

          const payload = {
            type: 'print',
            external_reference: `order-${orderId}-${Date.now()}`,
            config: { point: { terminal_id: mpDeviceId, subtype: 'custom' } },
            content
          };

          const mpRes = await fetch('https://api.mercadopago.com/terminals/v1/actions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Idempotency-Key': `print-${orderId}-${Date.now()}`,
              'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify(payload)
          });
          if (!mpRes.ok) {
            const errData = await mpRes.json().catch(() => ({}));
            console.error('[MP Print] Error al imprimir comprobante:', errData);
          }
        } catch (printErr) {
          console.error('[MP Print] Error al imprimir comprobante:', printErr.message);
        }
      })();
    }

    res.json({ success: true, order: updatedOrder });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/orders/:orderId/cancel-payment', async (req, res) => {
  try {
    const { orderId } = req.params;
    const storeId = req.body.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }

    const [orders] = await pool.execute(
      'SELECT * FROM orders WHERE id = ? AND store_id = ?',
      [parseInt(orderId), parseInt(storeId)]
    );

    if (orders.length === 0) {
      return res.status(404).json({ error: 'Orden no encontrada' });
    }

    const order = orders[0];
    if (!order.mp_order_id) {
      return res.status(400).json({ error: 'Esta orden no tiene un pago de Mercado Pago' });
    }

    const store = await getStoreById(parseInt(storeId));
    let mercadopagoAccessToken = store?.mercadopago_access_token;
    if (order.terminal_id) {
      const [posRows] = await pool.execute(
        "SELECT api_key FROM pos_terminals WHERE id = ? AND provider = 'mercadopago'",
        [order.terminal_id]
      );
      if (posRows[0]?.api_key) mercadopagoAccessToken = posRows[0].api_key;
    }

    if (mercadopagoAccessToken) {
      try {
        await cancelMercadoPagoOrder(order.mp_order_id, mercadopagoAccessToken);
      } catch (cancelError) {
        console.error('Error cancelando orden en Mercado Pago:', cancelError.message);
      }
    }

    await pool.execute(
      'UPDATE orders SET status = ? WHERE id = ? AND store_id = ?',
      ['canceled', parseInt(orderId), parseInt(storeId)]
    );

    if (pluginManager) {
      pluginManager.hooks.emit('payment_failed', { store_id: parseInt(storeId), order_id: parseInt(orderId), reason: 'canceled' });
    }

    res.json({ success: true, message: 'Pago cancelado' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/store/:code/tv-orders', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });

    const [rows] = await pool.execute(
      `SELECT id, order_number, status, total, created_at, completed_at
       FROM orders
       WHERE store_id = ? AND payment_process = 1
         AND (
           (status IN ('preparing', 'ready') AND DATE(created_at) = CURDATE())
           OR
           (status = 'completed' AND completed_at >= NOW() - INTERVAL 5 MINUTE)
         )
       ORDER BY created_at ASC`,
      [store.id]
    );

    res.json({
      store: {
        code: store.code,
        name: store.name,
        primary_color: store.primary_color || '#000000',
        secondary_color: store.secondary_color || '#FFFFFF',
        accent_color: store.accent_color || '#D4AF37',
        logo_url: store.logo_url || null
      },
      preparing: rows.filter(o => o.status === 'preparing').map(o => ({
        id: o.id,
        order_number: o.order_number,
        created_at: o.created_at
      })),
      ready: rows.filter(o => o.status === 'ready').map(o => ({
        id: o.id,
        order_number: o.order_number,
        created_at: o.created_at
      })),
      completed: rows.filter(o => o.status === 'completed').map(o => ({
        id: o.id,
        order_number: o.order_number,
        completed_at: o.completed_at
      }))
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/store/:code/orders', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });

    const [rows] = await pool.execute(
      `SELECT o.*, w.name as completed_by_name
       FROM orders o
       LEFT JOIN workers w ON o.completed_by = w.id
       WHERE o.store_id = ? AND o.payment_process = 1 AND DATE(o.created_at) = CURDATE()
       ORDER BY o.created_at DESC`,
      [store.id]
    );

    const orders = [];
    for (const order of rows) {
      const [items] = await pool.execute(
        `SELECT oi.*, COALESCE(p.name, 'Producto eliminado') as product_name
         FROM order_items oi
         LEFT JOIN products p ON oi.product_id = p.id
         WHERE oi.order_id = ?`,
        [order.id]
      );
      orders.push({
        id: order.id,
        external_reference: order.external_reference,
        sequence_id: order.sequence_id,
        reference_id: order.reference_id,
        order_number: order.order_number,
        order_type: order.order_type,
        status: order.status,
        cash_approved: order.cash_approved ? 1 : 0,
        payment_process: order.payment_process,
        total: parseFloat(order.total),
        subtotal: parseFloat(order.subtotal || 0),
        discount_total: parseFloat(order.discount_total || 0),
        payment_method: order.payment_method,
        coupon_code: order.coupon_code,
        completed_by_name: order.completed_by_name,
        created_at: order.created_at,
        table_number: order.table_number ?? null,
        reprint_count: order.reprint_count || 0,
        service_type: order.order_type === 'takeout' ? 'llevar' : 'servir',
        event_name: order.event_name || null,
        show_time: order.show_time || null,
        items: items.map(item => ({
          id: item.id,
          product_id: item.product_id,
          product_name: item.product_name,
          quantity: item.quantity,
          unit_price: parseFloat(item.unit_price),
          selected_ingredients: JSON.parse(item.selected_ingredients || '[]'),
          selected_extras: JSON.parse(item.selected_extras || '[]')
        }))
      });
    }

    res.json({
      store: { code: store.code, name: store.name },
      total_orders: orders.length,
      orders
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/orders', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const orders = await getOrders(parseInt(storeId));
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/orders/store/:storeId', async (req, res) => {
  try {
    const { storeId } = req.params;
    const orders = await getOrders(parseInt(storeId), true);
    res.json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/orders/store/:storeId/whatsapp', async (req, res) => {
  try {
    const { storeId } = req.params;
    const orders = await getWhatsAppOrders(parseInt(storeId));
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/orders/store/:storeId/find', async (req, res) => {
  try {
    const { storeId } = req.params;
    const { q } = req.query;
    if (!q?.trim()) return res.json(null);
    const term = q.trim().toUpperCase();
    const [rows] = await pool.execute(
      `SELECT o.*, w.name as completed_by_name
       FROM orders o
       LEFT JOIN workers w ON o.completed_by = w.id
       WHERE o.store_id = ?
       AND DATE(o.created_at) = CURDATE()
       AND (UPPER(o.order_number) = ? OR CAST(o.id AS CHAR) = ?)
       LIMIT 1`,
      [parseInt(storeId), term, term]
    );
    if (rows.length === 0) return res.json(null);
    const order = rows[0];
    const [items] = await pool.execute(
      `SELECT oi.*, COALESCE(p.name, 'Producto eliminado') as product_name
       FROM order_items oi LEFT JOIN products p ON oi.product_id = p.id
       WHERE oi.order_id = ?`,
      [order.id]
    );
    const parsedItems = items.map(item => ({
      ...item,
      selected_ingredients: item.selected_ingredients ? JSON.parse(item.selected_ingredients) : [],
      selected_extras: item.selected_extras ? JSON.parse(item.selected_extras) : []
    }));
    res.json({ ...order, total: parseFloat(order.total) || 0, items: parsedItems });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/orders/:id/status', authenticateToken, async (req, res) => {
  try {
    const { status, worker_id, worker_name } = req.body;
    const { id } = req.params;
    const { store_id } = req.query;

    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }

    const isWorker = req.user.type === 'worker';
    const hasAccess = isWorker
      ? parseInt(req.user.store_id) === parseInt(store_id)
      : await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!hasAccess) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }

    await updateOrderStatus(parseInt(id), parseInt(store_id), status, worker_id, worker_name);
    const [fullRows] = await pool.execute('SELECT * FROM orders WHERE id = ?', [parseInt(id)]);
    const order = fullRows[0] ? { ...fullRows[0], total: parseFloat(fullRows[0].total) || 0 } : { id: parseInt(id), status };
    const io_instance = req.app.get('io');
    if (io_instance) {
      io_instance.to(`store_${store_id}`).emit('order_updated', order);
    }
    res.json(order);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/orders/bulk', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    const { ids } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    if (!Array.isArray(ids) || !ids.length) return res.status(400).json({ error: 'ids es requerido' });
    if (req.user.type === 'worker') return res.status(403).json({ error: 'Solo el administrador puede eliminar pedidos' });
    const hasAccess = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!hasAccess) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const safeIds = ids.map(Number).filter(n => n > 0);
    if (!safeIds.length) return res.status(400).json({ error: 'ids inválidos' });
    const placeholders = safeIds.map(() => '?').join(',');
    await pool.execute(`DELETE FROM order_items WHERE order_id IN (${placeholders})`, safeIds);
    await pool.execute(`DELETE FROM orders WHERE id IN (${placeholders}) AND store_id = ?`, [...safeIds, parseInt(store_id)]);
    res.json({ success: true, deleted: safeIds.length });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/orders/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id } = req.query;
    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });
    if (req.user.type === 'worker') return res.status(403).json({ error: 'Solo el administrador puede eliminar pedidos' });
    const hasAccess = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!hasAccess) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const id = parseInt(req.params.id);
    await pool.execute('DELETE FROM order_items WHERE order_id = ?', [id]);
    await pool.execute('DELETE FROM orders WHERE id = ? AND store_id = ?', [id, parseInt(store_id)]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/orders/:id/approve-cash', authenticateToken, async (req, res) => {
  try {
    const { worker_id, worker_name } = req.body;
    const { id } = req.params;
    const { store_id } = req.query;

    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }

    const isWorker = req.user.type === 'worker';
    const hasAccess = isWorker
      ? req.user.store_id === parseInt(store_id)
      : await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!hasAccess) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    
    console.log('approve-cash request:', { id, store_id, worker_id, worker_name });
    const order = await approveCashPayment(parseInt(id), parseInt(store_id), worker_id, worker_name);
    console.log('approve-cash result:', order);
    const io_instance = req.app.get('io');
    if (io_instance) {
      io_instance.to(`store_${store_id}`).emit('cash_approved', order);
    }
    res.json(order);
  } catch (error) {
    console.error('approve-cash error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/orders/:id/mark-paid', authenticateToken, async (req, res) => {
  try {
    const { worker_id, worker_name } = req.body;
    const { id } = req.params;
    const { store_id } = req.query;

    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });

    const isWorker = req.user.type === 'worker';
    const hasAccess = isWorker
      ? parseInt(req.user.store_id) === parseInt(store_id)
      : await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!hasAccess) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });

    const storeData = await getStoreById(parseInt(store_id));
    const paidStatus = ['pending', 'completed'].includes(storeData?.paid_order_status) ? storeData.paid_order_status : 'pending';
    await pool.execute(
      `UPDATE orders SET payment_process = 1, cash_approved = 1, status = ? WHERE id = ? AND store_id = ?`,
      [paidStatus, parseInt(id), parseInt(store_id)]
    );
    const [rows] = await pool.execute('SELECT * FROM orders WHERE id = ?', [parseInt(id)]);
    const order = rows[0] ? { ...rows[0], total: parseFloat(rows[0].total) || 0 } : { id: parseInt(id) };
    const io_instance = req.app.get('io');
    if (io_instance) {
      io_instance.to(`store_${store_id}`).emit('cash_approved', order);
    }
    res.json(order);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/orders/:id/reprint', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { store_id } = req.query;

    if (!store_id) return res.status(400).json({ error: 'store_id es requerido' });

    const isWorker = req.user.type === 'worker';
    const hasAccess = isWorker
      ? req.user.store_id === parseInt(store_id)
      : await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!hasAccess) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });

    try {
      await pool.execute('SHOW COLUMNS FROM orders LIKE ?', ['reprint_count']).then(async ([cols]) => {
        if (cols.length === 0) await pool.execute('ALTER TABLE orders ADD COLUMN reprint_count INT DEFAULT 0');
      });
    } catch {}

    await pool.execute(
      'UPDATE orders SET reprint_count = COALESCE(reprint_count, 0) + 1 WHERE id = ? AND store_id = ?',
      [parseInt(id), parseInt(store_id)]
    );

    const [[order]] = await pool.execute('SELECT reprint_count FROM orders WHERE id = ?', [parseInt(id)]);
    res.json({ reprint_count: order?.reprint_count || 1 });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/workers/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ error: 'Usuario y contraseña son requeridos' });
    }
    
    const worker = await authenticateWorker(username, password);
    
    if (!worker) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }
    
    const token = jwt.sign(
      { id: worker.id, type: 'worker', store_id: worker.store_id },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    res.json({
      token,
      worker: {
        id: worker.id,
        username: worker.username,
        name: worker.name,
        store_id: worker.store_id,
        store_name: worker.store_name,
        store_code: worker.store_code
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Endpoint para que el admin pueda acceder como un worker específico
app.post('/api/admin/login-as-worker/:workerId', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user') {
      return res.status(403).json({ error: 'Solo admins pueden usar esta función' });
    }

    const workerId = parseInt(req.params.workerId);
    const [workerRows] = await pool.execute('SELECT * FROM workers WHERE id = ?', [workerId]);
    
    if (!workerRows.length) {
      return res.status(404).json({ error: 'Trabajador no encontrado' });
    }

    const worker = workerRows[0];

    // Verificar que el admin es dueño de la tienda del worker
    const isOwner = await verifyStoreOwnership(worker.store_id, req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a este trabajador' });
    }

    // Obtener datos de la tienda
    const [storeRows] = await pool.execute('SELECT code, name FROM stores WHERE id = ?', [worker.store_id]);
    const store = storeRows[0];

    // Generar token para el worker
    const token = jwt.sign(
      { id: worker.id, type: 'worker', store_id: worker.store_id },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      token,
      worker: {
        id: worker.id,
        username: worker.username,
        name: worker.name,
        store_id: worker.store_id,
        store_name: store?.name,
        store_code: store?.code
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/workers', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user' && req.user.type !== 'worker') {
      return res.status(403).json({ error: 'Acceso denegado' });
    }
    
    const storeId = req.query.store_id || req.user.store_id;
    if (!storeId) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    if (req.user.type === 'user') {
      const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
      if (!isOwner) {
        return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
      }
    }
    const workers = await getWorkers(parseInt(storeId));
    res.json(workers);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/workers', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user') {
      return res.status(403).json({ error: 'Acceso denegado' });
    }
    
    const { store_id, username, password, name } = req.body;
    
    if (!store_id || !username || !password || !name) {
      return res.status(400).json({ error: 'Todos los campos son requeridos' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    const worker = await createWorker(parseInt(store_id), { username, password, name });
    res.json(worker);
  } catch (error) {
    if (error.message.includes('Duplicate') || error.message.includes('ya está en uso')) {
      return res.status(400).json({ error: 'El nombre de usuario ya está en uso. Elige otro.' });
    }
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/workers/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user') {
      return res.status(403).json({ error: 'Acceso denegado' });
    }
    
    const { store_id } = req.query;
    if (!store_id) {
      return res.status(400).json({ error: 'store_id es requerido' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) {
      return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    }
    await deleteWorker(parseInt(req.params.id), parseInt(store_id));
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/workers/orders', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'worker') {
      return res.status(403).json({ error: 'Acceso solo para trabajadores' });
    }

    const orders = await getWorkerOrders(req.user.store_id);
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =================== TAREAS SEMANALES ===================

function getWeekStart() {
  const now = new Date();
  const d = new Date(now);
  d.setDate(d.getDate() - d.getDay());
  d.setHours(0, 0, 0, 0);
  return d.toISOString().split('T')[0];
}

app.get('/api/tasks', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user') return res.status(403).json({ error: 'Acceso denegado' });
    const storeId = req.query.store_id;
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const isOwner = await verifyStoreOwnership(parseInt(storeId), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const weekStart = (req.query.week_start && /^\d{4}-\d{2}-\d{2}$/.test(req.query.week_start))
      ? req.query.week_start
      : getWeekStart();
    const [tasks] = await pool.execute(`
      SELECT t.*, w.name as worker_name, w.username as worker_username,
             tc.completed_at, tc.completed_by_worker_id,
             cw.name as completed_by_name
      FROM tasks t
      JOIN workers w ON t.worker_id = w.id
      LEFT JOIN task_completions tc ON tc.task_id = t.id AND tc.week_start = ?
      LEFT JOIN workers cw ON tc.completed_by_worker_id = cw.id
      WHERE t.store_id = ?
      ORDER BY t.worker_id, t.day_of_week, t.due_time
    `, [weekStart, storeId]);
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/tasks', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user') return res.status(403).json({ error: 'Acceso denegado' });
    const { store_id, worker_id, name, description, day_of_week, due_time } = req.body;
    if (!store_id || !worker_id || !name || day_of_week === undefined || !due_time) {
      return res.status(400).json({ error: 'Faltan campos requeridos' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const [result] = await pool.execute(
      'INSERT INTO tasks (store_id, worker_id, name, description, day_of_week, due_time) VALUES (?, ?, ?, ?, ?, ?)',
      [store_id, worker_id, name, description || null, day_of_week, due_time]
    );
    const [rows] = await pool.execute(
      'SELECT t.*, w.name as worker_name, w.username as worker_username FROM tasks t JOIN workers w ON t.worker_id = w.id WHERE t.id = ?',
      [result.insertId]
    );
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/tasks/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user') return res.status(403).json({ error: 'Acceso denegado' });
    const { name, description, day_of_week, due_time, worker_id } = req.body;
    const [existing] = await pool.execute('SELECT * FROM tasks WHERE id = ?', [req.params.id]);
    if (!existing[0]) return res.status(404).json({ error: 'Tarea no encontrada' });
    const isOwner = await verifyStoreOwnership(existing[0].store_id, req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    await pool.execute(
      'UPDATE tasks SET name = ?, description = ?, day_of_week = ?, due_time = ?, worker_id = ? WHERE id = ?',
      [name, description || null, day_of_week, due_time, worker_id, req.params.id]
    );
    const [rows] = await pool.execute(
      'SELECT t.*, w.name as worker_name, w.username as worker_username FROM tasks t JOIN workers w ON t.worker_id = w.id WHERE t.id = ?',
      [req.params.id]
    );
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/tasks/duplicate-worker', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user') return res.status(403).json({ error: 'Acceso denegado' });
    const { store_id, source_worker_id, target_worker_id } = req.body;
    if (!store_id || !source_worker_id || !target_worker_id) {
      return res.status(400).json({ error: 'Faltan campos requeridos' });
    }
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    const [sourceTasks] = await pool.execute(
      'SELECT name, description, day_of_week, due_time FROM tasks WHERE store_id = ? AND worker_id = ?',
      [store_id, source_worker_id]
    );
    for (const t of sourceTasks) {
      await pool.execute(
        'INSERT INTO tasks (store_id, worker_id, name, description, day_of_week, due_time) VALUES (?, ?, ?, ?, ?, ?)',
        [store_id, target_worker_id, t.name, t.description, t.day_of_week, t.due_time]
      );
    }
    res.json({ success: true, count: sourceTasks.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/tasks/duplicate-to-store', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user') return res.status(403).json({ error: 'Acceso denegado' });
    const { source_store_id, target_store_id, worker_mapping } = req.body;
    // worker_mapping: { "source_worker_id": target_worker_id, ... }
    if (!source_store_id || !target_store_id || !worker_mapping || typeof worker_mapping !== 'object') {
      return res.status(400).json({ error: 'Faltan campos requeridos' });
    }
    const [srcOk, tgtOk] = await Promise.all([
      verifyStoreOwnership(parseInt(source_store_id), req.user.id),
      verifyStoreOwnership(parseInt(target_store_id), req.user.id),
    ]);
    if (!srcOk) return res.status(403).json({ error: 'Sin acceso a la tienda origen' });
    if (!tgtOk) return res.status(403).json({ error: 'Sin acceso a la tienda destino' });

    const [sourceTasks] = await pool.execute(
      'SELECT name, description, day_of_week, due_time, worker_id FROM tasks WHERE store_id = ?',
      [source_store_id]
    );

    let count = 0;
    for (const t of sourceTasks) {
      const targetWorkerId = worker_mapping[String(t.worker_id)];
      if (!targetWorkerId) continue; // sin mapeo definido para este worker, se omite
      await pool.execute(
        'INSERT INTO tasks (store_id, worker_id, name, description, day_of_week, due_time) VALUES (?, ?, ?, ?, ?, ?)',
        [target_store_id, targetWorkerId, t.name, t.description, t.day_of_week, t.due_time]
      );
      count++;
    }
    res.json({ success: true, count });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/tasks/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user') return res.status(403).json({ error: 'Acceso denegado' });
    const [existing] = await pool.execute('SELECT * FROM tasks WHERE id = ?', [req.params.id]);
    if (!existing[0]) return res.status(404).json({ error: 'Tarea no encontrada' });
    const isOwner = await verifyStoreOwnership(existing[0].store_id, req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'No tienes acceso a esta tienda' });
    await pool.execute('DELETE FROM tasks WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/tasks/worker-history', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'user') return res.status(403).json({ error: 'Acceso denegado' });
    const { store_id, worker_id } = req.query;
    if (!store_id || !worker_id) return res.status(400).json({ error: 'Faltan parámetros' });
    const isOwner = await verifyStoreOwnership(parseInt(store_id), req.user.id);
    if (!isOwner) return res.status(403).json({ error: 'Acceso denegado' });

    const [tasks] = await pool.execute(
      'SELECT id, name, description, day_of_week, due_time FROM tasks WHERE store_id = ? AND worker_id = ? ORDER BY day_of_week, due_time',
      [store_id, worker_id]
    );

    if (tasks.length === 0) return res.json({ tasks: [], weeks: [] });

    const taskIds = tasks.map(t => t.id);
    const [completions] = await pool.query(
      `SELECT tc.task_id, tc.week_start, tc.completed_at, tc.completed_by_worker_id,
              w.name as completed_by_name
       FROM task_completions tc
       LEFT JOIN workers w ON tc.completed_by_worker_id = w.id
       WHERE tc.task_id IN (?)
       ORDER BY tc.week_start DESC`,
      [taskIds]
    );

    const weekMap = {};
    for (const c of completions) {
      const ws = c.week_start instanceof Date
        ? c.week_start.toISOString().split('T')[0]
        : String(c.week_start).split('T')[0];
      if (!weekMap[ws]) weekMap[ws] = { week_start: ws, completions: {} };
      weekMap[ws].completions[c.task_id] = {
        completed_at: c.completed_at,
        completed_by_name: c.completed_by_name
      };
    }

    // Always include current week even with no completions yet
    const _now = new Date();
    _now.setDate(_now.getDate() - _now.getDay());
    const currentWS = `${_now.getFullYear()}-${String(_now.getMonth()+1).padStart(2,'0')}-${String(_now.getDate()).padStart(2,'0')}`;
    if (!weekMap[currentWS]) weekMap[currentWS] = { week_start: currentWS, completions: {} };

    const weeks = Object.values(weekMap).sort((a, b) => b.week_start.localeCompare(a.week_start));
    res.json({ tasks, weeks });
  } catch (err) {
    console.error('❌ worker-history error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/worker-tasks', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'worker') return res.status(403).json({ error: 'Acceso denegado' });
    const weekStart = getWeekStart();
    const [tasks] = await pool.execute(`
      SELECT t.*, tc.completed_at, tc.completed_by_worker_id,
             cw.name as completed_by_name
      FROM tasks t
      LEFT JOIN task_completions tc ON tc.task_id = t.id AND tc.week_start = ?
      LEFT JOIN workers cw ON tc.completed_by_worker_id = cw.id
      WHERE t.worker_id = ?
      ORDER BY t.day_of_week, t.due_time
    `, [weekStart, req.user.id]);
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/worker-tasks/:taskId/complete', authenticateToken, async (req, res) => {
  try {
    if (req.user.type !== 'worker') return res.status(403).json({ error: 'Acceso denegado' });
    const taskId = parseInt(req.params.taskId);
    const [tasks] = await pool.execute('SELECT * FROM tasks WHERE id = ? AND worker_id = ?', [taskId, req.user.id]);
    if (!tasks[0]) return res.status(404).json({ error: 'Tarea no encontrada' });
    const task = tasks[0];
    const now = new Date();
    const todayDow = now.getDay();
    if (todayDow !== task.day_of_week) {
      return res.status(400).json({ error: 'Esta tarea no corresponde al día de hoy' });
    }
    const [dueH, dueM] = task.due_time.split(':').map(Number);
    const dueDate = new Date();
    dueDate.setHours(dueH, dueM, 0, 0);
    const expireDate = new Date(dueDate.getTime() + 60 * 60 * 1000);
    if (now < dueDate) return res.status(400).json({ error: 'La tarea aún no está disponible' });
    if (now > expireDate) return res.status(400).json({ error: 'El plazo de 1 hora para marcar esta tarea ha expirado' });
    const weekStart = getWeekStart();
    await pool.execute(
      'INSERT IGNORE INTO task_completions (task_id, week_start, completed_by_worker_id) VALUES (?, ?, ?)',
      [taskId, weekStart, req.user.id]
    );
    io.to(`store_${task.store_id}`).emit('task_completed', {
      task_id: taskId, worker_id: req.user.id, week_start: weekStart, completed_at: now
    });
    res.json({ success: true, completed_at: now });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =================== FIN TAREAS ===================

// Public endpoint: get cash orders by POS PIN (for Android apps)
app.get('/api/getCashOrders', async (req, res) => {
  try {
    const { pin } = req.query;
    if (!pin) return res.status(400).json({ error: 'PIN requerido' });

    // Try unified pos_terminals first, then legacy mercado_pago_terminals
    let terminal = await getPosTerminalByPin(String(pin).trim());
    let storeId;

    if (terminal) {
      storeId = terminal.store_id;
    } else {
      const legacyTerminal = await getMercadoPagoTerminalByPin(String(pin).trim());
      if (!legacyTerminal) return res.status(401).json({ error: 'PIN inválido' });
      terminal = legacyTerminal;
      const [storeRows] = await pool.execute(
        'SELECT id FROM stores WHERE user_id = ? LIMIT 1', [terminal.user_id]
      );
      if (!storeRows[0]) return res.status(404).json({ error: 'Tienda no encontrada' });
      storeId = storeRows[0].id;
    }

    const pinStr = String(pin).trim();
    const [orders] = await pool.execute(
      `SELECT o.id, o.order_number, o.order_type, o.total, o.status, o.cash_approved,
              o.table_number, o.terminal_id, o.pos_pin, o.created_at
       FROM orders o
       WHERE o.store_id = ? AND o.payment_method = 'cash'
         AND o.pos_pin = ?
         AND o.created_at >= NOW() - INTERVAL 24 HOUR
       ORDER BY o.created_at DESC`,
      [storeId, pinStr]
    );

    for (const order of orders) {
      const [items] = await pool.execute(
        `SELECT oi.id, oi.quantity, oi.unit_price,
                oi.selected_extras, oi.selected_ingredients,
                COALESCE(p.name, 'Producto eliminado') AS product_name
         FROM order_items oi
         LEFT JOIN products p ON oi.product_id = p.id
         WHERE oi.order_id = ?`,
        [order.id]
      );
      order.items = items.map(item => ({
        ...item,
        selected_extras: (() => { try { return JSON.parse(item.selected_extras || '[]'); } catch { return []; } })(),
        selected_ingredients: (() => { try { return JSON.parse(item.selected_ingredients || '[]'); } catch { return []; } })()
      }));
      order.display_number = order.order_number
        ? (order.table_number ? `${order.order_number} (Mesa: ${order.table_number})` : order.order_number)
        : (order.table_number ? `Mesa: ${order.table_number}` : `#${order.id}`);
    }

    res.json({ store_id: storeId, terminal_id: terminal.id, terminal_name: terminal.name, pos_pin: pinStr, orders });
  } catch (err) {
    console.error('Error getCashOrders:', err);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// =================== pos_terminals UNIFICADO ===================

app.get('/api/pos-terminals', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id ? parseInt(req.query.store_id) : null;
    const terminals = await getPosTerminals(req.user.id, storeId);
    res.json(terminals);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/pos-terminals', authenticateToken, async (req, res) => {
  try {
    const { store_id, provider, name, api_key, device_id } = req.body;
    if (!store_id || !provider || !name) {
      return res.status(400).json({ error: 'store_id, provider y name son requeridos' });
    }
    let pos_pin;
    let attempts = 0;
    do {
      pos_pin = String(Math.floor(100000 + Math.random() * 900000));
      const existing = await getPosTerminalByPin(pos_pin);
      if (!existing) break;
      attempts++;
    } while (attempts < 10);
    const terminal = await createPosTerminal({
      user_id: req.user.id, store_id: parseInt(store_id), provider,
      name: name.trim(), api_key: api_key || '', device_id: device_id || '', pos_pin
    });
    res.json(terminal);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/pos-terminals/:id', authenticateToken, async (req, res) => {
  try {
    const { name, api_key, device_id } = req.body;
    if (!name) return res.status(400).json({ error: 'name requerido' });
    const result = await updatePosTerminal(parseInt(req.params.id), req.user.id, { name, api_key, device_id });
    res.json(result);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/pos-terminals/:id', authenticateToken, async (req, res) => {
  try {
    await deletePosTerminal(parseInt(req.params.id), req.user.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/public/:code/pos-terminals', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const terminals = await getPosTerminalsByStore(store.id);
    res.json(terminals);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// =================== FIN pos_terminals UNIFICADO ===================

app.get('/api/mercado-pago-terminals', authenticateToken, async (req, res) => {
  try {
    const storeId = req.query.store_id ? parseInt(req.query.store_id) : null;
    const all = await getPosTerminals(req.user.id, storeId);
    const terminals = all
      .filter(t => t.provider === 'mercadopago')
      .map(t => ({ ...t, mercadopago_access_token: t.api_key, mercadopago_terminal_id: t.device_id }));
    res.json(terminals);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/mercado-pago-terminals', authenticateToken, async (req, res) => {
  try {
    const { name, mercadopago_access_token, mercadopago_terminal_id, store_id } = req.body;

    if (!name || !mercadopago_access_token || !mercadopago_terminal_id || !store_id) {
      return res.status(400).json({ error: 'Todos los campos son requeridos' });
    }

    let pos_pin;
    let attempts = 0;
    do {
      pos_pin = String(Math.floor(100000 + Math.random() * 900000));
      const existing = await getPosTerminalByPin(pos_pin);
      if (!existing) break;
      attempts++;
    } while (attempts < 10);

    const terminal = await createPosTerminal({
      user_id: req.user.id,
      store_id: parseInt(store_id),
      provider: 'mercadopago',
      name: name.trim(),
      api_key: mercadopago_access_token,
      device_id: mercadopago_terminal_id,
      pos_pin
    });

    res.json({ ...terminal, mercadopago_access_token: terminal.api_key, mercadopago_terminal_id: terminal.device_id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/mercado-pago-terminals/:id', authenticateToken, async (req, res) => {
  try {
    const { name, mercadopago_access_token, mercadopago_terminal_id } = req.body;
    if (!name || !mercadopago_access_token || !mercadopago_terminal_id) {
      return res.status(400).json({ error: 'Todos los campos son requeridos' });
    }
    const result = await updatePosTerminal(parseInt(req.params.id), req.user.id, {
      name,
      api_key: mercadopago_access_token,
      device_id: mercadopago_terminal_id
    });
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/mercado-pago-terminals/:id', authenticateToken, async (req, res) => {
  try {
    await deletePosTerminal(parseInt(req.params.id), req.user.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Detect MP devices from access token (for setup wizard)
app.post('/api/mercado-pago-detect-devices', authenticateToken, async (req, res) => {
  try {
    const { access_token } = req.body;
    if (!access_token) return res.status(400).json({ error: 'Access token requerido' });
    const mpRes = await fetch('https://api.mercadopago.com/terminals/v1/list?limit=50', {
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${access_token}` }
    });
    if (!mpRes.ok) return res.status(mpRes.status).json({ error: 'Token invalido o error de MercadoPago' });
    const data = await mpRes.json();
    res.json(data.data?.terminals || []);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// List MP devices from API
app.get('/api/mercado-pago-terminals/:id/devices', authenticateToken, async (req, res) => {
  try {
    const terminal = await getPosTerminalById(parseInt(req.params.id));
    if (!terminal || terminal.user_id !== req.user.id) return res.status(404).json({ error: 'Terminal no encontrada' });
    const mpRes = await fetch('https://api.mercadopago.com/terminals/v1/list?limit=50', {
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${terminal.api_key}` }
    });
    if (!mpRes.ok) return res.status(mpRes.status).json({ error: 'Error al consultar MercadoPago' });
    const data = await mpRes.json();
    res.json(data.data?.terminals || []);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Change MP terminal operating mode
app.patch('/api/mercado-pago-terminals/:id/mode', authenticateToken, async (req, res) => {
  try {
    const terminal = await getPosTerminalById(parseInt(req.params.id));
    if (!terminal || terminal.user_id !== req.user.id) return res.status(404).json({ error: 'Terminal no encontrada' });
    const { device_id, operating_mode } = req.body;
    if (!device_id || !operating_mode) return res.status(400).json({ error: 'device_id y operating_mode requeridos' });
    if (!['PDV', 'STANDALONE'].includes(operating_mode)) return res.status(400).json({ error: 'Modo debe ser PDV o STANDALONE' });
    const mpRes = await fetch('https://api.mercadopago.com/terminals/v1/setup', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${terminal.api_key}` },
      body: JSON.stringify({ terminals: [{ id: device_id, operating_mode }] })
    });
    if (!mpRes.ok) {
      const err = await mpRes.text();
      return res.status(mpRes.status).json({ error: 'Error MercadoPago: ' + err });
    }
    const data = await mpRes.json();
    res.json(data);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Get MP terminal status (operating_mode) from MercadoPago API
app.get('/api/mercado-pago-terminals/:id/status', authenticateToken, async (req, res) => {
  try {
    const terminal = await getPosTerminalById(parseInt(req.params.id));
    if (!terminal || terminal.user_id !== req.user.id) return res.status(404).json({ error: 'Terminal no encontrada' });
    const mpRes = await fetch('https://api.mercadopago.com/terminals/v1/list?limit=50', {
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${terminal.api_key}` }
    });
    if (!mpRes.ok) return res.status(mpRes.status).json({ error: 'Error al consultar MercadoPago' });
    const data = await mpRes.json();
    const terminals = data.data?.terminals || [];
    const found = terminals.find(t => t.id === terminal.device_id);
    if (!found) return res.status(404).json({ error: 'Dispositivo no encontrado en MercadoPago' });
    res.json({ operating_mode: found.operating_mode || 'UNDEFINED', terminal: found });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// ==================== Screensaver API ====================

let _screensaverTableReady = false;
async function ensureScreensaverTable() {
  if (_screensaverTableReady) return;
  await pool.execute(`
    CREATE TABLE IF NOT EXISTS screensaver_config (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      store_id INT NOT NULL DEFAULT 0,
      enabled BOOLEAN DEFAULT FALSE,
      media_url VARCHAR(500) DEFAULT NULL,
      timeout_seconds INT DEFAULT 60,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_screensaver_store (user_id, store_id)
    )
  `);
  _screensaverTableReady = true;
}

// Get screensaver config (admin)
app.get('/api/screensaver/config', authenticateToken, async (req, res) => {
  try {
    await ensureScreensaverTable();
    const store_id = parseInt(req.query.store_id) || 0;
    const [rows] = await pool.execute('SELECT * FROM screensaver_config WHERE user_id = ? AND store_id = ?', [req.user.id, store_id]);
    res.json(rows[0] || { enabled: false, media_url: null, timeout_seconds: 60 });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Save screensaver config (admin, with optional image upload)
app.post('/api/screensaver/config', authenticateToken, upload.single('media'), async (req, res) => {
  try {
    await ensureScreensaverTable();
    const enabled = req.body.enabled === 'true' || req.body.enabled === true;
    const timeout_seconds = parseInt(req.body.timeout_seconds) || 60;
    let media_url = req.body.media_url || null;
    if (req.file) media_url = '/uploads/' + req.file.filename;
    const store_id = parseInt(req.body.store_id) || 0;
    await pool.execute(
      `INSERT INTO screensaver_config (user_id, store_id, enabled, media_url, timeout_seconds)
       VALUES (?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE enabled = VALUES(enabled), media_url = COALESCE(VALUES(media_url), media_url), timeout_seconds = VALUES(timeout_seconds), updated_at = NOW()`,
      [req.user.id, store_id, enabled, media_url, timeout_seconds]
    );
    const [rows] = await pool.execute('SELECT * FROM screensaver_config WHERE user_id = ? AND store_id = ?', [req.user.id, store_id]);
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Delete screensaver media (admin)
app.delete('/api/screensaver/media', authenticateToken, async (req, res) => {
  try {
    await ensureScreensaverTable();
    const store_id = parseInt(req.query.store_id) || 0;
    await pool.execute('UPDATE screensaver_config SET media_url = NULL, updated_at = NOW() WHERE user_id = ? AND store_id = ?', [req.user.id, store_id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Public endpoint: get screensaver for a store code (checks premium)
app.get('/api/public/:code/screensaver', async (req, res) => {
  try {
    await ensureScreensaverTable();
    const store = await getStoreByCode(req.params.code.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const plan = await getUserPlan(store.user_id);
    const isPremium = plan && plan.plan_name && plan.plan_name !== 'Gratis';
    if (!isPremium) return res.json({ enabled: false });
    const [rows] = await pool.execute('SELECT * FROM screensaver_config WHERE user_id = ?', [store.user_id]);
    const cfg = rows[0] || { enabled: false, media_url: null, timeout_seconds: 60 };
    res.json({ ...cfg, store_logo: store.logo_url || null, store_name: store.name });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ==================== Support Tickets API ====================

// Ensure tickets tables
let _ticketTablesReady = false;
let _ticketAvatarReady = false;
async function ensureTicketTables() {
  if (_ticketTablesReady && _ticketAvatarReady) return;
  try {
    await pool.execute(`CREATE TABLE IF NOT EXISTS support_tickets (
      id INT PRIMARY KEY AUTO_INCREMENT,
      user_id INT NOT NULL,
      subject VARCHAR(255) NOT NULL,
      priority ENUM('low','normal','important','urgent') DEFAULT 'normal',
      status ENUM('open','closed','resolved') DEFAULT 'open',
      support_pin VARCHAR(6) DEFAULT '000000',
      assigned_to VARCHAR(255) DEFAULT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`);
    // Add missing columns
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM support_tickets');
      const names = cols.map(c => c.Field);
      if (!names.includes('assigned_to')) await pool.execute('ALTER TABLE support_tickets ADD COLUMN assigned_to VARCHAR(255) DEFAULT NULL');
      if (!names.includes('support_pin')) await pool.execute('ALTER TABLE support_tickets ADD COLUMN support_pin VARCHAR(6) DEFAULT "000000"');
    } catch {}
    await pool.execute(`CREATE TABLE IF NOT EXISTS ticket_messages (
      id INT PRIMARY KEY AUTO_INCREMENT,
      ticket_id INT NOT NULL,
      sender_type ENUM('user','admin') NOT NULL,
      sender_name VARCHAR(255),
      sender_avatar TEXT DEFAULT NULL,
      message TEXT,
      image TEXT DEFAULT NULL,
      image_admin_only BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE
    )`);
    if (!_ticketAvatarReady) {
      try {
        const [cols] = await pool.execute('SHOW COLUMNS FROM ticket_messages LIKE ?', ['sender_avatar']);
        if (cols.length === 0) await pool.execute('ALTER TABLE ticket_messages ADD COLUMN sender_avatar TEXT DEFAULT NULL AFTER sender_name');
        _ticketAvatarReady = true;
      } catch {}
    }
    _ticketTablesReady = true;
  } catch (e) { console.error('Ticket tables error:', e.message); }
}

// Helper: genera el HTML del email de notificación de tickets
function ticketEmailHtml({ badge, badgeColor = '#D4AF37', title, ticketId, user, extra = '', body }) {
  return `<div style="font-family:sans-serif;max-width:540px;margin:auto;border:1px solid #e0e0e0;border-radius:12px;overflow:hidden">
    <div style="background:#000;padding:20px 28px">
      <span style="font-size:20px;font-weight:900;color:#D4AF37;letter-spacing:1px">SRServi</span>
      <span style="color:#666;font-size:13px;margin-left:8px">· Soporte</span>
    </div>
    <div style="padding:28px">
      <p style="margin:0 0 6px;font-size:11px;color:${badgeColor};text-transform:uppercase;letter-spacing:1px;font-weight:800">${badge}</p>
      <h2 style="margin:0 0 20px;font-size:18px;color:#111;line-height:1.4">${title}</h2>
      <table style="width:100%;border-collapse:collapse;margin-bottom:20px">
        <tr>
          <td style="padding:7px 0;font-size:13px;color:#888;width:110px">Ticket</td>
          <td style="padding:7px 0;font-size:13px;font-weight:700;color:#111">#${ticketId}</td>
        </tr>
        <tr>
          <td style="padding:7px 0;font-size:13px;color:#888">Usuario</td>
          <td style="padding:7px 0;font-size:13px;color:#111">${user}</td>
        </tr>
        ${extra}
      </table>
      ${body ? `<div style="background:#f5f5f5;border-radius:8px;padding:16px;margin-bottom:24px;font-size:14px;color:#333;line-height:1.6;border-left:4px solid #D4AF37;word-break:break-word">${String(body).replace(/\n/g, '<br>')}</div>` : ''}
      <a href="${BASE_URL}/superadmin" style="display:inline-block;background:#D4AF37;color:#000;font-weight:900;font-size:13px;padding:11px 22px;border-radius:8px;text-decoration:none">
        Ver en el panel →
      </a>
    </div>
    <div style="padding:14px 28px;background:#fafafa;border-top:1px solid #e0e0e0;font-size:11px;color:#aaa">
      Enviado automáticamente · SRServi Soporte
    </div>
  </div>`;
}

// Helper: enviar email a todos los superadmins (fire-and-forget, sin bloquear el request)
function notifySuperadmins(subject, html) {
  setImmediate(async () => {
    try {
      const [admins] = await pool.execute('SELECT email FROM superadmin WHERE email IS NOT NULL');
      for (const sa of admins) {
        try {
          await mailer.sendMail({
            from: `"SRServi Soporte" <${process.env.EMAIL_USER}>`,
            to: sa.email,
            subject,
            html
          });
        } catch (err) {
          console.error(`Error enviando email a ${sa.email}:`, err.message);
        }
      }
    } catch (err) {
      console.error('Error consultando superadmins para email:', err.message);
    }
  });
}

// User: create ticket
app.post('/api/tickets', authenticateToken, async (req, res) => {
  try {
    await ensureTicketTables();
    const { subject, priority, message } = req.body;
    if (!subject || !message) return res.status(400).json({ error: 'Asunto y mensaje requeridos' });
    const pin = String(Math.floor(100000 + Math.random() * 900000));
    const [result] = await pool.execute(
      'INSERT INTO support_tickets (user_id, subject, priority, support_pin) VALUES (?, ?, ?, ?)',
      [req.user.id, subject, priority || 'normal', pin]
    );
    await pool.execute(
      'INSERT INTO ticket_messages (ticket_id, sender_type, sender_name, message) VALUES (?, ?, ?, ?)',
      [result.insertId, 'user', req.user.username || 'Usuario', message]
    );
    // Auto-reply from bot
    const botMsg = 'Bienvenido al soporte de SRServi. En cuanto haya un agente disponible su solicitud sera atendida. Esto puede demorar desde 1 hora hasta 24 horas, o puede ser atendida al instante.\n\nPor seguridad, nunca le pediremos datos personales, contrasenas o informacion sensible a traves de nuestra plataforma de soporte ni por correo electronico.';
    await pool.execute(
      'INSERT INTO ticket_messages (ticket_id, sender_type, sender_name, message) VALUES (?, ?, ?, ?)',
      [result.insertId, 'admin', 'SRServi Bot', botMsg]
    );
    io.emit('ticket_created', { ticket_id: result.insertId });
    res.json({ id: result.insertId, support_pin: pin });

    const prioridades = { low: 'Leve', normal: 'Normal', important: 'Importante', urgent: 'Urgente' };
    const prLabel = prioridades[priority || 'normal'] || priority || 'Normal';
    const prColor = priority === 'urgent' ? '#e74c3c' : priority === 'important' ? '#f39c12' : '#3498db';
    const senderName = req.user.business_name || req.user.username || req.user.email;
    notifySuperadmins(
      `[Ticket #${result.insertId}] ${subject}`,
      ticketEmailHtml({
        badge: 'Nuevo ticket de soporte',
        badgeColor: '#D4AF37',
        title: subject,
        ticketId: result.insertId,
        user: `${senderName} (${req.user.email})`,
        extra: `<tr><td style="padding:8px 0;font-size:13px;color:#888;width:110px">Prioridad</td><td style="padding:8px 0;font-size:13px;font-weight:700;color:${prColor}">${prLabel}</td></tr>`,
        body: message,
      })
    );
  } catch (error) { console.error('Error creating ticket:', error); res.status(500).json({ error: error.message }); }
});

// User: list my tickets
app.get('/api/tickets', authenticateToken, async (req, res) => {
  try {
    await ensureTicketTables();
    const [rows] = await pool.execute(
      'SELECT id, subject, priority, status, support_pin, assigned_to, created_at, updated_at FROM support_tickets WHERE user_id = ? ORDER BY updated_at DESC',
      [req.user.id]
    );
    res.json(rows);
  } catch (error) { console.error('Error listing tickets:', error); res.status(500).json({ error: error.message }); }
});

// User: get ticket messages (filter admin-only images)
app.get('/api/tickets/:id/messages', authenticateToken, async (req, res) => {
  try {
    await ensureTicketTables();
    const [ticket] = await pool.execute('SELECT * FROM support_tickets WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (ticket.length === 0) return res.status(404).json({ error: 'Ticket no encontrado' });
    const [msgs] = await pool.execute('SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC', [req.params.id]);
    const filtered = msgs.map(m => ({ ...m, image: m.image_admin_only ? null : m.image }));
    res.json({ ticket: ticket[0], messages: filtered });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// User: send message with optional image
app.post('/api/tickets/:id/messages', authenticateToken, upload.single('image'), async (req, res) => {
  try {
    await ensureTicketTables();
    const [ticket] = await pool.execute('SELECT * FROM support_tickets WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (ticket.length === 0) return res.status(404).json({ error: 'Ticket no encontrado' });
    if (ticket[0].status === 'resolved') return res.status(400).json({ error: 'Ticket resuelto' });
    const image = req.file ? `/uploads/${req.file.filename}` : null;
    const msg = req.body.message || '';
    if (!msg && !image) return res.status(400).json({ error: 'Mensaje o imagen requeridos' });
    const [result] = await pool.execute(
      'INSERT INTO ticket_messages (ticket_id, sender_type, sender_name, message, image, image_admin_only) VALUES (?, ?, ?, ?, ?, ?)',
      [req.params.id, 'user', req.user.username || 'Usuario', msg, image, image ? 1 : 0]
    );
    await pool.execute('UPDATE support_tickets SET status = "open", updated_at = NOW() WHERE id = ?', [req.params.id]);
    io.emit('ticket_message', { ticket_id: parseInt(req.params.id), message_id: result.insertId, sender_type: 'user', sender_name: req.user.username || 'Usuario', message: msg });
    res.json({ id: result.insertId });

    const senderName = req.user.business_name || req.user.username || req.user.email;
    notifySuperadmins(
      `[Ticket #${req.params.id}] Nuevo mensaje — ${ticket[0].subject}`,
      ticketEmailHtml({
        badge: 'Nuevo mensaje de usuario',
        badgeColor: '#3498db',
        title: ticket[0].subject,
        ticketId: req.params.id,
        user: `${senderName} (${req.user.email})`,
        body: msg || '(imagen adjunta)',
      })
    );
  } catch (error) { console.error('Error sending ticket message:', error); res.status(500).json({ error: error.message }); }
});

// User: close ticket
app.put('/api/tickets/:id/close', authenticateToken, async (req, res) => {
  try {
    await pool.execute('UPDATE support_tickets SET status = "closed" WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    io.emit('ticket_updated', { ticket_id: parseInt(req.params.id) });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// User: reopen ticket
app.put('/api/tickets/:id/reopen', authenticateToken, async (req, res) => {
  try {
    const [ticket] = await pool.execute('SELECT * FROM support_tickets WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (ticket.length === 0) return res.status(404).json({ error: 'Ticket no encontrado' });
    if (ticket[0].status === 'resolved') return res.status(400).json({ error: 'No se puede reabrir un ticket resuelto' });
    await pool.execute('UPDATE support_tickets SET status = "open" WHERE id = ?', [req.params.id]);
    io.emit('ticket_updated', { ticket_id: parseInt(req.params.id) });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Superadmin: list all tickets
app.get('/api/superadmin/tickets', authenticateSuperadminToken, async (req, res) => {
  try {
    await ensureTicketTables();
    const [rows] = await pool.execute(
      `SELECT t.*, u.username, u.email, u.business_name
       FROM support_tickets t JOIN users u ON t.user_id = u.id
       ORDER BY FIELD(t.priority, 'urgent','important','normal','low'), t.updated_at DESC`
    );
    res.json(rows);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Superadmin: get ticket messages (full, including admin-only images)
app.get('/api/superadmin/tickets/:id/messages', authenticateSuperadminToken, async (req, res) => {
  try {
    const [ticket] = await pool.execute(
      `SELECT t.*, u.username, u.email, u.business_name FROM support_tickets t JOIN users u ON t.user_id = u.id WHERE t.id = ?`,
      [req.params.id]
    );
    if (ticket.length === 0) return res.status(404).json({ error: 'Ticket no encontrado' });
    const [msgs] = await pool.execute('SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC', [req.params.id]);
    res.json({ ticket: ticket[0], messages: msgs });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Superadmin: send message (assigns admin to ticket on first reply)
app.post('/api/superadmin/tickets/:id/messages', authenticateSuperadminToken, upload.single('image'), async (req, res) => {
  try {
    await ensureTicketTables();
    // Ensure superadmin columns
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM superadmin');
      const names = cols.map(c => c.Field);
      if (!names.includes('username')) await pool.execute('ALTER TABLE superadmin ADD COLUMN username VARCHAR(255) DEFAULT NULL');
      if (!names.includes('avatar')) await pool.execute('ALTER TABLE superadmin ADD COLUMN avatar TEXT DEFAULT NULL');
    } catch {}
    // Get admin profile
    let adminName = 'Soporte';
    let adminAvatar = null;
    try {
      const [rows] = await pool.execute('SELECT id, email, username, avatar FROM superadmin WHERE id = ?', [req.superadmin.id]);
      console.log('Admin profile for ticket:', req.superadmin.id, rows[0]);
      if (rows[0]) {
        adminName = rows[0].username || rows[0].email || 'Soporte';
        adminAvatar = rows[0].avatar || null;
      }
    } catch (e) { console.error('Error getting admin profile:', e.message); }
    const image = req.file ? `/uploads/${req.file.filename}` : null;
    // Add sender_avatar column if missing
    try {
      await pool.execute('ALTER TABLE ticket_messages ADD COLUMN sender_avatar TEXT DEFAULT NULL');
      console.log('Added sender_avatar column');
    } catch (alterErr) {
      // Column already exists or other error - that's fine
      if (!alterErr.message.includes('Duplicate')) console.log('sender_avatar column:', alterErr.message);
    }
    const [result] = await pool.execute(
      'INSERT INTO ticket_messages (ticket_id, sender_type, sender_name, sender_avatar, message, image, image_admin_only) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [req.params.id, 'admin', adminName, adminAvatar, req.body.message || '', image, req.body.admin_only === 'true' ? 1 : 0]
    );
    console.log('Message saved with avatar:', adminAvatar, 'insertId:', result.insertId);
    await pool.execute('UPDATE support_tickets SET assigned_to = COALESCE(assigned_to, ?), updated_at = NOW() WHERE id = ?', [adminName, req.params.id]);
    io.emit('ticket_message', { ticket_id: parseInt(req.params.id), message_id: result.insertId, sender_type: 'admin', sender_name: adminName, sender_avatar: adminAvatar, message: req.body.message || '' });
    res.json({ id: result.insertId });
  } catch (error) { console.error('Error sending admin message:', error); res.status(500).json({ error: error.message }); }
});

// Superadmin: resolve ticket
app.put('/api/superadmin/tickets/:id/resolve', authenticateSuperadminToken, async (req, res) => {
  try {
    await pool.execute('UPDATE support_tickets SET status = "resolved" WHERE id = ?', [req.params.id]);
    io.emit('ticket_updated', { ticket_id: parseInt(req.params.id) });
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Superadmin: verify support pin
app.post('/api/superadmin/tickets/:id/verify-pin', authenticateSuperadminToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT support_pin FROM support_tickets WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Ticket no encontrado' });
    res.json({ valid: rows[0].support_pin === req.body.pin });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// ==================== Plugin Management API ====================

const requirePremium = async (req, res, next) => {
  try {
    const plan = await getUserPlan(req.user.id);
    const isPremium = plan && plan.plan_name && plan.plan_name !== 'Gratis';
    if (!isPremium) {
      return res.status(403).json({ error: 'Necesitas un plan Premium para usar plugins' });
    }
    next();
  } catch {
    res.status(403).json({ error: 'Error verificando plan' });
  }
};

const pluginUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });

app.get('/api/admin/plugins', authenticateToken, async (req, res) => {
  try {
    if (!pluginManager) return res.json([]);
    const plugins = await pluginManager.getAllPlugins();
    res.json(plugins);
  } catch (error) {
    console.error('❌ Error in GET /api/admin/plugins:', error);
    // If table doesn't exist yet, return empty
    if (error.message && error.message.includes("doesn't exist")) {
      return res.json([]);
    }
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/admin/plugins/upload', authenticateToken, pluginUpload.single('plugin'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No se envió archivo' });
    if (!pluginManager) return res.status(500).json({ error: 'Plugin system not initialized' });
    const result = await pluginManager.install(req.file.buffer);
    res.json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/admin/plugins/:id/activate', authenticateToken, async (req, res) => {
  try {
    if (!pluginManager) return res.status(500).json({ error: 'Plugin system not initialized' });
    await pluginManager.activate(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/admin/plugins/:id/deactivate', authenticateToken, async (req, res) => {
  try {
    if (!pluginManager) return res.status(500).json({ error: 'Plugin system not initialized' });
    await pluginManager.deactivate(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/api/admin/plugins/:id', authenticateToken, async (req, res) => {
  try {
    if (!pluginManager) return res.status(500).json({ error: 'Plugin system not initialized' });
    await pluginManager.uninstall(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/admin/plugins/:id/settings/:storeId', authenticateToken, async (req, res) => {
  try {
    if (!pluginManager) return res.json({});
    const settings = await pluginManager.getPluginSettings(req.params.id, parseInt(req.params.storeId));
    res.json(settings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/admin/plugins/:id/settings/:storeId', authenticateToken, async (req, res) => {
  try {
    if (!pluginManager) return res.status(500).json({ error: 'Plugin system not initialized' });
    await pluginManager.savePluginSettings(req.params.id, parseInt(req.params.storeId), req.body);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Client manifest - checks premium via token if provided
app.get('/api/plugins/client-manifest', async (req, res) => {
  try {
    if (!pluginManager) return res.json([]);

    const manifest = await pluginManager.getClientManifest();
    res.json(manifest);
  } catch (error) {
    console.error('❌ Error in GET /api/plugins/client-manifest:', error);
    res.json([]);
  }
});

// ==================== Plugin Workshop API ====================

const workshopDir = path.join(__serverDir, 'plugins', 'workshop-uploads');
if (!fs.existsSync(workshopDir)) fs.mkdirSync(workshopDir, { recursive: true });

const workshopUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, workshopDir),
    filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_'))
  }),
  limits: { fileSize: 50 * 1024 * 1024 }
});

app.use('/api/workshop/files', express.static(workshopDir));

// Publish a plugin (or new version)
app.post('/api/workshop/publish', authenticateToken, workshopUpload.fields([
  { name: 'plugin', maxCount: 1 },
  { name: 'logo', maxCount: 1 }
]), async (req, res) => {
  try {
    const { description, contact_email, changelog } = req.body;
    if (!req.files?.plugin?.[0]) return res.status(400).json({ error: 'Se requiere un archivo .zip' });
    if (!contact_email) return res.status(400).json({ error: 'Se requiere email de contacto' });

    const zipFile = req.files.plugin[0];
    const logoFile = req.files?.logo?.[0] || null;

    const AdmZip = (await import('adm-zip')).default;
    const zip = new AdmZip(zipFile.path);
    const entries = zip.getEntries();

    let pluginJsonEntry = null;
    for (const entry of entries) {
      const normalized = entry.entryName.replace(/\\/g, '/');
      if (normalized.endsWith('plugin.json') && !entry.isDirectory) {
        const parts = normalized.split('/').filter(Boolean);
        if (parts.length <= 2) { pluginJsonEntry = entry; break; }
      }
    }
    if (!pluginJsonEntry) {
      fs.unlinkSync(zipFile.path);
      if (logoFile) fs.unlinkSync(logoFile.path);
      return res.status(400).json({ error: 'plugin.json no encontrado en el ZIP' });
    }

    let pluginJson;
    try { pluginJson = JSON.parse(pluginJsonEntry.getData().toString('utf8')); } catch {
      fs.unlinkSync(zipFile.path);
      if (logoFile) fs.unlinkSync(logoFile.path);
      return res.status(400).json({ error: 'plugin.json inválido' });
    }

    if (!pluginJson.id || !pluginJson.name || !pluginJson.version) {
      fs.unlinkSync(zipFile.path);
      if (logoFile) fs.unlinkSync(logoFile.path);
      return res.status(400).json({ error: 'plugin.json debe tener id, name y version' });
    }

    const user = await getUserById(req.user.id);
    const author = user?.business_name || user?.username || 'Anónimo';
    const logoPath = logoFile ? `/api/workshop/files/${logoFile.filename}` : null;
    const zipPath = `/api/workshop/files/${zipFile.filename}`;

    const [existing] = await pool.execute('SELECT id, user_id FROM plugin_workshop WHERE plugin_id = ?', [pluginJson.id]);

    if (existing.length > 0) {
      if (existing[0].user_id !== req.user.id) {
        fs.unlinkSync(zipFile.path);
        if (logoFile) fs.unlinkSync(logoFile.path);
        return res.status(403).json({ error: 'No eres el autor de este plugin' });
      }
      // Check duplicate version
      const [dupVer] = await pool.execute(
        'SELECT id FROM plugin_workshop_versions WHERE plugin_id = ? AND version = ?',
        [pluginJson.id, pluginJson.version]
      );
      if (dupVer.length > 0) {
        fs.unlinkSync(zipFile.path);
        if (logoFile) fs.unlinkSync(logoFile.path);
        return res.status(400).json({ error: `La versión ${pluginJson.version} ya existe. Cambia la versión en plugin.json` });
      }
      // Update main entry
      let updateQuery = `UPDATE plugin_workshop SET name = ?, latest_version = ?, description = ?, author = ?, contact_email = ?,
         hooks = ?, admin_slots = ?, store_slots = ?, updated_at = NOW()`;
      let updateParams = [pluginJson.name, pluginJson.version, description || pluginJson.description || '', author, contact_email,
         JSON.stringify(pluginJson.hooks || []), JSON.stringify(pluginJson.adminSlots || []),
         JSON.stringify(pluginJson.storeSlots || [])];
      if (logoFile) {
        updateQuery += ', logo = ?';
        updateParams.push(logoPath);
      }
      updateQuery += ' WHERE plugin_id = ?';
      updateParams.push(pluginJson.id);
      await pool.execute(updateQuery, updateParams);
    } else {
      await pool.execute(
        `INSERT INTO plugin_workshop (plugin_id, user_id, name, latest_version, description, author, contact_email, logo, downloads, zip_path, hooks, admin_slots, store_slots)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)`,
        [pluginJson.id, req.user.id, pluginJson.name, pluginJson.version,
         description || pluginJson.description || '', author, contact_email,
         logoPath, zipPath, JSON.stringify(pluginJson.hooks || []),
         JSON.stringify(pluginJson.adminSlots || []), JSON.stringify(pluginJson.storeSlots || [])]
      );
    }

    // Insert version
    await pool.execute(
      `INSERT INTO plugin_workshop_versions (plugin_id, version, zip_path, changelog, status)
       VALUES (?, ?, ?, ?, 'pending')`,
      [pluginJson.id, pluginJson.version, zipPath, changelog || null]
    );

    res.json({ success: true, plugin_id: pluginJson.id, name: pluginJson.name, version: pluginJson.version });
  } catch (error) {
    console.error('❌ Error publishing plugin:', error);
    res.status(500).json({ error: error.message });
  }
});

// Browse workshop
app.get('/api/workshop/plugins', async (req, res) => {
  try {
    // Migrate old column name if needed
    try {
      const [cols] = await pool.execute('SHOW COLUMNS FROM plugin_workshop');
      const colNames = cols.map(c => c.Field);
      if (colNames.includes('version') && !colNames.includes('latest_version')) {
        await pool.execute('ALTER TABLE plugin_workshop CHANGE version latest_version VARCHAR(50) NOT NULL');
      }
      if (colNames.includes('zip_path') && !colNames.includes('latest_version')) {
        // Old schema had zip_path on main table; just ignore it
      }
    } catch (migErr) { /* ignore migration errors */ }

    const search = req.query.search || '';
    let query = `SELECT plugin_id, name, latest_version, description, author, contact_email, logo, downloads, hooks, admin_slots, store_slots, created_at, updated_at
                 FROM plugin_workshop WHERE status = 'approved'`;
    const params = [];
    if (search) {
      query += ' AND (name LIKE ? OR description LIKE ? OR author LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    query += ' ORDER BY downloads DESC, created_at DESC';
    const [rows] = await pool.execute(query, params);
    res.json(rows);
  } catch (error) {
    if (error.message?.includes("doesn't exist") || error.message?.includes("Unknown column")) return res.json([]);
    res.status(500).json({ error: error.message });
  }
});

// Get versions of a plugin
app.get('/api/workshop/plugins/:pluginId/versions', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT v.* FROM plugin_workshop_versions v WHERE v.plugin_id = ? AND v.status = 'approved' ORDER BY v.created_at DESC`,
      [req.params.pluginId]
    );
    res.json(rows);
  } catch (error) {
    if (error.message?.includes("doesn't exist")) return res.json([]);
    res.status(500).json({ error: error.message });
  }
});

// Install a specific version from workshop
app.post('/api/workshop/install/:pluginId', authenticateToken, async (req, res) => {
  try {
    const { pluginId } = req.params;
    const { version } = req.body || {};

    // If version specified, get that version's zip; otherwise get latest approved
    let zipPath;
    if (version) {
      const [vRows] = await pool.execute(
        'SELECT zip_path FROM plugin_workshop_versions WHERE plugin_id = ? AND version = ? AND status = ?',
        [pluginId, version, 'approved']
      );
      if (vRows.length === 0) return res.status(404).json({ error: 'Versión no encontrada o no aprobada' });
      zipPath = vRows[0].zip_path;
    } else {
      const [vRows] = await pool.execute(
        'SELECT zip_path FROM plugin_workshop_versions WHERE plugin_id = ? AND status = ? ORDER BY created_at DESC LIMIT 1',
        [pluginId, 'approved']
      );
      if (vRows.length === 0) return res.status(404).json({ error: 'No hay versiones aprobadas' });
      zipPath = vRows[0].zip_path;
    }

    const zipFilePath = path.join(workshopDir, path.basename(zipPath));
    if (!fs.existsSync(zipFilePath)) return res.status(404).json({ error: 'Archivo no encontrado' });
    if (!pluginManager) return res.status(500).json({ error: 'Plugin system not ready' });

    const zipBuffer = fs.readFileSync(zipFilePath);
    const result = await pluginManager.install(zipBuffer);
    await pool.execute('UPDATE plugin_workshop SET downloads = downloads + 1 WHERE plugin_id = ?', [pluginId]);

    res.json({ success: true, plugin: result });
  } catch (error) {
    console.error('❌ Error installing from workshop:', error);
    res.status(500).json({ error: error.message });
  }
});

// My published plugins (with versions)
app.get('/api/workshop/my-plugins', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM plugin_workshop WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]
    );
    for (const row of rows) {
      const [versions] = await pool.execute(
        'SELECT version, status, changelog, created_at FROM plugin_workshop_versions WHERE plugin_id = ? ORDER BY created_at DESC',
        [row.plugin_id]
      );
      row.versions = versions;
    }
    res.json(rows);
  } catch (error) {
    if (error.message?.includes("doesn't exist")) return res.json([]);
    res.status(500).json({ error: error.message });
  }
});

// Delete my published plugin
app.delete('/api/workshop/my-plugins/:pluginId', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM plugin_workshop WHERE plugin_id = ? AND user_id = ?', [req.params.pluginId, req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'No encontrado' });
    await pool.execute('DELETE FROM plugin_workshop_versions WHERE plugin_id = ?', [req.params.pluginId]);
    await pool.execute('DELETE FROM plugin_workshop WHERE plugin_id = ? AND user_id = ?', [req.params.pluginId, req.user.id]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Check installed plugins for current user
app.get('/api/workshop/installed-ids', authenticateToken, async (req, res) => {
  try {
    if (!pluginManager) return res.json([]);
    const plugins = await pluginManager.getAllPlugins();
    res.json(plugins.map(p => ({ plugin_id: p.plugin_id, version: p.version })));
  } catch (error) {
    res.json([]);
  }
});

// Superadmin: list all workshop plugins with versions
app.get('/api/superadmin/workshop', authenticateSuperadminToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM plugin_workshop ORDER BY created_at DESC');
    for (const row of rows) {
      const [versions] = await pool.execute(
        'SELECT * FROM plugin_workshop_versions WHERE plugin_id = ? ORDER BY created_at DESC',
        [row.plugin_id]
      );
      row.versions = versions;
    }
    res.json(rows);
  } catch (error) {
    if (error.message?.includes("doesn't exist")) return res.json([]);
    res.status(500).json({ error: error.message });
  }
});

// Superadmin: review plugin source code before approving
app.get('/api/superadmin/workshop/:pluginId/version/:version/review', authenticateSuperadminToken, async (req, res) => {
  try {
    const [versions] = await pool.execute(
      'SELECT zip_path FROM plugin_workshop_versions WHERE plugin_id = ? AND version = ?',
      [req.params.pluginId, req.params.version]
    );
    if (versions.length === 0) return res.status(404).json({ error: 'Version no encontrada' });
    const workshopDir = path.join(__serverDir, 'plugins', 'workshop-uploads');
    const zipFilePath = path.join(workshopDir, path.basename(versions[0].zip_path));
    if (!fs.existsSync(zipFilePath)) return res.status(404).json({ error: 'ZIP no encontrado' });

    const AdmZip = (await import('adm-zip')).default;
    const zip = new AdmZip(zipFilePath);
    const entries = zip.getEntries();
    const files = {};
    const dangerousPatterns = [
      /require\s*\(\s*['"]child_process['"]\s*\)/,
      /require\s*\(\s*['"]fs['"]\s*\)/,
      /import\s+.*from\s+['"]fs['"]/,
      /import\s+.*from\s+['"]child_process['"]/,
      /process\.env/,
      /eval\s*\(/,
      /Function\s*\(/,
      /localStorage/,
      /document\.cookie/,
    ];

    const warnings = [];
    for (const entry of entries) {
      if (entry.isDirectory) continue;
      const name = entry.entryName.replace(/\\/g, '/');
      const ext = path.extname(name).toLowerCase();
      if (['.js', '.json', '.css', '.html', '.md', '.txt'].includes(ext)) {
        const content = entry.getData().toString('utf8');
        files[name] = content;
        // Scan for dangerous patterns
        for (const pattern of dangerousPatterns) {
          if (pattern.test(content)) {
            warnings.push({ file: name, pattern: pattern.source, message: `Uso sospechoso detectado: ${pattern.source}` });
          }
        }
      } else {
        files[name] = `[Archivo binario: ${entry.header.size} bytes]`;
      }
    }
    res.json({ files, warnings });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Superadmin: approve/reject a specific version
app.put('/api/superadmin/workshop/:pluginId/version/:version/status', authenticateSuperadminToken, async (req, res) => {
  try {
    const { status } = req.body;
    if (!['approved', 'rejected', 'pending'].includes(status)) {
      return res.status(400).json({ error: 'Estado inválido' });
    }
    await pool.execute(
      'UPDATE plugin_workshop_versions SET status = ? WHERE plugin_id = ? AND version = ?',
      [status, req.params.pluginId, req.params.version]
    );
    // If any version approved, mark main plugin as approved
    const [approved] = await pool.execute(
      'SELECT id FROM plugin_workshop_versions WHERE plugin_id = ? AND status = ?',
      [req.params.pluginId, 'approved']
    );
    const mainStatus = approved.length > 0 ? 'approved' : status;
    await pool.execute('UPDATE plugin_workshop SET status = ? WHERE plugin_id = ?', [mainStatus, req.params.pluginId]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== APK Static Download ====================
app.get('/api/download/launcher', (req, res) => {
  const apkPath = path.join(__serverDir, '../client/dist/SRServiLauncherClient.apk');
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', 'attachment; filename="SRServiLauncherClient.apk"');
  res.sendFile(apkPath);
});

app.get('/api/download/tv', (req, res) => {
  const apkPath = path.join(__serverDir, '../client/public/SRServiTVOrder.apk');
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', 'attachment; filename="SRServiTVOrder.apk"');
  res.sendFile(apkPath);
});

app.get('/api/download/windows', (req, res) => {
  const zipPath = path.join(__serverDir, '../client/public/SRServiWindowsClient.zip');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="SRServiWindowsClient.zip"');
  res.sendFile(zipPath);
});

app.get('/api/download/cctv', (req, res) => {
  const apkPath = path.join(__serverDir, '../client/public/CCTV.apk');
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', 'attachment; filename="CCTV.apk"');
  res.sendFile(apkPath);
});

app.get('/api/download/aforo-windows', (req, res) => {
  const zipPath = path.join(__serverDir, 'public/downloads/AforoBridge-Windows.zip');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="AforoBridge-Windows.zip"');
  res.sendFile(zipPath);
});

app.get('/api/download/aforo-android', (req, res) => {
  const apkPath = path.join(__serverDir, 'public/downloads/AforoBridge-Android.apk');
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', 'attachment; filename="AforoBridge-Android.apk"');
  res.sendFile(apkPath);
});

// ==================== APK Releases ====================

app.get('/api/superadmin/apks', authenticateSuperadminToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM apk_releases ORDER BY version_code DESC');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/superadmin/apks', authenticateSuperadminToken, apkUpload.fields([
  { name: 'apk', maxCount: 1 },
  { name: 'logo', maxCount: 1 }
]), async (req, res) => {
  try {
    const { name, description, version } = req.body;
    if (!name || !version) return res.status(400).json({ error: 'Nombre y versión son requeridos' });
    if (!req.files?.apk?.[0]) return res.status(400).json({ error: 'Archivo APK es requerido' });

    const apkUrl = `/uploads/apks/${req.files.apk[0].filename}`;
    const logoUrl = req.files?.logo?.[0] ? `/uploads/apks/${req.files.logo[0].filename}` : null;

    // Auto-increment version_code
    const [last] = await pool.execute('SELECT MAX(version_code) as max_code FROM apk_releases');
    const versionCode = (last[0].max_code || 0) + 1;

    const [result] = await pool.execute(
      'INSERT INTO apk_releases (name, description, version, version_code, logo, apk_url) VALUES (?, ?, ?, ?, ?, ?)',
      [name, description || '', version, versionCode, logoUrl, apkUrl]
    );

    res.json({ id: result.insertId, name, version, version_code: versionCode, apk_url: apkUrl, logo: logoUrl });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/superadmin/apks/:id', authenticateSuperadminToken, async (req, res) => {
  try {
    await pool.execute('DELETE FROM apk_releases WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ─── SUPERADMIN: PEDIDOS ────────────────────────────────────────────────────

app.get('/api/superadmin/orders', authenticateSuperadminToken, async (req, res) => {
  try {
    const { store_id, date_from, date_to, status, limit = 200, offset = 0 } = req.query;
    const limitVal  = Math.max(1, parseInt(limit)  || 200);
    const offsetVal = Math.max(0, parseInt(offset) || 0);
    let where = '1=1';
    const params = [];
    if (store_id) { where += ' AND o.store_id = ?'; params.push(parseInt(store_id)); }
    if (date_from) { where += ' AND DATE(o.created_at) >= ?'; params.push(date_from); }
    if (date_to)   { where += ' AND DATE(o.created_at) <= ?'; params.push(date_to); }
    if (status)    { where += ' AND o.status = ?'; params.push(status); }
    const [rows] = await pool.execute(
      `SELECT o.*, s.name as store_name, s.code as store_code
       FROM orders o
       LEFT JOIN stores s ON o.store_id = s.id
       WHERE ${where}
       ORDER BY o.created_at DESC
       LIMIT ${limitVal} OFFSET ${offsetVal}`,
      params
    );
    const [countRows] = await pool.execute(
      `SELECT COUNT(*) as total FROM orders o WHERE ${where}`,
      params
    );
    const orders = rows.map(o => ({ ...o, total: parseFloat(o.total) || 0 }));
    res.json({ orders, total: countRows[0].total });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/superadmin/orders/:id', authenticateSuperadminToken, async (req, res) => {
  try {
    await pool.execute('DELETE FROM order_items WHERE order_id = ?', [parseInt(req.params.id)]);
    await pool.execute('DELETE FROM orders WHERE id = ?', [parseInt(req.params.id)]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/superadmin/orders/:id/mark-paid', authenticateSuperadminToken, async (req, res) => {
  try {
    await pool.execute(
      `UPDATE orders SET status = 'completed', cash_approved = 1, payment_process = 1 WHERE id = ?`,
      [parseInt(req.params.id)]
    );
    const [rows] = await pool.execute('SELECT * FROM orders WHERE id = ?', [parseInt(req.params.id)]);
    res.json(rows[0] || {});
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/superadmin/orders/:id/items', authenticateSuperadminToken, async (req, res) => {
  try {
    const [items] = await pool.execute(
      `SELECT oi.*, COALESCE(p.name, 'Producto eliminado') as product_name
       FROM order_items oi LEFT JOIN products p ON oi.product_id = p.id
       WHERE oi.order_id = ?`,
      [parseInt(req.params.id)]
    );
    res.json(items.map(i => ({
      ...i,
      selected_extras: i.selected_extras ? JSON.parse(i.selected_extras) : [],
      selected_ingredients: i.selected_ingredients ? JSON.parse(i.selected_ingredients) : [],
    })));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Revenue por tienda (superadmin)
app.get('/api/superadmin/revenue', authenticateSuperadminToken, async (req, res) => {
  try {
    const { date_from, date_to, status = 'completed' } = req.query;
    let onExtra = '';
    const params = [];
    if (status && status !== 'all') { onExtra += ' AND o.status = ?'; params.push(status); }
    if (date_from) { onExtra += ' AND DATE(o.created_at) >= ?'; params.push(date_from); }
    if (date_to) { onExtra += ' AND DATE(o.created_at) <= ?'; params.push(date_to); }
    const [rows] = await pool.execute(
      `SELECT s.id, s.name, s.code, s.is_banned,
        COUNT(o.id) AS total_orders,
        COALESCE(SUM(o.total), 0) AS total_revenue,
        COALESCE(AVG(o.total), 0) AS avg_order,
        MAX(o.created_at) AS last_order
       FROM stores s
       LEFT JOIN orders o ON s.id = o.store_id${onExtra}
       GROUP BY s.id, s.name, s.code, s.is_banned
       ORDER BY total_revenue DESC`,
      params
    );
    const result = rows.map(r => ({
      ...r,
      total_revenue: parseFloat(r.total_revenue) || 0,
      avg_order: parseFloat(r.avg_order) || 0,
      total_orders: parseInt(r.total_orders) || 0,
    }));
    const total_platform = result.reduce((s, r) => s + r.total_revenue, 0);
    const total_orders_all = result.reduce((s, r) => s + r.total_orders, 0);
    res.json({ stores: result, summary: { total_platform, total_orders: total_orders_all } });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Endpoint público para obtener la última versión
app.get('/api/apk/latest', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM apk_releases ORDER BY version_code DESC LIMIT 1');
    if (rows.length === 0) return res.status(404).json({ error: 'No hay versiones disponibles' });
    const release = rows[0];
    res.json({
      name: release.name,
      description: release.description,
      version: release.version,
      version_code: release.version_code,
      logo: release.logo,
      apk_url: release.apk_url,
      created_at: release.created_at
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Endpoint público para obtener todas las versiones
app.get('/api/apk/releases', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM apk_releases ORDER BY version_code DESC');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

let pluginManager = null;

// Prevent plugin errors from crashing the server
process.on('uncaughtException', (err) => {
  console.error('🔌 Uncaught exception (server kept running):', err.message);
});
process.on('unhandledRejection', (reason) => {
  console.error('🔌 Unhandled rejection (server kept running):', reason?.message || reason);
});

async function startServer() {
  try {
    await initDatabase();
    console.log('Base de datos inicializada');
    await initTicketeriaTables();

    app.set('io', io);

    // Initialize plugin system
    pluginManager = new PluginManager(app, pool, io);
    try {
      await pluginManager.loadAllActive();
    } catch (pluginError) {
      console.error('🔌 Error loading plugins (server continues):', pluginError.message);
    }

    // ==================== TUU POS NATIVO ====================
    const TUU_API = 'https://integrations.payment.haulmer.com/RemotePayment/v2';

    let tuuActivePolls = new global.Map ? new global.Map() : new Map();
    const squareActivePolls = new Map(); // checkoutId -> intervalId

    async function tuuGetUserIdFromStore(storeId) {
      const [rows] = await pool.execute('SELECT user_id FROM stores WHERE id = ?', [storeId]);
      return rows[0]?.user_id || null;
    }

    async function tuuGetConfig(userId) {
      const [rows] = await pool.execute('SELECT * FROM tuu_config WHERE user_id = ?', [userId]);
      return rows[0] || null;
    }

    async function tuuGetDeviceForUid(deviceUid, storeId) {
      if (!deviceUid) return null;
      const [rows] = await pool.execute(
        `SELECT d.* FROM tuu_devices d JOIN tuu_device_pos dp ON d.id = dp.tuu_device_id WHERE dp.device_uid = ? AND dp.store_id = ?`,
        [deviceUid, storeId]
      );
      return rows[0] || null;
    }

    async function tuuGetAnyDeviceForStore(storeId) {
      const userId = await tuuGetUserIdFromStore(storeId);
      const [rows] = await pool.execute(
        `SELECT d.*, dp.device_uid
         FROM tuu_devices d
         LEFT JOIN tuu_device_pos dp ON d.id = dp.tuu_device_id AND dp.store_id = ?
         WHERE d.user_id = ?
         LIMIT 1`,
        [storeId, userId]
      );
      return rows[0] || null;
    }

    async function tuuCreatePayment(apiKey, amount, deviceSerial, description, dteType, orderNumber, tableNumber, tipAmount, tipPercent) {
      const idempotencyKey = crypto.randomUUID();
      const extraData = {
        sourceName: 'SRServi',
        sourceVersion: '1.1.0'
      };
      const customFields = [];
      if (orderNumber) customFields.push({ name: 'ORDEN', value: String(orderNumber), print: true });
      if (tableNumber) customFields.push({ name: 'MESA', value: String(tableNumber), print: true });
      if (tipAmount > 0) customFields.push({ name: 'PROPINA', value: String(Math.round(tipAmount)), print: true });
      if (customFields.length > 0) extraData.customFields = customFields;
      const response = await fetch(`${TUU_API}/Create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-Key': apiKey },
        body: JSON.stringify({
          Amount: Math.round(amount),
          Device: deviceSerial,
          IdempotencyKey: idempotencyKey,
          Description: description || 'Pago SRServi',
          DteType: dteType || 0,
          extraData
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || `Error ${response.status}`);
      return { ...data, idempotencyKey: data.idempotencyKey || idempotencyKey };
    }

    async function tuuCheckStatus(apiKey, idempotencyKey) {
      const response = await fetch(`${TUU_API}/GetPaymentRequest/${idempotencyKey}`, {
        headers: { 'X-API-Key': apiKey }
      });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.message || `Error ${response.status}`);
      }
      return response.json();
    }

    function tuuStartPolling(apiKey, idempotencyKey, storeId, orderId) {
      let attempts = 0;
      const intervalId = setInterval(async () => {
        attempts++;
        try {
          const data = await tuuCheckStatus(apiKey, idempotencyKey);
          if (data.status === 'Completed') {
            clearInterval(intervalId);
            tuuActivePolls.delete(idempotencyKey);
            await pool.execute(
              'UPDATE tuu_transactions SET status = ?, transaction_ref = ?, updated_at = NOW() WHERE idempotency_key = ?',
              ['Completed', data.transactionReference || null, idempotencyKey]
            );
            let orderNumber = null;
            if (orderId) {
              await pool.execute(
                "UPDATE orders SET status = 'preparing', payment_process = 1, cash_approved = TRUE, sequence_id = ?, reference_id = ? WHERE id = ?",
                [data.sequenceNumber || null, data.transactionReference || null, orderId]
              ).catch(() => {});
              const [orRows] = await pool.execute('SELECT order_number FROM orders WHERE id = ?', [orderId]).catch(() => [[]]);
              orderNumber = orRows[0]?.order_number || null;
            }
            const socketId = userSockets.get(parseInt(storeId));
            if (socketId) io.to(socketId).emit('tuu_payment_update', { idempotencyKey, orderId, order_number: orderNumber, status: 'Completed', transactionRef: data.transactionReference, sequenceNumber: data.sequenceNumber });
          } else if (data.status === 'Canceled' || data.status === 'Failed') {
            clearInterval(intervalId);
            tuuActivePolls.delete(idempotencyKey);
            await pool.execute('UPDATE tuu_transactions SET status = ?, updated_at = NOW() WHERE idempotency_key = ?', [data.status, idempotencyKey]);
            if (orderId) {
              await pool.execute("UPDATE orders SET status = 'canceled' WHERE id = ?", [orderId]).catch(() => {});
            }
            const socketId = userSockets.get(parseInt(storeId));
            if (socketId) io.to(socketId).emit('tuu_payment_update', { idempotencyKey, orderId, status: data.status });
          }
        } catch (err) {
          console.error('Tuu poll error:', err.message);
        }
        if (attempts >= 60) {
          clearInterval(intervalId);
          tuuActivePolls.delete(idempotencyKey);
          await pool.execute('UPDATE tuu_transactions SET status = ?, updated_at = NOW() WHERE idempotency_key = ?', ['Timeout', idempotencyKey]);
          const socketId = userSockets.get(parseInt(storeId));
          if (socketId) io.to(socketId).emit('tuu_payment_update', { idempotencyKey, orderId, status: 'Timeout' });
        }
      }, 5000);
      tuuActivePolls.set(idempotencyKey, intervalId);
    }

    app.get('/api/tuu/config', async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const userId = await tuuGetUserIdFromStore(storeId);
        const config = await tuuGetConfig(userId);
        res.json(config ? { api_key: config.api_key, dte_type: config.dte_type } : { api_key: '', dte_type: 0 });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/tuu/config', async (req, res) => {
      try {
        const { store_id, api_key, dte_type } = req.body;
        const userId = await tuuGetUserIdFromStore(parseInt(store_id));
        await pool.execute(
          'INSERT INTO tuu_config (user_id, api_key, dte_type) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE api_key = ?, dte_type = ?',
          [userId, api_key, dte_type || 0, api_key, dte_type || 0]
        );
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/tuu/devices', async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const userId = await tuuGetUserIdFromStore(storeId);
        const [posDevices] = await pool.execute('SELECT * FROM tuu_devices WHERE user_id = ? ORDER BY name', [userId]);
        let storeDevices = [];
        try {
          const [rows] = await pool.execute('SELECT * FROM store_devices WHERE store_id = ? ORDER BY last_seen DESC', [storeId]);
          storeDevices = rows;
        } catch { /* table might not exist */ }
        let assignments = [];
        try {
          const [rows] = await pool.execute('SELECT * FROM tuu_device_pos WHERE store_id = ?', [storeId]);
          assignments = rows;
        } catch { /* table might not exist */ }
        res.json({ posDevices, storeDevices, assignments });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/tuu/devices', async (req, res) => {
      try {
        const { store_id, name, serial, device_id, api_key } = req.body;
        if (!name || !serial) return res.status(400).json({ error: 'Nombre y serial requeridos' });
        const userId = await tuuGetUserIdFromStore(parseInt(store_id));
        if (api_key) {
          await pool.execute(
            'INSERT INTO tuu_config (user_id, api_key) VALUES (?, ?) ON DUPLICATE KEY UPDATE api_key = ?',
            [userId, api_key, api_key]
          );
        }
        let result;
        try {
          [result] = await pool.execute('INSERT INTO tuu_devices (user_id, name, serial, device_id) VALUES (?, ?, ?, ?)', [userId, name, serial, device_id || '']);
        } catch {
          [result] = await pool.execute('INSERT INTO tuu_devices (user_id, name, serial) VALUES (?, ?, ?)', [userId, name, serial]);
        }
        const deviceUid = 'tuu-' + result.insertId + '-' + Date.now();
        try {
          await pool.execute(
            'INSERT INTO tuu_device_pos (device_uid, tuu_device_id, store_id) VALUES (?, ?, ?)',
            [deviceUid, result.insertId, parseInt(store_id)]
          );
        } catch { }
        res.json({ id: result.insertId, name, serial, device_id: device_id || '' });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.delete('/api/tuu/devices/:id', async (req, res) => {
      try {
        await pool.execute('DELETE FROM tuu_device_pos WHERE tuu_device_id = ?', [req.params.id]);
        await pool.execute('DELETE FROM tuu_devices WHERE id = ?', [req.params.id]);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/tuu/devices/assign', async (req, res) => {
      try {
        const { store_id, device_uid, tuu_device_id } = req.body;
        if (!device_uid || !tuu_device_id) return res.status(400).json({ error: 'device_uid y tuu_device_id requeridos' });
        await pool.execute(
          'INSERT INTO tuu_device_pos (device_uid, tuu_device_id, store_id) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE tuu_device_id = ?',
          [device_uid, parseInt(tuu_device_id), parseInt(store_id), parseInt(tuu_device_id)]
        );
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/tuu/available', async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const deviceUid = req.query.device_uid;
        const userId = await tuuGetUserIdFromStore(storeId);
        const config = await tuuGetConfig(userId);
        if (!config?.api_key) return res.json({ available: false });
        const device = deviceUid ? await tuuGetDeviceForUid(deviceUid, storeId) : await tuuGetAnyDeviceForStore(storeId);
        res.json({ available: !!device?.serial, deviceName: device?.name || null });
      } catch (e) { res.json({ available: false }); }
    });

    // ── NATIVE TUU ENDPOINTS (no plugin system) ──────────────────────────

    app.get('/api/tuu/provider', async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const deviceUid = req.query.device_uid;
        const terminalId = parseInt(req.query.terminal_id) || null;
        if (!storeId) return res.json({ available: false });
        const userId = await tuuGetUserIdFromStore(storeId);
        const config = await tuuGetConfig(userId);
        if (!config?.api_key) return res.json({ available: false, reason: 'No API Key TUU' });
        let device = null;
        if (terminalId) {
          const [rows] = await pool.execute('SELECT * FROM tuu_devices WHERE id = ? AND user_id = ?', [terminalId, userId]);
          device = rows[0] || null;
        }
        if (!device && deviceUid) device = await tuuGetDeviceForUid(deviceUid, storeId);
        if (!device) device = await tuuGetAnyDeviceForStore(storeId);
        if (!device) return res.json({ available: false, reason: 'No hay dispositivo TUU' });
        res.json({ available: true, provider: 'tuu', deviceName: device.name, deviceSerial: device.serial, deviceId: device.id });
      } catch (e) { res.json({ available: false, reason: e.message }); }
    });

    app.post('/api/tuu/charge', async (req, res) => {
      try {
        const { store_id, order_id, amount, description, device_uid, terminal_id, tip_amount, tip_percent } = req.body;
        if (!store_id || !amount) return res.status(400).json({ error: 'store_id y amount requeridos' });
        const userId = await tuuGetUserIdFromStore(parseInt(store_id));

        let apiKey = null;
        let dteType = 0;
        let device = null;

        // 1. Buscar terminal por ID en pos_terminals (fuente principal)
        if (terminal_id) {
          const posTerm = await getPosTerminalById(parseInt(terminal_id)).catch(() => null);
          if (posTerm && posTerm.provider === 'tuu') {
            apiKey = posTerm.api_key || null;
            device = { serial: posTerm.device_id, name: posTerm.name };
            console.log(`[tuu/charge] pos_terminals → serial="${device.serial}" apiKey="${apiKey ? apiKey.slice(0,8) + '…' : 'VACÍO'}"`);
          } else {
            // fallback legacy: tuu_devices
            const [rows] = await pool.execute('SELECT * FROM tuu_devices WHERE id = ? AND user_id = ?', [parseInt(terminal_id), userId]);
            if (rows[0]) device = rows[0];
          }
        }

        // 2. Si no hay device aún, buscar por device_uid o cualquiera de la tienda
        if (!device && device_uid) device = await tuuGetDeviceForUid(device_uid, parseInt(store_id));
        if (!device) device = await tuuGetAnyDeviceForStore(parseInt(store_id));
        if (!device) return res.status(400).json({ error: 'No hay POS TUU configurado. Ve al admin > Vincular POS.' });

        // 3. Si no se obtuvo apiKey desde pos_terminals, usar tuu_config como fallback
        if (!apiKey) {
          const config = await tuuGetConfig(userId);
          apiKey = config?.api_key || null;
          dteType = config?.dte_type || 0;
          console.log(`[tuu/charge] tuu_config fallback → apiKey="${apiKey ? apiKey.slice(0,8) + '…' : 'VACÍO'}"`);
        } else {
          const config = await tuuGetConfig(userId);
          dteType = config?.dte_type || 0;
        }

        if (!apiKey) return res.status(400).json({ error: 'API Key de TUU no configurada. Ve al admin > Vincular POS > TUU.' });
        console.log(`[tuu/charge] enviando → serial="${device.serial}" amount=${amount}`);
        let orderNumber = null;
        let tableNumber = null;
        if (order_id) {
          const [orRows] = await pool.execute('SELECT order_number, store_id, table_number FROM orders WHERE id = ?', [order_id]).catch(() => [[]]);
          orderNumber = orRows[0]?.order_number || null;
          tableNumber = orRows[0]?.table_number || null;
          if (orRows[0] && !orderNumber) {
            const orderStoreId = orRows[0].store_id || store_id;
            const [usedRows] = await pool.execute(
              'SELECT order_number FROM orders WHERE store_id = ? AND DATE(created_at) = CURDATE() AND order_number IS NOT NULL',
              [orderStoreId]
            );
            const used = new Set(usedRows.map(r => r.order_number));
            const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            let orderNum = null;
            for (let i = 0; i < 200 && !orderNum; i++) {
              const c = letters[Math.floor(Math.random() * 26)] + String(Math.floor(Math.random() * 99) + 1).padStart(2, '0');
              if (!used.has(c)) orderNum = c;
            }
            if (!orderNum) orderNum = String(used.size + 1);
            await pool.execute('UPDATE orders SET order_number = ? WHERE id = ?', [orderNum, order_id]);
            orderNumber = orderNum;
          }
        }
        const payment = await tuuCreatePayment(apiKey, amount, device.serial, description || '', dteType, orderNumber, tableNumber, tip_amount || 0, tip_percent || 0);
        await pool.execute(
          'INSERT INTO tuu_transactions (store_id, order_id, idempotency_key, amount, status, device_serial) VALUES (?, ?, ?, ?, ?, ?)',
          [parseInt(store_id), order_id || null, payment.idempotencyKey, Math.round(amount), 'Pending', device.serial]
        );
        tuuStartPolling(apiKey, payment.idempotencyKey, parseInt(store_id), order_id);
        res.json({ success: true, paymentKey: payment.idempotencyKey, status: payment.status, deviceName: device.name });
      } catch (e) {
        console.error('[tuu/charge]', e.message);
        res.status(500).json({ error: e.message });
      }
    });

    app.get('/api/tuu/status/:key', async (req, res) => {
      try {
        const [rows] = await pool.execute(
          'SELECT t.*, o.order_number FROM tuu_transactions t LEFT JOIN orders o ON o.id = t.order_id WHERE t.idempotency_key = ?',
          [req.params.key]
        );
        if (rows.length === 0) return res.status(404).json({ error: 'No encontrado' });
        res.json(rows[0]);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/tuu/cancel/:key', async (req, res) => {
      try {
        const key = req.params.key;
        const intervalId = tuuActivePolls.get(key);
        if (intervalId) { clearInterval(intervalId); tuuActivePolls.delete(key); }
        await pool.execute('UPDATE tuu_transactions SET status = ?, updated_at = NOW() WHERE idempotency_key = ?', ['Canceled', key]);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // ── END NATIVE TUU ENDPOINTS ──────────────────────────────────────────

    app.get('/api/plugins/payments/provider', async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const deviceUid = req.query.device_uid;
        const terminalId = parseInt(req.query.terminal_id);
        const terminalProvider = req.query.terminal_provider || '';
        console.log('[provider] store_id:', storeId, 'device_uid:', deviceUid, 'terminal_id:', terminalId, 'terminal_provider:', terminalProvider);
        if (!storeId) { console.log('[provider] FAIL: no storeId'); return res.json({ available: false, reason: 'no storeId' }); }
        let userId;
        try {
          userId = await tuuGetUserIdFromStore(storeId);
          console.log('[provider] userId:', userId);
        } catch (e) { console.log('[provider] tuuGetUserIdFromStore error:', e.message); return res.json({ available: false, reason: 'userId error: ' + e.message }); }
        let config;
        try {
          config = await tuuGetConfig(userId);
          console.log('[provider] config:', config ? JSON.stringify(config) : 'null');
          console.log('[provider] config.api_key exists:', !!config?.api_key);
        } catch (e) { console.log('[provider] tuuGetConfig error:', e.message); return res.json({ available: false, reason: 'config error: ' + e.message }); }
        if (!config?.api_key) { console.log('[provider] FAIL: no api_key'); return res.json({ available: false, reason: 'No hay API Key de Tuu configurada para esta cuenta. Ve al admin > Tuu POS > Configuración.' }); }
        // FIX: Si el usuario eligió explícitamente un terminal que NO es Tuu (ej: MercadoPago),
        // no debemos activar el proveedor Tuu aunque existan dispositivos Tuu en la tienda.
        if (terminalProvider && terminalProvider !== 'tuu') {
          console.log('[provider] SKIP: terminal_provider is', terminalProvider, '- not Tuu, deferring to MercadoPago handler');
          return res.json({ available: false, reason: 'Terminal seleccionado no es Tuu' });
        }
        let device = null;
        if (terminalId && terminalProvider === 'tuu') {
          console.log('[provider] Looking for tuu device by terminal_id:', terminalId);
          const [rows] = await pool.execute('SELECT * FROM tuu_devices WHERE id = ? AND user_id = ?', [terminalId, userId]);
          console.log('[provider] tuu_devices by id result:', rows.length, rows[0]?.name);
          device = rows[0] || null;
        }
        if (!device && deviceUid) {
          console.log('[provider] Looking for tuu device by device_uid:', deviceUid);
          device = await tuuGetDeviceForUid(deviceUid, storeId);
          console.log('[provider] tuuGetDeviceForUid result:', device?.name);
        }
        if (!device) {
          console.log('[provider] Looking for any tuu device for store');
          device = await tuuGetAnyDeviceForStore(storeId);
          console.log('[provider] tuuGetAnyDeviceForStore result:', device?.name);
        }
        if (!device) { console.log('[provider] FAIL: no device found'); return res.json({ available: false, reason: 'No hay POS Tuu configurado para esta tienda. Ve al admin > Tuu POS > Vincular POS.' }); }
        console.log('[provider] SUCCESS - device:', device.name);
        res.json({
          available: true,
          provider: 'tuu',
          deviceUid: device.device_uid || deviceUid,
          deviceName: device.name,
          deviceSerial: device.serial
        });
      } catch (e) { console.error('[provider] error:', e.message); res.json({ available: false, reason: 'error: ' + e.message }); }
    });

    // Square provider — native handler (called when PluginManager passes via next())
    app.get('/api/plugins/payments/provider', async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const terminalId = parseInt(req.query.terminal_id);
        const terminalProvider = req.query.terminal_provider || '';
        if (!storeId) return res.json({ available: false });
        if (terminalProvider && terminalProvider !== 'square') return res.json({ available: false });
        // Get userId from store
        const [storeRows] = await pool.execute('SELECT user_id FROM stores WHERE id = ?', [storeId]);
        if (!storeRows[0]) return res.json({ available: false });
        const userId = storeRows[0].user_id;
        const [cfgRows] = await pool.execute('SELECT * FROM square_config WHERE user_id = ?', [userId]);
        if (!cfgRows[0]?.access_token) return res.json({ available: false, reason: 'No Square config' });
        let device = null;
        if (terminalId) {
          const [rows] = await pool.execute('SELECT * FROM square_devices WHERE id = ? AND user_id = ?', [terminalId, userId]);
          device = rows[0] || null;
        }
        if (!device) {
          const [rows] = await pool.execute('SELECT * FROM square_devices WHERE user_id = ? AND store_id = ? LIMIT 1', [userId, storeId]);
          device = rows[0] || null;
        }
        if (!device) return res.json({ available: false, reason: 'No Square device found' });
        res.json({ available: true, provider: 'square', deviceId: device.device_id, deviceName: device.name });
      } catch (e) { res.json({ available: false, reason: e.message }); }
    });

    app.post('/api/plugins/payments/charge', async (req, res) => {
      try {
        const { store_id, order_id, amount, description, device_uid, terminal_id, terminal_provider } = req.body;
        console.log('[charge] body:', JSON.stringify({ store_id, amount, terminal_id, terminal_provider, device_uid }));
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        if (amount === undefined || amount === null || amount === '') return res.status(400).json({ error: 'amount requerido' });
        if (Number(amount) === 0) return res.status(400).json({ error: 'El monto no puede ser cero' });
        let userId;
        try {
          userId = await tuuGetUserIdFromStore(parseInt(store_id));
          console.log('[charge] userId:', userId);
        } catch (e) { console.error('[charge] userId error:', e.message); return res.status(500).json({ error: 'Error al obtener usuario de tienda' }); }
        let config;
        try {
          config = await tuuGetConfig(userId);
          console.log('[charge] config:', config ? JSON.stringify({api_key: config.api_key ? '***' : 'null'}) : 'null');
        } catch (e) { console.error('[charge] config error:', e.message); return res.status(500).json({ error: 'Error al obtener config Tuu' }); }
        // Si el terminal es Square, lo maneja el bloque Square de abajo.
        if (terminal_provider && terminal_provider === 'square') {
          // ── SQUARE TERMINAL CHARGE ──────────────────────────────────────
          console.log('[charge-square] starting - store_id:', store_id, 'terminal_id:', terminal_id, 'amount:', amount);
          try {
            // Ensure sq_checkouts table exists
            await pool.execute(`CREATE TABLE IF NOT EXISTS sq_checkouts (
              id INT AUTO_INCREMENT PRIMARY KEY,
              checkout_id VARCHAR(255) NOT NULL UNIQUE,
              store_id INT NOT NULL,
              order_id INT DEFAULT NULL,
              amount INT NOT NULL,
              currency VARCHAR(3) DEFAULT 'USD',
              status VARCHAR(50) DEFAULT 'PENDING',
              device_id VARCHAR(255) DEFAULT NULL,
              created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )`);

            // Get Square config for this store
            const [storeRows2] = await pool.execute('SELECT user_id FROM stores WHERE id = ?', [parseInt(store_id)]);
            if (!storeRows2[0]) return res.status(400).json({ error: 'Tienda no encontrada' });
            const sqUserId = storeRows2[0].user_id;
            let sqCfg = await squareGetConfig(sqUserId, parseInt(store_id));
            if (!sqCfg?.access_token) return res.status(400).json({ error: 'Square no configurado. Ve al admin > Vincular POS > Square.' });

            // Find device
            let sqDevice = null;
            if (terminal_id) {
              const [sqDevRows] = await pool.execute('SELECT * FROM square_devices WHERE id = ? AND user_id = ?', [parseInt(terminal_id), sqUserId]);
              sqDevice = sqDevRows[0] || null;
              // Fallback: try pos_terminals (new unified table)
              if (!sqDevice) {
                const posTerm = await getPosTerminalById(parseInt(terminal_id)).catch(() => null);
                if (posTerm && posTerm.provider === 'square') {
                  sqDevice = { device_id: posTerm.device_id, name: posTerm.name };
                  if (posTerm.api_key) sqCfg = { ...sqCfg, access_token: posTerm.api_key };
                }
              }
            }
            if (!sqDevice) {
              const [sqDevRows] = await pool.execute('SELECT * FROM square_devices WHERE user_id = ? AND store_id = ? ORDER BY created_at DESC LIMIT 1', [sqUserId, parseInt(store_id)]);
              sqDevice = sqDevRows[0] || null;
            }
            if (!sqDevice) return res.status(400).json({ error: 'No hay terminal Square vinculado. Ve al admin > Vincular POS > Square.' });

            // Strip device: prefix if present (legacy)
            const sqDeviceId = sqDevice.device_id.startsWith('device:') ? sqDevice.device_id.slice(7) : sqDevice.device_id;

            // Read store currency to convert amount correctly
            // Square always needs the smallest currency unit (cents for USD/EUR/etc, whole units for JPY/CLP/etc)
            const ZERO_DECIMAL_CURRENCIES = new Set(['JPY', 'KRW', 'CLP', 'GNF', 'ISK', 'KMF', 'MGA', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'BIF']);
            const [cfgRows] = await pool.execute('SELECT currency_code FROM store_configurations WHERE store_id = ? LIMIT 1', [parseInt(store_id)]).catch(() => [[]]);
            const storeCurrency = cfgRows[0]?.currency_code || 'USD';
            const sqAmount = ZERO_DECIMAL_CURRENCIES.has(storeCurrency)
              ? Math.round(Number(amount))
              : Math.round(Number(amount) * 100);

            const sqPayload = {
              idempotency_key: 'sq_' + Date.now() + '_' + Math.random().toString(36).slice(2),
              checkout: {
                amount_money: { amount: sqAmount, currency: storeCurrency },
                device_options: { device_id: sqDeviceId },
                reference_id: String(order_id || ''),
                note: description || ('Orden #' + (order_id || '')),
              }
            };

            console.log('[charge-square] POST /v2/terminals/checkouts payload:', JSON.stringify(sqPayload));

            const sqRes = await fetch('https://connect.squareup.com/v2/terminals/checkouts', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + sqCfg.access_token,
                'Square-Version': '2026-01-22'
              },
              body: JSON.stringify(sqPayload)
            });

            const sqData = await sqRes.json();
            console.log('[charge-square] Square response status:', sqRes.status, 'checkout id:', sqData?.checkout?.id);

            if (!sqRes.ok || !sqData?.checkout?.id) {
              const sqErr = sqData?.errors?.[0]?.detail || 'Error desconocido Square';
              console.error('[charge-square] Square API error:', sqErr);
              return res.status(400).json({ error: sqErr });
            }

            const checkoutId = sqData.checkout.id;

            // Persist to DB
            await pool.execute(
              'INSERT INTO sq_checkouts (checkout_id, store_id, order_id, amount, currency, status, device_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
              [checkoutId, parseInt(store_id), order_id || null, sqAmount, 'USD', 'PENDING', sqDeviceId]
            );

            // Start server-side polling (every 5s, max 60 attempts = 5 min)
            let sqAttempts = 0;
            const sqPollId = setInterval(async () => {
              sqAttempts++;
              try {
                const pollRes = await fetch('https://connect.squareup.com/v2/terminals/checkouts/' + encodeURIComponent(checkoutId), {
                  headers: { 'Authorization': 'Bearer ' + sqCfg.access_token, 'Square-Version': '2026-01-22' }
                });
                const pollData = await pollRes.json();
                const sqStatus = pollData?.checkout?.status || 'UNKNOWN';
                console.log('[charge-square] poll attempt', sqAttempts, 'status:', sqStatus, 'checkout:', checkoutId);

                if (sqStatus === 'COMPLETED') {
                  clearInterval(sqPollId); squareActivePolls.delete(checkoutId);
                  await pool.execute('UPDATE sq_checkouts SET status = ? WHERE checkout_id = ?', ['Completed', checkoutId]);
                  if (order_id) {
                    await pool.execute("UPDATE orders SET status = 'preparing', payment_process = 1, cash_approved = TRUE WHERE id = ?", [order_id]).catch(() => {});
                  }
                  const socketId = userSockets.get(parseInt(store_id));
                  console.log('[charge-square] COMPLETED - store_id:', store_id, 'socketId:', socketId || 'NOT FOUND');
                  if (socketId) io.to(socketId).emit('square_payment_update', { checkoutId, orderId: order_id, status: 'Completed' });
                } else if (sqStatus === 'CANCELED' || sqStatus === 'CANCEL_REQUESTED') {
                  clearInterval(sqPollId); squareActivePolls.delete(checkoutId);
                  await pool.execute('UPDATE sq_checkouts SET status = ? WHERE checkout_id = ?', ['Canceled', checkoutId]);
                  if (order_id) {
                    await pool.execute("UPDATE orders SET status = 'canceled' WHERE id = ?", [order_id]).catch(() => {});
                  }
                  const socketId = userSockets.get(parseInt(store_id));
                  if (socketId) io.to(socketId).emit('square_payment_update', { checkoutId, orderId: order_id, status: 'Canceled' });
                }
              } catch (pollErr) { console.error('[charge-square] poll error:', pollErr.message); }

              if (sqAttempts >= 60) {
                clearInterval(sqPollId); squareActivePolls.delete(checkoutId);
                // Auto-cancel on timeout
                fetch('https://connect.squareup.com/v2/terminals/checkouts/' + encodeURIComponent(checkoutId) + '/cancel', {
                  method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + sqCfg.access_token, 'Square-Version': '2026-01-22' },
                  body: '{}'
                }).catch(() => {});
                await pool.execute('UPDATE sq_checkouts SET status = ? WHERE checkout_id = ?', ['Timeout', checkoutId]);
                const socketId = userSockets.get(parseInt(store_id));
                if (socketId) io.to(socketId).emit('square_payment_update', { checkoutId, orderId: order_id, status: 'Timeout' });
              }
            }, 5000);
            squareActivePolls.set(checkoutId, sqPollId);

            return res.json({ success: true, paymentKey: checkoutId, status: 'PENDING', deviceName: sqDevice.name, provider: 'square' });

          } catch (sqErr) {
            console.error('[charge-square] error:', sqErr.message);
            return res.status(500).json({ error: sqErr.message });
          }
          // ── END SQUARE TERMINAL CHARGE ──────────────────────────────────
        }

        if (terminal_provider && terminal_provider !== 'tuu') {
          console.log('[charge] SKIP: terminal_provider is', terminal_provider, '- not Tuu');
          return res.status(400).json({ error: 'Terminal seleccionado no es Tuu. Usa el flujo de MercadoPago.' });
        }
        if (!config?.api_key) {
          console.log('[charge] FAIL: no api_key for userId:', userId);
          return res.status(400).json({ error: 'API Key de Tuu no configurada. Ve al admin > Tuu POS > Configuración y guarda tu API Key.' });
        }
        let device = null;
        if (terminal_id && terminal_provider === 'tuu') {
          console.log('[charge] Looking for device by terminal_id:', terminal_id, 'userId:', userId);
          const [rows] = await pool.execute('SELECT * FROM tuu_devices WHERE id = ? AND user_id = ?', [parseInt(terminal_id), userId]);
          console.log('[charge] tuu_devices result:', rows.length, rows[0]?.name);
          device = rows[0] || null;
        }
        if (!device && device_uid) {
          device = await tuuGetDeviceForUid(device_uid, parseInt(store_id));
          console.log('[charge] tuuGetDeviceForUid result:', device?.name);
        }
        if (!device) {
          device = await tuuGetAnyDeviceForStore(parseInt(store_id));
          console.log('[charge] tuuGetAnyDeviceForStore result:', device?.name);
        }
        if (!device) {
          console.log('[charge] FAIL: no device found');
          return res.status(400).json({ error: 'No hay POS Tuu configurado. Ve al admin > Tuu POS > Vincular POS.' });
        }
        console.log('[charge] SUCCESS - using device:', device.name, 'serial:', device.serial);
        const payment = await tuuCreatePayment(config.api_key, amount, device.serial, description || '', config.dte_type);
        await pool.execute(
          'INSERT INTO tuu_transactions (store_id, order_id, idempotency_key, amount, status, device_serial) VALUES (?, ?, ?, ?, ?, ?)',
          [parseInt(store_id), order_id || null, payment.idempotencyKey, Math.round(amount), 'Pending', device.serial]
        );
        tuuStartPolling(config.api_key, payment.idempotencyKey, parseInt(store_id), order_id);
        res.json({ success: true, paymentKey: payment.idempotencyKey, status: payment.status, deviceName: device.name });
      } catch (e) {
        console.error('Tuu plugin charge error:', e.message);
        res.status(500).json({ error: e.message });
      }
    });

    app.get('/api/plugins/payments/status/:key', async (req, res) => {
      try {
        const key = req.params.key;

        // 1. Check Square checkouts first (checkout IDs look like random strings, not idempotency keys)
        const [sqRows] = await pool.execute('SELECT * FROM sq_checkouts WHERE checkout_id = ?', [key]);
        if (sqRows.length > 0) {
          const sq = sqRows[0];
          // If still pending, query Square API for fresh status
          if (sq.status === 'PENDING') {
            try {
              const storeId = sq.store_id;
              const [storeRows] = await pool.execute('SELECT user_id FROM stores WHERE id = ?', [storeId]);
              const userId = storeRows[0]?.user_id;
              if (userId) {
                const cfg = await squareGetConfig(userId, storeId);
                if (cfg?.access_token) {
                  const pollRes = await fetch('https://connect.squareup.com/v2/terminals/checkouts/' + encodeURIComponent(key), {
                    headers: { 'Authorization': 'Bearer ' + cfg.access_token, 'Square-Version': '2026-01-22' }
                  });
                  const pollData = await pollRes.json();
                  const freshStatus = pollData?.checkout?.status || 'UNKNOWN';
                  if (freshStatus !== 'PENDING' && freshStatus !== 'IN_PROGRESS') {
                    // Normalize Square status → Store.jsx expected values
                    const normalized = freshStatus === 'COMPLETED' ? 'Completed' : freshStatus === 'CANCELED' || freshStatus === 'CANCEL_REQUESTED' ? 'Canceled' : freshStatus;
                    await pool.execute('UPDATE sq_checkouts SET status = ? WHERE checkout_id = ?', [normalized, key]);
                    sq.status = normalized;
                  }
                }
              }
            } catch (pollErr) { console.error('[status-square] poll error:', pollErr.message); }
          }
          // Normalize stored status for Store.jsx polling
          const normalized = sq.status === 'COMPLETED' ? 'Completed' : sq.status === 'CANCELED' ? 'Canceled' : sq.status;
          return res.json({ status: normalized, provider: 'square', checkout_id: key });
        }

        // 2. Fall through to Tuu transactions
        const [rows] = await pool.execute('SELECT * FROM tuu_transactions WHERE idempotency_key = ?', [key]);
        if (rows.length === 0) return res.status(404).json({ error: 'No encontrado' });
        res.json(rows[0]);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/plugins/payments/cancel/:key', async (req, res) => {
      const key = req.params.key;

      // Check if it's a Square checkout
      const [sqRows] = await pool.execute('SELECT * FROM sq_checkouts WHERE checkout_id = ?', [key]).catch(() => [[]]);
      if (sqRows.length > 0) {
        // Stop polling
        const sqPollId = squareActivePolls.get(key);
        if (sqPollId) { clearInterval(sqPollId); squareActivePolls.delete(key); }
        // Cancel on Square API
        try {
          const storeId = sqRows[0].store_id;
          const [storeRows] = await pool.execute('SELECT user_id FROM stores WHERE id = ?', [storeId]);
          const userId = storeRows[0]?.user_id;
          if (userId) {
            const cfg = await squareGetConfig(userId, sqRows[0].store_id);
            if (cfg?.access_token) {
              await fetch('https://connect.squareup.com/v2/terminals/checkouts/' + encodeURIComponent(key) + '/cancel', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + cfg.access_token, 'Square-Version': '2026-01-22' },
                body: '{}'
              });
            }
          }
        } catch (e) { console.error('[cancel-square] error:', e.message); }
        await pool.execute('UPDATE sq_checkouts SET status = ? WHERE checkout_id = ?', ['Canceled', key]).catch(() => {});
        return res.json({ success: true, provider: 'square' });
      }

      // Tuu cancel
      const intervalId = tuuActivePolls.get(key);
      if (intervalId) { clearInterval(intervalId); tuuActivePolls.delete(key); }
      await pool.execute('UPDATE tuu_transactions SET status = ?, updated_at = NOW() WHERE idempotency_key = ?', ['Canceled', key]);
      res.json({ success: true });
    });

    app.post('/api/tuu/pay', async (req, res) => {
      try {
        const { store_id, order_id, amount, description, device_uid } = req.body;
        if (!store_id || !amount) return res.status(400).json({ error: 'store_id y amount requeridos' });
        const userId = await tuuGetUserIdFromStore(parseInt(store_id));
        const config = await tuuGetConfig(userId);
        if (!config?.api_key) return res.status(400).json({ error: 'API Key de Tuu no configurada' });
        let device = device_uid ? await tuuGetDeviceForUid(device_uid, parseInt(store_id)) : null;
        if (!device) device = await tuuGetAnyDeviceForStore(parseInt(store_id));
        if (!device) return res.status(400).json({ error: 'No hay POS asignado. Configura un POS en Tuu POS del admin.' });
        const payment = await tuuCreatePayment(config.api_key, amount, device.serial, description, config.dte_type);
        await pool.execute(
          'INSERT INTO tuu_transactions (store_id, order_id, idempotency_key, amount, status, device_serial) VALUES (?, ?, ?, ?, ?, ?)',
          [parseInt(store_id), order_id || null, payment.idempotencyKey, Math.round(amount), 'Pending', device.serial]
        );
        tuuStartPolling(config.api_key, payment.idempotencyKey, parseInt(store_id), order_id);
        res.json({ success: true, idempotencyKey: payment.idempotencyKey, status: payment.status, deviceName: device.name });
      } catch (e) {
        console.error('Tuu pay error:', e.message);
        res.status(500).json({ error: e.message });
      }
    });

    app.get('/api/tuu/status/:key', async (req, res) => {
      try {
        const [rows] = await pool.execute('SELECT * FROM tuu_transactions WHERE idempotency_key = ?', [req.params.key]);
        if (rows.length === 0) return res.status(404).json({ error: 'No encontrado' });
        res.json(rows[0]);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/tuu/cancel/:key', async (req, res) => {
      const intervalId = tuuActivePolls.get(req.params.key);
      if (intervalId) { clearInterval(intervalId); tuuActivePolls.delete(req.params.key); }
      await pool.execute('UPDATE tuu_transactions SET status = ?, updated_at = NOW() WHERE idempotency_key = ?', ['Canceled', req.params.key]);
      res.json({ success: true });
    });

    app.get('/api/tuu/transactions', async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const [rows] = await pool.execute('SELECT * FROM tuu_transactions WHERE store_id = ? ORDER BY created_at DESC LIMIT 50', [storeId]);
        res.json(rows);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/tuu/test', async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const userId = await tuuGetUserIdFromStore(storeId);
        const config = await tuuGetConfig(userId);
        if (!config?.api_key) return res.json({ success: false, error: 'API Key no configurada' });
        const device = await tuuGetAnyDeviceForStore(storeId);
        res.json({ success: true, device: device?.name || 'Sin POS asignado' });
      } catch (e) { res.json({ success: false, error: e.message }); }
    });


    // =====================================================================
    // SQUARE TERMINAL — device code pairing + payments
    // =====================================================================
    (async () => {
      // Ensure tables exist
      try {
        await pool.execute(`CREATE TABLE IF NOT EXISTS square_config (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          store_id INT DEFAULT NULL,
          access_token TEXT NOT NULL,
          location_id VARCHAR(255) NOT NULL DEFAULT '',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )`);
        // Migration: add store_id if missing
        try {
          await pool.execute('ALTER TABLE square_config ADD COLUMN store_id INT DEFAULT NULL');
          console.log('✅ Columna store_id agregada a square_config');
        } catch (e) { if (!e.message.includes('Duplicate column')) console.error('[Square] migration:', e.message); }
        await pool.execute(`CREATE TABLE IF NOT EXISTS square_devices (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          store_id INT NOT NULL,
          name VARCHAR(255) NOT NULL,
          device_id VARCHAR(255) NOT NULL,
          device_code_id VARCHAR(255) DEFAULT NULL,
          location_id VARCHAR(255) DEFAULT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`);
      } catch (e) { console.error('[Square] Table init error:', e.message); }
    })();

    // Helper: get userId from JWT token
    async function squareGetUserId(req) {
      const auth = req.headers['authorization'] || '';
      const tok = auth.replace('Bearer ', '').trim();
      if (!tok) throw new Error('No token');
      const decoded = jwt.verify(tok, JWT_SECRET);
      return decoded.id;
    }

    // Helper: get Square config by store_id first, fallback to user global
    async function squareGetConfig(userId, storeId = null) {
      if (storeId) {
        const [rows] = await pool.execute('SELECT * FROM square_config WHERE store_id = ? LIMIT 1', [storeId]);
        if (rows[0]) return rows[0];
      }
      const [rows] = await pool.execute('SELECT * FROM square_config WHERE user_id = ? AND store_id IS NULL LIMIT 1', [userId]);
      return rows[0] || null;
    }

    // GET /api/square/config
    app.get('/api/square/config', async (req, res) => {
      try {
        const userId = await squareGetUserId(req);
        const storeId = req.query.store_id ? parseInt(req.query.store_id) : null;
        const cfg = await squareGetConfig(userId, storeId);
        res.json(cfg ? { access_token: cfg.access_token ? '***' : '', location_id: cfg.location_id, hasToken: !!cfg.access_token } : { access_token: '', location_id: '', hasToken: false });
      } catch (e) { res.status(401).json({ error: e.message }); }
    });

    // POST /api/square/config — save access_token + location_id
    app.post('/api/square/config', async (req, res) => {
      try {
        const userId = await squareGetUserId(req);
        const { access_token, location_id, store_id } = req.body;
        if (!access_token) return res.status(400).json({ error: 'access_token requerido' });
        const sid = store_id ? parseInt(store_id) : null;
        const [existing] = await pool.execute(
          sid ? 'SELECT id FROM square_config WHERE store_id = ? LIMIT 1' : 'SELECT id FROM square_config WHERE user_id = ? AND store_id IS NULL LIMIT 1',
          [sid || userId]
        );
        if (existing[0]) {
          await pool.execute('UPDATE square_config SET access_token=?, location_id=?, updated_at=NOW() WHERE id=?',
            [access_token, location_id || '', existing[0].id]);
        } else {
          await pool.execute('INSERT INTO square_config (user_id, store_id, access_token, location_id) VALUES (?,?,?,?)',
            [userId, sid, access_token, location_id || '']);
        }
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // GET /api/square/locations — fetch locations from Square API
    app.get('/api/square/locations', async (req, res) => {
      try {
        const userId = await squareGetUserId(req);
        const storeId = req.query.store_id ? parseInt(req.query.store_id) : null;
        const cfg = await squareGetConfig(userId, storeId);
        if (!cfg?.access_token) return res.status(400).json({ error: 'Configura el Access Token primero' });
        const sqRes = await fetch('https://connect.squareup.com/v2/locations', {
          headers: { 'Authorization': 'Bearer ' + cfg.access_token, 'Square-Version': '2026-01-22' }
        });
        const data = await sqRes.json();
        if (!sqRes.ok) return res.status(sqRes.status).json({ error: data?.errors?.[0]?.detail || 'Error Square API' });
        res.json(data.locations || []);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // POST /api/square/device-code — generate login code
    app.post('/api/square/device-code', async (req, res) => {
      try {
        const userId = await squareGetUserId(req);
        const storeId = req.body.store_id ? parseInt(req.body.store_id) : null;
        const cfg = await squareGetConfig(userId, storeId);
        if (!cfg?.access_token) return res.status(400).json({ error: 'Configura el Access Token primero' });
        const locationId = req.body.location_id || cfg.location_id;
        if (!locationId) return res.status(400).json({ error: 'Se requiere Location ID' });
        const deviceName = req.body.device_name || 'Square Terminal';
        const idempotencyKey = 'sq_code_' + Date.now() + '_' + Math.random().toString(36).slice(2);
        const sqRes = await fetch('https://connect.squareup.com/v2/devices/codes', {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + cfg.access_token, 'Square-Version': '2026-01-22', 'Content-Type': 'application/json' },
          body: JSON.stringify({ idempotency_key: idempotencyKey, device_code: { name: deviceName, product_type: 'TERMINAL_API', location_id: locationId } })
        });
        const data = await sqRes.json();
        if (!sqRes.ok) return res.status(sqRes.status).json({ error: data?.errors?.[0]?.detail || 'Error Square API', errors: data?.errors });
        res.json(data.device_code);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // GET /api/square/device-code/:id — poll pairing status
    app.get('/api/square/device-code/:id', async (req, res) => {
      try {
        const userId = await squareGetUserId(req);
        const storeId = req.query.store_id ? parseInt(req.query.store_id) : null;
        const cfg = await squareGetConfig(userId, storeId);
        if (!cfg?.access_token) return res.status(400).json({ error: 'No config' });
        const sqRes = await fetch('https://connect.squareup.com/v2/devices/codes/' + encodeURIComponent(req.params.id), {
          headers: { 'Authorization': 'Bearer ' + cfg.access_token, 'Square-Version': '2026-01-22' }
        });
        const data = await sqRes.json();
        if (!sqRes.ok) return res.status(sqRes.status).json({ error: data?.errors?.[0]?.detail || 'Error' });
        res.json(data.device_code);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // POST /api/square/devices — save paired device
    app.post('/api/square/devices', async (req, res) => {
      try {
        const userId = await squareGetUserId(req);
        const { store_id, name, device_id, device_code_id, location_id } = req.body;
        if (!store_id || !device_id) return res.status(400).json({ error: 'store_id y device_id requeridos' });
        const [result] = await pool.execute(
          'INSERT INTO square_devices (user_id, store_id, name, device_id, device_code_id, location_id) VALUES (?, ?, ?, ?, ?, ?)',
          [userId, store_id, name || 'Square Terminal', device_id, device_code_id || null, location_id || null]
        );
        res.json({ success: true, id: result.insertId });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // GET /api/square/devices — list devices for store
    app.get('/api/square/devices', async (req, res) => {
      try {
        const userId = await squareGetUserId(req);
        const storeId = parseInt(req.query.store_id);
        const [rows] = await pool.execute('SELECT * FROM square_devices WHERE user_id = ? AND store_id = ? ORDER BY created_at DESC', [userId, storeId]);
        res.json(rows);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // DELETE /api/square/devices/:id
    app.delete('/api/square/devices/:id', async (req, res) => {
      try {
        const userId = await squareGetUserId(req);
        await pool.execute('DELETE FROM square_devices WHERE id = ? AND user_id = ?', [req.params.id, userId]);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // GET /api/plugins/payments/provider — Square native (fallthrough from PluginManager)
    // Already handled above for Tuu — Square check is added here as an additional fallthrough
    app.get('/api/square/provider', async (req, res) => {
      try {
        const userId = await squareGetUserId(req);
        const storeId = parseInt(req.query.store_id);
        const terminalId = parseInt(req.query.terminal_id);
        const terminalProvider = req.query.terminal_provider || '';
        if (terminalProvider && terminalProvider !== 'square') return res.json({ available: false });
        const cfg = await squareGetConfig(userId, storeId || null);
        if (!cfg?.access_token) return res.json({ available: false, reason: 'No Square config' });
        let device = null;
        if (terminalId) {
          const [rows] = await pool.execute('SELECT * FROM square_devices WHERE id = ? AND user_id = ?', [terminalId, userId]);
          device = rows[0] || null;
        }
        if (!device) {
          const [rows] = await pool.execute('SELECT * FROM square_devices WHERE user_id = ? AND store_id = ? LIMIT 1', [userId, storeId]);
          device = rows[0] || null;
        }
        if (!device) return res.json({ available: false, reason: 'No Square device found' });
        res.json({ available: true, provider: 'square', deviceId: device.device_id, deviceName: device.name });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // =====================================================================
    // HAULMER QR — integración nativa (sin plugin)
    // =====================================================================
    const HAULMER_NATIVE_API = 'https://core.payment.haulmer.com/api/v1/payment';

    (async () => {
      try {
        await pool.execute(`CREATE TABLE IF NOT EXISTS haulmer_native_config (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          store_id INT DEFAULT NULL,
          account_id VARCHAR(255) NOT NULL,
          secret_key VARCHAR(500) NOT NULL,
          commerce_name VARCHAR(255) DEFAULT 'Mi Tienda',
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )`);
        // Migration: add store_id if missing
        try {
          await pool.execute('ALTER TABLE haulmer_native_config ADD COLUMN store_id INT DEFAULT NULL');
          console.log('✅ Columna store_id agregada a haulmer_native_config');
        } catch (e) { if (!e.message.includes('Duplicate column')) console.error('[Haulmer] migration:', e.message); }
        await pool.execute(`CREATE TABLE IF NOT EXISTS haulmer_native_transactions (
          id INT AUTO_INCREMENT PRIMARY KEY,
          store_id INT NOT NULL,
          order_id INT DEFAULT NULL,
          reference VARCHAR(120) NOT NULL UNIQUE,
          amount INT NOT NULL,
          status VARCHAR(50) DEFAULT 'pending',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )`);
      } catch (e) { console.error('[Haulmer] Table init error:', e.message); }
    })();

    function haulmerSign(data, secret) {
      const keys = Object.keys(data).filter(k => k.startsWith('x_')).sort();
      const str = keys.filter(k => data[k] != null && data[k] !== '').map(k => k + data[k]).join('');
      return crypto.createHmac('sha256', secret).update(str).digest('hex');
    }

    // GET /api/haulmer/config
    app.get('/api/haulmer/config', authenticateToken, async (req, res) => {
      try {
        const storeId = req.query.store_id ? parseInt(req.query.store_id) : null;
        let rows;
        if (storeId) {
          [rows] = await pool.execute('SELECT account_id, commerce_name FROM haulmer_native_config WHERE store_id = ? LIMIT 1', [storeId]);
          if (!rows[0]) [rows] = await pool.execute('SELECT account_id, commerce_name FROM haulmer_native_config WHERE user_id = ? AND store_id IS NULL LIMIT 1', [req.user.id]);
        } else {
          [rows] = await pool.execute('SELECT account_id, commerce_name FROM haulmer_native_config WHERE user_id = ? AND store_id IS NULL LIMIT 1', [req.user.id]);
        }
        res.json(rows[0] || {});
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // POST /api/haulmer/config
    app.post('/api/haulmer/config', authenticateToken, async (req, res) => {
      try {
        const { account_id, secret_key, commerce_name, store_id } = req.body;
        if (!account_id) return res.status(400).json({ error: 'account_id requerido' });
        const sid = store_id ? parseInt(store_id) : null;
        const [existing] = await pool.execute(
          sid ? 'SELECT id FROM haulmer_native_config WHERE store_id = ? LIMIT 1' : 'SELECT id FROM haulmer_native_config WHERE user_id = ? AND store_id IS NULL LIMIT 1',
          [sid || req.user.id]
        );
        if (existing[0]) {
          await pool.execute('UPDATE haulmer_native_config SET account_id=?, secret_key=?, commerce_name=?, updated_at=NOW() WHERE id=?',
            [account_id.trim(), (secret_key || '').trim(), (commerce_name || 'Mi Tienda').trim(), existing[0].id]);
        } else {
          await pool.execute('INSERT INTO haulmer_native_config (user_id, store_id, account_id, secret_key, commerce_name) VALUES (?,?,?,?,?)',
            [req.user.id, sid, account_id.trim(), (secret_key || '').trim(), (commerce_name || 'Mi Tienda').trim()]);
        }
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // GET /api/haulmer/available?store_id=X
    app.get('/api/haulmer/available', async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const [storeRows] = await pool.execute('SELECT user_id FROM stores WHERE id = ?', [storeId]);
        if (!storeRows[0]) return res.json({ available: false });
        let [rows] = await pool.execute('SELECT account_id, secret_key FROM haulmer_native_config WHERE store_id = ? LIMIT 1', [storeId]);
        if (!rows[0]) [rows] = await pool.execute('SELECT account_id, secret_key FROM haulmer_native_config WHERE user_id = ? AND store_id IS NULL LIMIT 1', [storeRows[0].user_id]);
        const cfg = rows[0];
        res.json({ available: !!(cfg?.account_id && cfg?.secret_key) });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // POST /api/haulmer/payment — crea pago y devuelve URL
    app.post('/api/haulmer/payment', async (req, res) => {
      try {
        const { store_id, order_id, amount, description, return_url,
                customer_email, customer_name, customer_phone } = req.body;
        const [storeRows] = await pool.execute('SELECT user_id, code FROM stores WHERE id = ?', [store_id]);
        if (!storeRows[0]) return res.status(404).json({ error: 'Tienda no encontrada' });
        let [cfgRows] = await pool.execute('SELECT * FROM haulmer_native_config WHERE store_id = ? LIMIT 1', [store_id]);
        if (!cfgRows[0]) [cfgRows] = await pool.execute('SELECT * FROM haulmer_native_config WHERE user_id = ? AND store_id IS NULL LIMIT 1', [storeRows[0].user_id]);
        const config = cfgRows[0];
        if (!config?.account_id || !config?.secret_key) return res.status(400).json({ error: 'Haulmer no configurado' });

        const storeCode = storeRows[0].code;
        const reference = `SRSN-${store_id}-${order_id || 0}-${Date.now()}`;
        const serverUrl = 'https://srservi2.srautomatic.com';

        const nameParts = (customer_name || 'Cliente SRServi').split(' ');
        const firstName = nameParts[0] || 'Cliente';
        const lastName = nameParts.slice(1).join(' ') || 'SRServi';

        const baseReturnUrl = return_url ? `${serverUrl}${return_url}` : `${serverUrl}/store/${storeCode}`;
        const completeUrl = `${baseReturnUrl}${baseReturnUrl.includes('?') ? '&' : '?'}ref=${reference}`;
        const cancelUrl = return_url ? `${serverUrl}${return_url}` : `${serverUrl}/store/${storeCode}`;

        const payload = {
          x_account_id: config.account_id,
          x_amount: Math.round(amount),
          x_currency: 'CLP',
          x_customer_email: customer_email || 'cliente@srservi.com',
          x_customer_first_name: firstName,
          x_customer_last_name: lastName,
          x_customer_phone: customer_phone || '+56900000000',
          x_description: description || 'Pago SRServi',
          x_reference: reference,
          x_shop_name: config.commerce_name || 'SRServi',
          x_url_callback: `${serverUrl}/api/haulmer/webhook`,
          x_url_cancel:   cancelUrl,
          x_url_complete: completeUrl
        };
        payload.x_signature = haulmerSign(payload, config.secret_key);

        const hRes = await fetch(HAULMER_NATIVE_API, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-REDIRECT': 'false' },
          body: JSON.stringify(payload)
        });
        if (!hRes.ok) throw new Error(`Haulmer ${hRes.status}: ${await hRes.text()}`);

        const raw = await hRes.text();
        let paymentUrl = null;
        try { const d = JSON.parse(raw); paymentUrl = d.url || d.redirectUrl || d.x_redirect_url || d.processUrl || d.payment_url; } catch {}
        if (!paymentUrl && raw.startsWith('http')) paymentUrl = raw.trim();
        if (!paymentUrl) throw new Error('No se obtuvo URL de pago de Haulmer');

        await pool.execute(
          'INSERT INTO haulmer_native_transactions (store_id, order_id, reference, amount, status) VALUES (?, ?, ?, ?, ?)',
          [store_id, order_id || null, reference, Math.round(amount), 'pending']
        );
        if (order_id) {
          await pool.execute('UPDATE orders SET external_reference = ? WHERE id = ?', [reference, order_id]).catch(() => {});
        }

        res.json({ success: true, paymentUrl, reference });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // GET /api/haulmer/payment/:reference/status — poll desde frontend
    app.get('/api/haulmer/payment/:reference/status', async (req, res) => {
      try {
        const [rows] = await pool.execute(
          'SELECT t.status, t.order_id, t.reference, t.amount, o.order_number FROM haulmer_native_transactions t LEFT JOIN orders o ON o.id = t.order_id WHERE t.reference = ?',
          [req.params.reference]
        );
        if (!rows[0]) return res.status(404).json({ error: 'No encontrado' });
        res.json(rows[0]);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Shared helper: confirm a Haulmer payment, update order, assign order_number
    async function haulmerConfirmOrder(tx, reference, authCode) {
      await pool.execute(
        'UPDATE haulmer_native_transactions SET status = ?, updated_at = NOW() WHERE reference = ?',
        ['completed', reference]
      );
      if (!tx.order_id) return null;
      await pool.execute(
        "UPDATE orders SET payment_process = 1, cash_approved = TRUE, status = 'preparing', reference_id = ?, sequence_id = ? WHERE id = ?",
        [authCode || reference, reference, tx.order_id]
      ).catch(() => {});
      // Assign order_number if missing
      const [existing] = await pool.execute('SELECT order_number FROM orders WHERE id = ?', [tx.order_id]);
      let finalOrderNumber = existing[0]?.order_number || null;
      if (existing[0] && !existing[0].order_number) {
        const [usedRows] = await pool.execute(
          'SELECT order_number FROM orders WHERE store_id = ? AND DATE(created_at) = CURDATE() AND order_number IS NOT NULL',
          [tx.store_id]
        );
        const used = new Set(usedRows.map(r => r.order_number));
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        let orderNum = null;
        for (let i = 0; i < 200 && !orderNum; i++) {
          const c = letters[Math.floor(Math.random() * 26)] + String(Math.floor(Math.random() * 99) + 1).padStart(2, '0');
          if (!used.has(c)) orderNum = c;
        }
        if (!orderNum) orderNum = String(used.size + 1);
        await pool.execute('UPDATE orders SET order_number = ? WHERE id = ?', [orderNum, tx.order_id]);
        finalOrderNumber = orderNum;
      }
      return finalOrderNumber;
    }

    // POST /api/haulmer/webhook — Haulmer llama aquí al completar el pago
    app.post('/api/haulmer/webhook', async (req, res) => {
      try {
        const params = { ...req.query, ...req.body };
        const reference = params.x_reference;
        const result    = params.x_result;
        if (!reference) return res.status(400).json({ error: 'Missing reference' });

        const [txs] = await pool.execute('SELECT * FROM haulmer_native_transactions WHERE reference = ?', [reference]);
        if (!txs[0]) return res.status(404).json({ error: 'Transacción no encontrada' });
        const tx = txs[0];

        // Verificar firma
        const [cfgRows] = await pool.execute(
          `SELECT hnc.* FROM haulmer_native_config hnc
           JOIN stores s ON s.user_id = hnc.user_id WHERE s.id = ?`, [tx.store_id]
        );
        const config = cfgRows[0];
        if (config && params.x_signature) {
          const checkData = { ...params }; delete checkData.x_signature;
          if (haulmerSign(checkData, config.secret_key) !== params.x_signature) {
            return res.status(400).json({ error: 'Firma inválida' });
          }
        }

        if (result === 'completed' && tx.status !== 'completed') {
          const orderNumber = await haulmerConfirmOrder(tx, reference, params.x_authorization_code || null);
          // Handle ticket purchases (TKT- prefix)
          if (reference.startsWith('TKT-')) {
            const [tktPurchases] = await pool.execute("SELECT * FROM ticket_purchases WHERE haulmer_reference = ? AND status = 'pending'", [reference]);
            if (tktPurchases[0]) {
              await pool.execute("UPDATE ticket_purchases SET status = 'paid', paid_at = NOW() WHERE haulmer_reference = ?", [reference]);
              issueAndEmailTickets(tktPurchases[0].id).catch(e => console.error('[Ticketería]', e.message));
            }
          }
          if (tx.order_id) {
            io.to(`store_${tx.store_id}`).emit('qr_payment_completed', { order_id: tx.order_id, reference, order_number: orderNumber });
            // Also emit payment_confirmed so WorkerPanel picks it up in real-time
            const [orderRows] = await pool.execute('SELECT * FROM orders WHERE id = ?', [tx.order_id]);
            if (orderRows[0]) {
              const [itemRows] = await pool.execute('SELECT * FROM order_items WHERE order_id = ?', [tx.order_id]);
              io.to(`store_${tx.store_id}`).emit('payment_confirmed', { ...orderRows[0], items: itemRows });
            }
          }
        } else if (result === 'failed' || result === 'cancelled') {
          await pool.execute(
            'UPDATE haulmer_native_transactions SET status = ?, updated_at = NOW() WHERE reference = ?',
            [result, reference]
          );
        }
        res.json({ success: true });
      } catch (e) { console.error('[Haulmer webhook]', e); res.status(500).json({ error: e.message }); }
    });

    // POST /api/haulmer/confirm — frontend llama esto al volver de pago con x_result=completed
    app.post('/api/haulmer/confirm', async (req, res) => {
      try {
        const params = req.body;
        const reference = params.x_reference;
        if (!reference || !reference.startsWith('SRSN-')) return res.status(400).json({ error: 'Referencia inválida' });

        const [txs] = await pool.execute('SELECT * FROM haulmer_native_transactions WHERE reference = ?', [reference]);
        if (!txs[0]) return res.status(404).json({ error: 'Transacción no encontrada' });
        const tx = txs[0];

        if (tx.status === 'completed') {
          // Already confirmed — just return the order_number
          const [orRows] = await pool.execute('SELECT order_number FROM orders WHERE id = ?', [tx.order_id]);
          return res.json({ success: true, order_number: orRows[0]?.order_number || null, already_confirmed: true });
        }

        const orderNumber = await haulmerConfirmOrder(tx, reference, params.x_authorization_code || null);
        if (tx.order_id) {
          io.to(`store_${tx.store_id}`).emit('qr_payment_completed', { order_id: tx.order_id, reference, order_number: orderNumber });
          const [orderRows] = await pool.execute('SELECT * FROM orders WHERE id = ?', [tx.order_id]);
          if (orderRows[0]) {
            const [itemRows] = await pool.execute('SELECT * FROM order_items WHERE order_id = ?', [tx.order_id]);
            io.to(`store_${tx.store_id}`).emit('payment_confirmed', { ...orderRows[0], items: itemRows });
          }
        }
        res.json({ success: true, order_number: orderNumber });
      } catch (e) { console.error('[Haulmer confirm]', e); res.status(500).json({ error: e.message }); }
    });

    // ── Ratings ─────────────────────────────────────────────────────────────
    // Public: submit a rating for a store
    app.post('/api/public/:code/ratings', async (req, res) => {
      try {
        const store = await getStoreByCode(req.params.code);
        if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
        const { rating, comment, order_id, source } = req.body;
        const r = parseInt(rating);
        if (isNaN(r) || r < 0 || r > 10) return res.status(400).json({ error: 'La calificación debe ser entre 0 y 10' });
        await pool.execute(
          'INSERT INTO store_ratings (store_id, order_id, rating, comment, source) VALUES (?, ?, ?, ?, ?)',
          [store.id, order_id || null, r, comment?.trim() || null, source || 'qr']
        );
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: get ratings for selected store
    app.get('/api/ratings', authenticateToken, async (req, res) => {
      try {
        const { store_id } = req.query;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        // Verify ownership
        const [storeRows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!storeRows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [ratings] = await pool.execute(
          'SELECT * FROM store_ratings WHERE store_id = ? ORDER BY created_at DESC LIMIT 200',
          [store_id]
        );
        const [summary] = await pool.execute(
          'SELECT COUNT(*) as total, AVG(rating) as avg_rating FROM store_ratings WHERE store_id = ?',
          [store_id]
        );
        res.json({ ratings, summary: summary[0] });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // ── Rappi Integration ────────────────────────────────────────────────────

    // Admin: get Rappi config
    app.get('/api/rappi/config', authenticateToken, async (req, res) => {
      try {
        const { store_id } = req.query;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [rows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!rows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [cfg] = await pool.execute('SELECT * FROM rappi_config WHERE store_id = ?', [store_id]);
        res.json({ config: cfg[0] || null });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: save Rappi config
    app.post('/api/rappi/config', authenticateToken, async (req, res) => {
      try {
        const { store_id, is_enabled, webhook_secret } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [rows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!rows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [existing] = await pool.execute('SELECT id FROM rappi_config WHERE store_id = ?', [store_id]);
        if (existing.length) {
          await pool.execute(
            'UPDATE rappi_config SET is_enabled = ?, webhook_secret = ? WHERE store_id = ?',
            [is_enabled ? 1 : 0, webhook_secret || null, store_id]
          );
        } else {
          await pool.execute(
            'INSERT INTO rappi_config (store_id, is_enabled, webhook_secret) VALUES (?, ?, ?)',
            [store_id, is_enabled ? 1 : 0, webhook_secret || null]
          );
        }
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: get recent Rappi orders
    app.get('/api/rappi/orders', authenticateToken, async (req, res) => {
      try {
        const { store_id } = req.query;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [rows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!rows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [orders] = await pool.execute(
          `SELECT id, order_number, rappi_order_id, customer_name, customer_phone,
                  external_items, total, status, payment_method, created_at
           FROM orders WHERE store_id = ? AND order_type = 'rappi'
           ORDER BY created_at DESC LIMIT 100`,
          [store_id]
        );
        res.json({ orders });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Public: Rappi webhook — receives orders from Rappi platform
    app.post('/api/rappi/webhook/:store_code', async (req, res) => {
      try {
        const store = await getStoreByCode(req.params.store_code);
        if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });

        // Check config
        const [cfgRows] = await pool.execute('SELECT * FROM rappi_config WHERE store_id = ?', [store.id]);
        const cfg = cfgRows[0];
        if (!cfg || !cfg.is_enabled) return res.status(403).json({ error: 'Integración Rappi no habilitada' });

        // Verify webhook secret if configured
        if (cfg.webhook_secret) {
          const sig = req.headers['x-rappi-signature'] || req.headers['x-webhook-token'] || req.headers['authorization'];
          if (!sig || !sig.includes(cfg.webhook_secret)) {
            return res.status(401).json({ error: 'Firma inválida' });
          }
        }

        const payload = req.body;

        // Flexible Rappi payload parsing — handles multiple format versions
        const rappiId = payload.id || payload.order_id || payload.orderId || String(Date.now());
        const rappiState = (payload.state || payload.status || '').toUpperCase();

        // Ignore cancellations and non-confirmed states
        if (['CANCELLED', 'REJECTED', 'EXPIRED'].includes(rappiState)) {
          return res.json({ success: true, ignored: true });
        }

        // Avoid duplicate orders
        const [existing] = await pool.execute('SELECT id FROM orders WHERE rappi_order_id = ? AND store_id = ?', [rappiId, store.id]);
        if (existing.length) return res.json({ success: true, duplicate: true });

        // Parse items — Rappi sends items in various structures
        let rawItems = [];
        const orderBody = payload.order || payload;
        if (Array.isArray(orderBody.items_with_price)) rawItems = orderBody.items_with_price;
        else if (Array.isArray(orderBody.items)) rawItems = orderBody.items;
        else if (Array.isArray(payload.items)) rawItems = payload.items;
        else if (Array.isArray(payload.products)) rawItems = payload.products;

        const externalItems = rawItems.map(i => ({
          name: i.name || i.product_name || i.sku || 'Producto',
          quantity: Number(i.quantity || i.qty || 1),
          unit_price: Number(i.price || i.unit_price || i.unitPrice || 0),
          notes: i.comment || i.note || '',
        }));

        // Parse total
        const total = Number(
          payload.total_value || payload.totalValue || payload.total ||
          orderBody.total || orderBody.total_value ||
          externalItems.reduce((s, i) => s + i.unit_price * i.quantity, 0) || 0
        );

        // Parse customer
        const client = payload.client || payload.customer || payload.user || {};
        const customerName = [client.name, client.first_name, client.firstName].filter(Boolean).join(' ') || 'Cliente Rappi';
        const customerPhone = client.phone || client.cellphone || '';

        // Parse payment
        const payMethod = (payload.payment_method || (payload.payment && payload.payment.type) || 'online').toLowerCase();
        const isCash = payMethod.includes('cash') || payMethod.includes('efectivo');

        // Get store order_number
        const orderNumber = await generateUniqueOrderNumber(store.id);

        const [result] = await pool.execute(
          `INSERT INTO orders (store_id, user_id, order_type, subtotal, discount_total, total, payment_method,
           cash_approved, payment_process, status, external_items, customer_name, customer_phone,
           rappi_order_id, order_number)
           VALUES (?, ?, 'rappi', ?, 0, ?, ?, ?, 1, 'preparing', ?, ?, ?, ?, ?)`,
          [
            store.id, store.user_id,
            total, total,
            isCash ? 'cash' : 'online',
            isCash ? 0 : 1,
            JSON.stringify(externalItems),
            customerName, customerPhone,
            rappiId, orderNumber
          ]
        );
        const orderId = result.insertId;

        const newOrder = {
          id: orderId,
          order_number: orderNumber,
          store_id: store.id,
          order_type: 'rappi',
          total,
          status: 'preparing',
          payment_method: isCash ? 'cash' : 'online',
          cash_approved: isCash ? 0 : 1,
          payment_process: 1,
          external_items: externalItems,
          customer_name: customerName,
          customer_phone: customerPhone,
          rappi_order_id: rappiId,
          items: externalItems,
          created_at: new Date().toISOString(),
        };

        // Notify worker panel via socket
        const socketId = userSockets.get(store.id);
        if (socketId) {
          io.to(socketId).emit('new_order', newOrder);
        }

        res.json({ success: true, order_id: orderId, order_number: orderNumber });
      } catch (e) {
        console.error('Rappi webhook error:', e);
        res.status(500).json({ error: e.message });
      }
    });

    // ── System Updates / Changelog ───────────────────────────────────────────
    const { CHANGELOGS } = await import('./changelogs.js');

    // Get updates + unread count for current user
    app.get('/api/updates', authenticateToken, async (req, res) => {
      try {
        const [rows] = await pool.execute('SELECT last_seen_update_id FROM users WHERE id = ?', [req.user.id]);
        const lastSeen = rows[0]?.last_seen_update_id || 0;
        const unread = CHANGELOGS.filter(u => u.id > lastSeen).length;
        res.json({ updates: CHANGELOGS, unread, last_seen_id: lastSeen });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Mark all updates as seen
    app.post('/api/updates/mark-seen', authenticateToken, async (req, res) => {
      try {
        const latest = CHANGELOGS[0]?.id || 0;
        await pool.execute('UPDATE users SET last_seen_update_id = ? WHERE id = ?', [latest, req.user.id]);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // ── UberEats Integration ─────────────────────────────────────────────────

    app.get('/api/ubereats/config', authenticateToken, async (req, res) => {
      try {
        const { store_id } = req.query;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [rows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!rows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [cfg] = await pool.execute('SELECT * FROM ubereats_config WHERE store_id = ?', [store_id]);
        res.json({ config: cfg[0] || null });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/ubereats/config', authenticateToken, async (req, res) => {
      try {
        const { store_id, is_enabled, webhook_secret } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [rows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!rows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [existing] = await pool.execute('SELECT id FROM ubereats_config WHERE store_id = ?', [store_id]);
        if (existing.length) {
          await pool.execute('UPDATE ubereats_config SET is_enabled = ?, webhook_secret = ? WHERE store_id = ?',
            [is_enabled ? 1 : 0, webhook_secret || null, store_id]);
        } else {
          await pool.execute('INSERT INTO ubereats_config (store_id, is_enabled, webhook_secret) VALUES (?, ?, ?)',
            [store_id, is_enabled ? 1 : 0, webhook_secret || null]);
        }
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/ubereats/orders', authenticateToken, async (req, res) => {
      try {
        const { store_id } = req.query;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [rows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!rows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [orders] = await pool.execute(
          `SELECT id, order_number, ubereats_order_id, customer_name, customer_phone,
                  external_items, total, status, payment_method, created_at
           FROM orders WHERE store_id = ? AND order_type = 'ubereats'
           ORDER BY created_at DESC LIMIT 100`,
          [store_id]
        );
        res.json({ orders });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Public: UberEats webhook
    app.post('/api/ubereats/webhook/:store_code', async (req, res) => {
      try {
        const store = await getStoreByCode(req.params.store_code);
        if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });

        const [cfgRows] = await pool.execute('SELECT * FROM ubereats_config WHERE store_id = ?', [store.id]);
        const cfg = cfgRows[0];
        if (!cfg || !cfg.is_enabled) return res.status(403).json({ error: 'Integración UberEats no habilitada' });

        if (cfg.webhook_secret) {
          const sig = req.headers['x-uber-signature'] || req.headers['x-webhook-token'] || req.headers['authorization'] || '';
          if (!sig.includes(cfg.webhook_secret)) return res.status(401).json({ error: 'Firma inválida' });
        }

        const payload = req.body;

        // Ignore non-order or cancelled events
        const eventType = payload.event_type || payload.type || '';
        const status = (payload.status || payload.current_state || '').toLowerCase();
        if (status === 'cancelled' || status === 'unfulfilled' || eventType === 'orders.cancel') {
          return res.json({ success: true, ignored: true });
        }

        // UberEats order ID
        const ueId = String(payload.order_id || payload.id || payload.orderId || Date.now());

        // Avoid duplicates
        const [existing] = await pool.execute('SELECT id FROM orders WHERE ubereats_order_id = ? AND store_id = ?', [ueId, store.id]);
        if (existing.length) return res.json({ success: true, duplicate: true });

        // Parse items — UberEats uses cart.items[] with nested price objects
        const externalItems = [];
        const cartItems = payload.cart?.items || payload.items || payload.orderItems || [];
        for (const item of cartItems) {
          // UberEats price can be nested: price.unit_price.amount or flat unit_price
          const unitPrice = Number(
            item.price?.unit_price?.amount || item.price?.base_unit_price?.amount ||
            item.unit_price || item.price || 0
          );
          // Modifiers / selected options
          const modGroups = item.selected_modifier_groups || item.customizations || item.modifiers || [];
          const mods = modGroups
            .flatMap(g => (g.selected_items || g.options || []).map(o => o.title || o.name || ''))
            .filter(Boolean).join(', ');
          externalItems.push({
            name: item.title || item.name || item.productName || 'Producto',
            quantity: Number(item.quantity || item.qty || 1),
            unit_price: unitPrice,
            notes: [item.special_instructions, mods].filter(Boolean).join(' · '),
          });
        }

        // Total — UberEats uses total.price or total_price.amount
        const total = Number(
          payload.total?.price || payload.total?.amount ||
          payload.total_price?.amount || payload.totalAmount || payload.total ||
          externalItems.reduce((s, i) => s + i.unit_price * i.quantity, 0) || 0
        );

        // Customer — UberEats uses eater object
        const eater = payload.eater || payload.customer || payload.user || {};
        const customerName = [eater.first_name, eater.last_name, eater.name].filter(Boolean).join(' ') || 'Cliente UberEats';
        const customerPhone = eater.phone || eater.phone_number || '';

        // Payment — UberEats orders are almost always prepaid online
        const rawPay = (payload.payment_info?.status || payload.payment_method || 'online').toLowerCase();
        const isCash = rawPay.includes('cash') || rawPay.includes('efectivo');

        const orderNumber = await generateUniqueOrderNumber(store.id);

        const [result] = await pool.execute(
          `INSERT INTO orders (store_id, user_id, order_type, subtotal, discount_total, total, payment_method,
           cash_approved, payment_process, status, external_items, customer_name, customer_phone,
           ubereats_order_id, order_number)
           VALUES (?, ?, 'ubereats', ?, 0, ?, ?, ?, 1, 'preparing', ?, ?, ?, ?, ?)`,
          [
            store.id, store.user_id, total, total,
            isCash ? 'cash' : 'online', isCash ? 0 : 1,
            JSON.stringify(externalItems),
            customerName, customerPhone, ueId, orderNumber,
          ]
        );
        const orderId = result.insertId;

        const newOrder = {
          id: orderId, order_number: orderNumber, store_id: store.id,
          order_type: 'ubereats', total, status: 'preparing',
          payment_method: isCash ? 'cash' : 'online',
          cash_approved: isCash ? 0 : 1, payment_process: 1,
          external_items: externalItems, customer_name: customerName,
          customer_phone: customerPhone, ubereats_order_id: ueId,
          items: externalItems, created_at: new Date().toISOString(),
        };

        const socketId = userSockets.get(store.id);
        if (socketId) io.to(socketId).emit('new_order', newOrder);

        res.json({ success: true, order_id: orderId, order_number: orderNumber });
      } catch (e) {
        console.error('UberEats webhook error:', e);
        res.status(500).json({ error: e.message });
      }
    });

    // ── PedidosYa Integration ────────────────────────────────────────────────

    app.get('/api/pedidosya/config', authenticateToken, async (req, res) => {
      try {
        const { store_id } = req.query;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [rows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!rows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [cfg] = await pool.execute('SELECT * FROM pedidosya_config WHERE store_id = ?', [store_id]);
        res.json({ config: cfg[0] || null });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/pedidosya/config', authenticateToken, async (req, res) => {
      try {
        const { store_id, is_enabled, webhook_secret } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [rows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!rows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [existing] = await pool.execute('SELECT id FROM pedidosya_config WHERE store_id = ?', [store_id]);
        if (existing.length) {
          await pool.execute(
            'UPDATE pedidosya_config SET is_enabled = ?, webhook_secret = ? WHERE store_id = ?',
            [is_enabled ? 1 : 0, webhook_secret || null, store_id]
          );
        } else {
          await pool.execute(
            'INSERT INTO pedidosya_config (store_id, is_enabled, webhook_secret) VALUES (?, ?, ?)',
            [store_id, is_enabled ? 1 : 0, webhook_secret || null]
          );
        }
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/pedidosya/orders', authenticateToken, async (req, res) => {
      try {
        const { store_id } = req.query;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [rows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!rows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [orders] = await pool.execute(
          `SELECT id, order_number, pedidosya_order_id, customer_name, customer_phone,
                  external_items, total, status, payment_method, created_at
           FROM orders WHERE store_id = ? AND order_type = 'pedidosya'
           ORDER BY created_at DESC LIMIT 100`,
          [store_id]
        );
        res.json({ orders });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Public: PedidosYa webhook
    app.post('/api/pedidosya/webhook/:store_code', async (req, res) => {
      try {
        const store = await getStoreByCode(req.params.store_code);
        if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });

        const [cfgRows] = await pool.execute('SELECT * FROM pedidosya_config WHERE store_id = ?', [store.id]);
        const cfg = cfgRows[0];
        if (!cfg || !cfg.is_enabled) return res.status(403).json({ error: 'Integración PedidosYa no habilitada' });

        if (cfg.webhook_secret) {
          const sig = req.headers['x-pedidosya-signature'] || req.headers['x-webhook-token'] || req.headers['authorization'] || '';
          if (!sig.includes(cfg.webhook_secret)) return res.status(401).json({ error: 'Firma inválida' });
        }

        const payload = req.body;

        // Ignore non-confirmed states
        const state = (payload.state || payload.status || payload.orderState || '').toUpperCase();
        if (['CANCELLED', 'REJECTED', 'EXPIRED', 'CLOSED_REJECTED'].includes(state)) {
          return res.json({ success: true, ignored: true });
        }

        // PedidosYa order ID
        const pyId = String(payload.orderId || payload.id || payload.order_id || Date.now());

        // Avoid duplicates
        const [existing] = await pool.execute('SELECT id FROM orders WHERE pedidosya_order_id = ? AND store_id = ?', [pyId, store.id]);
        if (existing.length) return res.json({ success: true, duplicate: true });

        // Parse items — PedidosYa groups items in sections[]
        const externalItems = [];
        const sections = payload.sections || payload.products || payload.items || [];
        if (Array.isArray(sections) && sections.length) {
          // PedidosYa format: sections[].items[]
          for (const section of sections) {
            const sectionItems = section.items || (section.integrationCode ? [section] : []);
            for (const item of sectionItems) {
              const options = (item.optionGroups || item.options || [])
                .flatMap(g => (g.options || [g]).map(o => o.name || ''))
                .filter(Boolean)
                .join(', ');
              externalItems.push({
                name: item.name || item.productName || item.integrationCode || 'Producto',
                quantity: Number(item.amount || item.quantity || item.qty || 1),
                unit_price: Number(item.price || item.unitPrice || item.unit_price || 0),
                notes: [item.comment, options].filter(Boolean).join(' · '),
              });
            }
          }
        } else if (Array.isArray(payload.orderItems)) {
          // Alternative flat format
          for (const item of payload.orderItems) {
            externalItems.push({
              name: item.name || item.productName || 'Producto',
              quantity: Number(item.quantity || item.amount || 1),
              unit_price: Number(item.price || item.unitPrice || 0),
              notes: item.comment || '',
            });
          }
        }

        // Parse total — PedidosYa uses totalAmount or totalValue
        const total = Number(
          payload.totalAmount || payload.totalValue || payload.total || payload.subTotal ||
          externalItems.reduce((s, i) => s + i.unit_price * i.quantity, 0) || 0
        );

        // Parse customer
        const user = payload.user || payload.customer || payload.client || {};
        const customerName = [user.name, user.firstName, user.lastName].filter(Boolean).join(' ') || 'Cliente PedidosYa';
        const customerPhone = user.phone || user.cellphone || '';

        // Payment
        const rawPay = (payload.paymentMethod || payload.payment_method || 'online').toString().toLowerCase();
        const isCash = rawPay.includes('cash') || rawPay.includes('efectivo') || rawPay.includes('money');

        const orderNumber = await generateUniqueOrderNumber(store.id);

        const [result] = await pool.execute(
          `INSERT INTO orders (store_id, user_id, order_type, subtotal, discount_total, total, payment_method,
           cash_approved, payment_process, status, external_items, customer_name, customer_phone,
           pedidosya_order_id, order_number)
           VALUES (?, ?, 'pedidosya', ?, 0, ?, ?, ?, 1, 'preparing', ?, ?, ?, ?, ?)`,
          [
            store.id, store.user_id,
            total, total,
            isCash ? 'cash' : 'online',
            isCash ? 0 : 1,
            JSON.stringify(externalItems),
            customerName, customerPhone,
            pyId, orderNumber,
          ]
        );
        const orderId = result.insertId;

        const newOrder = {
          id: orderId,
          order_number: orderNumber,
          store_id: store.id,
          order_type: 'pedidosya',
          total,
          status: 'preparing',
          payment_method: isCash ? 'cash' : 'online',
          cash_approved: isCash ? 0 : 1,
          payment_process: 1,
          external_items: externalItems,
          customer_name: customerName,
          customer_phone: customerPhone,
          pedidosya_order_id: pyId,
          items: externalItems,
          created_at: new Date().toISOString(),
        };

        const socketId = userSockets.get(store.id);
        if (socketId) io.to(socketId).emit('new_order', newOrder);

        res.json({ success: true, order_id: orderId, order_number: orderNumber });
      } catch (e) {
        console.error('PedidosYa webhook error:', e);
        res.status(500).json({ error: e.message });
      }
    });

    const DEFAULT_SURVEY_QUESTIONS = [
      { key: 'frequency',       text: '¿Con qué frecuencia nos visitas?',          options: ['Primera vez', 'A veces', 'Seguido', 'Siempre'] },
      { key: 'how_found',       text: '¿Cómo nos conociste?',                       options: ['Redes sociales', 'Recomendación', 'Google', 'Pasando por aquí'] },
      { key: 'age_range',       text: '¿Cuál es tu rango de edad?',                 options: ['Menos de 25', '25–35', '36–50', 'Más de 50'] },
      { key: 'product_quality', text: '¿Cómo calificarías la calidad del producto?', options: ['Excelente', 'Buena', 'Regular', 'Mala'] },
      { key: 'disliked',        text: '¿Qué no te gustó de tu visita?',             options: ['El producto', 'La atención', 'El tiempo de espera', 'El precio'] },
      { key: 'wait_time',       text: '¿Cómo fue el tiempo de espera?',             options: ['Muy rápido', 'Aceptable', 'Un poco largo', 'Demasiado largo'] },
      { key: 'staff',           text: '¿Cómo fue la atención del personal?',        options: ['Excelente', 'Buena', 'Regular', 'Mala'] },
      { key: 'price_fair',      text: '¿El precio te parece justo?',                options: ['Muy justo', 'Justo', 'Un poco caro', 'Caro'] },
      { key: 'return',          text: '¿Volverías a visitarnos?',                   options: ['Sí, seguro', 'Probablemente', 'Tal vez', 'No'] },
      { key: 'recommend',       text: '¿Recomendarías este lugar a alguien?',       options: ['Sí, definitivamente', 'Probablemente', 'Tal vez', 'No'] },
    ];

    // Public: get survey questions (custom or defaults)
    app.get('/api/public/:code/survey-questions', async (req, res) => {
      try {
        const store = await getStoreByCode(req.params.code);
        if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
        const [rows] = await pool.execute('SELECT survey_questions FROM stores WHERE id = ?', [store.id]);
        const custom = rows[0]?.survey_questions;
        const questions = custom ? (typeof custom === 'string' ? JSON.parse(custom) : custom) : DEFAULT_SURVEY_QUESTIONS;
        res.json({ questions, is_custom: !!custom });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: get survey config
    app.get('/api/survey-config', authenticateToken, async (req, res) => {
      try {
        const { store_id } = req.query;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [storeRows] = await pool.execute('SELECT id, survey_questions FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!storeRows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const custom = storeRows[0].survey_questions;
        const questions = custom ? (typeof custom === 'string' ? JSON.parse(custom) : custom) : null;
        res.json({ questions, defaults: DEFAULT_SURVEY_QUESTIONS });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: save survey config
    app.put('/api/survey-config', authenticateToken, async (req, res) => {
      try {
        const { store_id, questions } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [storeRows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!storeRows.length) return res.status(403).json({ error: 'Acceso denegado' });
        // null = reset to defaults
        const value = questions === null ? null : JSON.stringify(questions);
        await pool.execute('UPDATE stores SET survey_questions = ? WHERE id = ?', [value, store_id]);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Public: submit client survey
    app.post('/api/public/:code/client-survey', async (req, res) => {
      try {
        const store = await getStoreByCode(req.params.code);
        if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
        const { answers } = req.body;
        if (!answers || typeof answers !== 'object') return res.status(400).json({ error: 'Respuestas inválidas' });
        await pool.execute(
          'INSERT INTO client_surveys (store_id, answers) VALUES (?, ?)',
          [store.id, JSON.stringify(answers)]
        );
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: get client surveys for selected store
    app.get('/api/client-surveys', authenticateToken, async (req, res) => {
      try {
        const { store_id } = req.query;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [storeRows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!storeRows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const [surveys] = await pool.execute(
          'SELECT * FROM client_surveys WHERE store_id = ? ORDER BY created_at DESC LIMIT 500',
          [store_id]
        );
        res.json({ surveys });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // ── Background Removal ───────────────────────────────────────────────────
    const VENV_DIR  = path.join(__serverDir, 'BGRemover', 'venv');
    const VENV_PY   = path.join(VENV_DIR, 'bin', 'python3');
    const VENV_PIP  = path.join(VENV_DIR, 'bin', 'pip');
    let _bgReady = false; // true once venv+rembg confirmed

    const runCmd = (cmd, args, opts = {}) => new Promise((resolve, reject) => {
      execFile(cmd, args, { timeout: 60000, ...opts }, (err, stdout, stderr) => {
        if (err) reject(Object.assign(err, { stdout, stderr }));
        else resolve({ stdout, stderr });
      });
    });

    // Find a system python3 to bootstrap the venv
    async function findSystemPython() {
      for (const cmd of ['python3', 'python3.12', 'python3.11', 'python3.10', 'python3.9', 'python']) {
        try { await runCmd(cmd, ['--version']); return cmd; } catch {}
      }
      return null;
    }

    async function ensureBgEnv() {
      if (_bgReady) return true;
      try {
        // 1 — If venv already exists and rembg importable, we're done
        if (fs.existsSync(VENV_PY)) {
          try {
            await runCmd(VENV_PY, ['-c', 'import rembg']);
            _bgReady = true;
            console.log('[bg_remover] Entorno listo (venv existente)');
            return true;
          } catch {}
        }

        // 2 — Create venv if needed
        if (!fs.existsSync(VENV_DIR)) {
          const sysPy = await findSystemPython();
          if (!sysPy) throw new Error('Python3 no encontrado en el sistema');
          console.log(`[bg_remover] Creando venv con ${sysPy}...`);
          await runCmd(sysPy, ['-m', 'venv', VENV_DIR], { timeout: 60000 });
          console.log('[bg_remover] Venv creado');
        }

        // 3 — Install rembg[cpu] inside the venv
        console.log('[bg_remover] Instalando rembg[cpu] en el venv...');
        await runCmd(VENV_PIP, [
          'install', 'rembg[cpu]', 'pillow', 'onnxruntime',
          '--quiet', '--no-warn-script-location'
        ], { timeout: 600000 }); // 10 min max

        // 4 — Verify
        await runCmd(VENV_PY, ['-c', 'import rembg']);
        _bgReady = true;
        console.log('[bg_remover] rembg[cpu] instalado correctamente en venv');
        return true;
      } catch (e) {
        console.error('[bg_remover] Error preparando entorno:', e.message || e.stderr || e);
        return false;
      }
    }

    // Start setup in background so first request isn't cold
    ensureBgEnv().catch(() => {});

    app.post('/api/remove-background', upload.single('image'), async (req, res) => {
      try {
        if (!req.file) return res.status(400).json({ error: 'No se recibió imagen' });

        const ready = await ensureBgEnv();
        if (!ready) return res.status(500).json({ error: 'El entorno de remoción de fondo no está disponible' });

        const inputPath  = path.resolve(req.file.path);
        const outputFilename = req.file.filename.replace(/\.[^.]+$/, '') + '_sin_fondo.png';
        const outputPath = path.resolve('uploads', outputFilename);
        const scriptPath = path.join(__serverDir, 'BGRemover', 'bg_remover.py');

        const childEnv = {
          ...process.env,
          ONNXRUNTIME_EXECUTION_PROVIDERS: 'CPUExecutionProvider',
          ORT_LOGGING_LEVEL_FATAL: '3',
          U2NET_HOME: path.join(__serverDir, 'BGRemover', 'models'),
        };

        await runCmd(VENV_PY, [scriptPath, inputPath, outputPath], {
          env: childEnv,
          timeout: 120000,
        });

        res.json({ url: `/uploads/${outputFilename}` });
      } catch (e) {
        console.error('[remove-background]', e.message);
        res.status(500).json({ error: 'Error al remover el fondo' });
      }
    });

    // ─── Instagram Auto-Post ────────────────────────────────────────────────

    app.get('/api/instagram/:storeId', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const cfg = await getInstagramConfig(req.params.storeId);
        const safe = cfg ? { ...cfg, ig_password: cfg.ig_password ? '••••••' : '' } : { ig_username: '', ig_password: '', caption_template: '', enabled: false, last_posted_at: null, last_error: null, template_counter: 0, post_time: '10:00', post_days: '0' };
        res.json(safe);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/instagram/:storeId', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const { ig_username, ig_password, caption_template, enabled, post_time, post_days } = req.body;
        const existing = await getInstagramConfig(req.params.storeId);
        const finalPass = ig_password === '••••••' ? (existing?.ig_password || '') : ig_password;
        await saveInstagramConfig(req.params.storeId, { ig_username, ig_password: finalPass, caption_template, enabled, post_time, post_days });
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/instagram/:storeId/preview', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const cfg = await getInstagramConfig(req.params.storeId);
        const [topProds] = await pool.execute(
          `SELECT p.id,p.name,p.description,p.price,p.image,COUNT(oi.id) AS sales
           FROM products p LEFT JOIN order_items oi ON oi.product_id=p.id
           WHERE p.store_id=? GROUP BY p.id ORDER BY sales DESC LIMIT 5`,
          [req.params.storeId]
        );
        const [coupons] = await pool.execute(
          'SELECT * FROM coupons WHERE store_id=? AND is_active=TRUE ORDER BY discount_value DESC LIMIT 3',
          [req.params.storeId]
        );
        const tplOverride = req.query.tpl !== undefined ? parseInt(req.query.tpl) : null;
        const tplCounter  = tplOverride !== null ? tplOverride : (cfg?.template_counter || 0);
        const buf = await generatePromoImage({ store, topProducts: topProds, coupons, templateCounter: tplCounter, currencySymbol: store.currency_symbol || '$' });
        res.setHeader('Content-Type', 'image/jpeg');
        res.send(buf);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/instagram/:storeId/post-now', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const cfg = await getInstagramConfig(req.params.storeId);
        if (!cfg?.ig_username || !cfg?.ig_password) return res.status(400).json({ error: 'Configura usuario y contraseña primero' });
        if (!cfg.ig_connected) return res.status(400).json({ error: 'Debes conectar tu cuenta de Instagram primero' });
        const [topProds] = await pool.execute(
          `SELECT p.id,p.name,p.description,p.price,p.image,COUNT(oi.id) AS sales
           FROM products p LEFT JOIN order_items oi ON oi.product_id=p.id
           WHERE p.store_id=? GROUP BY p.id ORDER BY sales DESC LIMIT 5`,
          [req.params.storeId]
        );
        const [coupons] = await pool.execute(
          'SELECT * FROM coupons WHERE store_id=? AND is_active=TRUE ORDER BY discount_value DESC LIMIT 3',
          [req.params.storeId]
        );
        const buf = await generatePromoImage({ store, topProducts: topProds, coupons, templateCounter: cfg.template_counter || 0, currencySymbol: store.currency_symbol || '$' });
        const caption = cfg.caption_template || `✨ ${store.name} ✨\n\n🔥 Mirá nuestras ofertas y los más pedidos de la semana.\n\n📲 Pedí en: ${BASE_URL}/store/${store.code}\n\n#${store.name.replace(/\s+/g,'')} #SRServi`;
        await postToInstagram({ storeId: req.params.storeId, imageBuffer: buf, caption });
        await updateInstagramPosted(req.params.storeId, null);
        res.json({ ok: true });
      } catch (e) {
        await updateInstagramPosted(req.params.storeId, e.message).catch(() => {});
        res.status(500).json({ error: e.message });
      }
    });

    // Start Instagram login (handles personal accounts + 2FA + challenge)
    app.post('/api/instagram/:storeId/connect', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const cfg = await getInstagramConfig(req.params.storeId);
        if (!cfg?.ig_username || !cfg?.ig_password) return res.status(400).json({ error: 'Guarda usuario y contraseña primero' });
        const result = await startInstagramLogin(req.params.storeId, cfg.ig_username, cfg.ig_password);
        if (result.status === 'ok') {
          await saveInstagramSession(req.params.storeId, null);
          return res.json({ ok: true });
        }
        if (result.status === '2fa_required') {
          return res.json({ needsTwoFactor: true, info: result.info || {}, hint: result.hint || '' });
        }
        if (result.status === 'challenge_required') {
          return res.json({ needsChallenge: true, hint: result.hint || '' });
        }
      } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // Complete 2FA or challenge verification
    app.post('/api/instagram/:storeId/verify', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const { code, type } = req.body;
        if (!code) return res.status(400).json({ error: 'Código requerido' });
        const result = await completeInstagramVerify(req.params.storeId, code, type || 'challenge');
        if (result.status === 'ok') {
          await saveInstagramSession(req.params.storeId, null);
          return res.json({ ok: true });
        }
        res.status(400).json({ error: 'Verificación fallida' });
      } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // Disconnect Instagram session
    app.delete('/api/instagram/:storeId/session', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        await deleteInstagramSession(req.params.storeId);
        await clearInstagramSession(req.params.storeId);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // ─── TikTok Auto-Post ────────────────────────────────────────────────────

    const { postToTikTok, startQrLogin, checkQrStatus, loginWithEmail } = await import('./tiktok-service.js');

    app.get('/api/tiktok/:storeId', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const cfg = await getTikTokConfig(req.params.storeId);
        res.json({
          caption_template: cfg?.caption_template || '',
          enabled:          !!cfg?.enabled,
          post_time:        cfg?.post_time || '10:00',
          post_days:        cfg?.post_days || '0',
          tk_connected:     !!cfg?.tk_connected,
          last_posted_at:   cfg?.last_posted_at || null,
          last_error:       cfg?.last_error || null,
          template_counter: cfg?.template_counter ?? 0,
        });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/tiktok/:storeId', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const { caption_template, enabled, post_time, post_days } = req.body;
        await saveTikTokConfig(req.params.storeId, { caption_template, enabled, post_time, post_days });
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Guardar cookies del navegador del usuario
    app.post('/api/tiktok/:storeId/connect', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const { cookie_string } = req.body;
        if (!cookie_string?.trim()) return res.status(400).json({ error: 'Cookies requeridas' });
        await saveTikTokSession(req.params.storeId, cookie_string.trim());
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Generar QR para login
    app.post('/api/tiktok/:storeId/qr', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const result = await startQrLogin(req.params.storeId);
        res.json({ qr: result.qrBase64 });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Verificar estado del QR
    app.get('/api/tiktok/:storeId/qr-status', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const result = await checkQrStatus(req.params.storeId);
        if (result.status === 'success') {
          await saveTikTokSession(req.params.storeId, result.cookieString);
        }
        res.json({ status: result.status });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Login con email y contraseña
    app.post('/api/tiktok/:storeId/login', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const { email, password } = req.body;
        if (!email?.trim() || !password?.trim()) return res.status(400).json({ error: 'Email y contraseña requeridos' });
        const result = await loginWithEmail({ email: email.trim(), password: password.trim() });
        if (result.success) {
          await saveTikTokSession(req.params.storeId, result.cookieString);
          res.json({ ok: true });
        } else {
          res.status(400).json({ error: result.error });
        }
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/tiktok/:storeId/preview', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const cfg = await getTikTokConfig(req.params.storeId);
        const [topProds] = await pool.execute(
          `SELECT p.id,p.name,p.description,p.price,p.image,COUNT(oi.id) AS sales
           FROM products p LEFT JOIN order_items oi ON oi.product_id=p.id
           WHERE p.store_id=? GROUP BY p.id ORDER BY sales DESC LIMIT 5`,
          [req.params.storeId]
        );
        const [coupons] = await pool.execute(
          'SELECT * FROM coupons WHERE store_id=? AND is_active=TRUE ORDER BY discount_value DESC LIMIT 3',
          [req.params.storeId]
        );
        const tplOverride = req.query.tpl !== undefined ? parseInt(req.query.tpl) : null;
        const tplCounter  = tplOverride !== null ? tplOverride : (cfg?.template_counter || 0);
        const buf = await generatePromoImage({ store, topProducts: topProds, coupons, templateCounter: tplCounter, currencySymbol: store.currency_symbol || '$' });
        res.setHeader('Content-Type', 'image/jpeg');
        res.send(buf);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/tiktok/:storeId/post-now', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        const cfg = await getTikTokConfig(req.params.storeId);
        if (!cfg?.tk_connected || !cfg?.session_cookie) return res.status(400).json({ error: 'Conectá tu cuenta de TikTok primero' });
        const [topProds] = await pool.execute(
          `SELECT p.id,p.name,p.description,p.price,p.image,COUNT(oi.id) AS sales
           FROM products p LEFT JOIN order_items oi ON oi.product_id=p.id
           WHERE p.store_id=? GROUP BY p.id ORDER BY sales DESC LIMIT 5`,
          [req.params.storeId]
        );
        const [coupons] = await pool.execute(
          'SELECT * FROM coupons WHERE store_id=? AND is_active=TRUE ORDER BY discount_value DESC LIMIT 3',
          [req.params.storeId]
        );
        const buf     = await generatePromoImage({ store, topProducts: topProds, coupons, templateCounter: cfg.template_counter || 0, currencySymbol: store.currency_symbol || '$' });
        const caption = cfg.caption_template || `✨ ${store.name} ✨\n\n🔥 Mirá nuestras ofertas y los más pedidos de la semana.\n\n📲 Pedí en: ${BASE_URL}/store/${store.code}\n\n#${store.name.replace(/\s+/g,'')} #SRServi #TikTok`;
        await postToTikTok({ cookieString: cfg.session_cookie, imageBuffer: buf, caption });
        await updateTikTokPosted(req.params.storeId, null);
        res.json({ ok: true });
      } catch (e) {
        await updateTikTokPosted(req.params.storeId, e.message).catch(() => {});
        res.status(500).json({ error: e.message });
      }
    });

    app.delete('/api/tiktok/:storeId/disconnect', authenticateToken, async (req, res) => {
      try {
        const store = await getStoreById(req.params.storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'No autorizado' });
        await clearTikTokTokens(req.params.storeId);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // ============================================================
    // CAJA (CASH REGISTER) ENDPOINTS
    // ============================================================

    // Admin: open cash register for selected store
    app.post('/api/admin/cash-register/open', authenticateToken, async (req, res) => {
      try {
        if (req.user.type === 'worker') return res.status(403).json({ error: 'Usar /api/cash-register/open para trabajadores' });
        const { store_id, opening_amount } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [storeRows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!storeRows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const register = await openCashRegister(store_id, 0, 'Administrador', opening_amount);
        io.to(`store_${store_id}`).emit('cash_register_changed', { open: true, register });
        res.json(register);
      } catch (err) { res.status(400).json({ error: err.message }); }
    });

    // Admin: close cash register for selected store
    app.post('/api/admin/cash-register/close', authenticateToken, async (req, res) => {
      try {
        if (req.user.type === 'worker') return res.status(403).json({ error: 'Usar /api/cash-register/close para trabajadores' });
        const { store_id } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const [storeRows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!storeRows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const open = await getOpenCashRegister(store_id);
        if (!open) return res.status(400).json({ error: 'No hay caja abierta' });
        await closeCashRegister(store_id, 'admin');
        io.to(`store_${store_id}`).emit('cash_register_changed', { open: false });
        await sendCashRegisterReport(store_id, 'admin', open);
        res.json({ success: true });
      } catch (err) { res.status(500).json({ error: err.message }); }
    });

    app.post('/api/cash-register/open', authenticateToken, async (req, res) => {
      try {
        if (req.user.type !== 'worker') return res.status(403).json({ error: 'Solo trabajadores pueden abrir la caja' });
        const storeId = req.user.store_id;
        const { opening_amount } = req.body;
        const [workerRows] = await pool.execute('SELECT * FROM workers WHERE id = ?', [req.user.id]);
        const worker = workerRows[0];
        if (!worker) return res.status(404).json({ error: 'Trabajador no encontrado' });
        const register = await openCashRegister(storeId, worker.id, worker.name || worker.username, opening_amount);
        io.to(`store_${storeId}`).emit('cash_register_changed', { open: true, register });
        res.json(register);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    app.post('/api/cash-register/close', authenticateToken, async (req, res) => {
      try {
        if (req.user.type !== 'worker') return res.status(403).json({ error: 'Solo trabajadores pueden cerrar la caja' });
        const storeId = req.user.store_id;
        const open = await getOpenCashRegister(storeId);
        if (!open) return res.status(400).json({ error: 'No hay caja abierta' });
        await closeCashRegister(storeId, 'manual');
        io.to(`store_${storeId}`).emit('cash_register_changed', { open: false });
        await sendCashRegisterReport(storeId, 'manual', open);
        res.json({ success: true });
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    // Worker: registrar un egreso (gasto/retiro) en la caja abierta
    app.post('/api/cash-register/movement', authenticateToken, async (req, res) => {
      try {
        if (req.user.type !== 'worker') return res.status(403).json({ error: 'Solo trabajadores' });
        const storeId = req.user.store_id;
        const { amount, description, category } = req.body;
        const open = await getOpenCashRegister(storeId);
        if (!open) return res.status(400).json({ error: 'No hay caja abierta' });
        const [workerRows] = await pool.execute('SELECT name, username FROM workers WHERE id = ?', [req.user.id]);
        const worker = workerRows[0];
        const workerName = worker ? (worker.name || worker.username) : null;
        const movement = await addCashMovement(open.id, storeId, amount, description, category, workerName);
        res.json(movement);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    // Worker: eliminar un egreso de la caja abierta
    app.delete('/api/cash-register/movement/:id', authenticateToken, async (req, res) => {
      try {
        if (req.user.type !== 'worker') return res.status(403).json({ error: 'Solo trabajadores' });
        await deleteCashMovement(req.params.id, req.user.store_id);
        res.json({ success: true });
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    // Worker: estado de resultados de la caja abierta (ingresos/egresos)
    app.get('/api/cash-register/summary', authenticateToken, async (req, res) => {
      try {
        if (req.user.type !== 'worker') return res.status(403).json({ error: 'Solo trabajadores' });
        const storeId = req.user.store_id;
        const open = await getOpenCashRegister(storeId);
        if (!open) return res.status(400).json({ error: 'No hay caja abierta' });
        const financials = await getCashRegisterFinancials(storeId, open);
        res.json({ register: open, ...financials });
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    app.get('/api/admin/cash-register/history', authenticateToken, async (req, res) => {
      try {
        if (req.user.type === 'worker') return res.status(403).json({ error: 'Acceso denegado' });
        const { store_id, date_from, date_to } = req.query;
        if (!store_id || !date_from || !date_to) return res.status(400).json({ error: 'store_id, date_from y date_to son requeridos' });
        const [storeRows] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [store_id, req.user.id]);
        if (!storeRows.length) return res.status(403).json({ error: 'Acceso denegado' });
        const history = await getCashRegisterHistory(store_id, date_from, date_to);
        res.json(history);
      } catch (err) { res.status(500).json({ error: err.message }); }
    });

    app.get('/api/cash-register/status/:storeId', async (req, res) => {
      try {
        const open = await getOpenCashRegister(req.params.storeId);
        res.json({ open: !!open, register: open || null });
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    // Cron cada día a medianoche — cerrar cajas abiertas y enviar email
    cron.schedule('0 0 * * *', async () => {
      console.log('[Caja] Cierre automático de cajas...');
      try {
        const openRegisters = await getAllOpenCashRegisters();
        for (const reg of openRegisters) {
          try {
            await closeCashRegister(reg.store_id, 'auto');
            io.to(`store_${reg.store_id}`).emit('cash_register_changed', { open: false });
            await sendCashRegisterReport(reg.store_id, 'auto', reg);
            console.log(`[Caja] ✅ Cerrada caja tienda ${reg.store_name}`);
          } catch (e) {
            console.error(`[Caja] ❌ Error tienda ${reg.store_name}:`, e.message);
          }
        }
      } catch (e) { console.error('[Caja] Cron error:', e.message); }
    });

    // ─── CCTV Cartelería Digital ──────────────────────────────────────────────

    const cctvDir = path.join(__serverDir, 'uploads', 'cctv');
    if (!fs.existsSync(cctvDir)) fs.mkdirSync(cctvDir, { recursive: true });

    const cctvStorage = multer.diskStorage({
      destination: (req, file, cb) => cb(null, cctvDir),
      filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
      }
    });
    const cctvUpload = multer({
      storage: cctvStorage,
      limits: { fileSize: 4 * 1024 * 1024 * 1024 },
      fileFilter: (req, file, cb) => {
        const allowedExts = ['.mp4', '.webm', '.avi', '.mov', '.mpeg', '.mpg', '.mkv'];
        if (allowedExts.includes(path.extname(file.originalname).toLowerCase())) return cb(null, true);
        cb(new Error('Solo se permiten videos (mp4, webm, avi, mov, mkv)'));
      }
    });

    const cctvMusicUpload = multer({
      storage: cctvStorage,
      limits: { fileSize: 200 * 1024 * 1024 },
      fileFilter: (req, file, cb) => {
        const allowedExts = ['.mp3', '.m4a', '.aac', '.wav', '.ogg', '.flac'];
        if (allowedExts.includes(path.extname(file.originalname).toLowerCase())) return cb(null, true);
        cb(new Error('Solo se permiten audios (mp3, m4a, aac, wav, ogg, flac)'));
      }
    });

    const cctvImageUpload = multer({
      storage: cctvStorage,
      limits: { fileSize: 20 * 1024 * 1024 },
      fileFilter: (req, file, cb) => {
        const allowedExts = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
        if (allowedExts.includes(path.extname(file.originalname).toLowerCase())) return cb(null, true);
        cb(new Error('Solo se permiten imágenes (jpg, jpeg, png, gif, webp)'));
      }
    });

    let _cctvReady = false;
    async function ensureCctvTables() {
      if (_cctvReady) return;
      await pool.execute(`
        CREATE TABLE IF NOT EXISTS cctv_videos (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          filename VARCHAR(255) NOT NULL,
          original_name VARCHAR(255) NOT NULL,
          file_size BIGINT DEFAULT 0,
          url VARCHAR(500) NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_cctv_videos_user (user_id)
        )
      `);
      await pool.execute(`
        CREATE TABLE IF NOT EXISTS cctv_screens (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          device_token VARCHAR(64) DEFAULT NULL,
          device_name VARCHAR(100) DEFAULT 'TV',
          pairing_code VARCHAR(10) DEFAULT NULL,
          current_video_id INT DEFAULT NULL,
          last_seen TIMESTAMP NULL DEFAULT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY uq_cctv_token (device_token),
          INDEX idx_cctv_screens_user (user_id),
          INDEX idx_cctv_screens_code (pairing_code)
        )
      `);
      await pool.execute(`
        CREATE TABLE IF NOT EXISTS cctv_power_log (
          id INT AUTO_INCREMENT PRIMARY KEY,
          screen_id INT NOT NULL,
          event ENUM('on','off') NOT NULL,
          logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_cctv_power_screen (screen_id),
          INDEX idx_cctv_power_logged (logged_at)
        )
      `);
      await pool.execute(`
        CREATE TABLE IF NOT EXISTS cctv_music (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          filename VARCHAR(255) NOT NULL,
          original_name VARCHAR(255) NOT NULL,
          file_size BIGINT DEFAULT 0,
          url VARCHAR(500) NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_cctv_music_user (user_id)
        )
      `);
      await pool.execute(`
        CREATE TABLE IF NOT EXISTS cctv_albums (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          name VARCHAR(255) NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_cctv_albums_user (user_id)
        )
      `);
      await pool.execute(`
        CREATE TABLE IF NOT EXISTS cctv_images (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          album_id INT DEFAULT NULL,
          filename VARCHAR(255) NOT NULL,
          original_name VARCHAR(255) NOT NULL,
          file_size BIGINT DEFAULT 0,
          url VARCHAR(500) NOT NULL,
          duration_seconds INT DEFAULT 5,
          sort_order INT DEFAULT 0,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_cctv_images_user (user_id)
        )
      `);
      await pool.execute(`
        CREATE TABLE IF NOT EXISTS cctv_schedules (
          id INT AUTO_INCREMENT PRIMARY KEY,
          screen_id INT NOT NULL,
          user_id INT NOT NULL,
          video_id INT NOT NULL,
          name VARCHAR(255) DEFAULT '',
          start_time CHAR(5) NOT NULL,
          end_time CHAR(5) DEFAULT NULL,
          days JSON NOT NULL,
          active TINYINT(1) NOT NULL DEFAULT 1,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_cctv_sched_screen (screen_id),
          INDEX idx_cctv_sched_user (user_id)
        )
      `);
      for (const sql of [
        'ALTER TABLE cctv_screens ADD COLUMN video_muted TINYINT(1) DEFAULT 0',
        'ALTER TABLE cctv_screens ADD COLUMN current_music_id INT DEFAULT NULL',
        "ALTER TABLE cctv_screens ADD COLUMN display_mode ENUM('video','images') DEFAULT 'video'",
        'ALTER TABLE cctv_screens ADD COLUMN current_album_id INT DEFAULT NULL',
        'ALTER TABLE cctv_screens ADD COLUMN volume_level TINYINT(3) UNSIGNED NOT NULL DEFAULT 100',
        'ALTER TABLE cctv_images ADD COLUMN album_id INT DEFAULT NULL'
      ]) {
        try { await pool.execute(sql); } catch (_) { /* columna ya existe */ }
      }
      _cctvReady = true;
    }

    // Admin: list videos
    app.get('/api/cctv/videos', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [rows] = await pool.execute('SELECT * FROM cctv_videos WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
        res.json(rows);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: upload video
    app.post('/api/cctv/videos', authenticateToken, cctvUpload.single('video'), async (req, res) => {
      try {
        await ensureCctvTables();
        if (!req.file) return res.status(400).json({ error: 'No se recibió video' });
        const url = `/uploads/cctv/${req.file.filename}`;
        const [result] = await pool.execute(
          'INSERT INTO cctv_videos (user_id, filename, original_name, file_size, url) VALUES (?, ?, ?, ?, ?)',
          [req.user.id, req.file.filename, req.file.originalname, req.file.size, url]
        );
        const [rows] = await pool.execute('SELECT * FROM cctv_videos WHERE id = ?', [result.insertId]);
        res.json(rows[0]);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: delete video
    app.delete('/api/cctv/videos/:id', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [rows] = await pool.execute('SELECT * FROM cctv_videos WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        if (!rows.length) return res.status(404).json({ error: 'Video no encontrado' });
        const filePath = path.join(cctvDir, rows[0].filename);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        await pool.execute('DELETE FROM cctv_videos WHERE id = ?', [req.params.id]);
        await pool.execute('UPDATE cctv_screens SET current_video_id = NULL WHERE current_video_id = ?', [req.params.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: list screens
    app.get('/api/cctv/screens', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [rows] = await pool.execute(`
          SELECT s.*, v.original_name AS video_name, v.url AS video_url,
            m.original_name AS music_name, m.id AS music_id,
            alb.name AS album_name,
            (CASE WHEN s.last_seen IS NOT NULL AND TIMESTAMPDIFF(SECOND, s.last_seen, NOW()) < 90 THEN 1 ELSE 0 END) AS is_online
          FROM cctv_screens s
          LEFT JOIN cctv_videos v ON v.id = s.current_video_id
          LEFT JOIN cctv_music m ON m.id = s.current_music_id
          LEFT JOIN cctv_albums alb ON alb.id = s.current_album_id
          WHERE s.user_id = ? AND s.device_token IS NOT NULL
          ORDER BY s.created_at DESC
        `, [req.user.id]);
        res.json(rows);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: generate pairing code
    app.post('/api/cctv/screens/generate-code', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        await pool.execute(
          'DELETE FROM cctv_screens WHERE user_id = ? AND device_token IS NULL AND created_at < DATE_SUB(NOW(), INTERVAL 15 MINUTE)',
          [req.user.id]
        );
        const code = Math.random().toString(36).substring(2, 8).toUpperCase();
        await pool.execute('INSERT INTO cctv_screens (user_id, pairing_code) VALUES (?, ?)', [req.user.id, code]);
        res.json({ code });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: assign video to screen
    app.put('/api/cctv/screens/:id/assign', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const { video_id } = req.body;
        if (video_id) {
          const [vRows] = await pool.execute('SELECT id FROM cctv_videos WHERE id = ? AND user_id = ?', [video_id, req.user.id]);
          if (!vRows.length) return res.status(404).json({ error: 'Video no encontrado' });
        }
        await pool.execute(
          'UPDATE cctv_screens SET current_video_id = ? WHERE id = ? AND user_id = ?',
          [video_id || null, req.params.id, req.user.id]
        );
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: rename screen
    app.put('/api/cctv/screens/:id/name', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const { name } = req.body;
        await pool.execute('UPDATE cctv_screens SET device_name = ? WHERE id = ? AND user_id = ?', [name || 'TV', req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: delete screen
    app.delete('/api/cctv/screens/:id', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        await pool.execute('DELETE FROM cctv_screens WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // TV Device: pair with store code (permanent) or legacy random code (public)
    app.post('/api/cctv/pair', async (req, res) => {
      try {
        await ensureCctvTables();
        const { pairing_code, device_name } = req.body;
        if (!pairing_code) return res.status(400).json({ error: 'Código requerido' });
        const dname = device_name || 'TV Cartelería';

        // Try as store code first (permanent — the recommended method)
        const [storeRows] = await pool.execute(
          'SELECT id, user_id FROM stores WHERE code = ?',
          [pairing_code.toLowerCase().trim()]
        );
        if (storeRows.length) {
          const { user_id } = storeRows[0];
          // If same device_name already paired for this user, reuse its token
          const [existing] = await pool.execute(
            'SELECT id, device_token FROM cctv_screens WHERE user_id = ? AND device_name = ? AND device_token IS NOT NULL',
            [user_id, dname]
          );
          if (existing.length) {
            return res.json({ device_token: existing[0].device_token, paired: true });
          }
          const deviceToken = crypto.randomBytes(32).toString('hex');
          await pool.execute(
            'INSERT INTO cctv_screens (user_id, device_name, device_token) VALUES (?, ?, ?)',
            [user_id, dname, deviceToken]
          );
          return res.json({ device_token: deviceToken, paired: true });
        }

        // Fall back to legacy random pairing code (temporary, 15-min expiry)
        const [rows] = await pool.execute(
          'SELECT * FROM cctv_screens WHERE pairing_code = ? AND device_token IS NULL',
          [pairing_code]
        );
        if (!rows.length) {
          const [existing] = await pool.execute('SELECT device_token FROM cctv_screens WHERE pairing_code = ?', [pairing_code]);
          if (existing.length && existing[0].device_token) {
            return res.json({ device_token: existing[0].device_token, paired: true });
          }
          return res.status(404).json({ error: 'Código inválido o expirado' });
        }
        const deviceToken = crypto.randomBytes(32).toString('hex');
        await pool.execute(
          'UPDATE cctv_screens SET device_token = ?, device_name = ? WHERE id = ?',
          [deviceToken, dname, rows[0].id]
        );
        res.json({ device_token: deviceToken, paired: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // TV Device: get config and update heartbeat (public)
    app.get('/api/cctv/device-config', async (req, res) => {
      try {
        await ensureCctvTables();
        const { device_token } = req.query;
        if (!device_token) return res.status(400).json({ error: 'device_token requerido' });
        const [rows] = await pool.execute(`
          SELECT s.id, s.user_id, s.device_name, s.current_video_id, s.video_muted,
            COALESCE(s.volume_level, 100) AS volume_level,
            COALESCE(s.display_mode, 'video') AS display_mode,
            v.url AS video_url, v.original_name AS video_name, v.filename AS video_filename,
            m.url AS music_url, m.original_name AS music_name
          FROM cctv_screens s
          LEFT JOIN cctv_videos v ON v.id = s.current_video_id
          LEFT JOIN cctv_music m ON m.id = s.current_music_id
          WHERE s.device_token = ?
        `, [device_token]);
        if (!rows.length) return res.status(404).json({ error: 'Dispositivo no encontrado' });
        await pool.execute('UPDATE cctv_screens SET last_seen = NOW() WHERE device_token = ?', [device_token]);
        const config = { ...rows[0] };
        const userId = config.user_id;
        const screenId = config.id;
        delete config.user_id;
        config.video_muted = !!config.video_muted;
        if (config.display_mode === 'images') {
          const albumId = rows[0].current_album_id;
          let imgSql = 'SELECT url, duration_seconds FROM cctv_images WHERE user_id = ?';
          const imgParams = [userId];
          if (albumId) { imgSql += ' AND album_id = ?'; imgParams.push(albumId); }
          imgSql += ' ORDER BY sort_order ASC, created_at ASC';
          const [imgs] = await pool.execute(imgSql, imgParams);
          config.images = imgs;
        }
        const [schedRows] = await pool.execute(`
          SELECT cs.id, cs.video_id, cs.name, cs.start_time, cs.end_time, cs.days,
            v.url AS video_url, v.original_name AS video_name
          FROM cctv_schedules cs
          JOIN cctv_videos v ON v.id = cs.video_id
          WHERE cs.screen_id = ? AND cs.active = 1
          ORDER BY cs.start_time ASC
        `, [screenId]);
        config.schedules = schedRows.map(s => ({
          ...s,
          days: typeof s.days === 'string' ? JSON.parse(s.days) : (s.days || [])
        }));
        res.json(config);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // TV Device: report power event (public) — called by TV app on boot/shutdown
    app.post('/api/cctv/power-event', async (req, res) => {
      try {
        await ensureCctvTables();
        const { device_token, event } = req.body;
        if (!device_token || !['on', 'off'].includes(event)) return res.status(400).json({ error: 'device_token y event (on|off) requeridos' });
        const [rows] = await pool.execute('SELECT id FROM cctv_screens WHERE device_token = ?', [device_token]);
        if (!rows.length) return res.status(404).json({ error: 'Dispositivo no encontrado' });
        await pool.execute('INSERT INTO cctv_power_log (screen_id, event) VALUES (?, ?)', [rows[0].id, event]);
        await pool.execute('UPDATE cctv_screens SET last_seen = NOW() WHERE device_token = ?', [device_token]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: get power log for a screen
    app.get('/api/cctv/screens/:id/power-log', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [screen] = await pool.execute('SELECT id FROM cctv_screens WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        if (!screen.length) return res.status(404).json({ error: 'Pantalla no encontrada' });
        const [rows] = await pool.execute(
          'SELECT event, logged_at FROM cctv_power_log WHERE screen_id = ? ORDER BY logged_at DESC LIMIT 100',
          [req.params.id]
        );
        res.json(rows);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: list music
    app.get('/api/cctv/music', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [rows] = await pool.execute('SELECT * FROM cctv_music WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
        res.json(rows);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: upload music
    app.post('/api/cctv/music', authenticateToken, cctvMusicUpload.single('music'), async (req, res) => {
      try {
        await ensureCctvTables();
        if (!req.file) return res.status(400).json({ error: 'No se recibió archivo de música' });
        const url = `/uploads/cctv/${req.file.filename}`;
        const [result] = await pool.execute(
          'INSERT INTO cctv_music (user_id, filename, original_name, file_size, url) VALUES (?, ?, ?, ?, ?)',
          [req.user.id, req.file.filename, req.file.originalname, req.file.size, url]
        );
        const [rows] = await pool.execute('SELECT * FROM cctv_music WHERE id = ?', [result.insertId]);
        res.json(rows[0]);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: delete music
    app.delete('/api/cctv/music/:id', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [rows] = await pool.execute('SELECT * FROM cctv_music WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        if (!rows.length) return res.status(404).json({ error: 'Música no encontrada' });
        const filePath = path.join(cctvDir, rows[0].filename);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        await pool.execute('DELETE FROM cctv_music WHERE id = ?', [req.params.id]);
        await pool.execute('UPDATE cctv_screens SET current_music_id = NULL WHERE current_music_id = ?', [req.params.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: toggle mute for a screen
    app.put('/api/cctv/screens/:id/mute', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const { muted } = req.body;
        await pool.execute('UPDATE cctv_screens SET video_muted = ? WHERE id = ? AND user_id = ?', [muted ? 1 : 0, req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: set volume for a screen (0-100)
    app.put('/api/cctv/screens/:id/volume', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const vol = Math.max(0, Math.min(100, parseInt(req.body.volume_level) || 100));
        await pool.execute('UPDATE cctv_screens SET volume_level = ? WHERE id = ? AND user_id = ?', [vol, req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: list schedules for a screen
    app.get('/api/cctv/screens/:id/schedules', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [screen] = await pool.execute('SELECT id FROM cctv_screens WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        if (!screen.length) return res.status(404).json({ error: 'Pantalla no encontrada' });
        const [rows] = await pool.execute(`
          SELECT cs.*, v.original_name AS video_name
          FROM cctv_schedules cs
          JOIN cctv_videos v ON v.id = cs.video_id
          WHERE cs.screen_id = ? AND cs.user_id = ?
          ORDER BY cs.start_time ASC
        `, [req.params.id, req.user.id]);
        res.json(rows.map(r => ({ ...r, active: !!r.active, days: typeof r.days === 'string' ? JSON.parse(r.days) : (r.days || []) })));
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: create schedule for a screen
    app.post('/api/cctv/screens/:id/schedules', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [screen] = await pool.execute('SELECT id FROM cctv_screens WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        if (!screen.length) return res.status(404).json({ error: 'Pantalla no encontrada' });
        const { video_id, name, start_time, end_time, days } = req.body;
        if (!video_id || !start_time) return res.status(400).json({ error: 'video_id y start_time requeridos' });
        if (!/^\d{2}:\d{2}$/.test(start_time)) return res.status(400).json({ error: 'Formato de hora inválido (HH:MM)' });
        if (end_time && !/^\d{2}:\d{2}$/.test(end_time)) return res.status(400).json({ error: 'Formato de hora_fin inválido (HH:MM)' });
        const [vCheck] = await pool.execute('SELECT id FROM cctv_videos WHERE id = ? AND user_id = ?', [video_id, req.user.id]);
        if (!vCheck.length) return res.status(404).json({ error: 'Video no encontrado' });
        const daysJson = JSON.stringify(Array.isArray(days) ? days : []);
        const [result] = await pool.execute(
          'INSERT INTO cctv_schedules (screen_id, user_id, video_id, name, start_time, end_time, days) VALUES (?, ?, ?, ?, ?, ?, ?)',
          [req.params.id, req.user.id, video_id, name || '', start_time, end_time || null, daysJson]
        );
        res.json({ id: result.insertId, ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: toggle active / update schedule
    app.put('/api/cctv/schedules/:id', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const { active, name, start_time, end_time, days, video_id } = req.body;
        const fields = []; const vals = [];
        if (active !== undefined) { fields.push('active = ?'); vals.push(active ? 1 : 0); }
        if (name !== undefined) { fields.push('name = ?'); vals.push(name); }
        if (start_time !== undefined) { fields.push('start_time = ?'); vals.push(start_time); }
        if (end_time !== undefined) { fields.push('end_time = ?'); vals.push(end_time || null); }
        if (days !== undefined) { fields.push('days = ?'); vals.push(JSON.stringify(Array.isArray(days) ? days : [])); }
        if (video_id !== undefined) { fields.push('video_id = ?'); vals.push(video_id); }
        if (!fields.length) return res.status(400).json({ error: 'Nada que actualizar' });
        vals.push(req.params.id, req.user.id);
        await pool.execute(`UPDATE cctv_schedules SET ${fields.join(', ')} WHERE id = ? AND user_id = ?`, vals);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: delete schedule
    app.delete('/api/cctv/schedules/:id', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        await pool.execute('DELETE FROM cctv_schedules WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: list albums
    app.get('/api/cctv/albums', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [rows] = await pool.execute(
          'SELECT a.*, COUNT(i.id) AS image_count FROM cctv_albums a LEFT JOIN cctv_images i ON i.album_id = a.id WHERE a.user_id = ? GROUP BY a.id ORDER BY a.created_at ASC',
          [req.user.id]
        );
        res.json(rows);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: create album
    app.post('/api/cctv/albums', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const { name } = req.body;
        if (!name?.trim()) return res.status(400).json({ error: 'Nombre requerido' });
        const [result] = await pool.execute('INSERT INTO cctv_albums (user_id, name) VALUES (?, ?)', [req.user.id, name.trim()]);
        res.json({ id: result.insertId, name: name.trim(), image_count: 0 });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: delete album (images move to no album)
    app.delete('/api/cctv/albums/:id', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        await pool.execute('UPDATE cctv_images SET album_id = NULL WHERE album_id = ? AND user_id = ?', [req.params.id, req.user.id]);
        await pool.execute('UPDATE cctv_screens SET current_album_id = NULL WHERE current_album_id = ? AND user_id = ?', [req.params.id, req.user.id]);
        await pool.execute('DELETE FROM cctv_albums WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: assign image to album (null = remove from album)
    app.put('/api/cctv/images/:id/album', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const { album_id } = req.body;
        await pool.execute('UPDATE cctv_images SET album_id = ? WHERE id = ? AND user_id = ?', [album_id || null, req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: assign album to screen (null = show all images)
    app.put('/api/cctv/screens/:id/album', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const { album_id } = req.body;
        await pool.execute('UPDATE cctv_screens SET current_album_id = ? WHERE id = ? AND user_id = ?', [album_id || null, req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: list images
    app.get('/api/cctv/images', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [rows] = await pool.execute('SELECT * FROM cctv_images WHERE user_id = ? ORDER BY sort_order ASC, created_at ASC', [req.user.id]);
        res.json(rows);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: upload images (multiple)
    app.post('/api/cctv/images', authenticateToken, cctvImageUpload.array('images', 30), async (req, res) => {
      try {
        await ensureCctvTables();
        if (!req.files?.length) return res.status(400).json({ error: 'No se recibieron imágenes' });
        const [[maxRow]] = await pool.execute('SELECT COALESCE(MAX(sort_order), -1) AS max_order FROM cctv_images WHERE user_id = ?', [req.user.id]);
        let nextOrder = (maxRow.max_order ?? -1) + 1;
        for (const file of req.files) {
          await pool.execute(
            'INSERT INTO cctv_images (user_id, filename, original_name, file_size, url, sort_order) VALUES (?, ?, ?, ?, ?, ?)',
            [req.user.id, file.filename, file.originalname, file.size, `/uploads/cctv/${file.filename}`, nextOrder++]
          );
        }
        const [rows] = await pool.execute('SELECT * FROM cctv_images WHERE user_id = ? ORDER BY sort_order ASC', [req.user.id]);
        res.json(rows);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: update image order
    app.put('/api/cctv/images/order', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const { order } = req.body;
        for (const item of order) {
          await pool.execute('UPDATE cctv_images SET sort_order = ? WHERE id = ? AND user_id = ?', [item.sort_order, item.id, req.user.id]);
        }
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: set image duration
    app.put('/api/cctv/images/:id/duration', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const dur = Math.max(1, Math.min(300, parseInt(req.body.duration_seconds) || 5));
        await pool.execute('UPDATE cctv_images SET duration_seconds = ? WHERE id = ? AND user_id = ?', [dur, req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: delete image
    app.delete('/api/cctv/images/:id', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const [rows] = await pool.execute('SELECT * FROM cctv_images WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        if (!rows.length) return res.status(404).json({ error: 'Imagen no encontrada' });
        const filePath = path.join(cctvDir, rows[0].filename);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        await pool.execute('DELETE FROM cctv_images WHERE id = ?', [req.params.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: set screen display mode (video / images)
    app.put('/api/cctv/screens/:id/mode', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const { mode } = req.body;
        if (!['video', 'images'].includes(mode)) return res.status(400).json({ error: 'Modo inválido' });
        await pool.execute('UPDATE cctv_screens SET display_mode = ? WHERE id = ? AND user_id = ?', [mode, req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Admin: assign music to screen
    app.put('/api/cctv/screens/:id/music', authenticateToken, async (req, res) => {
      try {
        await ensureCctvTables();
        const { music_id } = req.body;
        if (music_id) {
          const [mRows] = await pool.execute('SELECT id FROM cctv_music WHERE id = ? AND user_id = ?', [music_id, req.user.id]);
          if (!mRows.length) return res.status(404).json({ error: 'Música no encontrada' });
        }
        await pool.execute('UPDATE cctv_screens SET current_music_id = ? WHERE id = ? AND user_id = ?', [music_id || null, req.params.id, req.user.id]);
        res.json({ ok: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Cron cada domingo a las 10:00
    cron.schedule('0 * * * *', async () => {
      const now = new Date();
      const currentHour = now.getHours();
      const currentDay  = now.getDay(); // 0=Dom, 1=Lun, ..., 6=Sáb
      const todayStr    = now.toISOString().slice(0, 10); // YYYY-MM-DD
      console.log(`[Instagram] Revisando publicaciones automáticas — ${now.toLocaleString('es-CL')}...`);
      try {
        const configs = await getActiveInstagramConfigs();
        for (const cfg of configs) {
          try {
            // Verificar hora
            const [postHour] = (cfg.post_time || '10:00').split(':').map(Number);
            if (postHour !== currentHour) continue;

            // Verificar día
            const days = (cfg.post_days || '0').split(',').map(Number);
            if (!days.includes(currentDay)) continue;

            // Verificar que no se haya publicado hoy ya
            if (cfg.last_posted_at) {
              const lastStr = new Date(cfg.last_posted_at).toISOString().slice(0, 10);
              if (lastStr === todayStr) {
                console.log(`[Instagram] ${cfg.store_name}: ya publicado hoy`);
                continue;
              }
            }

            const [topProds] = await pool.execute(
              `SELECT p.id,p.name,p.description,p.price,p.image,COUNT(oi.id) AS sales
               FROM products p LEFT JOIN order_items oi ON oi.product_id=p.id
               WHERE p.store_id=? GROUP BY p.id ORDER BY sales DESC LIMIT 5`,
              [cfg.store_id]
            );
            const [coupons] = await pool.execute(
              'SELECT * FROM coupons WHERE store_id=? AND is_active=TRUE ORDER BY discount_value DESC LIMIT 3',
              [cfg.store_id]
            );
            const buf = await generatePromoImage({ store: cfg, topProducts: topProds, coupons, templateCounter: cfg.template_counter || 0, currencySymbol: cfg.currency_symbol || '$' });
            const caption = cfg.caption_template || `✨ ${cfg.store_name} ✨\n\n🔥 Lo mejor de la semana!\n\n📲 ${BASE_URL}/store/${cfg.store_code}\n\n#${(cfg.store_name||'').replace(/\s+/g,'')} #SRServi`;
            await postToInstagram({ storeId: cfg.store_id, imageBuffer: buf, caption });
            await updateInstagramPosted(cfg.store_id, null);
            console.log(`[Instagram] ✅ ${cfg.store_name}`);
          } catch (e) {
            await updateInstagramPosted(cfg.store_id, e.message).catch(() => {});
            console.error(`[Instagram] ❌ ${cfg.store_name}:`, e.message);
          }
        }
      } catch (e) { console.error('[Instagram] Cron error:', e.message); }
    });

    // TikTok auto-post cron (runs every hour, checks schedule per store)
    cron.schedule('0 * * * *', async () => {
      const now        = new Date();
      const currentHour = now.getHours();
      const currentDay  = now.getDay();
      const todayStr    = now.toISOString().slice(0, 10);
      try {
        const configs = await getActiveTikTokConfigs();
        for (const cfg of configs) {
          try {
            const [postHour] = (cfg.post_time || '10:00').split(':').map(Number);
            if (postHour !== currentHour) continue;
            const days = (cfg.post_days || '0').split(',').map(Number);
            if (!days.includes(currentDay)) continue;
            if (cfg.last_posted_at) {
              const lastStr = new Date(cfg.last_posted_at).toISOString().slice(0, 10);
              if (lastStr === todayStr) { console.log(`[TikTok] ${cfg.store_name}: ya publicado hoy`); continue; }
            }
            const [topProds] = await pool.execute(
              `SELECT p.id,p.name,p.description,p.price,p.image,COUNT(oi.id) AS sales
               FROM products p LEFT JOIN order_items oi ON oi.product_id=p.id
               WHERE p.store_id=? GROUP BY p.id ORDER BY sales DESC LIMIT 5`,
              [cfg.store_id]
            );
            const [coupons] = await pool.execute(
              'SELECT * FROM coupons WHERE store_id=? AND is_active=TRUE ORDER BY discount_value DESC LIMIT 3',
              [cfg.store_id]
            );
            const buf     = await generatePromoImage({ store: cfg, topProducts: topProds, coupons, templateCounter: cfg.template_counter || 0, currencySymbol: cfg.currency_symbol || '$' });
            const caption = cfg.caption_template || `✨ ${cfg.store_name} ✨\n\n🔥 Lo mejor de la semana!\n\n📲 ${BASE_URL}/store/${cfg.store_code}\n\n#${(cfg.store_name||'').replace(/\s+/g,'')} #SRServi #TikTok`;
            await postToTikTok({ cookieString: cfg.session_cookie, imageBuffer: buf, caption });
            await updateTikTokPosted(cfg.store_id, null);
            console.log(`[TikTok] ✅ ${cfg.store_name}`);
          } catch (e) {
            await updateTikTokPosted(cfg.store_id, e.message).catch(() => {});
            console.error(`[TikTok] ❌ ${cfg.store_name}:`, e.message);
          }
        }
      } catch (e) { console.error('[TikTok] Cron error:', e.message); }
    });

    // ─── SRBrain Routes ──────────────────────────────────────────────────────

    app.get('/api/brain/config', authenticateToken, async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        const config = await getAiConfig(storeId);
        res.json(config || { enabled: false, auto_promotions: true, worker_reminders: true, morale_messages: true, promotion_threshold: 20, sender_name: 'El Administrador' });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/brain/config', authenticateToken, async (req, res) => {
      try {
        const storeId = parseInt(req.body.store_id);
        if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        const config = await saveAiConfig(storeId, req.body);
        res.json(config);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/brain/log', authenticateToken, async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        const log = await getAiActivityLog(storeId, 100);
        res.json(log);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/brain/run', authenticateToken, async (req, res) => {
      try {
        const storeId = parseInt(req.body.store_id);
        if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        res.json({ message: 'SRBrain ejecutándose en background...' });
        runSrBrainForStore(storeId).catch(e => console.error('[Brain manual]', e.message));
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Worker phone update
    app.patch('/api/workers/:id/phone', authenticateToken, async (req, res) => {
      try {
        const { phone } = req.body;
        await updateWorkerPhone(parseInt(req.params.id), phone || null);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Procedures
    app.get('/api/procedures', authenticateToken, async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        res.json(await getProcedures(storeId));
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/procedures', authenticateToken, async (req, res) => {
      try {
        const { store_id, title, product_id, steps } = req.body;
        if (!store_id || !title) return res.status(400).json({ error: 'store_id y title requeridos' });
        const store = await getStoreById(parseInt(store_id));
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        const procedure = await createProcedure(parseInt(store_id), { title, product_id, steps: steps || [] });
        res.json(procedure);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.put('/api/procedures/:id', authenticateToken, async (req, res) => {
      try {
        const { store_id, title, product_id, steps } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(parseInt(store_id));
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        const procedure = await updateProcedure(parseInt(req.params.id), parseInt(store_id), { title, product_id, steps });
        res.json(procedure);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.delete('/api/procedures/:id', authenticateToken, async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const store = await getStoreById(storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        await deleteProcedure(parseInt(req.params.id), storeId);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Public: workers can see procedures for their store
    app.get('/api/public/procedures/:storeCode', async (req, res) => {
      try {
        const store = await getStoreByCode(req.params.storeCode.toUpperCase());
        if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
        res.json(await getProcedures(store.id));
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Prep Tables (tablas de preparación de productos — múltiples por tienda)
    app.get('/api/prep-tables', authenticateToken, async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        res.json(await getPrepTables(storeId));
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/prep-tables', authenticateToken, async (req, res) => {
      try {
        const { store_id, ...data } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(parseInt(store_id));
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        const id = await createPrepTable(parseInt(store_id), data);
        res.json({ id });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.put('/api/prep-tables/:id', authenticateToken, async (req, res) => {
      try {
        const { store_id, ...data } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(parseInt(store_id));
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        await updatePrepTable(parseInt(req.params.id), parseInt(store_id), data);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.delete('/api/prep-tables/:id', authenticateToken, async (req, res) => {
      try {
        const storeId = parseInt(req.query.store_id);
        const store = await getStoreById(storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        await deletePrepTable(parseInt(req.params.id), storeId);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/public/prep-tables/:storeCode', async (req, res) => {
      try {
        const store = await getStoreByCode(req.params.storeCode.toUpperCase());
        if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
        res.json(await getPrepTables(store.id));
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Custom Creations (canvas 1920×1080)
    const ensureCustomCreations = async () => {
      await pool.execute(`CREATE TABLE IF NOT EXISTS custom_creations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        store_id INT NOT NULL,
        title VARCHAR(255) NOT NULL DEFAULT 'Sin título',
        background_image TEXT,
        elements JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )`);
    };

    app.get('/api/custom-creations', authenticateToken, async (req, res) => {
      try {
        await ensureCustomCreations();
        const storeId = parseInt(req.query.store_id);
        if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        const [rows] = await pool.execute('SELECT * FROM custom_creations WHERE store_id = ? ORDER BY created_at DESC', [storeId]);
        res.json(rows.map(r => ({ ...r, elements: r.elements ? (typeof r.elements === 'string' ? JSON.parse(r.elements) : r.elements) : [] })));
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/custom-creations', authenticateToken, async (req, res) => {
      try {
        await ensureCustomCreations();
        const { store_id, title, background_image, elements } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(parseInt(store_id));
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        const [result] = await pool.execute(
          'INSERT INTO custom_creations (store_id, title, background_image, elements) VALUES (?, ?, ?, ?)',
          [parseInt(store_id), title || 'Sin título', background_image || '', JSON.stringify(elements || [])]
        );
        res.json({ id: result.insertId });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.put('/api/custom-creations/:id', authenticateToken, async (req, res) => {
      try {
        await ensureCustomCreations();
        const { store_id, title, background_image, elements } = req.body;
        if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
        const store = await getStoreById(parseInt(store_id));
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        await pool.execute(
          'UPDATE custom_creations SET title = ?, background_image = ?, elements = ?, updated_at = NOW() WHERE id = ? AND store_id = ?',
          [title || 'Sin título', background_image || '', JSON.stringify(elements || []), parseInt(req.params.id), parseInt(store_id)]
        );
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.delete('/api/custom-creations/:id', authenticateToken, async (req, res) => {
      try {
        await ensureCustomCreations();
        const storeId = parseInt(req.query.store_id);
        const store = await getStoreById(storeId);
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
        await pool.execute('DELETE FROM custom_creations WHERE id = ? AND store_id = ?', [parseInt(req.params.id), storeId]);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/public/custom-creations/:storeCode', async (req, res) => {
      try {
        await ensureCustomCreations();
        const store = await getStoreByCode(req.params.storeCode.toUpperCase());
        if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
        const [rows] = await pool.execute('SELECT * FROM custom_creations WHERE store_id = ? ORDER BY created_at DESC', [store.id]);
        res.json(rows.map(r => ({ ...r, elements: r.elements ? (typeof r.elements === 'string' ? JSON.parse(r.elements) : r.elements) : [] })));
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // León IA procedure generation
    app.post('/api/brain/generate-procedure', authenticateToken, async (req, res) => {
      try {
        const { store_id, product_name, extra_context } = req.body;
        if (!store_id || !product_name) return res.status(400).json({ error: 'store_id y product_name requeridos' });
        const store = await getStoreById(parseInt(store_id));
        if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });

        const prompt = `Genera un procedimiento de preparación paso a paso para: "${product_name}".
${extra_context ? 'Contexto adicional: ' + extra_context : ''}

Responde SOLO con JSON válido, sin texto extra:
{
  "title": "Procedimiento: ${product_name}",
  "steps": [
    { "step": 1, "title": "Título del paso", "instruction": "Instrucción detallada del paso. Sé específico y claro.", "tip": "Consejo opcional" },
    { "step": 2, "title": "...", "instruction": "...", "tip": "..." }
  ]
}

Incluye entre 4 y 8 pasos. Cada instrucción debe ser clara para un trabajador nuevo.`;

        const leonRes = await fetch('http://localhost:7777/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ question: prompt, store_id: parseInt(store_id), history: [] }),
          signal: AbortSignal.timeout(90000)
        });

        if (!leonRes.ok) return res.status(503).json({ error: 'León IA no disponible' });
        const leonData = await leonRes.json();
        const raw = leonData.answer || '';
        const match = raw.match(/\{[\s\S]*\}/);
        if (!match) return res.status(422).json({ error: 'León IA no devolvió JSON válido', raw });
        const parsed = JSON.parse(match[0]);
        res.json(parsed);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Cron SRBrain — cada hora evalúa qué tiendas deben ejecutarse según su schedule
    cron.schedule('0 * * * *', async () => {
      try {
        const now = new Date();
        const currentHour = now.getHours();
        const currentDay = now.getDay() === 0 ? 7 : now.getDay(); // 1=Lun...7=Dom
        const configs = await getAllEnabledAiConfigs();
        for (const cfg of configs) {
          const hour = cfg.send_hour ?? 8;
          const days = (cfg.send_days || '1,2,3,4,5,6,7').split(',').map(Number);
          if (hour === currentHour && days.includes(currentDay)) {
            runSrBrainForStore(cfg.store_id).catch(e => console.error(`[SRBrain] Error tienda ${cfg.store_id}:`, e.message));
          }
        }
      } catch (e) { console.error('[SRBrain] Cron error:', e.message); }
    });

    // WhatsApp routes — todas requieren store_id que pertenece al usuario autenticado
    async function verifyStoreOwner(req, res) {
      const storeId = parseInt(req.query.store_id || req.body?.store_id);
      if (!storeId) { res.status(400).json({ error: 'store_id requerido' }); return null; }
      const ok = await verifyStoreOwnership(storeId, req.user.id);
      if (!ok) { res.status(403).json({ error: 'Sin acceso a esta tienda' }); return null; }
      return storeId;
    }

    app.get('/api/whatsapp/status', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      res.json(getWhatsAppStatus(storeId));
    });

    app.get('/api/whatsapp/qr', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      const status = getWhatsAppStatus(storeId);
      if (!status.hasQR) return res.status(404).json({ error: 'Sin QR disponible. Inicia la conexión primero.' });
      res.json({ qr: status.qr });
    });

    app.post('/api/whatsapp/connect', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      initWhatsApp(storeId).catch(e => console.error(`[WhatsApp:${storeId}]`, e.message));
      res.json({ message: 'Iniciando conexión WhatsApp...' });
    });

    app.post('/api/whatsapp/disconnect', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      try {
        await disconnectWhatsApp(storeId);
        res.json({ message: 'WhatsApp desconectado' });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/whatsapp/reconnect', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      try {
        await reconnectWhatsApp(storeId);
        res.json({ message: 'Reconectando...' });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Diagnóstico: ver mensajes pendientes y estado de conexión por tienda
    app.get('/api/whatsapp/debug', authenticateToken, async (req, res) => {
      try {
        const pending = await getPendingScheduledMessages();
        const result = pending.map(msg => ({
          id: msg.id,
          store_id: msg.store_id,
          scheduled_at: msg.scheduled_at,
          wa_connected: getWhatsAppStatus(msg.store_id).connected,
          recipients: typeof msg.recipients === 'string' ? JSON.parse(msg.recipients) : msg.recipients,
        }));
        res.json({ pending_count: result.length, messages: result });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/whatsapp/groups', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      try {
        const groups = await getWhatsAppGroups(storeId);
        res.json(groups);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/whatsapp/send', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      try {
        const { to, message } = req.body;
        if (!to || !message) return res.status(400).json({ error: 'to y message requeridos' });
        await sendWhatsAppMessage(storeId, to, message);
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Scheduled WhatsApp messages — CRUD
    app.get('/api/whatsapp/scheduled', authenticateToken, async (req, res) => {
      try {
        const messages = await getScheduledMessages(req.user.id);
        res.json(messages);
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/whatsapp/scheduled', authenticateToken, async (req, res) => {
      try {
        const { store_id, message, recipients, scheduled_at, recurrence } = req.body;
        if (!store_id || !message || !recipients || !scheduled_at) {
          return res.status(400).json({ error: 'store_id, message, recipients y scheduled_at son requeridos' });
        }
        // Convert "YYYY-MM-DDTHH:MM" (datetime-local) to MySQL format "YYYY-MM-DD HH:MM:00"
        const sqlDatetime = scheduled_at.replace('T', ' ') + (scheduled_at.length === 16 ? ':00' : '');
        if (new Date(scheduled_at) <= new Date()) {
          return res.status(400).json({ error: 'La fecha programada debe ser futura' });
        }
        const id = await createScheduledMessage({
          userId: req.user.id,
          storeId: store_id,
          message,
          recipients,
          scheduledAt: sqlDatetime,
          recurrence: recurrence || 'none'
        });
        res.json({ id, success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.delete('/api/whatsapp/scheduled/:id', authenticateToken, async (req, res) => {
      try {
        const ok = await cancelScheduledMessage(parseInt(req.params.id), req.user.id);
        if (!ok) return res.status(404).json({ error: 'Mensaje no encontrado o ya procesado' });
        res.json({ success: true });
      } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Chatbot de pedidos por WhatsApp
    app.get('/api/whatsapp/bot', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      const enabled = getBotEnabled(storeId);
      const phone = getBotPhone(storeId);
      const link = phone
        ? `https://wa.me/${phone}?text=Hola%2C%20quiero%20hacer%20un%20pedido`
        : null;
      res.json({ enabled, phone, link });
    });

    app.post('/api/whatsapp/bot', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      const { enabled } = req.body;
      setBotEnabled(storeId, !!enabled);
      res.json({ enabled: !!enabled });
    });

    // Bot business info (address, opening hours)
    app.get('/api/whatsapp/bot-info', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      const [rows] = await pool.execute('SELECT address, opening_hours FROM stores WHERE id = ?', [storeId]);
      const row = rows[0] || {};
      res.json({ address: row.address || '', opening_hours: row.opening_hours || '' });
    });

    app.post('/api/whatsapp/bot-info', authenticateToken, async (req, res) => {
      const storeId = await verifyStoreOwner(req, res);
      if (!storeId) return;
      const { address, opening_hours } = req.body;
      await pool.execute('UPDATE stores SET address = ?, opening_hours = ? WHERE id = ?', [address || null, opening_hours || null, storeId]);
      res.json({ ok: true });
    });

    // Windows app download — generates a self-extracting .exe via NSIS (Linux) or zip fallback (dev)
    app.get('/api/apps/windows', async (req, res) => {
      try {
        const { storeCode } = req.query;
        if (!storeCode) return res.status(400).json({ error: 'storeCode requerido' });

        const [stores] = await pool.execute(
          'SELECT * FROM stores WHERE code = ?',
          [storeCode.toUpperCase()]
        );
        if (!stores.length) return res.status(404).json({ error: 'Tienda no encontrada' });
        const store = stores[0];

        const publishDir = path.join(__serverDir, 'web', 'windows', 'bin', 'Release', 'net10.0-windows', 'win-x64', 'publish');
        if (!fs.existsSync(publishDir)) {
          return res.status(503).json({ error: 'La app aún no está compilada. Contacta soporte.' });
        }

        const storeUrl = `https://srservi2.srautomatic.com/store/${store.code}`;

        if (process.platform === 'linux') {
          // Auto-install NSIS if missing
          try { execSync('which makensis', { stdio: 'pipe' }); }
          catch { execSync('apt-get install -y nsis', { stdio: 'inherit' }); }

          const tmpDir = `/tmp/srservi-win-${crypto.randomUUID()}`;
          const exeName = `SRServi-Totem-${store.code}.exe`;
          const exePath = `${tmpDir}/${exeName}`;

          try {
            fs.mkdirSync(tmpDir, { recursive: true });

            // NSIS script: silent install to %LOCALAPPDATA%\SRServi\Totem, injects config, launches Totem.exe
            const nsiScript = [
              'Unicode true',
              'RequestExecutionLevel user',
              'SilentInstall silent',
              `Name "SRServi Totem ${store.code}"`,
              `OutFile "${exePath}"`,
              'InstallDir "$LOCALAPPDATA\\SRServi\\Totem"',
              '',
              'Section',
              '  SetOutPath "$INSTDIR"',
              `  File /r "${publishDir}/*"`,
              '',
              '  FileOpen $0 "$INSTDIR\\config.json" w',
              `  FileWrite $0 '{"url":"${storeUrl}"}'`,
              '  FileClose $0',
              '',
              '  Exec "$INSTDIR\\Totem.exe"',
              'SectionEnd',
            ].join('\n');

            const scriptPath = `${tmpDir}/installer.nsi`;
            fs.writeFileSync(scriptPath, nsiScript, 'utf8');
            execSync(`makensis "${scriptPath}"`, { stdio: 'pipe' });

            const exeBuffer = fs.readFileSync(exePath);
            res.setHeader('Content-Type', 'application/octet-stream');
            res.setHeader('Content-Disposition', `attachment; filename="${exeName}"`);
            res.setHeader('Content-Length', exeBuffer.length);
            return res.send(exeBuffer);
          } finally {
            try { execSync(`rm -rf "${tmpDir}"`); } catch {}
          }
        }

        // Dev fallback (Windows): zip
        const zip = new AdmZip();
        zip.addLocalFolder(publishDir, 'SRServi-Totem');
        zip.addFile('SRServi-Totem/config.json', Buffer.from(JSON.stringify({ url: storeUrl }), 'utf8'));
        const zipBuffer = zip.toBuffer();
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', `attachment; filename="SRServi-Totem-${store.code}.zip"`);
        res.setHeader('Content-Length', zipBuffer.length);
        res.send(zipBuffer);
      } catch (err) {
        console.error('[Apps/Windows] Error:', err.message);
        res.status(500).json({ error: 'Error generando la app: ' + err.message });
      }
    });

    // Android app build — starts background compile job and returns jobId
    app.post('/api/apps/android/build', async (req, res) => {
      try {
        const { appName, storeCode, force } = req.body;
        const validApps = ['launcher', 'tvordenes', 'cctv'];
        if (!validApps.includes(appName)) return res.status(400).json({ error: 'App inválida' });

        if (appName !== 'cctv' && storeCode) {
          const [stores] = await pool.execute(
            'SELECT id FROM stores WHERE code = ?',
            [storeCode.toUpperCase()]
          );
          if (!stores.length) return res.status(404).json({ error: 'Tienda no encontrada' });
        }

        const code = storeCode ? storeCode.toUpperCase() : null;
        const result = await startBuild(appName, code, !!force);

        if (result.cached) {
          return res.json({ status: 'done', jobId: null, cached: true, appName, storeCode: code });
        }
        res.json({ status: 'building', jobId: result.jobId, cached: false, appName, storeCode: code });
      } catch (err) {
        console.error('[Apps/Android/Build]', err.message);
        res.status(500).json({ error: err.message });
      }
    });

    // Android app build — poll job status
    app.get('/api/apps/android/status/:jobId', (req, res) => {
      const job = getBuildJob(req.params.jobId);
      if (!job) return res.status(404).json({ error: 'Job no encontrado' });
      res.json({ status: job.status, progress: job.progress, error: job.error });
    });

    // Android app download — streams the compiled APK
    app.get('/api/apps/android/download', async (req, res) => {
      try {
        const { appName, storeCode, jobId } = req.query;

        let apkPath = null;

        if (jobId) {
          const job = getBuildJob(jobId);
          if (!job) return res.status(404).json({ error: 'Job no encontrado' });
          if (job.status !== 'done') return res.status(400).json({ error: 'Build no terminado' });
          apkPath = job.apkPath;
        } else {
          apkPath = getCachedApk(appName, storeCode ? storeCode.toUpperCase() : null);
        }

        if (!apkPath) return res.status(404).json({ error: 'APK no disponible' });

        const fileName = storeCode ? `${appName}-${storeCode.toUpperCase()}.apk` : `${appName}.apk`;
        res.setHeader('Content-Type', 'application/vnd.android.package-archive');
        res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
        fs.createReadStream(apkPath).pipe(res);
      } catch (err) {
        console.error('[Apps/Android/Download]', err.message);
        res.status(500).json({ error: 'Error al descargar el APK' });
      }
    });

    // Cron: procesar mensajes programados cada minuto
    let schedLock = false;
    cron.schedule('* * * * *', async () => {
      if (schedLock) return;
      schedLock = true;
      try {
        const pending = await getPendingScheduledMessages();
        if (pending.length > 0) console.log(`[WhatsApp Sched] ${pending.length} mensaje(s) pendiente(s)`);

        for (const msg of pending) {
          try {
            const recipients = typeof msg.recipients === 'string' ? JSON.parse(msg.recipients) : msg.recipients;

            // 1. Verificar conexión WhatsApp PRIMERO — si no hay conexión, reintentar el próximo minuto
            const wa = getWhatsAppStatus(msg.store_id);
            if (!wa.connected) {
              console.warn(`[WhatsApp Sched] Tienda ${msg.store_id} sin WhatsApp conectado — mensaje ${msg.id} reintentará`);
              continue;
            }

            // 2. Resolver destinatarios
            let targets = [];
            if (recipients.type === 'all') {
              const workers = await getWorkersWithPhone(msg.store_id);
              targets = workers.map(w => w.phone);
            } else if (recipients.type === 'specific' && Array.isArray(recipients.worker_ids)) {
              const workers = await getWorkersWithPhone(msg.store_id);
              const ids = new Set(recipients.worker_ids);
              targets = workers.filter(w => ids.has(w.id)).map(w => w.phone);
            } else if (recipients.type === 'groups' && Array.isArray(recipients.group_jids)) {
              targets = recipients.group_jids;
            }

            if (targets.length === 0) {
              console.warn(`[WhatsApp Sched] Mensaje ${msg.id} sin destinatarios válidos — marcando fallido`);
              await markScheduledMessageFailed(msg.id);
              continue;
            }

            // 3. Reclamar atómicamente (evita doble envío si hubiera overlap)
            const claimed = await markScheduledMessageSent(msg.id);
            if (!claimed) continue; // ya fue tomado por otra instancia

            // 4. Enviar
            let sent = 0;
            for (const target of targets) {
              try {
                await sendWhatsAppMessage(msg.store_id, target, msg.message);
                sent++;
              } catch (e) {
                console.error(`[WhatsApp Sched] Error enviando a ${target}:`, e.message);
              }
            }
            console.log(`[WhatsApp Sched] Mensaje ${msg.id} enviado a ${sent}/${targets.length} destinatarios`);

            // 5. Si hubo error total (0 enviados), marcar fallido
            if (sent === 0) {
              await markScheduledMessageFailed(msg.id);
            }

            // 6. Recurrencia diaria
            if (msg.recurrence === 'daily') {
              const next = new Date();
              next.setDate(next.getDate() + 1);
              const pad = n => String(n).padStart(2, '0');
              const nextSql = `${next.getFullYear()}-${pad(next.getMonth()+1)}-${pad(next.getDate())} ${pad(next.getHours())}:${pad(next.getMinutes())}:00`;
              await createScheduledMessage({
                userId: msg.user_id,
                storeId: msg.store_id,
                message: msg.message,
                recipients,
                scheduledAt: nextSql,
                recurrence: 'daily'
              });
              console.log(`[WhatsApp Sched] Próxima ocurrencia diaria para mensaje ${msg.id}: ${nextSql}`);
            }
          } catch (e) {
            console.error(`[WhatsApp Sched] Error procesando mensaje ${msg.id}:`, e.message);
            await markScheduledMessageFailed(msg.id);
          }
        }
      } catch (e) {
        console.error('[WhatsApp Sched] Error en cron:', e.message);
      } finally {
        schedLock = false;
      }
    });

    // Auto-start WhatsApp for each store that has a saved session
    for (const storeId of getAutoStartStoreIds()) {
      initWhatsApp(storeId).catch(e => console.warn(`[WhatsApp:${storeId}] Auto-start failed:`, e.message));
    }

    // RTSP people counter — reanudar streams activos al arrancar
    try {
      const { rtspCounterService } = await import('./rtsp-counter.js');
      await rtspCounterService.initAll();
      app._rtspCounterService = rtspCounterService;
    } catch (e) {
      console.warn('[RTSP] No se pudo iniciar servicio de aforo RTSP:', e.message);
    }

    server.listen(PORT, HOST, () => {
      console.log(`Servidor corriendo en http://${HOST}:${PORT}`);
    });

    // Instagram Python service — se inicia automáticamente con el servidor
    initInstagramService().catch(e => console.warn('[IG-Service] Error autostart:', e.message));

    // León IA — configuración automática en background (no bloquea el servidor)
    if (process.platform === 'linux') {
      initLeonIA().catch(e => console.warn('[León IA] Error autostart:', e.message));
    }
  } catch (error) {
    console.error('Error al iniciar el servidor:', error);
    process.exit(1);
  }
}

// ─── Attendance API ──────────────────────────────────────────────────────────

app.get('/api/attendance/:storeCode/persons', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const persons = await getAttendancePersons(store.id);
    res.json(persons);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/attendance/:storeCode/persons', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const { rut, name, surname, face_descriptor, face_photo } = req.body;
    if (!rut || !name || !surname || !face_descriptor)
      return res.status(400).json({ error: 'Faltan campos requeridos' });
    const existing = await getAttendancePersonByRut(store.id, rut);
    if (existing) return res.status(409).json({ error: 'Este RUT ya está registrado con otro rostro' });
    const id = await createAttendancePerson(store.id, rut, name, surname, face_descriptor, face_photo);
    res.json({ id, rut, name, surname });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/attendance/:storeCode/check-rut/:rut', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const person = await getAttendancePersonByRut(store.id, req.params.rut);
    res.json({ exists: !!person, person: person ? { id: person.id, name: person.name, surname: person.surname } : null });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/attendance/:storeCode/record', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const { person_id, type } = req.body;
    const valid = ['ENTRADA','SALIDA','INICIO_ALMUERZO','FIN_ALMUERZO','INICIO_PAUSA','FIN_PAUSA'];
    if (!valid.includes(type)) return res.status(400).json({ error: 'Tipo de registro inválido' });
    const id = await createAttendanceRecord(store.id, person_id, type);
    const last = await getLastAttendanceRecord(store.id, person_id);
    res.json({ id, type, recorded_at: last?.recorded_at });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/attendance/:storeCode/records', authenticateToken, async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    if (!await verifyStoreOwnership(store.id, req.user.id)) return res.status(403).json({ error: 'Sin permiso' });
    const { date, startDate, endDate } = req.query;
    let records;
    if (startDate && endDate) {
      records = await getAttendanceRecordsRange(store.id, startDate, endDate);
    } else {
      const d = date || new Date().toISOString().split('T')[0];
      records = await getAttendanceRecords(store.id, d);
    }
    res.json(records);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/attendance/:storeCode/persons/admin', authenticateToken, async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    if (!await verifyStoreOwnership(store.id, req.user.id)) return res.status(403).json({ error: 'Sin permiso' });
    const persons = await getAttendancePersons(store.id);
    res.json(persons.map(p => ({ id: p.id, rut: p.rut, name: p.name, surname: p.surname, face_photo: p.face_photo, created_at: p.created_at })));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/attendance/:storeCode/persons/:personId', authenticateToken, async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    if (!await verifyStoreOwnership(store.id, req.user.id)) return res.status(403).json({ error: 'Sin permiso' });
    await deleteAttendancePerson(req.params.personId, store.id);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Sales & Commissions API ──────────────────────────────────────────────────

app.get('/api/attendance/:storeCode/sales/config', authenticateToken, async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    if (!await verifyStoreOwnership(store.id, req.user.id)) return res.status(403).json({ error: 'Sin permiso' });
    res.json(await getSalesConfig(store.id));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/attendance/:storeCode/sales/config', authenticateToken, async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    if (!await verifyStoreOwnership(store.id, req.user.id)) return res.status(403).json({ error: 'Sin permiso' });
    const { commission_rate, daily_bonus, success_bonus, commission_threshold, am_start, am_end, pm_start, pm_end } = req.body;
    await upsertSalesConfig(store.id, {
      commission_rate: parseFloat(commission_rate) || 1,
      daily_bonus: parseFloat(daily_bonus) || 10,
      success_bonus: parseFloat(success_bonus) || 10,
      commission_threshold: parseFloat(commission_threshold) || 0,
      am_start: am_start || '08:00:00',
      am_end: am_end || '14:00:00',
      pm_start: pm_start || '14:00:00',
      pm_end: pm_end || '22:00:00',
    });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/attendance/:storeCode/sales', authenticateToken, async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    if (!await verifyStoreOwnership(store.id, req.user.id)) return res.status(403).json({ error: 'Sin permiso' });
    const year = parseInt(req.query.year) || new Date().getFullYear();
    const month = parseInt(req.query.month) || (new Date().getMonth() + 1);
    const [sales, config] = await Promise.all([
      getSalesForMonth(store.id, year, month),
      getSalesConfig(store.id)
    ]);
    const autoSales = await getSalesFromOrders(
      store.id, year, month,
      config.am_start || '08:00:00', config.am_end || '14:00:00',
      config.pm_start || '14:00:00', config.pm_end || '22:00:00'
    );
    res.json({ sales, autoSales, config });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/attendance/:storeCode/sales', authenticateToken, async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    if (!await verifyStoreOwnership(store.id, req.user.id)) return res.status(403).json({ error: 'Sin permiso' });
    const { date, shift, gross_sales, net_sales, transactions, notes } = req.body;
    if (!date || !['AM','PM','PART_TIME'].includes(shift))
      return res.status(400).json({ error: 'Datos inválidos' });
    await upsertSaleRecord(store.id, date, shift, parseFloat(gross_sales)||0, parseFloat(net_sales)||0, parseInt(transactions)||0, notes);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/attendance/:storeCode/sales', authenticateToken, async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    if (!await verifyStoreOwnership(store.id, req.user.id)) return res.status(403).json({ error: 'Sin permiso' });
    const { date, shift } = req.query;
    if (!date || !['AM','PM','PART_TIME'].includes(shift))
      return res.status(400).json({ error: 'Datos inválidos' });
    await deleteSaleRecord(store.id, date, shift);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Restaurant Tables — admin CRUD
app.get('/api/restaurant-tables', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const store = await getStoreById(storeId);
    if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
    res.json(await getRestaurantTablesWithStatus(storeId));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/restaurant-tables', authenticateToken, async (req, res) => {
  try {
    const { store_id, ...data } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
    const store = await getStoreById(parseInt(store_id));
    if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
    res.json(await createRestaurantTable(parseInt(store_id), data));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/restaurant-tables/:id', authenticateToken, async (req, res) => {
  try {
    const { store_id, ...data } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
    const store = await getStoreById(parseInt(store_id));
    if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
    const updated = await updateRestaurantTable(parseInt(req.params.id), parseInt(store_id), data);
    if (!updated) return res.status(404).json({ error: 'Mesa no encontrada' });
    res.json(updated);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/restaurant-tables/:id', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const store = await getStoreById(storeId);
    if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
    await deleteRestaurantTable(parseInt(req.params.id), storeId);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Public: workers can see table status for their store
app.get('/api/public/restaurant-tables/:storeCode', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    res.json(await getRestaurantTablesWithStatus(store.id));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Get active (pending) order for a specific table
app.get('/api/public/table-order/:storeCode/:tableId', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const tableId = parseInt(req.params.tableId);
    const [rows] = await pool.execute(`
      SELECT o.id, o.order_number, o.total, o.status, o.payment_method, o.created_at, o.table_number, o.persons
      FROM orders o
      WHERE o.store_id = ? AND o.table_number = ? AND o.status = 'pending'
      ORDER BY o.created_at DESC LIMIT 1
    `, [store.id, tableId]);
    if (rows.length === 0) return res.json(null);
    const order = rows[0];
    const [itemRows] = await pool.execute(`
      SELECT oi.id, oi.product_id, oi.quantity, oi.unit_price,
             oi.selected_ingredients, oi.selected_extras, p.name as product_name
      FROM order_items oi
      JOIN products p ON p.id = oi.product_id
      WHERE oi.order_id = ?
    `, [order.id]);
    order.items = itemRows.map(r => ({
      ...r,
      selected_ingredients: (() => { try { return JSON.parse(r.selected_ingredients || '[]'); } catch { return []; } })(),
      selected_extras: (() => { try { return JSON.parse(r.selected_extras || '[]'); } catch { return []; } })()
    }));
    res.json(order);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Add items to an existing pending order
app.post('/api/orders/:id/add-items', async (req, res) => {
  try {
    const orderId = parseInt(req.params.id);
    const { store_id, items } = req.body;
    if (!store_id || !items || items.length === 0) return res.status(400).json({ error: 'Items requeridos' });
    const [orderRows] = await pool.execute(
      "SELECT * FROM orders WHERE id = ? AND store_id = ? AND status = 'pending'",
      [orderId, store_id]
    );
    if (orderRows.length === 0) return res.status(404).json({ error: 'Pedido no encontrado o no está pendiente' });
    let additionalTotal = 0;
    for (const item of items) {
      await pool.execute(
        'INSERT INTO order_items (order_id, product_id, quantity, unit_price, selected_ingredients, selected_extras) VALUES (?, ?, ?, ?, ?, ?)',
        [orderId, item.product_id, item.quantity, item.unit_price,
         JSON.stringify(item.selected_ingredients || []), JSON.stringify(item.selected_extras || [])]
      );
      additionalTotal += parseFloat(item.unit_price) * parseInt(item.quantity);
    }
    await pool.execute('UPDATE orders SET total = total + ? WHERE id = ?', [additionalTotal, orderId]);
    const [updated] = await pool.execute('SELECT * FROM orders WHERE id = ?', [orderId]);
    const [itemRows] = await pool.execute(`
      SELECT oi.id, oi.product_id, oi.quantity, oi.unit_price,
             oi.selected_ingredients, oi.selected_extras, p.name as product_name
      FROM order_items oi JOIN products p ON p.id = oi.product_id
      WHERE oi.order_id = ?
    `, [orderId]);
    const order = { ...updated[0], items: itemRows.map(r => ({
      ...r,
      selected_ingredients: (() => { try { return JSON.parse(r.selected_ingredients || '[]'); } catch { return []; } })(),
      selected_extras: (() => { try { return JSON.parse(r.selected_extras || '[]'); } catch { return []; } })()
    })) };
    const socketId = userSockets.get(parseInt(store_id));
    if (socketId) io.to(socketId).emit('order_updated', order);
    res.json(order);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Delivery System ──────────────────────────────────────────────────────────

// Admin: get/update delivery settings
app.get('/api/delivery-settings', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const store = await getStoreById(storeId);
    if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
    res.json(await getDeliverySettings(storeId) || {});
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/delivery-settings', authenticateToken, async (req, res) => {
  try {
    const { store_id, ...data } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
    const store = await getStoreById(parseInt(store_id));
    if (!store || store.user_id !== req.user.id) return res.status(403).json({ error: 'Acceso denegado' });
    res.json(await upsertDeliverySettings(parseInt(store_id), data));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Public: get nearby delivery restaurants
app.get('/api/delivery/restaurants', async (req, res) => {
  try {
    const lat = parseFloat(req.query.lat);
    const lng = parseFloat(req.query.lng);
    if (isNaN(lat) || isNaN(lng)) return res.status(400).json({ error: 'Coordenadas requeridas' });
    const stores = await getNearbyDeliveryStores(lat, lng, 30);
    const now = new Date();
    const currentTime = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0');
    const result = stores.map(s => {
      let isOpen = false;
      if (s.hours_source === 'cash_register') {
        isOpen = s.has_open_register > 0;
      } else {
        isOpen = currentTime >= s.open_time && currentTime <= s.close_time;
      }
      return {
        id: s.id, code: s.code, name: s.name,
        logo: s.logo ? `${BASE_URL}${s.logo}` : null,
        address: s.address, distance_km: Math.round(s.distance_km * 10) / 10,
        fee: s.fee, min_order: s.min_order, estimated_minutes: s.estimated_minutes,
        isOpen
      };
    });
    res.json(result);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Customer auth: register with password
app.post('/api/delivery/auth/register', async (req, res) => {
  try {
    const { email, password, name, phone } = req.body;
    if (!email || !email.includes('@')) return res.status(400).json({ error: 'Email inválido' });
    if (!password || password.length < 6) return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });
    if (!name?.trim()) return res.status(400).json({ error: 'El nombre es requerido' });
    const { customer, code } = await registerDeliveryCustomer(email.toLowerCase().trim(), password, name.trim(), phone?.trim());
    try {
      await mailer.sendMail({
        from: `"SRServi Delivery" <${process.env.EMAIL_USER}>`,
        to: email,
        subject: 'Verifica tu cuenta SRServi',
        html: `<div style="font-family:sans-serif;max-width:420px;margin:0 auto;padding:28px;background:#0a0a0a;color:#fff;border-radius:12px">
          <div style="text-align:center;margin-bottom:20px"><img src="https://srservi2.srautomatic.com/iconweb.png" width="48" style="border-radius:10px" /></div>
          <h2 style="text-align:center;color:#D4AF37;margin:0 0 10px">Verifica tu email</h2>
          <p style="text-align:center;color:#aaa;margin:0 0 24px">Hola ${name}! Ingresa este código para activar tu cuenta:</p>
          <div style="text-align:center;font-size:40px;font-weight:900;letter-spacing:10px;color:#D4AF37;padding:20px;background:#111;border-radius:10px">${code}</div>
          <p style="text-align:center;color:#666;font-size:12px;margin-top:16px">Expira en 15 minutos</p>
        </div>`
      });
    } catch (mailErr) { console.warn('[Delivery Register] Email error:', mailErr.message); }
    res.json({ message: 'Código enviado', customerId: customer.id });
  } catch (e) { res.status(e.message.includes('ya tiene') ? 409 : 500).json({ error: e.message }); }
});

// Customer auth: login with password
app.post('/api/delivery/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email y contraseña requeridos' });
    const customer = await loginDeliveryCustomer(email.toLowerCase().trim(), password);
    if (!customer) return res.status(401).json({ error: 'Email o contraseña incorrectos' });
    const token = await createDeliverySession(customer.id);
    const { password_hash: _, verification_code: __, ...safe } = customer;
    res.json({ token, customer: safe });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Customer auth: my orders
app.get('/api/delivery/my-orders', async (req, res) => {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    const customer = await getDeliveryCustomerByToken(token);
    if (!customer) return res.status(401).json({ error: 'No autenticado' });
    res.json(await getCustomerOrders(customer.id));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Customer auth: track order
app.get('/api/delivery/order/:id/track', async (req, res) => {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    const customer = await getDeliveryCustomerByToken(token);
    if (!customer) return res.status(401).json({ error: 'No autenticado' });
    const order = await getDeliveryOrderForTracking(parseInt(req.params.id), customer.id);
    if (!order) return res.status(404).json({ error: 'Pedido no encontrado' });
    res.json(order);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Customer: update own profile
app.put('/api/delivery/my-profile', async (req, res) => {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    const customer = await getDeliveryCustomerByToken(token);
    if (!customer) return res.status(401).json({ error: 'No autenticado' });
    const { name, phone } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'El nombre es requerido' });
    const updated = await updateDeliveryCustomerProfile(customer.id, name.trim(), phone?.trim() || '');
    res.json(updated);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Customer auth: start (send code) — kept for legacy / email-only accounts
app.post('/api/delivery/auth/start', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email || !email.includes('@')) return res.status(400).json({ error: 'Email inválido' });
    const { customer, isNew } = await findOrCreateDeliveryCustomer(email.toLowerCase().trim());
    let code;
    if (!isNew) {
      code = await setDeliveryCustomerCode(email.toLowerCase().trim());
    } else {
      code = customer.verification_code;
    }
    // Send verification email
    try {
      await mailer.sendMail({
        from: `"SRServi Delivery" <${process.env.EMAIL_USER}>`,
        to: email,
        subject: 'Código de verificación SRServi',
        html: `<div style="font-family:sans-serif;max-width:400px;margin:0 auto;padding:24px;background:#0a0a0a;color:#fff;border-radius:12px">
          <div style="text-align:center;margin-bottom:20px">
            <div style="background:#D4AF37;color:#000;font-weight:900;font-size:22px;padding:10px 20px;border-radius:8px;display:inline-block">SR</div>
          </div>
          <h2 style="text-align:center;color:#D4AF37">Código de verificación</h2>
          <p style="text-align:center;color:#aaa">Ingresa este código en la app de delivery:</p>
          <div style="text-align:center;font-size:36px;font-weight:900;letter-spacing:8px;color:#D4AF37;padding:20px">${code}</div>
          <p style="text-align:center;color:#666;font-size:12px">Expira en 10 minutos</p>
        </div>`
      });
    } catch (mailErr) {
      console.warn('[Delivery] Email send error:', mailErr.message);
    }
    res.json({ message: 'Código enviado', isNew, needsProfile: isNew || !customer.name });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Customer auth: verify code
app.post('/api/delivery/auth/verify', async (req, res) => {
  try {
    const { email, code, name, phone } = req.body;
    if (!email || !code) return res.status(400).json({ error: 'Email y código requeridos' });
    const customer = await verifyDeliveryCustomerCode(email.toLowerCase().trim(), code.trim());
    if (!customer) return res.status(400).json({ error: 'Código inválido o expirado' });
    let finalCustomer = customer;
    if (name || phone) {
      finalCustomer = await completeDeliveryCustomerProfile(customer.id, name || customer.name, phone || customer.phone);
    }
    const token = await createDeliverySession(customer.id);
    const { verification_code: _, ...safeCustomer } = finalCustomer;
    res.json({ token, customer: safeCustomer });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Worker: get pending delivery orders
app.get('/api/worker/delivery', async (req, res) => {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    if (!token) return res.status(401).json({ error: 'Sin autorización' });
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    res.json(await getPendingDeliveryOrders(storeId));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Worker: update delivery order status
app.put('/api/worker/delivery/:id/status', async (req, res) => {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    if (!token) return res.status(401).json({ error: 'Sin autorización' });
    const { store_id, status } = req.body;
    const validStatuses = ['accepted', 'rejected', 'preparing', 'on_the_way', 'delivered'];
    if (!validStatuses.includes(status)) return res.status(400).json({ error: 'Estado inválido' });
    const order = await updateDeliveryOrderStatus(parseInt(req.params.id), parseInt(store_id), status);
    // Send status notification email
    if (order?.dc_email && status !== 'rejected') {
      const statusLabels = { accepted: '✅ Pedido recibido', preparing: '🍳 En preparación', on_the_way: '🛵 En camino', delivered: '📦 Entregado' };
      const statusMsg = { accepted: 'Tu pedido fue recibido y está siendo revisado por el restaurante.', preparing: 'Manos a la obra — ya están preparando tu pedido.', on_the_way: '¡Tu pedido está en camino! Prepárate para recibirlo.', delivered: '¡Tu pedido fue entregado! Esperamos que lo disfrutes.' };
      const statusColor = { accepted: '#0369a1', preparing: '#92400e', on_the_way: '#065f46', delivered: '#15803d' };
      const statusBg = { accepted: '#e0f2fe', preparing: '#fef3c7', on_the_way: '#d1fae5', delivered: '#f0fdf4' };
      try {
        const items = await getOrderItems(order.id);
        const subtotal = items.reduce((s, i) => s + i.unit_price * i.quantity, 0);
        const fee = Number(order.delivery_fee) || 0;
        const total = Number(order.total) || subtotal + fee;

        const itemsHtml = items.map(i => {
          const extras = Array.isArray(i.selected_extras) ? i.selected_extras : (JSON.parse(i.selected_extras || '[]'));
          const extrasStr = extras.length ? `<span style="color:#D4AF37;font-size:12px"> + ${extras.map(e => e.name).join(', ')}</span>` : '';
          return `<tr>
            <td style="padding:8px 0;border-bottom:1px solid #1e1e1e;color:#ccc;font-size:14px">${i.quantity}× ${i.product_name}${extrasStr}</td>
            <td style="padding:8px 0;border-bottom:1px solid #1e1e1e;color:#fff;font-weight:600;text-align:right;font-size:14px;white-space:nowrap">$${(i.unit_price * i.quantity).toFixed(0)}</td>
          </tr>`;
        }).join('');

        await mailer.sendMail({
          from: `"SRServi Delivery" <${process.env.EMAIL_USER}>`,
          to: order.dc_email,
          subject: `${statusLabels[status]} — Pedido #${order.id}`,
          html: `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#f3f4f6;font-family:'Helvetica Neue',Arial,sans-serif">
<div style="max-width:480px;margin:32px auto;background:#0a0a0a;border-radius:16px;overflow:hidden">

  <!-- Header -->
  <div style="background:#111;padding:24px;text-align:center;border-bottom:1px solid #1e1e1e">
    <img src="https://srservi2.srautomatic.com/iconweb.png" width="44" height="44" style="border-radius:10px;display:block;margin:0 auto 12px" />
    <div style="font-size:11px;letter-spacing:2px;color:#666;text-transform:uppercase;margin-bottom:4px">SRServi Delivery</div>
    <div style="color:#fff;font-size:13px">Pedido #${order.id}</div>
  </div>

  <!-- Status badge -->
  <div style="padding:28px 24px 20px;text-align:center">
    <div style="display:inline-block;background:${statusBg[status]};color:${statusColor[status]};font-weight:700;font-size:15px;padding:10px 22px;border-radius:30px;margin-bottom:14px">
      ${statusLabels[status]}
    </div>
    <p style="color:#aaa;font-size:14px;margin:0 0 4px">Hola <strong style="color:#fff">${order.dc_name || 'cliente'}</strong>,</p>
    <p style="color:#888;font-size:14px;margin:0">${statusMsg[status]}</p>
  </div>

  <!-- Store -->
  <div style="padding:0 24px 16px">
    <div style="background:#111;border-radius:10px;padding:12px 16px;display:flex;align-items:center;gap:10px">
      <span style="font-size:20px">🏪</span>
      <span style="color:#D4AF37;font-weight:700;font-size:15px">${order.store_name || 'Restaurante'}</span>
    </div>
  </div>

  <!-- Items -->
  <div style="padding:0 24px 16px">
    <div style="color:#555;font-size:11px;letter-spacing:1px;text-transform:uppercase;margin-bottom:10px">Tu pedido</div>
    <table style="width:100%;border-collapse:collapse">
      ${itemsHtml}
    </table>
    <table style="width:100%;border-collapse:collapse;margin-top:12px">
      <tr>
        <td style="color:#666;font-size:13px;padding:4px 0">Subtotal</td>
        <td style="color:#999;font-size:13px;text-align:right;padding:4px 0">$${subtotal.toFixed(0)}</td>
      </tr>
      <tr>
        <td style="color:#666;font-size:13px;padding:4px 0">Envío</td>
        <td style="color:#999;font-size:13px;text-align:right;padding:4px 0">${fee > 0 ? '$' + fee.toFixed(0) : 'Gratis'}</td>
      </tr>
      <tr>
        <td style="color:#fff;font-weight:700;font-size:15px;padding:10px 0 4px;border-top:1px solid #1e1e1e">Total</td>
        <td style="color:#D4AF37;font-weight:900;font-size:17px;text-align:right;padding:10px 0 4px;border-top:1px solid #1e1e1e">$${total.toFixed(0)}</td>
      </tr>
    </table>
  </div>

  <!-- Address -->
  ${order.delivery_address ? `<div style="padding:0 24px 20px">
    <div style="background:#111;border-radius:10px;padding:12px 16px">
      <div style="color:#555;font-size:11px;letter-spacing:1px;text-transform:uppercase;margin-bottom:6px">Dirección de entrega</div>
      <div style="color:#ccc;font-size:14px">📍 ${order.delivery_address}</div>
    </div>
  </div>` : ''}

  <!-- Footer -->
  <div style="padding:16px 24px 28px;text-align:center;border-top:1px solid #1e1e1e">
    <p style="color:#444;font-size:12px;margin:0">SRServi · Sistema de gestión para restaurantes</p>
  </div>

</div>
</body></html>`
        });
      } catch (mailErr) { console.warn('[Delivery Status Email]', mailErr.message); }
    }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Public: delivery store config (for store page in delivery mode)
app.get('/api/public/delivery-settings/:storeCode', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.storeCode.toUpperCase());
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    res.json(await getDeliverySettings(store.id) || {});
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Admin Roles ─────────────────────────────────────────────────────────────

app.get('/api/admin/roles', authenticateToken, async (req, res) => {
  try {
    if (!req.user.is_sub_account) await ensureDefaultRolesAndAccounts(req.user.id);
    res.json(await getRoles(req.user.id));
  }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/admin/roles', authenticateToken, async (req, res) => {
  try {
    if (req.user.is_sub_account) return res.status(403).json({ error: 'Sin permiso' });
    const { name, description, permissions } = req.body;
    if (!name?.trim()) return res.status(400).json({ error: 'Nombre requerido' });
    res.json(await createRole(req.user.id, { name, description, permissions }));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/admin/roles/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.is_sub_account) return res.status(403).json({ error: 'Sin permiso' });
    const { name, description, permissions } = req.body;
    if (!name?.trim()) return res.status(400).json({ error: 'Nombre requerido' });
    const updated = await updateRole(parseInt(req.params.id), req.user.id, { name, description, permissions });
    if (!updated) return res.status(404).json({ error: 'Rol no encontrado' });
    res.json(updated);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/admin/roles/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.is_sub_account) return res.status(403).json({ error: 'Sin permiso' });
    await deleteRole(parseInt(req.params.id), req.user.id);
    res.json({ ok: true });
  } catch (e) { res.status(e.message.includes('eliminar') ? 409 : 500).json({ error: e.message }); }
});

// ─── Admin Sub-accounts ───────────────────────────────────────────────────────

app.get('/api/admin/sub-accounts', authenticateToken, async (req, res) => {
  try {
    if (req.user.is_sub_account) return res.status(403).json({ error: 'Sin permiso' });
    await ensureDefaultRolesAndAccounts(req.user.id);
    res.json(await getSubAccounts(req.user.id));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/admin/sub-accounts', authenticateToken, async (req, res) => {
  try {
    if (req.user.is_sub_account) return res.status(403).json({ error: 'Sin permiso' });
    const { name, email, password, role_id } = req.body;
    if (!name?.trim() || !email?.trim() || !password) return res.status(400).json({ error: 'Nombre, email y contraseña son requeridos' });
    if (password.length < 6) return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });
    res.json(await createSubAccount(req.user.id, { name, email, password, role_id }));
  } catch (e) { res.status(e.message.includes('uso') || e.message.includes('registrado') ? 409 : 500).json({ error: e.message }); }
});

app.put('/api/admin/sub-accounts/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.is_sub_account) return res.status(403).json({ error: 'Sin permiso' });
    const { name, email, role_id, is_active, password } = req.body;
    if (!name?.trim()) return res.status(400).json({ error: 'Nombre requerido' });
    if (password && password.length < 6) return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });
    const updated = await updateSubAccount(parseInt(req.params.id), req.user.id, { name, email, role_id, is_active, password });
    res.json(updated);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/admin/sub-accounts/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.is_sub_account) return res.status(403).json({ error: 'Sin permiso' });
    await deleteSubAccount(parseInt(req.params.id), req.user.id);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Store Subdomains ─────────────────────────────────────────────────────────

// Public: resolve subdomain → store
app.get('/api/stores/by-subdomain/:subdomain', async (req, res) => {
  try {
    const subdomain = req.params.subdomain.toLowerCase().replace(/[^a-z0-9-]/g, '');
    if (!subdomain) return res.status(400).json({ error: 'Subdominio inválido' });
    const store = await getStoreBySubdomain(subdomain);
    if (!store) return res.status(404).json({ error: 'Subdominio no encontrado' });
    res.json({ code: store.code, name: store.name, logo: store.logo_url });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: get current subdomain
app.get('/api/stores/:id/subdomain', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const subdomain = await getStoreSubdomain(storeId);
    const baseDomain = (() => { try { return new URL(process.env.BASE_URL || '').hostname.split('.').slice(1).join('.'); } catch { return 'srautomatic.com'; } })();
    res.json({ subdomain, url: subdomain ? `https://${subdomain}.${baseDomain}` : null });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: set subdomain
app.post('/api/stores/:id/subdomain', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const [owned] = await pool.execute('SELECT id, code FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });

    const raw = (req.body.subdomain || '').toLowerCase().replace(/[^a-z0-9-]/g, '').trim();
    if (!raw) return res.status(400).json({ error: 'Subdominio requerido' });
    if (raw.length < 3) return res.status(400).json({ error: 'Mínimo 3 caracteres' });
    if (raw.length > 40) return res.status(400).json({ error: 'Máximo 40 caracteres' });
    const reserved = ['www', 'api', 'mail', 'smtp', 'ftp', 'admin', 'srservi2', 'app', 'static', 'cdn'];
    if (reserved.includes(raw)) return res.status(400).json({ error: 'Subdominio reservado' });

    // Release previous subdomain nginx config if exists
    const prev = await getStoreSubdomain(storeId);
    if (prev && prev !== raw) await unregisterSubdomain(prev);

    const clean = await setStoreSubdomain(storeId, raw);
    const nginxResult = await registerSubdomain(clean);

    const baseDomain = (() => { try { return new URL(process.env.BASE_URL || '').hostname.split('.').slice(1).join('.'); } catch { return 'srautomatic.com'; } })();
    res.json({
      ok: true,
      subdomain: clean,
      url: `https://${clean}.${baseDomain}`,
      nginx: nginxResult,
      warning: nginxResult.dev ? 'Modo desarrollo: nginx no fue modificado' : (!nginxResult.ok ? `nginx: ${nginxResult.error}` : null)
    });
  } catch (e) {
    if (e.message.includes('ya está en uso')) return res.status(409).json({ error: e.message });
    res.status(500).json({ error: e.message });
  }
});

// ─── People Counter ───────────────────────────────────────────────────────────

app.get('/api/stores/:id/people-counter/config', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const config = await getPeopleCounterConfig(storeId);
    res.json(config || {});
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/stores/:id/people-counter/config', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const { line, flip } = req.body;
    if (!line) return res.status(400).json({ error: 'line requerido' });
    await savePeopleCounterConfig(storeId, line, !!flip);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/stores/:id/people-counter/event', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const { direction, crossed_at } = req.body;
    await savePeopleCounterEvent(storeId, direction, crossed_at || new Date().toISOString());
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/stores/:id/people-counter/stats', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const date = req.query.date || new Date().toISOString().slice(0, 10);
    const stats = await getPeopleCounterStats(storeId, date);
    res.json(stats);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: remove subdomain
app.delete('/api/stores/:id/subdomain', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const prev = await getStoreSubdomain(storeId);
    if (prev) await unregisterSubdomain(prev);
    await clearStoreSubdomain(storeId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// =====================================================================
// TICKETERÍA — Venta de entradas con Haulmer + envío por correo
// =====================================================================

async function initTicketeriaTables() {
  try {
    await pool.execute(`CREATE TABLE IF NOT EXISTS ticket_events (
      id INT AUTO_INCREMENT PRIMARY KEY,
      store_id INT NOT NULL,
      name VARCHAR(255) NOT NULL,
      description TEXT,
      event_date DATE NOT NULL,
      time_start TIME NOT NULL,
      time_end TIME,
      location VARCHAR(500),
      image_url VARCHAR(1000),
      max_capacity INT DEFAULT NULL,
      sold_count INT DEFAULT 0,
      status ENUM('active','cancelled','finished') DEFAULT 'active',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    await pool.execute(`CREATE TABLE IF NOT EXISTS ticket_categories (
      id INT AUTO_INCREMENT PRIMARY KEY,
      event_id INT NOT NULL,
      name VARCHAR(100) NOT NULL,
      description VARCHAR(255),
      price INT NOT NULL DEFAULT 0,
      max_qty INT DEFAULT NULL,
      sort_order INT DEFAULT 0,
      FOREIGN KEY (event_id) REFERENCES ticket_events(id) ON DELETE CASCADE
    )`);
    await pool.execute(`CREATE TABLE IF NOT EXISTS ticket_purchases (
      id INT AUTO_INCREMENT PRIMARY KEY,
      store_id INT NOT NULL,
      event_id INT NOT NULL,
      buyer_name VARCHAR(255) NOT NULL,
      buyer_email VARCHAR(255) NOT NULL,
      buyer_phone VARCHAR(50),
      total_amount INT NOT NULL,
      haulmer_reference VARCHAR(120),
      viewer_code VARCHAR(7) UNIQUE,
      admitted TINYINT(1) DEFAULT 0,
      admitted_at TIMESTAMP NULL,
      status ENUM('pending','paid','failed','cancelled') DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      paid_at TIMESTAMP NULL
    )`);
    try { await pool.execute('ALTER TABLE ticket_purchases ADD COLUMN viewer_code VARCHAR(7) UNIQUE'); } catch(e) { if (!e.message.includes('Duplicate column')) {} }
    try { await pool.execute('ALTER TABLE ticket_purchases ADD COLUMN admitted TINYINT(1) DEFAULT 0'); } catch(e) {}
    try { await pool.execute('ALTER TABLE ticket_purchases ADD COLUMN admitted_at TIMESTAMP NULL'); } catch(e) {}
    await pool.execute(`CREATE TABLE IF NOT EXISTS ticket_purchase_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      purchase_id INT NOT NULL,
      category_id INT NOT NULL,
      category_name VARCHAR(100) NOT NULL,
      quantity INT NOT NULL,
      unit_price INT NOT NULL,
      subtotal INT NOT NULL,
      FOREIGN KEY (purchase_id) REFERENCES ticket_purchases(id) ON DELETE CASCADE
    )`);
    await pool.execute(`CREATE TABLE IF NOT EXISTS ticket_issued (
      id INT AUTO_INCREMENT PRIMARY KEY,
      purchase_id INT NOT NULL,
      event_id INT NOT NULL,
      category_id INT NOT NULL,
      category_name VARCHAR(100) NOT NULL,
      ticket_code VARCHAR(30) NOT NULL UNIQUE,
      buyer_name VARCHAR(255) NOT NULL,
      buyer_email VARCHAR(255) NOT NULL,
      status ENUM('valid','used','cancelled') DEFAULT 'valid',
      used_at TIMESTAMP NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (purchase_id) REFERENCES ticket_purchases(id) ON DELETE CASCADE
    )`);
    await pool.execute(`CREATE TABLE IF NOT EXISTS ticket_filter_config (
      id INT AUTO_INCREMENT PRIMARY KEY,
      store_id INT NOT NULL UNIQUE,
      show_search TINYINT(1) DEFAULT 1,
      show_genre  TINYINT(1) DEFAULT 1,
      show_country TINYINT(1) DEFAULT 0,
      show_price  TINYINT(1) DEFAULT 1,
      show_date   TINYINT(1) DEFAULT 1,
      genres      TEXT DEFAULT NULL,
      countries   TEXT DEFAULT NULL,
      updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`);
    // Migrations: add country/genre/min_age/max_age to ticket_events
    for (const col of [
      "ALTER TABLE ticket_events ADD COLUMN country VARCHAR(100) DEFAULT NULL",
      "ALTER TABLE ticket_events ADD COLUMN genre   VARCHAR(100) DEFAULT NULL",
    ]) {
      try { await pool.execute(col); } catch(e) { if (!e.message.includes('Duplicate column')) {} }
    }
    console.log('✅ Tablas de Ticketería listas');
  } catch (e) { console.error('[Ticketería] Table init error:', e.message); }
}

function generateTicketCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 7; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

async function issueAndEmailTickets(purchaseId) {
  try {
    const [purchases] = await pool.execute(
      'SELECT tp.*, te.name AS event_name, te.event_date, te.time_start, te.time_end, te.location FROM ticket_purchases tp JOIN ticket_events te ON te.id = tp.event_id WHERE tp.id = ?',
      [purchaseId]
    );
    if (!purchases[0]) return;
    const purchase = purchases[0];

    // No re-emitir si ya tiene viewer_code
    if (purchase.viewer_code) return;

    // Generar viewer_code único para la compra
    let viewerCode;
    let unique = false;
    while (!unique) {
      viewerCode = generateTicketCode();
      const [ex] = await pool.execute('SELECT id FROM ticket_purchases WHERE viewer_code = ?', [viewerCode]);
      if (!ex[0]) unique = true;
    }
    await pool.execute('UPDATE ticket_purchases SET viewer_code = ? WHERE id = ?', [viewerCode, purchaseId]);

    const [items] = await pool.execute('SELECT * FROM ticket_purchase_items WHERE purchase_id = ?', [purchaseId]);
    const totalTickets = items.reduce((s, i) => s + i.quantity, 0);

    // Registrar tickets individuales en ticket_issued (para trazabilidad interna)
    const [existingIssued] = await pool.execute('SELECT id FROM ticket_issued WHERE purchase_id = ? LIMIT 1', [purchaseId]);
    if (!existingIssued[0]) {
      for (const item of items) {
        for (let i = 0; i < item.quantity; i++) {
          let code2;
          let u2 = false;
          while (!u2) {
            code2 = generateTicketCode();
            const [e2] = await pool.execute('SELECT id FROM ticket_issued WHERE ticket_code = ?', [code2]);
            if (!e2[0]) u2 = true;
          }
          await pool.execute(
            'INSERT INTO ticket_issued (purchase_id, event_id, category_id, category_name, ticket_code, buyer_name, buyer_email) VALUES (?,?,?,?,?,?,?)',
            [purchaseId, purchase.event_id, item.category_id, item.category_name, code2, purchase.buyer_name, purchase.buyer_email]
          );
        }
      }
      await pool.execute('UPDATE ticket_events SET sold_count = sold_count + ? WHERE id = ?', [totalTickets, purchase.event_id]);
    }

    // ── Construir email ──────────────────────────────────────────────
    const ticketUrl = `${BASE_URL}/ticket/${viewerCode}`;

    // QR como buffer PNG (adjunto CID — visible en todos los clientes de correo)
    const qrBuffer = await QRCode.toBuffer(ticketUrl, {
      width: 260, margin: 2,
      color: { dark: '#111111', light: '#ffffff' }
    });

    // Fecha: el campo event_date viene como Date object o string YYYY-MM-DD
    const rawDate = purchase.event_date;
    const dateObj = rawDate instanceof Date ? rawDate : new Date(String(rawDate).slice(0,10) + 'T12:00:00');
    const eventDate = dateObj.toLocaleDateString('es-CL', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
    const timeStr = purchase.time_start
      ? String(purchase.time_start).slice(0, 5) + (purchase.time_end ? ' – ' + String(purchase.time_end).slice(0, 5) : '')
      : '';
    const totalStr = purchase.total_amount === 0 ? 'Gratis' : `$${Number(purchase.total_amount).toLocaleString('es-CL')}`;

    // Filas de categorías
    const catRows = items.map(item =>
      `<tr>
        <td style="padding:7px 12px;border-bottom:1px solid #f3f4f6;font-size:14px;color:#374151;">${item.category_name}</td>
        <td style="padding:7px 12px;border-bottom:1px solid #f3f4f6;font-size:14px;color:#374151;text-align:center;">${item.quantity}</td>
        <td style="padding:7px 12px;border-bottom:1px solid #f3f4f6;font-size:14px;color:#C8A415;font-weight:700;text-align:right;">${item.unit_price === 0 ? 'Gratis' : '$'+Number(item.unit_price).toLocaleString('es-CL')}</td>
      </tr>`
    ).join('');

    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:30px 10px;">
  <tr><td align="center">
  <table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;border-radius:14px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08);">

    <!-- Header dorado -->
    <tr><td style="background:#C8A415;padding:24px 30px;text-align:center;">
      <div style="font-size:28px;margin-bottom:6px;">🎟️</div>
      <h1 style="margin:0;color:#fff;font-size:22px;font-weight:900;letter-spacing:0.5px;">Tus Entradas</h1>
      <p style="margin:4px 0 0;color:rgba(255,255,255,0.85);font-size:14px;">${purchase.event_name}</p>
    </td></tr>

    <!-- Info evento -->
    <tr><td style="background:#fff;padding:24px 30px 0;">
      <table cellpadding="0" cellspacing="0" width="100%" style="margin-bottom:20px;">
        <tr><td style="padding:4px 0;font-size:14px;color:#374151;">📅 <strong>${eventDate}</strong></td></tr>
        ${timeStr ? `<tr><td style="padding:4px 0;font-size:14px;color:#374151;">⏰ ${timeStr}</td></tr>` : ''}
        ${purchase.location ? `<tr><td style="padding:4px 0;font-size:14px;color:#374151;">📍 ${purchase.location}</td></tr>` : ''}
        <tr><td style="padding:4px 0;font-size:14px;color:#374151;">👤 ${purchase.buyer_name} &lt;${purchase.buyer_email}&gt;</td></tr>
      </table>
    </td></tr>

    <!-- Tabla de entradas -->
    <tr><td style="background:#fff;padding:0 30px 20px;">
      <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e5e7eb;border-radius:10px;overflow:hidden;">
        <thead><tr style="background:#f9fafb;">
          <th style="padding:9px 12px;text-align:left;font-size:12px;color:#6b7280;font-weight:600;text-transform:uppercase;">Categoría</th>
          <th style="padding:9px 12px;text-align:center;font-size:12px;color:#6b7280;font-weight:600;text-transform:uppercase;">Cant.</th>
          <th style="padding:9px 12px;text-align:right;font-size:12px;color:#6b7280;font-weight:600;text-transform:uppercase;">Precio</th>
        </tr></thead>
        <tbody>${catRows}</tbody>
        <tfoot><tr style="background:#f9fafb;">
          <td colspan="2" style="padding:9px 12px;font-size:14px;font-weight:700;color:#111;">Total · ${totalTickets} persona${totalTickets !== 1 ? 's' : ''}</td>
          <td style="padding:9px 12px;font-size:16px;font-weight:900;color:#C8A415;text-align:right;">${totalStr}</td>
        </tr></tfoot>
      </table>
    </td></tr>

    <!-- QR central — adjunto CID -->
    <tr><td style="background:#fffbeb;padding:28px 30px;text-align:center;border-top:2px solid #C8A41540;border-bottom:2px solid #C8A41540;">
      <p style="margin:0 0 16px;font-size:14px;color:#374151;font-weight:600;">Presenta este código QR en la entrada del evento</p>
      <img src="cid:ticket-qr" width="220" height="220" alt="QR Entrada" style="display:block;margin:0 auto;border-radius:10px;border:4px solid #C8A415;"/>
      <div style="margin-top:14px;font-family:monospace;font-size:24px;font-weight:900;letter-spacing:5px;color:#111;">${viewerCode}</div>
      <p style="margin:8px 0 0;font-size:12px;color:#9ca3af;">Código único de tu compra</p>
    </td></tr>

    <!-- Botón ver online -->
    <tr><td style="background:#fff;padding:20px 30px;text-align:center;">
      <a href="${ticketUrl}" style="display:inline-block;background:#C8A415;color:#fff;font-weight:800;font-size:15px;padding:13px 32px;border-radius:10px;text-decoration:none;">
        Ver entrada en línea
      </a>
      <p style="margin:10px 0 0;font-size:12px;color:#9ca3af;">También puedes ver el estado de tu entrada en cualquier momento desde el enlace</p>
    </td></tr>

    <!-- Footer -->
    <tr><td style="background:#f9fafb;padding:14px 30px;text-align:center;border-top:1px solid #e5e7eb;">
      <p style="margin:0;font-size:11px;color:#9ca3af;">Powered by SRServi · Ref: ${purchase.haulmer_reference || viewerCode}</p>
    </td></tr>

  </table>
  </td></tr>
</table>
</body></html>`;

    await mailer.sendMail({
      from: `"SRServi Tickets" <${process.env.EMAIL_USER}>`,
      to: purchase.buyer_email,
      subject: `🎟️ Tus entradas — ${purchase.event_name}`,
      html,
      attachments: [{
        filename: 'entrada-qr.png',
        content: qrBuffer,
        cid: 'ticket-qr'   // referenciado en el HTML como src="cid:ticket-qr"
      }]
    });
  } catch (e) { console.error('[Ticketería] issueAndEmailTickets error:', e.message); }
}

// ── Admin: Eventos ──────────────────────────────────────────────────
app.get('/api/ticketeria/events', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const [rows] = await pool.execute('SELECT * FROM ticket_events WHERE store_id = ? ORDER BY event_date DESC', [storeId]);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/ticketeria/events', authenticateToken, async (req, res) => {
  try {
    const { store_id, name, description, event_date, time_start, time_end, location, image_url, max_capacity } = req.body;
    if (!store_id || !name || !event_date || !time_start) return res.status(400).json({ error: 'Campos requeridos: store_id, name, event_date, time_start' });
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [parseInt(store_id), req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const { genre, country } = req.body;
    const [result] = await pool.execute(
      'INSERT INTO ticket_events (store_id, name, description, event_date, time_start, time_end, location, image_url, max_capacity, genre, country) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
      [parseInt(store_id), name, description || null, event_date, time_start, time_end || null, location || null, image_url || null, max_capacity || null, genre || null, country || null]
    );
    const [newEvent] = await pool.execute('SELECT * FROM ticket_events WHERE id = ?', [result.insertId]);
    res.json(newEvent[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/ticketeria/events/:id', authenticateToken, async (req, res) => {
  try {
    const eventId = parseInt(req.params.id);
    const [evRows] = await pool.execute('SELECT te.* FROM ticket_events te JOIN stores s ON s.id = te.store_id WHERE te.id = ? AND s.user_id = ?', [eventId, req.user.id]);
    if (!evRows[0]) return res.status(403).json({ error: 'Sin permiso' });
    const { name, description, event_date, time_start, time_end, location, image_url, max_capacity, status, genre, country } = req.body;
    await pool.execute(
      'UPDATE ticket_events SET name=?, description=?, event_date=?, time_start=?, time_end=?, location=?, image_url=?, max_capacity=?, status=?, genre=?, country=? WHERE id=?',
      [name || evRows[0].name, description ?? evRows[0].description, event_date || evRows[0].event_date, time_start || evRows[0].time_start, time_end ?? evRows[0].time_end, location ?? evRows[0].location, image_url ?? evRows[0].image_url, max_capacity ?? evRows[0].max_capacity, status || evRows[0].status, genre ?? evRows[0].genre, country ?? evRows[0].country, eventId]
    );
    const [updated] = await pool.execute('SELECT * FROM ticket_events WHERE id = ?', [eventId]);
    res.json(updated[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/ticketeria/events/:id', authenticateToken, async (req, res) => {
  try {
    const eventId = parseInt(req.params.id);
    const [evRows] = await pool.execute('SELECT te.id FROM ticket_events te JOIN stores s ON s.id = te.store_id WHERE te.id = ? AND s.user_id = ?', [eventId, req.user.id]);
    if (!evRows[0]) return res.status(403).json({ error: 'Sin permiso' });
    await pool.execute('DELETE FROM ticket_events WHERE id = ?', [eventId]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Admin: Categorías ───────────────────────────────────────────────
app.get('/api/ticketeria/events/:id/categories', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM ticket_categories WHERE event_id = ? ORDER BY sort_order, id', [parseInt(req.params.id)]);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/ticketeria/events/:id/categories', authenticateToken, async (req, res) => {
  try {
    const eventId = parseInt(req.params.id);
    const [evRows] = await pool.execute('SELECT te.id FROM ticket_events te JOIN stores s ON s.id = te.store_id WHERE te.id = ? AND s.user_id = ?', [eventId, req.user.id]);
    if (!evRows[0]) return res.status(403).json({ error: 'Sin permiso' });
    const { name, description, price, max_qty, sort_order } = req.body;
    if (!name || price == null) return res.status(400).json({ error: 'name y price requeridos' });
    const [result] = await pool.execute(
      'INSERT INTO ticket_categories (event_id, name, description, price, max_qty, sort_order) VALUES (?,?,?,?,?,?)',
      [eventId, name, description || null, parseInt(price), (max_qty !== '' && max_qty != null) ? parseInt(max_qty) : null, sort_order || 0]
    );
    const [newCat] = await pool.execute('SELECT * FROM ticket_categories WHERE id = ?', [result.insertId]);
    res.json(newCat[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/ticketeria/categories/:id', authenticateToken, async (req, res) => {
  try {
    const catId = parseInt(req.params.id);
    const [catRows] = await pool.execute(
      'SELECT tc.* FROM ticket_categories tc JOIN ticket_events te ON te.id = tc.event_id JOIN stores s ON s.id = te.store_id WHERE tc.id = ? AND s.user_id = ?',
      [catId, req.user.id]
    );
    if (!catRows[0]) return res.status(403).json({ error: 'Sin permiso' });
    const { name, description, price, max_qty, sort_order } = req.body;
    await pool.execute(
      'UPDATE ticket_categories SET name=?, description=?, price=?, max_qty=?, sort_order=? WHERE id=?',
      [name || catRows[0].name, description ?? catRows[0].description, price != null ? parseInt(price) : catRows[0].price, (max_qty !== '' && max_qty != null) ? parseInt(max_qty) : null, sort_order ?? catRows[0].sort_order, catId]
    );
    const [updated] = await pool.execute('SELECT * FROM ticket_categories WHERE id = ?', [catId]);
    res.json(updated[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/ticketeria/categories/:id', authenticateToken, async (req, res) => {
  try {
    const catId = parseInt(req.params.id);
    const [catRows] = await pool.execute(
      'SELECT tc.id FROM ticket_categories tc JOIN ticket_events te ON te.id = tc.event_id JOIN stores s ON s.id = te.store_id WHERE tc.id = ? AND s.user_id = ?',
      [catId, req.user.id]
    );
    if (!catRows[0]) return res.status(403).json({ error: 'Sin permiso' });
    await pool.execute('DELETE FROM ticket_categories WHERE id = ?', [catId]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Admin: Compras y tickets emitidos ───────────────────────────────
app.get('/api/ticketeria/purchases', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const eventId = req.query.event_id ? parseInt(req.query.event_id) : null;
    const query = eventId
      ? 'SELECT tp.*, te.name AS event_name FROM ticket_purchases tp JOIN ticket_events te ON te.id = tp.event_id WHERE tp.store_id = ? AND tp.event_id = ? ORDER BY tp.created_at DESC'
      : 'SELECT tp.*, te.name AS event_name FROM ticket_purchases tp JOIN ticket_events te ON te.id = tp.event_id WHERE tp.store_id = ? ORDER BY tp.created_at DESC';
    const params = eventId ? [storeId, eventId] : [storeId];
    const [rows] = await pool.execute(query, params);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/ticketeria/tickets', authenticateToken, async (req, res) => {
  try {
    const eventId = parseInt(req.query.event_id);
    if (!eventId) return res.status(400).json({ error: 'event_id requerido' });
    const [evRows] = await pool.execute('SELECT te.id FROM ticket_events te JOIN stores s ON s.id = te.store_id WHERE te.id = ? AND s.user_id = ?', [eventId, req.user.id]);
    if (!evRows[0]) return res.status(403).json({ error: 'Sin permiso' });
    const [rows] = await pool.execute('SELECT * FROM ticket_issued WHERE event_id = ? ORDER BY created_at DESC', [eventId]);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Admin: Validar/escanear ticket ──────────────────────────────────
app.post('/api/ticketeria/tickets/:code/scan', authenticateToken, async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const [rows] = await pool.execute(
      'SELECT ti.*, te.name AS event_name, te.event_date, te.time_start, te.location FROM ticket_issued ti JOIN ticket_events te ON te.id = ti.event_id WHERE ti.ticket_code = ?',
      [code]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Ticket no encontrado' });
    const ticket = rows[0];
    const [evRows] = await pool.execute('SELECT te.id FROM ticket_events te JOIN stores s ON s.id = te.store_id WHERE te.id = ? AND s.user_id = ?', [ticket.event_id, req.user.id]);
    if (!evRows[0]) return res.status(403).json({ error: 'Sin permiso' });
    if (ticket.status === 'used') return res.status(409).json({ error: 'Ticket ya utilizado', ticket });
    if (ticket.status === 'cancelled') return res.status(409).json({ error: 'Ticket cancelado', ticket });
    await pool.execute('UPDATE ticket_issued SET status = ?, used_at = NOW() WHERE ticket_code = ?', ['used', code]);
    ticket.status = 'used';
    res.json({ success: true, ticket });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Público: info básica de tienda por código ────────────────────────
app.get('/api/stores/by-code/:code', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT id, name, code FROM stores WHERE code = ?', [req.params.code.toUpperCase()]);
    if (!rows[0]) return res.status(404).json({ error: 'Tienda no encontrada' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Público: config de filtros ───────────────────────────────────────
app.get('/api/ticketeria/filter-config', async (req, res) => {
  try {
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const [rows] = await pool.execute('SELECT * FROM ticket_filter_config WHERE store_id = ? LIMIT 1', [storeId]);
    if (!rows[0]) return res.json({ show_search:1, show_genre:1, show_country:0, show_price:1, show_date:1, genres:[], countries:[] });
    const cfg = rows[0];
    res.json({ ...cfg, genres: cfg.genres ? JSON.parse(cfg.genres) : [], countries: cfg.countries ? JSON.parse(cfg.countries) : [] });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Admin: guardar config de filtros ────────────────────────────────
app.post('/api/ticketeria/filter-config', authenticateToken, async (req, res) => {
  try {
    const { store_id, show_search, show_genre, show_country, show_price, show_date, genres, countries } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [parseInt(store_id), req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const genresJson = JSON.stringify(Array.isArray(genres) ? genres : []);
    const countriesJson = JSON.stringify(Array.isArray(countries) ? countries : []);
    await pool.execute(`INSERT INTO ticket_filter_config (store_id, show_search, show_genre, show_country, show_price, show_date, genres, countries)
      VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE show_search=?, show_genre=?, show_country=?, show_price=?, show_date=?, genres=?, countries=?`,
      [parseInt(store_id), show_search?1:0, show_genre?1:0, show_country?1:0, show_price?1:0, show_date?1:0, genresJson, countriesJson,
       show_search?1:0, show_genre?1:0, show_country?1:0, show_price?1:0, show_date?1:0, genresJson, countriesJson]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Público: eventos disponibles (con filtros) ───────────────────────
app.get('/api/ticketeria/public/events', async (req, res) => {
  try {
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const { search, genre, country, date_from, date_to } = req.query;
    let sql = "SELECT * FROM ticket_events WHERE store_id = ? AND status = 'active'";
    const params = [storeId];
    if (search)    { sql += ' AND name LIKE ?'; params.push(`%${search}%`); }
    if (genre)     { sql += ' AND genre = ?'; params.push(genre); }
    if (country)   { sql += ' AND country = ?'; params.push(country); }
    if (date_from) { sql += ' AND event_date >= ?'; params.push(date_from); }
    if (date_to)   { sql += ' AND event_date <= ?'; params.push(date_to); }
    sql += ' ORDER BY event_date ASC';
    const [rows] = await pool.execute(sql, params);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/ticketeria/public/events/:id', async (req, res) => {
  try {
    const eventId = parseInt(req.params.id);
    const [evRows] = await pool.execute('SELECT * FROM ticket_events WHERE id = ?', [eventId]);
    if (!evRows[0]) return res.status(404).json({ error: 'Evento no encontrado' });
    const [cats] = await pool.execute('SELECT * FROM ticket_categories WHERE event_id = ? ORDER BY sort_order, id', [eventId]);
    res.json({ ...evRows[0], categories: cats });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Público: crear compra sin pasarela (para terminal POS físico) ────
// Endpoint para el launcher Android — entrega compras de ticketería confirmadas del día
app.get('/api/store/:code/ticket-purchases', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });

    const [rows] = await pool.execute(
      `SELECT tp.*, te.name AS event_name, te.event_date, te.time_start
       FROM ticket_purchases tp
       JOIN ticket_events te ON te.id = tp.event_id
       WHERE tp.store_id = ? AND tp.status = 'paid'
         AND tp.viewer_code IS NOT NULL
         AND DATE(tp.paid_at) = CURDATE()
       ORDER BY tp.paid_at DESC`,
      [store.id]
    );

    const purchases = [];
    for (const row of rows) {
      const [items] = await pool.execute(
        'SELECT * FROM ticket_purchase_items WHERE purchase_id = ?',
        [row.id]
      );
      const showTime = row.event_date
        ? `${String(row.event_date).slice(0, 10)}${row.time_start ? 'T' + String(row.time_start).slice(0, 5) : ''}`.replace(/T$/, '')
        : null;
      purchases.push({
        id: row.id,
        viewer_code: row.viewer_code,
        qr_url: `${BASE_URL}/ticket/${row.viewer_code}`,
        event_name: row.event_name || null,
        show_time: showTime,
        total_amount: parseFloat(row.total_amount || 0),
        paid_at: row.paid_at,
        items: items.map(i => ({
          category_name: i.category_name,
          quantity: i.quantity,
          unit_price: parseFloat(i.unit_price || 0)
        }))
      });
    }

    res.json({ store: { code: store.code, name: store.name }, total: purchases.length, purchases });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/ticketeria/purchase/init', async (req, res) => {
  try {
    const { store_id, event_id, buyer_name, buyer_email, buyer_phone, items } = req.body;
    if (!store_id || !event_id || !items?.length)
      return res.status(400).json({ error: 'Campos requeridos: store_id, event_id, items' });
    const safeName = (buyer_name || '').trim() || 'Cliente';
    const safeEmail = (buyer_email || '').trim() || '';

    const [evRows] = await pool.execute("SELECT * FROM ticket_events WHERE id = ? AND status = 'active'", [parseInt(event_id)]);
    if (!evRows[0]) return res.status(404).json({ error: 'Evento no disponible' });

    let totalAmount = 0;
    const resolvedItems = [];
    for (const item of items) {
      if (!item.category_id || !item.quantity || item.quantity < 1) continue;
      const [cats] = await pool.execute('SELECT * FROM ticket_categories WHERE id = ? AND event_id = ?', [parseInt(item.category_id), parseInt(event_id)]);
      if (!cats[0]) return res.status(400).json({ error: `Categoría ${item.category_id} no válida` });
      const cat = cats[0];
      const qty = parseInt(item.quantity);
      resolvedItems.push({ category_id: cat.id, category_name: cat.name, quantity: qty, unit_price: cat.price, subtotal: cat.price * qty });
      totalAmount += cat.price * qty;
    }
    if (!resolvedItems.length) return res.status(400).json({ error: 'Ningún ítem válido' });

    const [storeRows] = await pool.execute('SELECT user_id, code FROM stores WHERE id = ?', [parseInt(store_id)]);
    if (!storeRows[0]) return res.status(404).json({ error: 'Tienda no encontrada' });

    const [purchaseResult] = await pool.execute(
      'INSERT INTO ticket_purchases (store_id, event_id, buyer_name, buyer_email, buyer_phone, total_amount) VALUES (?,?,?,?,?,?)',
      [parseInt(store_id), parseInt(event_id), safeName, safeEmail, buyer_phone || null, totalAmount]
    );
    const purchaseId = purchaseResult.insertId;
    for (const item of resolvedItems) {
      await pool.execute(
        'INSERT INTO ticket_purchase_items (purchase_id, category_id, category_name, quantity, unit_price, subtotal) VALUES (?,?,?,?,?,?)',
        [purchaseId, item.category_id, item.category_name, item.quantity, item.unit_price, item.subtotal]
      );
    }
    const reference = `TKT-${purchaseId}-${Date.now()}`;
    await pool.execute('UPDATE ticket_purchases SET haulmer_reference = ? WHERE id = ?', [reference, purchaseId]);

    if (totalAmount === 0) {
      await pool.execute("UPDATE ticket_purchases SET status = 'paid', paid_at = NOW() WHERE id = ?", [purchaseId]);
      issueAndEmailTickets(purchaseId).catch(e => console.error('[Ticketería gratis]', e.message));
      return res.json({ success: true, free: true, reference, purchaseId, totalAmount, storeId: parseInt(store_id) });
    }

    res.json({ success: true, reference, purchaseId, totalAmount, storeId: parseInt(store_id), eventName: evRows[0].name });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Público: iniciar compra con Haulmer ─────────────────────────────
app.post('/api/ticketeria/purchase', async (req, res) => {
  try {
    const { store_id, event_id, buyer_name, buyer_email, buyer_phone, items } = req.body;
    if (!store_id || !event_id || !buyer_name || !buyer_email || !items?.length) {
      return res.status(400).json({ error: 'Campos requeridos: store_id, event_id, buyer_name, buyer_email, items' });
    }

    const [evRows] = await pool.execute("SELECT * FROM ticket_events WHERE id = ? AND status = 'active'", [parseInt(event_id)]);
    if (!evRows[0]) return res.status(404).json({ error: 'Evento no disponible' });
    const event = evRows[0];

    let totalAmount = 0;
    const resolvedItems = [];
    for (const item of items) {
      if (!item.category_id || !item.quantity || item.quantity < 1) continue;
      const [cats] = await pool.execute('SELECT * FROM ticket_categories WHERE id = ? AND event_id = ?', [parseInt(item.category_id), parseInt(event_id)]);
      if (!cats[0]) return res.status(400).json({ error: `Categoría ${item.category_id} no válida` });
      const cat = cats[0];
      const qty = parseInt(item.quantity);
      resolvedItems.push({ category_id: cat.id, category_name: cat.name, quantity: qty, unit_price: cat.price, subtotal: cat.price * qty });
      totalAmount += cat.price * qty;
    }
    if (!resolvedItems.length) return res.status(400).json({ error: 'Ningún ítem válido' });

    const [storeRows] = await pool.execute('SELECT user_id, code FROM stores WHERE id = ?', [parseInt(store_id)]);
    if (!storeRows[0]) return res.status(404).json({ error: 'Tienda no encontrada' });

    const [purchaseResult] = await pool.execute(
      'INSERT INTO ticket_purchases (store_id, event_id, buyer_name, buyer_email, buyer_phone, total_amount) VALUES (?,?,?,?,?,?)',
      [parseInt(store_id), parseInt(event_id), buyer_name, buyer_email, buyer_phone || null, totalAmount]
    );
    const purchaseId = purchaseResult.insertId;

    for (const item of resolvedItems) {
      await pool.execute(
        'INSERT INTO ticket_purchase_items (purchase_id, category_id, category_name, quantity, unit_price, subtotal) VALUES (?,?,?,?,?,?)',
        [purchaseId, item.category_id, item.category_name, item.quantity, item.unit_price, item.subtotal]
      );
    }

    const reference = `TKT-${purchaseId}-${Date.now()}`;
    await pool.execute('UPDATE ticket_purchases SET haulmer_reference = ? WHERE id = ?', [reference, purchaseId]);

    // Entradas gratis: sin pasarela de pago
    if (totalAmount === 0) {
      await pool.execute("UPDATE ticket_purchases SET status = 'paid', paid_at = NOW() WHERE id = ?", [purchaseId]);
      issueAndEmailTickets(purchaseId).catch(e => console.error('[Ticketería gratis]', e.message));
      const storeCode = storeRows[0].code;
      return res.json({ success: true, free: true, reference, purchaseId, redirectUrl: `/tickets/${storeCode}?ref=${reference}` });
    }

    // Solo se necesita Haulmer si hay cobro
    let [cfgRows] = await pool.execute('SELECT * FROM haulmer_native_config WHERE store_id = ? LIMIT 1', [parseInt(store_id)]);
    if (!cfgRows[0]) [cfgRows] = await pool.execute('SELECT * FROM haulmer_native_config WHERE user_id = ? AND store_id IS NULL LIMIT 1', [storeRows[0].user_id]);
    const config = cfgRows[0];
    if (!config?.account_id || !config?.secret_key) return res.status(400).json({ error: 'Pasarela Haulmer no configurada para esta tienda' });

    const serverUrl = BASE_URL;
    const storeCode = storeRows[0].code;
    const nameParts = buyer_name.split(' ');
    const payload = {
      x_account_id: config.account_id,
      x_amount: Math.round(totalAmount),
      x_currency: 'CLP',
      x_customer_email: buyer_email,
      x_customer_first_name: nameParts[0],
      x_customer_last_name: nameParts.slice(1).join(' ') || 'Comprador',
      x_customer_phone: buyer_phone || '+56900000000',
      x_description: `Entradas: ${event.name}`,
      x_reference: reference,
      x_shop_name: config.commerce_name || 'SRServi',
      x_url_callback: `${serverUrl}/api/haulmer/webhook`,
      x_url_cancel: `${serverUrl}/tickets/${storeCode}?cancelled=1`,
      x_url_complete: `${serverUrl}/tickets/${storeCode}?ref=${reference}`
    };
    payload.x_signature = haulmerSignGlobal(payload, config.secret_key);

    const hRes = await fetch(HAULMER_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-REDIRECT': 'false' },
      body: JSON.stringify(payload)
    });
    if (!hRes.ok) throw new Error(`Haulmer ${hRes.status}: ${await hRes.text()}`);

    const raw = await hRes.text();
    let paymentUrl = null;
    try { const d = JSON.parse(raw); paymentUrl = d.url || d.redirectUrl || d.x_redirect_url || d.processUrl || d.payment_url; } catch {}
    if (!paymentUrl && raw.startsWith('http')) paymentUrl = raw.trim();
    if (!paymentUrl) throw new Error('No se obtuvo URL de pago de Haulmer');

    await pool.execute(
      'INSERT INTO haulmer_native_transactions (store_id, order_id, reference, amount, status) VALUES (?, NULL, ?, ?, ?)',
      [parseInt(store_id), reference, Math.round(totalAmount), 'pending']
    );

    res.json({ success: true, paymentUrl, reference, purchaseId });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Público: estado de compra ────────────────────────────────────────
app.get('/api/ticketeria/purchase/:reference/status', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT tp.*, te.name AS event_name FROM ticket_purchases tp JOIN ticket_events te ON te.id = tp.event_id WHERE tp.haulmer_reference = ?',
      [req.params.reference]
    );
    if (!rows[0]) return res.status(404).json({ error: 'No encontrado' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Público: ver compra por viewer_code ─────────────────────────────
app.get('/api/ticketeria/public/ticket/:code', async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const [pRows] = await pool.execute(`
      SELECT tp.*, te.name AS event_name, te.event_date, te.time_start, te.time_end, te.location, te.image_url AS event_image
      FROM ticket_purchases tp
      JOIN ticket_events te ON te.id = tp.event_id
      WHERE tp.viewer_code = ?`, [code]);
    if (!pRows[0]) return res.status(404).json({ error: 'Entrada no encontrada' });
    const purchase = pRows[0];
    const [items] = await pool.execute('SELECT * FROM ticket_purchase_items WHERE purchase_id = ? ORDER BY id', [purchase.id]);
    res.json({ ...purchase, items });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Admin: admitir compra completa por viewer_code ──────────────────
app.post('/api/ticketeria/admit/:code', authenticateToken, async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const [pRows] = await pool.execute(`
      SELECT tp.* FROM ticket_purchases tp
      JOIN ticket_events te ON te.id = tp.event_id
      JOIN stores s ON s.id = tp.store_id
      WHERE tp.viewer_code = ? AND s.user_id = ?`, [code, req.user.id]);
    if (!pRows[0]) return res.status(404).json({ error: 'Entrada no encontrada o sin permiso' });
    const purchase = pRows[0];
    if (purchase.admitted) return res.status(409).json({ error: 'Ya fue admitida', purchase });
    await pool.execute('UPDATE ticket_purchases SET admitted = 1, admitted_at = NOW() WHERE id = ?', [purchase.id]);
    await pool.execute("UPDATE ticket_issued SET status = 'used', used_at = NOW() WHERE purchase_id = ?", [purchase.id]);
    res.json({ success: true, purchase: { ...purchase, admitted: 1 } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Confirmar ticket desde redirect de Haulmer ───────────────────────
app.post('/api/ticketeria/purchase/:reference/confirm', async (req, res) => {
  try {
    const reference = req.params.reference;
    if (!reference.startsWith('TKT-')) return res.status(400).json({ error: 'Referencia inválida' });
    const [purchases] = await pool.execute("SELECT * FROM ticket_purchases WHERE haulmer_reference = ? AND status = 'pending'", [reference]);
    if (purchases[0]) {
      await pool.execute("UPDATE ticket_purchases SET status = 'paid', paid_at = NOW() WHERE haulmer_reference = ?", [reference]);
      issueAndEmailTickets(purchases[0].id).catch(e => console.error('[Ticketería]', e.message));
    }
    const [rows] = await pool.execute('SELECT tp.*, te.name AS event_name FROM ticket_purchases tp JOIN ticket_events te ON te.id = tp.event_id WHERE tp.haulmer_reference = ?', [reference]);
    if (!rows[0]) return res.status(404).json({ error: 'No encontrado' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Loyalty System ──────────────────────────────────────────────────────────

// Public: get loyalty config + customers for checkout (by store code)
app.get('/api/public/:code/loyalty', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const [config, customers] = await Promise.all([
      getLoyaltyConfig(store.id),
      getLoyalCustomers(store.id)
    ]);
    res.json({ config, customers });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Public: register new loyal customer
app.post('/api/public/:code/loyalty/register', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    const { name, phone, face_descriptor, face_photo } = req.body;
    if (!name || !face_descriptor) return res.status(400).json({ error: 'name y face_descriptor son requeridos' });
    const id = await createLoyalCustomer(store.id, name, phone, face_descriptor, face_photo);
    res.json({ id, name, phone: phone || null, purchase_count: 0 });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Public: record a purchase for a loyal customer
app.post('/api/public/:code/loyalty/purchase/:customerId', async (req, res) => {
  try {
    const store = await getStoreByCode(req.params.code);
    if (!store) return res.status(404).json({ error: 'Tienda no encontrada' });
    await incrementLoyalCustomerPurchases(parseInt(req.params.customerId));
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: get loyalty config
app.get('/api/loyalty/config', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const config = await getLoyaltyConfig(storeId);
    res.json(config);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: save loyalty config
app.put('/api/loyalty/config', authenticateToken, async (req, res) => {
  try {
    const { store_id, enabled, discount_percentage, required_purchases } = req.body;
    if (!store_id) return res.status(400).json({ error: 'store_id requerido' });
    await saveLoyaltyConfig(store_id, enabled, discount_percentage, required_purchases);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: list loyal customers
app.get('/api/loyalty/customers', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.query.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    const customers = await getLoyalCustomers(storeId);
    res.json(customers);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: delete loyal customer
app.delete('/api/loyalty/customers/:id', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.body.store_id);
    if (!storeId) return res.status(400).json({ error: 'store_id requerido' });
    await deleteLoyalCustomer(parseInt(req.params.id), storeId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── RTSP People Counter ─────────────────────────────────────────────────────

function getRTSP() { return app._rtspCounterService || null; }

// GET config RTSP
app.get('/api/stores/:id/people-counter/rtsp', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    const config = await getPeopleCounterRTSP(storeId);
    const status = getRTSP()?.getStatus(storeId) || { running: false };
    res.json({ ...config, ...status });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST guardar + iniciar/detener stream RTSP
app.post('/api/stores/:id/people-counter/rtsp', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });

    const { rtsp_url, rtsp_enabled, rtsp_sensitivity } = req.body;
    await savePeopleCounterRTSP(storeId, rtsp_url, rtsp_enabled, rtsp_sensitivity);

    const svc = getRTSP();
    if (svc) {
      if (rtsp_enabled && rtsp_url) {
        // Obtener línea actual de config
        const counterConfig = await import('./database.js').then(m => m.getPeopleCounterConfig(storeId));
        await svc.startStore(storeId, rtsp_url, counterConfig?.line || null, counterConfig?.flip || false, rtsp_sensitivity || 30);
      } else {
        svc.stopStore(storeId);
      }
    }
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET status del stream
app.get('/api/stores/:id/people-counter/rtsp/status', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, req.user.id]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });
    res.json(getRTSP()?.getStatus(storeId) || { running: false });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Snapshots en memoria subidos por el agente local
const localSnapshots = new Map(); // storeId → Buffer JPEG
const localAgentPing = new Map(); // storeId → timestamp último ping
const localMjpegClients = new Map(); // storeId → Set(sendFn) — clientes viendo la vista previa
const snapOwnerCache = new Map(); // 'userId:storeId' → expiración (evita 1 query SQL por frame)

async function checkSnapOwner(userId, storeId) {
  const key = `${userId}:${storeId}`;
  const exp = snapOwnerCache.get(key);
  if (exp && exp > Date.now()) return true;
  const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, userId]);
  if (!owned[0]) return false;
  snapOwnerCache.set(key, Date.now() + 60000);
  return true;
}

// POST: agente local sube snapshot JPEG
app.post('/api/stores/:id/people-counter/snapshot-upload', authenticateToken, async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    if (!await checkSnapOwner(req.user.id, storeId)) return res.status(403).json({ error: 'Sin permiso' });
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      const buf = Buffer.concat(chunks);
      localSnapshots.set(storeId, buf);
      localAgentPing.set(storeId, Date.now());
      // Reenviar el frame en vivo a los clientes MJPEG conectados (vista previa)
      const clients = localMjpegClients.get(storeId);
      if (clients) for (const send of clients) { try { send(buf); } catch {} }
      res.json({ ok: true });
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET: estado del agente local
app.get('/api/stores/:id/people-counter/agent-status', authenticateToken, async (req, res) => {
  const storeId = parseInt(req.params.id);
  const lastPing = localAgentPing.get(storeId);
  const active = lastPing && (Date.now() - lastPing) < 15000; // activo si ping < 15s
  res.json({ active: !!active, hasSnapshot: localSnapshots.has(storeId), lastPing: lastPing || null });
});

// GET stream MJPEG — pipe:3 directo de FFmpeg sin pasar por disco
app.get('/api/stores/:id/people-counter/mjpeg', async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const rawToken = req.headers.authorization?.replace('Bearer ', '') || req.query.token;
    if (!rawToken) return res.status(401).send('Sin token');
    let userId;
    try { userId = jwt.verify(rawToken, process.env.JWT_SECRET || 'srservi_secret_key_2024').id; } catch { return res.status(401).send('Token inválido'); }
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, userId]);
    if (!owned[0]) return res.status(403).send('Sin permiso');

    res.setHeader('Content-Type', 'multipart/x-mixed-replace; boundary=mjpegframe');
    res.setHeader('Cache-Control', 'no-cache, no-store');
    res.setHeader('Connection', 'close');
    res.flushHeaders();

    // Enviar el último snapshot inmediatamente si ya hay uno
    const firstSnap = getRTSP()?.getSnapshot(storeId) || localSnapshots.get(storeId);
    if (firstSnap) {
      res.write('--mjpegframe\r\nContent-Type: image/jpeg\r\n\r\n');
      res.write(firstSnap);
      res.write('\r\n');
    }

    // Recibir frames directamente desde pipe:3 de FFmpeg.
    // Backpressure: si el viewer no consume a tiempo (>512KB en cola) se salta
    // el frame en vez de acumular retraso — el video se mantiene en tiempo real.
    const sendFrame = (jpeg) => {
      if (res.destroyed || res.writableLength > 512 * 1024) return;
      res.write('--mjpegframe\r\nContent-Type: image/jpeg\r\n\r\n');
      res.write(jpeg);
      res.write('\r\n');
    };

    getRTSP()?.addMjpegClient(storeId, sendFrame);

    // También recibir frames del agente local (AforoBridge) en vivo
    let lset = localMjpegClients.get(storeId);
    if (!lset) { lset = new Set(); localMjpegClients.set(storeId, lset); }
    lset.add(sendFrame);

    req.on('close', () => {
      getRTSP()?.removeMjpegClient(storeId, sendFrame);
      localMjpegClients.get(storeId)?.delete(sendFrame);
    });
  } catch (e) { res.status(500).send(e.message); }
});

// GET snapshot JPEG — acepta token en header o query param
app.get('/api/stores/:id/people-counter/snapshot', async (req, res) => {
  try {
    const storeId = parseInt(req.params.id);
    const rawToken = req.headers.authorization?.replace('Bearer ', '') || req.query.token;
    if (!rawToken) return res.status(401).send('Sin token');
    let userId;
    try { userId = jwt.verify(rawToken, process.env.JWT_SECRET || 'srservi_secret_key_2024').id; } catch { return res.status(401).send('Token inválido'); }
    const [owned] = await pool.execute('SELECT id FROM stores WHERE id = ? AND user_id = ?', [storeId, userId]);
    if (!owned[0]) return res.status(403).json({ error: 'Sin permiso' });

    // Preferir snapshot del agente local; fallback al servidor remoto
    const snap = localSnapshots.get(storeId) || getRTSP()?.getSnapshot(storeId);
    if (!snap) return res.status(404).send('Sin imagen');
    res.setHeader('Content-Type', 'image/jpeg');
    res.setHeader('Cache-Control', 'no-store');
    res.send(snap);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET: descargar el agente local como archivo
import { readFileSync as fsReadFileSync } from 'fs';
import { join as fsJoin, dirname as fsDirname } from 'path';
import { fileURLToPath as fsFileURLToPath } from 'url';
const __serverDir2 = fsDirname(fsFileURLToPath(import.meta.url));

app.get('/api/people-counter/download-agent', authenticateToken, (req, res) => {
  try {
    const agentPath = fsJoin(__serverDir2, 'local-rtsp-agent.js');
    const content = fsReadFileSync(agentPath, 'utf8');
    res.setHeader('Content-Type', 'application/javascript');
    res.setHeader('Content-Disposition', 'attachment; filename="srservi-agente-local.js"');
    res.send(content);
  } catch (e) { res.status(500).json({ error: 'Agente no encontrado' }); }
});

startServer();